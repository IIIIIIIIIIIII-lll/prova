# API NetVisor

## Convenzione risposta

Successo:

```json
{
  "success": true,
  "data": {}
}
```

Errore:

```json
{
  "success": false,
  "error": "messaggio"
}
```

## Auth

### Login

`POST /api/auth/login`

```json
{
  "username": "admin",
  "password": "ChangeThis_AdminPassword123!"
}
```

Risposta:

```json
{
  "success": true,
  "data": {
    "access_token": "....",
    "refresh_token": "....",
    "admin_login_alert": true,
    "admin_login_message": "Accesso admin registrato",
    "user": {
      "id": 1,
      "username": "admin",
      "role": "admin",
      "must_change_password": true
    }
  }
}
```

### Logout

`POST /api/auth/logout`

### Refresh

`POST /api/auth/refresh`

```json
{
  "refresh_token": "session.randomtoken"
}
```

### Profilo corrente

`GET /api/auth/me`

### Cambio password

`POST /api/auth/change-password`

```json
{
  "current_password": "OldPassw0rd!",
  "new_password": "NewPassw0rd!More"
}
```

### Audit auth admin-only

- `GET /api/auth/audit`
- `GET /api/admin/audit-log`

## Header

API applicative protette:

```http
Authorization: Bearer <access_token>
```

Agent ingest:

```http
X-Agent-Key: <agent-key>
```

## Users admin-only

- `GET /api/users`
- `POST /api/users`
- `GET /api/users/{id}`
- `PATCH /api/users/{id}`
- `DELETE /api/users/{id}`
- `POST /api/users/{id}/reset-password`
- `POST /api/users/{id}/disable`
- `POST /api/users/{id}/enable`

## Read model admin/user

- `GET /api/health`
- `GET /api/dashboard/summary`
- `GET /api/dashboard/operations`
- `GET /api/nodes`
- `GET /api/nodes/{id}`
- `GET /api/nodes/{id}/services`
- `GET /api/nodes/{id}/alerts`
- `GET /api/nodes/{id}/logins`
- `GET /api/alerts`
- `GET /api/scans`
- `GET /api/scans/{id}`
- `GET /api/scans/{id}/events`
- `GET /api/scans/{id}/raw`
- `GET /api/topology`
- `GET /api/agents`
- `GET /api/agents/{agent_id}`
- `GET /api/agents/{agent_id}/metrics`
- `GET /api/agents/{agent_id}/services`
- `GET /api/agents/{agent_id}/events`
- `GET /api/security/logins/summary`
- `GET /api/connections/overview`

## Admin Operations Console endpoints

### Manual scan admin-only

- `POST /api/admin/scans/manual`
- alias compatibile: `POST /api/scans/manual`

Esempio:

```json
{
  "scanner": "nmap",
  "target": "192.168.50.20",
  "ports": "22,80,443,445",
  "protocol": "tcp",
  "mode": "safe"
}
```

### Scan jobs admin-only

- `GET /api/admin/scan-jobs`
- `POST /api/admin/scan-jobs`
- `GET /api/admin/scan-jobs/{id}`
- `PATCH /api/admin/scan-jobs/{id}`
- `DELETE /api/admin/scan-jobs/{id}`
- `POST /api/admin/scan-jobs/{id}/run`
- `GET /api/admin/scan-jobs/{id}/runs`

Esempio:

```json
{
  "name": "Lab Windows Server Ports",
  "scanner": "masscan",
  "target": "192.168.50.0/24",
  "ports": "80,443,445",
  "protocol": "tcp",
  "mode": "scheduled",
  "interval_seconds": 60,
  "enabled": true,
  "permanent": true
}
```

### Manual health check admin-only

- `POST /api/admin/health-checks/manual`

### Health checks admin-only

- `GET /api/admin/health-checks`
- `POST /api/admin/health-checks`
- `GET /api/admin/health-checks/{id}`
- `PATCH /api/admin/health-checks/{id}`
- `DELETE /api/admin/health-checks/{id}`
- `POST /api/admin/health-checks/{id}/run`
- `GET /api/admin/health-checks/{id}/results`

Esempio:

```json
{
  "name": "RDP Windows Server",
  "target": "192.168.50.20",
  "check_type": "tcp",
  "port": 3389,
  "service_label": "RDP",
  "interval_seconds": 60,
  "timeout_seconds": 5,
  "enabled": true,
  "permanent": true
}
```

## Alerts

- `PATCH /api/alerts/{id}/ack` admin-only
- `PATCH /api/alerts/{id}/close` admin-only

## Agents

Ingest agent protetto da `X-Agent-Key`:

- `POST /api/agents/register`
- `POST /api/agents/heartbeat`
- `POST /api/agents/metrics`
- `POST /api/agents/services`
- `POST /api/agents/events`

Esempio register:

```json
{
  "agent_id": "winserver-01",
  "hostname": "lab-winserver",
  "ip_address": "192.168.50.20",
  "os_name": "Windows Server 2022",
  "agent_version": "1.0.0"
}
```
