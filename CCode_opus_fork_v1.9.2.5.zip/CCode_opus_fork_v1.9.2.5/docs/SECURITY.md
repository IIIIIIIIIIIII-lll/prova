# Sicurezza NetVisor

## Ambito consentito

NetVisor e pensato solo per reti di laboratorio autorizzate. Non deve essere usato su Internet o verso terzi.

## Identity e auth

- utenti reali in tabella `Users`
- ruoli minimi `admin` e `user`
- login backend solo via `POST /api/auth/login`
- access token breve firmato server-side
- refresh token opaco casuale con hash salvato in `AuthSessions`
- refresh token ruotato a ogni uso
- logout con revoca sessione

## Password storage

- password mai salvate in chiaro
- algoritmo primario: Argon2id
- fallback: bcrypt
- salt per password gestito dalla libreria
- hash comprensivo di algoritmo, parametri e salt
- `AUTH_PEPPER` opzionale lato server, mai salvato nel database
- nessun hashing manuale con MD5/SHA1/SHA256

## Bootstrap admin

Se `Users` e vuota:

- il backend crea un admin iniziale da `ADMIN_USERNAME` e `ADMIN_PASSWORD`
- salva solo `password_hash`
- imposta `must_change_password=true`
- registra audit `user_created`

Se la tabella contiene utenti:

- il bootstrap non ricrea admin
- non sovrascrive password esistenti

## Hardening login

- rate limit login per IP e username
- lockout progressivo con `failed_login_count` e `locked_until`
- errori generici: `Credenziali non valide`
- policy password minima:
  - almeno 12 caratteri
  - almeno una maiuscola
  - almeno una minuscola
  - almeno un numero
  - almeno un simbolo
  - blocco password deboli come `password`, `admin`, `changeme`

## Audit e alert

`AuthAuditLog` registra almeno:

- `login_success`
- `login_failed`
- `logout`
- `refresh_success`
- `refresh_failed`
- `admin_login`
- `account_locked`
- `password_changed`
- `user_created`
- `user_disabled`

Quando un admin effettua login riuscito:

- viene scritto `admin_login` in `AuthAuditLog`
- viene creato un alert applicativo `admin_login`
- il frontend mostra un popup immediato
- la risposta mobile include `admin_login_alert=true`

## RBAC

- `admin`: operazioni mutative, utenti, settings operativi, scan jobs, health checks, query admin
- `user`: sola lettura su dashboard, topology, agents, alerts, logs, reports

La protezione reale e lato backend tramite decorator `@login_required` e `@role_required(...)`.

## Protezioni rete e scanning

- allowlist target tramite `SCAN_ALLOWED_CIDRS`
- blocco reti pubbliche con `ALLOW_PUBLIC_SCAN=false`
- controllo subnet troppo ampie con `MAX_SCAN_PREFIX_IPV4`
- rate limit Masscan con `MASSCAN_MAX_RATE`
- timeout per subprocess
- nessun `shell=True`
- nessuna opzione stealth/evasive
- nessun comando arbitrario passato dal client

## Frontend web

Nella demo web:

- access token e refresh token sono salvati in `sessionStorage`
- i token non vanno in `localStorage`
- il pannello API e un popover, non persistente in pagina

Limite noto: per una produzione reale e preferibile cookie HttpOnly via HTTPS o BFF pattern.

## Mobile MAUI

- il mobile non accede mai al database
- i token vengono salvati in `SecureStorage`
- le API usano `Authorization: Bearer <token>`
- logout e refresh sono gestiti dal client MAUI

## HTTPS e accesso esterno

Per accesso da rete esterna o 4G/5G:

- non esporre direttamente il Flask dev server
- usare reverse proxy HTTPS
- oppure usare VPN verso la LAN di laboratorio
- impostare `CORS_ORIGINS` con domini autorizzati reali
- non usare `CORS=*` con auth attiva

## Hardening applicativo e container

- security headers su backend e frontend
- payload limit applicativo
- rate limit generale API
- validazione input centralizzata
- container read-only dove possibile
- `no-new-privileges`
- `cap_drop: ALL`
- riaggiunta minima di capability necessarie al laboratorio
- bind locale delle porte sensibili

## Agent security

Gli agent didattici:

- inviano solo register, heartbeat, metriche, servizi e event summary
- non ricevono comandi remoti
- non fanno sniffing, exploit o persistenza nascosta
- usano `X-Agent-Key` dedicata lato backend
