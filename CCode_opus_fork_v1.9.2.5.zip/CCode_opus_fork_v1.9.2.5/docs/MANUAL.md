# Manuale prova NetVisor

## 1. Preparazione

1. Copia `.env.example` in `.env`
2. Imposta:
   - `MSSQL_SA_PASSWORD`
   - `ADMIN_USERNAME`
   - `ADMIN_PASSWORD`
   - `AUTH_PEPPER`
   - `JWT_SECRET_KEY`
3. Lascia per il primo test:
   - `ENABLE_REAL_SCAN=false`
   - `ALLOW_PUBLIC_SCAN=false`
   - `REQUIRE_AUTH=true`

## 2. Avvio

```bash
docker compose up -d --build
```

Verifica:

- [http://localhost:8080/login.html](http://localhost:8080/login.html)
- [http://localhost:5000/api/health](http://localhost:5000/api/health)

Nota: `localhost:1433` e solo la porta TCP di SQL Server.

## 3. Primo admin

Se `Users` e vuota, il backend crea l'admin iniziale da:

- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`

L'utente viene creato con `must_change_password=true`.

## 4. Login web

1. Apri [http://localhost:8080/login.html](http://localhost:8080/login.html)
2. Inserisci username e password
3. Dopo login admin riuscito:
   - compare popup `Accesso amministratore rilevato`
   - viene generato un alert applicativo
   - viene scritto audit `admin_login`

Se il backend richiede il cambio password, entra in [settings.html](http://localhost:8080/settings.html) e aggiorna subito la password.

## 5. Creazione user da admin

1. Accedi come admin
2. Apri [users.html](http://localhost:8080/users.html)
3. Compila `Create user`
4. Scegli ruolo:
   - `admin`
   - `user`
5. Salva

Da questa pagina puoi anche:

- aggiornare ruolo e display name
- disabilitare utente
- riabilitare utente
- resettare password
- eliminare utente

## 6. Admin Operations Console

Apri [admin-console.html](http://localhost:8080/admin-console.html). Solo gli admin la vedono.

Tab disponibili:

- `Manual Scan`
- `Scheduled Scan Jobs`
- `Connection Checks`
- `Run History`
- `Audit`

### Manual scan

Usa form guidato con:

- `scanner`
- `target`
- `ports`
- `protocol`
- `mode`

Il backend valida:

- subnet allowlist
- target privati
- porte e range
- scanner ammessi

### Scheduled scan jobs

Salva job permanenti con:

- `name`
- `scanner`
- `target`
- `ports`
- `interval_seconds`
- `enabled`
- `permanent`

Il worker `scan-worker` esegue i job con `next_run_at` scaduto.

### Connection checks

Salva monitor permanenti ICMP/TCP/HTTP/HTTPS.

### Audit

Mostra:

- auth audit
- audit operativo admin

## 7. Test curl

### Login

```bash
curl -X POST http://localhost:5000/api/auth/login ^
  -H "Content-Type: application/json" ^
  -d "{\"username\":\"admin\",\"password\":\"ChangeThis_AdminPassword123!\"}"
```

### Me

```bash
curl http://localhost:5000/api/auth/me ^
  -H "Authorization: Bearer <ACCESS_TOKEN>"
```

### Cambio password

```bash
curl -X POST http://localhost:5000/api/auth/change-password ^
  -H "Authorization: Bearer <ACCESS_TOKEN>" ^
  -H "Content-Type: application/json" ^
  -d "{\"current_password\":\"OldPassw0rd!\",\"new_password\":\"NewPassw0rd!More\"}"
```

### Creazione user

```bash
curl -X POST http://localhost:5000/api/users ^
  -H "Authorization: Bearer <ACCESS_TOKEN_ADMIN>" ^
  -H "Content-Type: application/json" ^
  -d "{\"username\":\"analyst1\",\"role\":\"user\",\"password\":\"AnalystPassw0rd!\",\"must_change_password\":true}"
```

### Manual scan admin

```bash
curl -X POST http://localhost:5000/api/admin/scans/manual ^
  -H "Authorization: Bearer <ACCESS_TOKEN_ADMIN>" ^
  -H "Content-Type: application/json" ^
  -d "{\"scanner\":\"nmap\",\"target\":\"192.168.50.20\",\"ports\":\"22,80,445\",\"protocol\":\"tcp\",\"mode\":\"safe\"}"
```

### Scheduled job admin

```bash
curl -X POST http://localhost:5000/api/admin/scan-jobs ^
  -H "Authorization: Bearer <ACCESS_TOKEN_ADMIN>" ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Lab job\",\"scanner\":\"masscan\",\"target\":\"192.168.50.0/24\",\"ports\":\"80,443,445\",\"protocol\":\"tcp\",\"mode\":\"scheduled\",\"interval_seconds\":60,\"enabled\":true,\"permanent\":true}"
```

### Health check admin

```bash
curl -X POST http://localhost:5000/api/admin/health-checks ^
  -H "Authorization: Bearer <ACCESS_TOKEN_ADMIN>" ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"RDP check\",\"target\":\"192.168.50.20\",\"check_type\":\"tcp\",\"port\":3389,\"service_label\":\"RDP\",\"interval_seconds\":60,\"timeout_seconds\":5,\"enabled\":true,\"permanent\":true}"
```

## 8. Test ruolo user

1. Crea un utente `user`
2. Fai login web con quell'utente
3. Verifica:
   - dashboard visibile
   - agents visibile
   - alerts visibile in lettura
   - `Admin Operations Console` non visibile
   - `Users` non visibile
   - chiamate admin-only rispondono `403`

## 9. Test popup admin

1. Fai login con un account ruolo `admin`
2. Verifica:
   - popup admin immediato
   - alert `admin_login` nella pagina Alerts
   - record `admin_login` in `AuthAuditLog`

## 10. Mobile MAUI

Apri `mobile/NetVisorMaui/NetVisorMaui.csproj` in Visual Studio.

Flusso:

1. `LoginPage`
2. `AuthService`
3. token salvati in `SecureStorage`
4. chiamate API con Bearer token
5. logout da toolbar

Per Android emulator usa tipicamente:

- `http://10.0.2.2:5000`

Per Windows locale:

- `http://localhost:5000`

## 11. Troubleshooting

- `Credenziali non valide`: verifica username/password, oppure account bloccato temporaneamente
- `Sessione non valida o scaduta`: rifai login o verifica `JWT_SECRET_KEY`
- `403` su pagina admin: stai usando un account `user`
- nessun job eseguito: controlla `enabled=true`, `permanent=true`, `interval_seconds>=60`
- target bloccato: verifica `SCAN_ALLOWED_CIDRS` e `ALLOW_PUBLIC_SCAN=false`
