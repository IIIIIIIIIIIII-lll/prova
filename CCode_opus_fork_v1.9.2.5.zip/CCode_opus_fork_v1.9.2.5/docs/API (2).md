# API NetVisor

## Autenticazione

Gli endpoint di lettura `GET` sono pubblici.

Gli endpoint di modifica `POST` e `PATCH` richiedono login admin.

Login:

- `POST /api/admin/login`

Risposta:

```json
{
  "success": true,
  "data": {
    "token": "....",
    "token_type": "Bearer",
    "expires_in_minutes": 480,
    "username": "admin"
  }
}
```

Header richiesto per operazioni admin:

```http
Authorization: Bearer <token>
```

## Convenzione risposta

Successo:

```json
{
  "success": true,
  "data": {}
}
```

Errore:

```json
{
  "success": false,
  "error": "messaggio"
}
```

## Endpoint

### Health

- `GET /api/health`

### Dashboard

- `GET /api/dashboard/summary`

### Nodes

- `GET /api/nodes`
- `GET /api/nodes/{id}`
- `GET /api/nodes/{id}/services`
- `GET /api/nodes/{id}/alerts`
- `GET /api/nodes/{id}/logins`

### Alerts

- `GET /api/alerts`
- `PATCH /api/alerts/{id}/ack`
- `PATCH /api/alerts/{id}/close`

### Scans

- `POST /api/scan`
- `GET /api/scans`
- `GET /api/scans/{id}`
- `GET /api/scans/{id}/events`
- `GET /api/scans/{id}/raw`

Esempio richiesta scansione:

```json
{
  "scanner": "nmap",
  "target": "192.168.1.0/24",
  "ports": "22,80,443",
  "mode": "safe"
}
```

### Connectivity

- `POST /api/ping`
- `POST /api/http-test`

Esempio ping:

```json
{
  "target": "192.168.1.10"
}
```

### Topology

- `GET /api/topology`

### Ingestion

- `POST /api/ingest/nmap`
- `POST /api/ingest/masscan`
- `POST /api/ingest/generic`

Esempio ingest generic:

```json
{
  "source": "custom-agent",
  "format": "json",
  "events": [
    {
      "event_type": "custom.notice",
      "severity": "info",
      "message": "Evento custom"
    }
  ]
}
```
