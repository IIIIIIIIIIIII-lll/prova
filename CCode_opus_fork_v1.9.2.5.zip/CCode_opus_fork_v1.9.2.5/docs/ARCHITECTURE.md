# Architettura NetVisor

## Livelli

1. Frontend Web Vanilla JS
   - Dashboard NOC
   - Liste nodi, alert, scansioni e topologia
   - Consumo API con `fetch`
2. Backend Flask
   - API REST JSON
   - Autenticazione Bearer + refresh token
   - RBAC admin/user
   - Validazione input
   - Parsing risultati scanner
   - Alert engine e logging
3. SQL Server
   - Persistenza per nodi, servizi, scan, log raw, eventi e audit
4. Scanner / Collector
   - Nmap e Masscan solo su CIDR autorizzati
   - Output raw + parsing
5. Agent didattici
   - Registrazione endpoint autorizzati
   - Heartbeat, metriche host, servizi osservati, event summary
   - Comunicazione solo outbound verso Flask API
6. Mobile MAUI
   - Login, home, nodi, alert, dettaglio nodo e test connettivita

## Identity layer

- `Users`: account applicativi con ruolo, hash password, lockout e stato attivo
- `AuthSessions`: refresh token hash, device metadata e revoca sessione
- `AuthAuditLog`: audit login/logout/refresh/password/user actions
- `password_service.py`: Argon2id primaria, bcrypt fallback, pepper opzionale
- `auth_service.py`: bootstrap admin, login, refresh, logout, cambio password, CRUD utenti admin
- `utils/security.py`: access token firmato, middleware auth, `@login_required`, `@role_required`

## Flusso dati

`scanner -> Flask ingest -> RawLogs -> parser -> Nodes/Services -> AlertEngine -> Dashboard/Mobile`

`agent -> Flask API -> Agents/AgentMetrics/AgentServices/AgentEvents -> AlertEngine -> Dashboard/Agents`

`browser/mobile -> /api/auth/login -> Users/AuthSessions/AuthAuditLog -> RBAC -> dashboard/admin console`

## Componenti principali

- `scanner_service.py`: validazione target, timeout, demo mode, esecuzione comandi sicuri
- `ingest_service.py`: persistenza raw log, normalizzazione dati e aggiornamento inventario
- `alert_engine.py`: regole minime di sicurezza ed eventi
- `agent_service.py`: register, heartbeat, metriche, servizi, eventi e regole di presenza agent
- `auth_service.py`: login, session rotation, audit e admin alert
- `repositories.py`: accesso SQL Server
- `scan_worker.py`: esecuzione periodica dei job di scansione dichiarativi
- `frontend/js/*.js`: rendering pagine SIEM-style, polling GET e drill-down topologia

## Modalita demo

Quando `ENABLE_REAL_SCAN=false`, il backend genera output demo realistico e aggiorna il database senza usare raw socket o privilegi elevati.

## Vista UI

La UI e organizzata come console SIEM enterprise:

- shell globale con sidebar sinistra, topbar superiore e right rail alert/eventi
- dashboard centrale con KPI, trend, top devices, latest scan runs e agent health
- pagina topology con zone logiche, cloud/container cliccabili e vista interna read-only
- pagina agents per telemetry host e alerting agent-centric
- `Admin Operations Console` per scan manuali, scan job permanenti, connection checks, run history e audit
- pagina `Users` per lifecycle account admin-only
