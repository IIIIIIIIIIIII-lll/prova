# Database NetVisor

## Tabelle

- `Nodes`: inventario host
- `Services`: servizi e porte osservate
- `Alerts`: alert operativi e di sicurezza
- `Scans`: richieste e risultati scansione
- `Tests`: ping e HTTP check
- `Logins`: eventi di login associati ai nodi
- `RawLogs`: output raw scanner o ingest
- `SecurityEvents`: eventi normalizzati stile mini-SIEM
- `AuditLog`: traccia azioni applicative

## Relazioni

- `Services.node_id -> Nodes.id`
- `Alerts.node_id -> Nodes.id`
- `Alerts.service_id -> Services.id`
- `Tests.node_id -> Nodes.id`
- `Logins.node_id -> Nodes.id`
- `RawLogs.scan_id -> Scans.id`
- `SecurityEvents.node_id -> Nodes.id`
- `SecurityEvents.service_id -> Services.id`
- `SecurityEvents.raw_log_id -> RawLogs.id`

## Campi obbligatori del diagramma

Lo schema mantiene tutte le tabelle e i campi del diagramma:

- `Scans`: `id`, `date`, `target`, `result`
- `Alerts`: `id`, `type`, `severity`, `description`, `timestamp`
- `Nodes`: `id`, `hostname`, `ip`, `status`, `last_seen`
- `Services`: `id`, `node_id`, `port`, `protocol`, `service_name`
- `Tests`: `id`, `node_id`, `type`, `latency`, `result`

In aggiunta, NetVisor mantiene i campi necessari per Mini-SIEM, scanner, audit e dashboard.

## Tabella Logins

`Logins` dipende da `Nodes` tramite `node_id`.

Campi:

- `id INT IDENTITY PRIMARY KEY`
- `node_id INT NOT NULL FK Nodes(id)`
- `username NVARCHAR(255) NOT NULL`
- `source NVARCHAR(100) NULL`
- `result NVARCHAR(30) NOT NULL`
- `timestamp DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()`
- `details NVARCHAR(MAX) NULL`

## Note operative

- `Nodes.ip` e univoco.
- `Services` usa vincolo univoco su `(node_id, port, protocol)`.
- Il bootstrap e idempotente.
