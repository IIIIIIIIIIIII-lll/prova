# Requirements NetVisor

## Requisiti software obbligatori

- Windows 10/11, Linux o macOS con Docker supportato
- Docker Desktop recente
- Docker Compose v2

## Requisiti software consigliati

- Visual Studio 2022 o successivo con workload `.NET MAUI` per provare il client mobile
- PowerShell 7 oppure Windows PowerShell per testare le API
- `sqlcmd` opzionale per inizializzazione o debug manuale di SQL Server

## Requisiti runtime del progetto

Il progetto usa questi componenti:

- Frontend: HTML, CSS, JavaScript Vanilla
- Backend: Python 3.11 in container
- API: Flask + Flask-CORS
- DB driver: ODBC Driver 18 for SQL Server
- Database: Microsoft SQL Server 2022
- Reverse/static serving frontend: Nginx Alpine
- Scanner: Nmap, Masscan, ping
- Mobile: .NET 8 MAUI

## Requisiti hardware consigliati

- CPU: 4 core consigliati
- RAM: 4 GB minimi liberi, 8 GB consigliati
- Disco: almeno 5 GB liberi per immagini Docker, volume SQL Server e build

## Porte usate

- `8080`: frontend web
- `5000`: backend Flask
- `1433`: SQL Server

## Variabili ambiente principali

Le principali variabili richieste sono:

- `MSSQL_SA_PASSWORD`
- `DB_PASSWORD`
- `DB_HOST`
- `DB_PORT`
- `DB_NAME`
- `DB_USER`
- `ENABLE_REAL_SCAN`
- `ALLOW_PUBLIC_SCAN`
- `SCAN_ALLOWED_CIDRS`
- `MASSCAN_MAX_RATE`
- `SCAN_TIMEOUT_SECONDS`
- `MAX_SCAN_PORTS`
- `CORS_ORIGINS`
- `REQUIRE_API_KEY`
- `NETVISOR_API_KEY`
- `MAX_CONTENT_LENGTH`
- `RATE_LIMIT_PER_MINUTE`
- `MAX_INGEST_EVENTS`
- `MAX_SCAN_PREFIX_IPV4`

## Requisiti sicurezza

- uso solo su rete di laboratorio autorizzata
- scansioni pubbliche disattivate di default
- target limitati da allowlist CIDR
- nessuna credenziale reale hard-coded

## Requisiti per test demo

Per il test iniziale basta:

- Docker Desktop
- file `.env`
- password SQL Server valida
- browser web

Non servono:

- privilegi raw packet
- accesso diretto al database dal frontend
- accesso diretto al database dall'app mobile

## Requisiti per test mobile MAUI

Per aprire e compilare la parte mobile servono:

- SDK .NET installato
- workload MAUI installato
- Visual Studio oppure CLI configurata
- permessi locali per NuGet e workload restore

## Requisiti backend Python

Il file backend Python usa queste dipendenze:

- `flask`
- `flask-cors`
- `pyodbc`
- `python-dotenv`
- `requests`

Vedi anche [requirements.txt](/C:/Users/Dr3w.DESKTOP-SLP4ALB/Documents/New%20project/NetVisor/backend/requirements.txt).
