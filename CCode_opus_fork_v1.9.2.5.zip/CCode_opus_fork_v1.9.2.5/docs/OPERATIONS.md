# Operazioni

Per una procedura completa di test usa anche [MANUAL.md](/C:/Users/Dr3w.DESKTOP-SLP4ALB/Documents/New%20project/NetVisor/docs/MANUAL.md).

## Avvio stack

```bash
docker compose up --build
```

## Inizializzazione DB

- Il backend esegue un bootstrap idempotente all'avvio.
- In alternativa usare manualmente:

```bash
sqlcmd -S localhost,1433 -U sa -P "<PASSWORD>" -i database/init.sql
```

## Avvio demo

- Lasciare `ENABLE_REAL_SCAN=false`.
- Aprire la dashboard e usare "Avvia scansione demo".
- Verificare `GET /api/dashboard/summary`, `GET /api/nodes` e `GET /api/alerts`.

## Avvio scansione reale

1. Impostare `ENABLE_REAL_SCAN=true`.
2. Verificare `ALLOW_PUBLIC_SCAN=false`.
3. Usare solo target compresi in `SCAN_ALLOWED_CIDRS`.
4. Lanciare `POST /api/scan`.

## Scanner opzionale

Il servizio `scanner` puo essere avviato con:

```bash
docker compose --profile scanner up --build
```
