# Stima costi

Tariffa ipotetica: 55 EUR/ora

| Area | Ore stimate | Costo |
|---|---:|---:|
| Frontend Vanilla | 16 | 880 EUR |
| Backend Flask | 28 | 1540 EUR |
| Database SQL Server | 8 | 440 EUR |
| Docker / Compose | 6 | 330 EUR |
| Mobile MAUI | 18 | 990 EUR |
| Test e collaudo | 12 | 660 EUR |
| Totale | 88 | 4840 EUR |
