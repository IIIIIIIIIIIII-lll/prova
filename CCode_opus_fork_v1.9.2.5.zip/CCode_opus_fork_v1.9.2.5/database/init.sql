IF DB_ID(N'NetVisor') IS NULL
BEGIN
    CREATE DATABASE [NetVisor];
END
GO

USE [NetVisor];
GO

IF OBJECT_ID(N'dbo.Nodes', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Nodes (
        id INT IDENTITY(1,1) PRIMARY KEY,
        hostname NVARCHAR(255) NULL,
        ip NVARCHAR(45) NOT NULL UNIQUE,
        status NVARCHAR(30) NOT NULL DEFAULT 'unknown',
        first_seen DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        last_seen DATETIME2 NULL,
        os_guess NVARCHAR(255) NULL,
        mac_address NVARCHAR(64) NULL,
        vendor NVARCHAR(255) NULL,
        risk_score INT NOT NULL DEFAULT 0
    );
END
GO

IF OBJECT_ID(N'dbo.Services', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Services (
        id INT IDENTITY(1,1) PRIMARY KEY,
        node_id INT NOT NULL,
        port INT NOT NULL,
        protocol NVARCHAR(10) NOT NULL,
        state NVARCHAR(30) NOT NULL,
        service_name NVARCHAR(120) NULL,
        product NVARCHAR(255) NULL,
        version NVARCHAR(255) NULL,
        banner NVARCHAR(MAX) NULL,
        first_seen DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        last_seen DATETIME2 NULL,
        CONSTRAINT UQ_Services_NodePortProtocol UNIQUE (node_id, port, protocol),
        CONSTRAINT FK_Services_Nodes FOREIGN KEY (node_id) REFERENCES dbo.Nodes(id)
    );
END
GO

IF OBJECT_ID(N'dbo.Alerts', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Alerts (
        id INT IDENTITY(1,1) PRIMARY KEY,
        type NVARCHAR(100) NOT NULL,
        severity NVARCHAR(20) NOT NULL,
        description NVARCHAR(MAX) NOT NULL,
        node_id INT NULL,
        service_id INT NULL,
        status NVARCHAR(30) NOT NULL DEFAULT 'open',
        timestamp DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_Alerts_Nodes FOREIGN KEY (node_id) REFERENCES dbo.Nodes(id),
        CONSTRAINT FK_Alerts_Services FOREIGN KEY (service_id) REFERENCES dbo.Services(id)
    );
END
GO

IF OBJECT_ID(N'dbo.Scans', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Scans (
        id INT IDENTITY(1,1) PRIMARY KEY,
        date DATETIME2 NULL,
        scanner NVARCHAR(50) NOT NULL,
        target NVARCHAR(255) NOT NULL,
        ports NVARCHAR(255) NULL,
        status NVARCHAR(30) NOT NULL DEFAULT 'queued',
        started_at DATETIME2 NULL,
        finished_at DATETIME2 NULL,
        result NVARCHAR(MAX) NULL,
        result_summary NVARCHAR(MAX) NULL,
        error_message NVARCHAR(MAX) NULL
    );
END
GO

IF COL_LENGTH('dbo.Scans', 'date') IS NULL
BEGIN
    ALTER TABLE dbo.Scans ADD date DATETIME2 NULL;
END
GO

IF COL_LENGTH('dbo.Scans', 'result') IS NULL
BEGIN
    ALTER TABLE dbo.Scans ADD result NVARCHAR(MAX) NULL;
END
GO

IF OBJECT_ID(N'dbo.Tests', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Tests (
        id INT IDENTITY(1,1) PRIMARY KEY,
        node_id INT NULL,
        target NVARCHAR(255) NOT NULL,
        type NVARCHAR(30) NOT NULL,
        latency FLOAT NULL,
        latency_ms INT NULL,
        result NVARCHAR(30) NOT NULL,
        checked_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        details NVARCHAR(MAX) NULL,
        CONSTRAINT FK_Tests_Nodes FOREIGN KEY (node_id) REFERENCES dbo.Nodes(id)
    );
END
GO

IF COL_LENGTH('dbo.Tests', 'latency') IS NULL
BEGIN
    ALTER TABLE dbo.Tests ADD latency FLOAT NULL;
END
GO

IF OBJECT_ID(N'dbo.RawLogs', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.RawLogs (
        id INT IDENTITY(1,1) PRIMARY KEY,
        source NVARCHAR(50) NOT NULL,
        scan_id INT NULL,
        format NVARCHAR(30) NOT NULL,
        content NVARCHAR(MAX) NOT NULL,
        received_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_RawLogs_Scans FOREIGN KEY (scan_id) REFERENCES dbo.Scans(id)
    );
END
GO

IF OBJECT_ID(N'dbo.SecurityEvents', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SecurityEvents (
        id INT IDENTITY(1,1) PRIMARY KEY,
        source NVARCHAR(50) NOT NULL,
        event_type NVARCHAR(100) NOT NULL,
        node_id INT NULL,
        service_id INT NULL,
        severity NVARCHAR(20) NOT NULL DEFAULT 'info',
        message NVARCHAR(MAX) NOT NULL,
        event_time DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        raw_log_id INT NULL,
        CONSTRAINT FK_SecurityEvents_Nodes FOREIGN KEY (node_id) REFERENCES dbo.Nodes(id),
        CONSTRAINT FK_SecurityEvents_Services FOREIGN KEY (service_id) REFERENCES dbo.Services(id),
        CONSTRAINT FK_SecurityEvents_RawLogs FOREIGN KEY (raw_log_id) REFERENCES dbo.RawLogs(id)
    );
END
GO

IF OBJECT_ID(N'dbo.AuditLog', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AuditLog (
        id INT IDENTITY(1,1) PRIMARY KEY,
        actor NVARCHAR(100) NULL,
        action NVARCHAR(100) NOT NULL,
        details NVARCHAR(MAX) NULL,
        created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
    );
END
GO

IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Users (
        id INT IDENTITY(1,1) PRIMARY KEY,
        username NVARCHAR(80) NOT NULL UNIQUE,
        email NVARCHAR(255) NULL UNIQUE,
        display_name NVARCHAR(255) NULL,
        role NVARCHAR(30) NOT NULL,
        password_hash NVARCHAR(500) NOT NULL,
        is_active BIT NOT NULL DEFAULT 1,
        must_change_password BIT NOT NULL DEFAULT 0,
        failed_login_count INT NOT NULL DEFAULT 0,
        locked_until DATETIME2 NULL,
        last_login_at DATETIME2 NULL,
        created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_at DATETIME2 NULL
    );
END
GO

IF OBJECT_ID(N'dbo.AuthSessions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AuthSessions (
        id INT IDENTITY(1,1) PRIMARY KEY,
        user_id INT NOT NULL,
        refresh_token_hash NVARCHAR(500) NOT NULL,
        user_agent NVARCHAR(500) NULL,
        ip_address NVARCHAR(80) NULL,
        created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        expires_at DATETIME2 NOT NULL,
        revoked_at DATETIME2 NULL,
        last_used_at DATETIME2 NULL,
        CONSTRAINT FK_AuthSessions_Users FOREIGN KEY (user_id) REFERENCES dbo.Users(id)
    );
END
GO

IF OBJECT_ID(N'dbo.AuthAuditLog', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AuthAuditLog (
        id INT IDENTITY(1,1) PRIMARY KEY,
        user_id INT NULL,
        username NVARCHAR(80) NULL,
        event_type NVARCHAR(80) NOT NULL,
        role NVARCHAR(30) NULL,
        ip_address NVARCHAR(80) NULL,
        user_agent NVARCHAR(500) NULL,
        success BIT NOT NULL,
        message NVARCHAR(MAX) NULL,
        created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_AuthAuditLog_Users FOREIGN KEY (user_id) REFERENCES dbo.Users(id)
    );
END
GO

IF OBJECT_ID(N'dbo.Logins', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Logins (
        id INT IDENTITY(1,1) PRIMARY KEY,
        node_id INT NOT NULL,
        username NVARCHAR(255) NOT NULL,
        source NVARCHAR(100) NULL,
        source_ip NVARCHAR(45) NULL,
        source_mac NVARCHAR(64) NULL,
        auth_channel NVARCHAR(50) NULL,
        account_type NVARCHAR(30) NULL,
        result NVARCHAR(30) NOT NULL,
        risk_score INT NOT NULL DEFAULT 0,
        timestamp DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        details NVARCHAR(MAX) NULL,
        CONSTRAINT FK_Logins_Nodes FOREIGN KEY (node_id) REFERENCES dbo.Nodes(id)
    );
END
GO

IF COL_LENGTH('dbo.Logins', 'source_ip') IS NULL
BEGIN
    ALTER TABLE dbo.Logins ADD source_ip NVARCHAR(45) NULL;
END
GO

IF COL_LENGTH('dbo.Logins', 'source_mac') IS NULL
BEGIN
    ALTER TABLE dbo.Logins ADD source_mac NVARCHAR(64) NULL;
END
GO

IF COL_LENGTH('dbo.Logins', 'auth_channel') IS NULL
BEGIN
    ALTER TABLE dbo.Logins ADD auth_channel NVARCHAR(50) NULL;
END
GO

IF COL_LENGTH('dbo.Logins', 'account_type') IS NULL
BEGIN
    ALTER TABLE dbo.Logins ADD account_type NVARCHAR(30) NULL;
END
GO

IF COL_LENGTH('dbo.Logins', 'risk_score') IS NULL
BEGIN
    ALTER TABLE dbo.Logins ADD risk_score INT NOT NULL CONSTRAINT DF_Logins_RiskScore DEFAULT 0;
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Logins_NodeTimestamp' AND object_id = OBJECT_ID(N'dbo.Logins'))
BEGIN
    CREATE INDEX IX_Logins_NodeTimestamp ON dbo.Logins(node_id, timestamp DESC);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Logins_UserTimestamp' AND object_id = OBJECT_ID(N'dbo.Logins'))
BEGIN
    CREATE INDEX IX_Logins_UserTimestamp ON dbo.Logins(username, timestamp DESC);
END
GO

IF OBJECT_ID(N'dbo.ScanJobs', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ScanJobs (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(120) NOT NULL,
        scanner NVARCHAR(30) NOT NULL,
        target NVARCHAR(255) NOT NULL,
        ports NVARCHAR(255) NOT NULL,
        protocol NVARCHAR(10) NOT NULL DEFAULT 'tcp',
        mode NVARCHAR(30) NOT NULL,
        interval_seconds INT NULL,
        enabled BIT NOT NULL DEFAULT 1,
        permanent BIT NOT NULL DEFAULT 0,
        last_status NVARCHAR(30) NULL,
        last_started_at DATETIME2 NULL,
        last_finished_at DATETIME2 NULL,
        next_run_at DATETIME2 NULL,
        last_error NVARCHAR(MAX) NULL,
        created_by_user_id INT NULL,
        created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_at DATETIME2 NULL,
        CONSTRAINT FK_ScanJobs_Users FOREIGN KEY (created_by_user_id) REFERENCES dbo.Users(id)
    );
END
GO

IF OBJECT_ID(N'dbo.ScanJobRuns', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ScanJobRuns (
        id INT IDENTITY(1,1) PRIMARY KEY,
        job_id INT NULL,
        scanner NVARCHAR(30) NOT NULL,
        target NVARCHAR(255) NOT NULL,
        ports NVARCHAR(255) NOT NULL,
        protocol NVARCHAR(10) NOT NULL DEFAULT 'tcp',
        status NVARCHAR(30) NOT NULL,
        started_at DATETIME2 NULL,
        finished_at DATETIME2 NULL,
        raw_log_id INT NULL,
        result_summary NVARCHAR(MAX) NULL,
        error_message NVARCHAR(MAX) NULL,
        CONSTRAINT FK_ScanJobRuns_ScanJobs FOREIGN KEY (job_id) REFERENCES dbo.ScanJobs(id),
        CONSTRAINT FK_ScanJobRuns_RawLogs FOREIGN KEY (raw_log_id) REFERENCES dbo.RawLogs(id)
    );
END
GO

IF OBJECT_ID(N'dbo.HealthChecks', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.HealthChecks (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(120) NOT NULL,
        target NVARCHAR(255) NOT NULL,
        check_type NVARCHAR(30) NOT NULL,
        port INT NULL,
        label NVARCHAR(120) NULL,
        service_label NVARCHAR(120) NULL,
        interval_seconds INT NOT NULL,
        timeout_seconds INT NOT NULL,
        enabled BIT NOT NULL DEFAULT 1,
        permanent BIT NOT NULL DEFAULT 0,
        last_status NVARCHAR(30) NULL,
        last_latency_ms INT NULL,
        last_checked_at DATETIME2 NULL,
        failure_count INT NOT NULL DEFAULT 0,
        created_by_user_id INT NULL,
        created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_at DATETIME2 NULL,
        CONSTRAINT FK_HealthChecks_Users FOREIGN KEY (created_by_user_id) REFERENCES dbo.Users(id)
    );
END
GO

IF OBJECT_ID(N'dbo.HealthCheckResults', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.HealthCheckResults (
        id INT IDENTITY(1,1) PRIMARY KEY,
        check_id INT NULL,
        target NVARCHAR(255) NOT NULL,
        check_type NVARCHAR(30) NOT NULL,
        port INT NULL,
        result NVARCHAR(30) NOT NULL,
        latency_ms INT NULL,
        error_message NVARCHAR(MAX) NULL,
        checked_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_HealthCheckResults_HealthChecks FOREIGN KEY (check_id) REFERENCES dbo.HealthChecks(id)
    );
END
GO

IF OBJECT_ID(N'dbo.Agents', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Agents (
        id INT IDENTITY(1,1) PRIMARY KEY,
        agent_id NVARCHAR(120) NOT NULL UNIQUE,
        hostname NVARCHAR(255) NOT NULL,
        ip_address NVARCHAR(45) NOT NULL,
        os_name NVARCHAR(255) NOT NULL,
        agent_version NVARCHAR(50) NOT NULL,
        status NVARCHAR(30) NOT NULL DEFAULT 'online',
        first_seen DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        last_seen DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
    );
END
GO

IF OBJECT_ID(N'dbo.AgentMetrics', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AgentMetrics (
        id INT IDENTITY(1,1) PRIMARY KEY,
        agent_id NVARCHAR(120) NOT NULL,
        cpu_percent FLOAT NOT NULL,
        ram_percent FLOAT NOT NULL,
        disk_percent FLOAT NOT NULL,
        uptime_seconds BIGINT NOT NULL,
        collected_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_AgentMetrics_Agents FOREIGN KEY (agent_id) REFERENCES dbo.Agents(agent_id)
    );
END
GO

IF OBJECT_ID(N'dbo.AgentServices', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AgentServices (
        id INT IDENTITY(1,1) PRIMARY KEY,
        agent_id NVARCHAR(120) NOT NULL,
        service_name NVARCHAR(255) NOT NULL,
        display_name NVARCHAR(255) NULL,
        status NVARCHAR(30) NOT NULL,
        checked_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_AgentServices_Agents FOREIGN KEY (agent_id) REFERENCES dbo.Agents(agent_id)
    );
END
GO

IF OBJECT_ID(N'dbo.AgentEvents', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AgentEvents (
        id INT IDENTITY(1,1) PRIMARY KEY,
        agent_id NVARCHAR(120) NOT NULL,
        source NVARCHAR(100) NOT NULL,
        level NVARCHAR(30) NOT NULL,
        message NVARCHAR(MAX) NOT NULL,
        event_time DATETIME2 NOT NULL,
        received_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_AgentEvents_Agents FOREIGN KEY (agent_id) REFERENCES dbo.Agents(agent_id)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ScanJobs_NextRun' AND object_id = OBJECT_ID(N'dbo.ScanJobs'))
BEGIN
    CREATE INDEX IX_ScanJobs_NextRun ON dbo.ScanJobs(enabled, mode, next_run_at);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Users_Username' AND object_id = OBJECT_ID(N'dbo.Users'))
BEGIN
    CREATE INDEX IX_Users_Username ON dbo.Users(username);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AuthSessions_UserExpiry' AND object_id = OBJECT_ID(N'dbo.AuthSessions'))
BEGIN
    CREATE INDEX IX_AuthSessions_UserExpiry ON dbo.AuthSessions(user_id, expires_at DESC);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AuthAuditLog_UserCreated' AND object_id = OBJECT_ID(N'dbo.AuthAuditLog'))
BEGIN
    CREATE INDEX IX_AuthAuditLog_UserCreated ON dbo.AuthAuditLog(username, created_at DESC);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ScanJobRuns_JobId' AND object_id = OBJECT_ID(N'dbo.ScanJobRuns'))
BEGIN
    CREATE INDEX IX_ScanJobRuns_JobId ON dbo.ScanJobRuns(job_id, id DESC);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_HealthChecks_Enabled' AND object_id = OBJECT_ID(N'dbo.HealthChecks'))
BEGIN
    CREATE INDEX IX_HealthChecks_Enabled ON dbo.HealthChecks(enabled, id DESC);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_HealthCheckResults_CheckId' AND object_id = OBJECT_ID(N'dbo.HealthCheckResults'))
BEGIN
    CREATE INDEX IX_HealthCheckResults_CheckId ON dbo.HealthCheckResults(check_id, checked_at DESC);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Agents_LastSeen' AND object_id = OBJECT_ID(N'dbo.Agents'))
BEGIN
    CREATE INDEX IX_Agents_LastSeen ON dbo.Agents(status, last_seen DESC);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AgentMetrics_AgentCollected' AND object_id = OBJECT_ID(N'dbo.AgentMetrics'))
BEGIN
    CREATE INDEX IX_AgentMetrics_AgentCollected ON dbo.AgentMetrics(agent_id, collected_at DESC);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AgentServices_AgentChecked' AND object_id = OBJECT_ID(N'dbo.AgentServices'))
BEGIN
    CREATE INDEX IX_AgentServices_AgentChecked ON dbo.AgentServices(agent_id, checked_at DESC);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AgentEvents_AgentReceived' AND object_id = OBJECT_ID(N'dbo.AgentEvents'))
BEGIN
    CREATE INDEX IX_AgentEvents_AgentReceived ON dbo.AgentEvents(agent_id, received_at DESC);
END
GO

IF COL_LENGTH('dbo.ScanJobs', 'protocol') IS NULL
BEGIN
    ALTER TABLE dbo.ScanJobs ADD protocol NVARCHAR(10) NOT NULL CONSTRAINT DF_ScanJobs_Protocol DEFAULT 'tcp';
END
GO

IF COL_LENGTH('dbo.ScanJobs', 'permanent') IS NULL
BEGIN
    ALTER TABLE dbo.ScanJobs ADD permanent BIT NOT NULL CONSTRAINT DF_ScanJobs_Permanent DEFAULT 0;
END
GO

IF COL_LENGTH('dbo.ScanJobs', 'created_by_user_id') IS NULL
BEGIN
    ALTER TABLE dbo.ScanJobs ADD created_by_user_id INT NULL;
END
GO

IF COL_LENGTH('dbo.ScanJobs', 'updated_at') IS NULL
BEGIN
    ALTER TABLE dbo.ScanJobs ADD updated_at DATETIME2 NULL;
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ScanJobs_Users')
BEGIN
    ALTER TABLE dbo.ScanJobs WITH NOCHECK
    ADD CONSTRAINT FK_ScanJobs_Users FOREIGN KEY (created_by_user_id) REFERENCES dbo.Users(id);
END
GO

IF COL_LENGTH('dbo.ScanJobRuns', 'protocol') IS NULL
BEGIN
    ALTER TABLE dbo.ScanJobRuns ADD protocol NVARCHAR(10) NOT NULL CONSTRAINT DF_ScanJobRuns_Protocol DEFAULT 'tcp';
END
GO

IF COL_LENGTH('dbo.ScanJobRuns', 'raw_log_id') IS NULL
BEGIN
    ALTER TABLE dbo.ScanJobRuns ADD raw_log_id INT NULL;
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ScanJobRuns_RawLogs')
BEGIN
    ALTER TABLE dbo.ScanJobRuns WITH NOCHECK
    ADD CONSTRAINT FK_ScanJobRuns_RawLogs FOREIGN KEY (raw_log_id) REFERENCES dbo.RawLogs(id);
END
GO

IF COL_LENGTH('dbo.HealthChecks', 'service_label') IS NULL
BEGIN
    ALTER TABLE dbo.HealthChecks ADD service_label NVARCHAR(120) NULL;
END
GO

IF COL_LENGTH('dbo.HealthChecks', 'permanent') IS NULL
BEGIN
    ALTER TABLE dbo.HealthChecks ADD permanent BIT NOT NULL CONSTRAINT DF_HealthChecks_Permanent DEFAULT 0;
END
GO

IF COL_LENGTH('dbo.HealthChecks', 'created_by_user_id') IS NULL
BEGIN
    ALTER TABLE dbo.HealthChecks ADD created_by_user_id INT NULL;
END
GO

IF COL_LENGTH('dbo.HealthChecks', 'updated_at') IS NULL
BEGIN
    ALTER TABLE dbo.HealthChecks ADD updated_at DATETIME2 NULL;
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_HealthChecks_Users')
BEGIN
    ALTER TABLE dbo.HealthChecks WITH NOCHECK
    ADD CONSTRAINT FK_HealthChecks_Users FOREIGN KEY (created_by_user_id) REFERENCES dbo.Users(id);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Scans)
BEGIN
    INSERT INTO dbo.Scans (date, scanner, target, ports, status, started_at, finished_at, result, result_summary)
    VALUES (DATEADD(MINUTE, -20, SYSUTCDATETIME()), N'demo', N'192.168.1.0/24', N'22,80,445,3389', N'completed', DATEADD(MINUTE, -20, SYSUTCDATETIME()), DATEADD(MINUTE, -19, SYSUTCDATETIME()), N'Demo bootstrap scan completata', N'Demo bootstrap scan con 3 host');
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Nodes)
BEGIN
    INSERT INTO dbo.Nodes (hostname, ip, status, last_seen, os_guess, mac_address, vendor, risk_score)
    VALUES
    (N'gateway-01', N'192.168.1.1', N'online', SYSUTCDATETIME(), N'Linux 5.x', N'AA:BB:CC:DD:EE:01', N'LabVendor', 15),
    (N'fileserver-01', N'192.168.1.20', N'online', SYSUTCDATETIME(), N'Windows Server 2019', N'AA:BB:CC:DD:EE:20', N'LabVendor', 80),
    (N'workstation-07', N'192.168.1.50', N'offline', DATEADD(HOUR, -3, SYSUTCDATETIME()), N'Windows 11', N'AA:BB:CC:DD:EE:50', N'LabVendor', 55);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Services)
BEGIN
    INSERT INTO dbo.Services (node_id, port, protocol, state, service_name, product, version, banner, last_seen)
    SELECT id, 80, N'tcp', N'open', N'http', N'nginx', N'1.24', N'nginx demo', SYSUTCDATETIME()
    FROM dbo.Nodes WHERE ip = N'192.168.1.1';

    INSERT INTO dbo.Services (node_id, port, protocol, state, service_name, product, version, banner, last_seen)
    SELECT id, 445, N'tcp', N'open', N'microsoft-ds', N'SMB', N'3.x', N'SMB demo', SYSUTCDATETIME()
    FROM dbo.Nodes WHERE ip = N'192.168.1.20';

    INSERT INTO dbo.Services (node_id, port, protocol, state, service_name, product, version, banner, last_seen)
    SELECT id, 3389, N'tcp', N'open', N'ms-wbt-server', N'RDP', N'10.0', N'RDP demo', SYSUTCDATETIME()
    FROM dbo.Nodes WHERE ip = N'192.168.1.50';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Alerts)
BEGIN
    INSERT INTO dbo.Alerts (type, severity, description, node_id, status)
    SELECT N'new_host_discovered', N'info', N'Nuovo host rilevato durante il bootstrap demo.', id, N'open'
    FROM dbo.Nodes WHERE ip = N'192.168.1.1';

    INSERT INTO dbo.Alerts (type, severity, description, node_id, status)
    SELECT N'host_went_offline', N'medium', N'Il nodo workstation-07 risulta offline nel dataset demo.', id, N'open'
    FROM dbo.Nodes WHERE ip = N'192.168.1.50';

    INSERT INTO dbo.Alerts (type, severity, description, node_id, service_id, status)
    SELECT N'critical_exposed_service', N'high', N'Servizio critico esposto sulla porta 3389.', n.id, s.id, N'open'
    FROM dbo.Nodes n
    INNER JOIN dbo.Services s ON s.node_id = n.id
    WHERE n.ip = N'192.168.1.50' AND s.port = 3389;
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.RawLogs)
BEGIN
    INSERT INTO dbo.RawLogs (source, scan_id, format, content)
    SELECT N'demo', id, N'json', N'{"message":"bootstrap raw log"}'
    FROM dbo.Scans WHERE scanner = N'demo';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.SecurityEvents)
BEGIN
    INSERT INTO dbo.SecurityEvents (source, event_type, node_id, severity, message, raw_log_id)
    SELECT N'demo', N'bootstrap', n.id, N'info', N'Evento demo di bootstrap.', rl.id
    FROM dbo.Nodes n
    CROSS JOIN (SELECT TOP 1 id FROM dbo.RawLogs ORDER BY id) rl
    WHERE n.ip = N'192.168.1.1';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Logins)
BEGIN
    INSERT INTO dbo.Logins (node_id, username, source, source_ip, source_mac, auth_channel, account_type, result, risk_score, details)
    SELECT id, N'admin-lab', N'demo-agent', N'192.168.1.5', N'AA:11:22:33:44:55', N'ssh', N'admin', N'success', 15, N'Login demo associato al nodo gateway.'
    FROM dbo.Nodes WHERE ip = N'192.168.1.1';

    INSERT INTO dbo.Logins (node_id, username, source, source_ip, source_mac, auth_channel, account_type, result, risk_score, details)
    SELECT id, N'svc-backup', N'demo-agent', N'192.168.1.77', N'AA:11:22:33:44:77', N'smb', N'service', N'failed', 50, N'Tentativo login demo fallito su fileserver.'
    FROM dbo.Nodes WHERE ip = N'192.168.1.20';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Logins WHERE username = N'admin-lab' AND source_ip = N'192.168.1.88')
BEGIN
    INSERT INTO dbo.Logins (node_id, username, source, source_ip, source_mac, auth_channel, account_type, result, risk_score, details)
    SELECT id, N'admin-lab', N'vpn-gateway', N'192.168.1.88', N'AA:11:22:33:44:99', N'rdp', N'admin', N'success', 80, N'Stesso account osservato da origine differente nel laboratorio.'
    FROM dbo.Nodes WHERE ip = N'192.168.1.60';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Logins WHERE username = N'svc-backup' AND source_ip = N'192.168.1.78')
BEGIN
    INSERT INTO dbo.Logins (node_id, username, source, source_ip, source_mac, auth_channel, account_type, result, risk_score, details)
    SELECT id, N'svc-backup', N'demo-agent', N'192.168.1.78', N'AA:11:22:33:44:78', N'smb', N'service', N'failed', 70, N'Nuovo tentativo fallito sullo stesso account di servizio.'
    FROM dbo.Nodes WHERE ip = N'192.168.1.20';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Logins WHERE username = N'svc-backup' AND source_ip = N'192.168.1.79')
BEGIN
    INSERT INTO dbo.Logins (node_id, username, source, source_ip, source_mac, auth_channel, account_type, result, risk_score, details)
    SELECT id, N'svc-backup', N'demo-agent', N'192.168.1.79', N'AA:11:22:33:44:79', N'smb', N'service', N'failed', 75, N'Tentativo ripetuto fallito potenzialmente sospetto.'
    FROM dbo.Nodes WHERE ip = N'192.168.1.20';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Logins WHERE username = N'ops-admin' AND source_ip = N'192.168.1.34')
BEGIN
    INSERT INTO dbo.Logins (node_id, username, source, source_ip, source_mac, auth_channel, account_type, result, risk_score, details)
    SELECT id, N'ops-admin', N'portal-web', N'192.168.1.34', N'AA:11:22:33:44:34', N'https', N'admin', N'failed', 55, N'Tentativo admin non riuscito tramite portale.'
    FROM dbo.Nodes WHERE ip = N'192.168.1.1';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.SecurityEvents WHERE event_type = N'login_anomaly_multi_origin')
BEGIN
    INSERT INTO dbo.SecurityEvents (source, event_type, node_id, severity, message)
    SELECT N'login-monitor', N'login_anomaly_multi_origin', id, N'high', N'Account admin-lab osservato da IP/MAC differenti.'
    FROM dbo.Nodes WHERE ip = N'192.168.1.60';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.SecurityEvents WHERE event_type = N'login_failure_burst')
BEGIN
    INSERT INTO dbo.SecurityEvents (source, event_type, node_id, severity, message)
    SELECT N'login-monitor', N'login_failure_burst', id, N'medium', N'Burst di tentativi falliti sull account svc-backup.'
    FROM dbo.Nodes WHERE ip = N'192.168.1.20';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Alerts WHERE type = N'multiple_failed_logins')
BEGIN
    INSERT INTO dbo.Alerts (type, severity, description, node_id, status)
    SELECT N'multiple_failed_logins', N'medium', N'Rilevati tentativi login falliti ripetuti per svc-backup.', id, N'open'
    FROM dbo.Nodes WHERE ip = N'192.168.1.20';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Alerts WHERE type = N'same_account_multi_origin')
BEGIN
    INSERT INTO dbo.Alerts (type, severity, description, node_id, status)
    SELECT N'same_account_multi_origin', N'high', N'Account admin-lab osservato da origini IP/MAC differenti.', id, N'open'
    FROM dbo.Nodes WHERE ip = N'192.168.1.60';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.AuditLog)
BEGIN
    INSERT INTO dbo.AuditLog (actor, action, details)
    VALUES (N'system', N'bootstrap', N'Bootstrap iniziale NetVisor eseguito.');
END
GO
