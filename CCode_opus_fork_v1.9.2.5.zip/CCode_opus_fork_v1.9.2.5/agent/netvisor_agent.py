from __future__ import annotations

import json
import os
import platform
import socket
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

import requests

try:
    import psutil
except ImportError:  # pragma: no cover - opzionale lato client
    psutil = None


AGENT_VERSION = "0.2.0"


def load_config(config_path: Path) -> dict:
    with config_path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    for field in ("agent_id", "backend_url", "agent_key", "interval_seconds"):
        if field not in data or str(data[field]).strip() == "":
            raise ValueError(f"Campo configurazione mancante: {field}")
    data.setdefault("services_to_watch", [])
    return data


def headers(config: dict) -> dict[str, str]:
    return {
        "Content-Type": "application/json",
        "X-Agent-Key": str(config["agent_key"]),
    }


def local_ip() -> str:
    try:
        return socket.gethostbyname(socket.gethostname())
    except OSError:
        return "127.0.0.1"


def collect_metrics() -> dict:
    if psutil is None:
        return {
            "cpu_percent": 0.0,
            "ram_percent": 0.0,
            "disk_percent": 0.0,
            "uptime_seconds": 0,
        }

    boot_seconds = int(time.time() - psutil.boot_time())
    return {
        "cpu_percent": round(psutil.cpu_percent(interval=0.2), 2),
        "ram_percent": round(psutil.virtual_memory().percent, 2),
        "disk_percent": round(psutil.disk_usage(os.path.abspath(os.sep)).percent, 2),
        "uptime_seconds": max(0, boot_seconds),
    }


def service_status(service_name: str) -> dict:
    checked_at = datetime.now(UTC).isoformat()
    if platform.system().lower().startswith("win"):
        try:
            result = subprocess.run(
                ["sc", "query", service_name],
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
            )
            output = (result.stdout or "") + "\n" + (result.stderr or "")
            output_upper = output.upper()
            if "RUNNING" in output_upper:
                state = "running"
            elif "STOPPED" in output_upper:
                state = "stopped"
            else:
                state = "unknown"
        except (OSError, subprocess.SubprocessError):
            state = "unknown"
    else:
        state = "unknown"

    return {
        "service_name": service_name,
        "display_name": service_name,
        "status": state,
        "checked_at": checked_at,
    }


def post_json(config: dict, path: str, payload: dict) -> None:
    url = f"{str(config['backend_url']).rstrip('/')}{path}"
    response = requests.post(url, headers=headers(config), data=json.dumps(payload), timeout=15)
    response.raise_for_status()


def register_agent(config: dict) -> None:
    payload = {
        "agent_id": config["agent_id"],
        "hostname": platform.node() or config["agent_id"],
        "ip": local_ip(),
        "os_name": f"{platform.system()} {platform.release()}",
        "agent_version": AGENT_VERSION,
    }
    post_json(config, "/api/agents/register", payload)


def send_heartbeat(config: dict) -> None:
    post_json(
        config,
        "/api/agents/heartbeat",
        {
            "agent_id": config["agent_id"],
            "timestamp": datetime.now(UTC).isoformat(),
            "status": "online",
        },
    )


def send_metrics(config: dict) -> None:
    payload = {"agent_id": config["agent_id"], **collect_metrics()}
    post_json(config, "/api/agents/metrics", payload)


def send_services(config: dict) -> None:
    services = [service_status(name) for name in config.get("services_to_watch", [])]
    if not services:
        return
    post_json(config, "/api/agents/services", {"agent_id": config["agent_id"], "services": services})


def main() -> int:
    config_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("agent_config.json")
    config = load_config(config_path)

    register_agent(config)
    print(f"[NetVisor Agent] registrato: {config['agent_id']}")

    interval_seconds = max(10, int(config["interval_seconds"]))
    while True:
        try:
            send_heartbeat(config)
            send_metrics(config)
            send_services(config)
            print(f"[NetVisor Agent] heartbeat+metrics inviati {datetime.now().isoformat(timespec='seconds')}")
        except requests.RequestException as exc:
            print(f"[NetVisor Agent] errore invio: {exc}", file=sys.stderr)
        time.sleep(interval_seconds)


if __name__ == "__main__":
    raise SystemExit(main())
