# NetVisor Agent

Agent didattico outbound per host autorizzati di laboratorio.

Funzioni:
- registrazione host;
- heartbeat periodico;
- invio metriche CPU/RAM/Disk/Uptime;
- invio stato servizi dichiarati nel file JSON;
- nessun comando remoto;
- nessuna azione offensiva;
- nessuna persistenza nascosta.

## Prerequisiti

- Python 3.10+
- `requests`
- opzionale `psutil` per metriche piu accurate

Installazione minima:

```powershell
py -m pip install requests psutil
```

## Configurazione

1. Copiare `agent_config.example.json` in `agent_config.json`.
2. Impostare:
   - `agent_id`
   - `backend_url`
   - `agent_key`
   - `interval_seconds`
   - `services_to_watch`

## Avvio

```powershell
cd agent
py netvisor_agent.py agent_config.json
```

## Sicurezza

- l'agent parla solo verso il backend dichiarato;
- usa header `X-Agent-Key`;
- non esegue istruzioni dal server;
- monitora solo metriche locali e servizi esplicitamente elencati.
