from flask import Blueprint

from models import Repository
from utils.responses import error_response, success_response


alerts_bp = Blueprint("alerts", __name__)
repository = Repository()


@alerts_bp.get("/api/alerts")
def list_alerts():
    return success_response(repository.list_alerts())


@alerts_bp.patch("/api/alerts/<int:alert_id>/ack")
def ack_alert(alert_id: int):
    updated = repository.update_alert_status(alert_id, "ack")
    if not updated:
        return error_response("Alert non trovato.", 404)
    repository.write_audit("ack_alert", f"Alert {alert_id} impostato ad ack")
    return success_response({"alert_id": alert_id, "status": "ack"})


@alerts_bp.patch("/api/alerts/<int:alert_id>/close")
def close_alert(alert_id: int):
    updated = repository.update_alert_status(alert_id, "closed")
    if not updated:
        return error_response("Alert non trovato.", 404)
    repository.write_audit("close_alert", f"Alert {alert_id} chiuso")
    return success_response({"alert_id": alert_id, "status": "closed"})
