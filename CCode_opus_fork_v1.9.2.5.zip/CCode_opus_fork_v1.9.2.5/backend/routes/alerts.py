from flask import Blueprint, request

from models import Repository
from utils.responses import error_response, success_response
from utils.security import get_current_user, role_required


alerts_bp = Blueprint("alerts", __name__)
repository = Repository()


# ── Workflow state machine ──────────────────────────────────────────────────
# open → ack → closed → deleted (one-way, no rollback).
# Le transizioni sono enforce-ate a livello SQL via WHERE clause: se la riga
# non è nello stato atteso, UPDATE rowcount = 0 e ritorniamo 409 Conflict
# con messaggio specifico. Questo previene corse fra UI multiple (admin A
# chiude mentre admin B prova a eliminare uno step prima).


def _actor() -> str:
    return (get_current_user() or {}).get("username", "system")


@alerts_bp.get("/api/alerts")
@role_required("admin", "user")
def list_alerts():
    # ?include_deleted=true → include i tombstone (default false).
    include_deleted = request.args.get("include_deleted", "false").lower() in {"1", "true", "yes"}
    return success_response(repository.list_alerts(include_deleted=include_deleted))


@alerts_bp.get("/api/alerts/deleted")
@role_required("admin", "user")
def list_deleted_alerts():
    """Tabella 'Deleted Tasks' — alert con status='deleted' (soft-delete)."""
    return success_response(repository.list_deleted_alerts())


@alerts_bp.patch("/api/alerts/<int:alert_id>/ack")
@role_required("admin")
def ack_alert(alert_id: int):
    existing = repository.get_alert(alert_id)
    if not existing:
        return error_response("Alert non trovato.", 404)
    if existing["status"] != "open":
        return error_response(
            f"Alert in stato '{existing['status']}': ACK consentito solo da 'open'.", 409
        )
    repository.ack_alert(alert_id)
    repository.write_audit("ack_alert", f"Alert {alert_id} → ack", actor=_actor())
    return success_response({"alert_id": alert_id, "status": "ack"})


@alerts_bp.patch("/api/alerts/<int:alert_id>/close")
@role_required("admin")
def close_alert(alert_id: int):
    existing = repository.get_alert(alert_id)
    if not existing:
        return error_response("Alert non trovato.", 404)
    if existing["status"] != "ack":
        return error_response(
            f"Alert in stato '{existing['status']}': Close consentito solo da 'ack'. "
            "Eseguire prima ACK.", 409,
        )
    repository.close_alert(alert_id)
    repository.write_audit("close_alert", f"Alert {alert_id} → closed", actor=_actor())
    return success_response({"alert_id": alert_id, "status": "closed"})


@alerts_bp.delete("/api/alerts/<int:alert_id>")
@role_required("admin")
def delete_alert(alert_id: int):
    """Soft-delete: l'alert resta in DB (per audit + Deleted Tasks UI) ma con
    status='deleted'. Consentito solo da status='closed' (no shortcut)."""
    existing = repository.get_alert(alert_id)
    if not existing:
        return error_response("Alert non trovato.", 404)
    if existing["status"] != "closed":
        return error_response(
            f"Alert in stato '{existing['status']}': Delete consentito solo da 'closed'. "
            "Eseguire prima il flusso ACK → Close.", 409,
        )
    repository.delete_alert(alert_id)
    repository.write_audit("delete_alert", f"Alert {alert_id} → deleted", actor=_actor())
    return success_response({"alert_id": alert_id, "status": "deleted"})
