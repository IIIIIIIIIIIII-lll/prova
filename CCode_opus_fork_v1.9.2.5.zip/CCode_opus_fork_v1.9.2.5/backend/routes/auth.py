from flask import Blueprint, request

from models import Repository
from services.auth_service import AuthError, AuthService
from services.validation_service import ValidationError, validate_sql_read_query
from utils.responses import error_response, success_response
from utils.security import get_current_user, get_request_ip, get_user_agent, login_required, role_required


auth_bp = Blueprint("auth", __name__)
repository = Repository()
service = AuthService(repository)


@auth_bp.post("/api/auth/login")
@auth_bp.post("/api/admin/login")
def auth_login():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(service.login(payload, get_request_ip(), get_user_agent()))
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except AuthError as exc:
        # Se è un fallimento con escalation lockout (warn/soft_lock/re_lock/disabled),
        # arricchiamo la response con `lockout` così il frontend mostra il popup giusto.
        # success_response/error_response standard restano invariate per compat.
        from flask import jsonify
        from utils.responses import _meta
        body = {"success": False, "error": str(exc), "_meta": _meta()}
        if getattr(exc, "lockout", None):
            body["lockout"] = exc.lockout
        return jsonify(body), exc.status_code


@auth_bp.post("/api/auth/logout")
@login_required
def auth_logout():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(
            service.logout(
                get_current_user(),
                payload.get("refresh_token"),
                get_request_ip(),
                get_user_agent(),
            )
        )
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except AuthError as exc:
        return error_response(str(exc), exc.status_code)


@auth_bp.post("/api/auth/refresh")
def auth_refresh():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(service.refresh(payload, get_request_ip(), get_user_agent()))
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except AuthError as exc:
        return error_response(str(exc), exc.status_code)


@auth_bp.get("/api/auth/me")
@login_required
def auth_me():
    try:
        return success_response(service.get_me(get_current_user()))
    except AuthError as exc:
        return error_response(str(exc), exc.status_code)


@auth_bp.post("/api/auth/change-password")
@login_required
def auth_change_password():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(service.change_password(get_current_user(), payload, get_request_ip(), get_user_agent()))
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except AuthError as exc:
        # PDF Errori_v4.2 §2.2: la state machine IDS scatena alert e propaga
        # `lockout` sull'AuthError (warn/soft_lock/re_lock/disabled) così il
        # frontend può mostrare popup escalation come per la login.
        from flask import jsonify
        from utils.responses import _meta
        body = {"success": False, "error": str(exc), "_meta": _meta()}
        if getattr(exc, "lockout", None):
            body["lockout"] = exc.lockout
        return jsonify(body), exc.status_code


@auth_bp.get("/api/auth/audit")
@role_required("admin")
def auth_audit():
    limit = request.args.get("limit", "100")
    try:
        resolved_limit = max(1, min(int(limit), 500))
    except ValueError:
        return error_response("Parametro limit non valido.", 400)
    return success_response(service.list_auth_audit_entries(limit=resolved_limit))


@auth_bp.get("/api/admin/audit-log")
@role_required("admin")
def admin_audit_log():
    limit = request.args.get("limit", "100")
    try:
        resolved_limit = max(1, min(int(limit), 500))
    except ValueError:
        return error_response("Parametro limit non valido.", 400)
    return success_response(repository.list_audit_log(limit=resolved_limit))


@auth_bp.post("/api/admin/query")
@role_required("admin")
def admin_query():
    try:
        payload = request.get_json(silent=True) or {}
        query = validate_sql_read_query(payload.get("query"))
    except ValidationError as exc:
        return error_response(str(exc), 400)
    try:
        result = repository.run_admin_read_query(query)
    except Exception as exc:
        # Errori SQL (colonna inesistente, sintassi, timeout) — ritorna messaggio leggibile
        # invece di un 500 generico "Errore interno del server".
        message = str(exc)
        # pyodbc serializza messaggi come "('42S22', \"...Invalid column name 'foo'...\")"
        # estraiamo l'ultima parte testuale per l'utente.
        if "[" in message and "]" in message:
            try:
                message = message.split("]")[-1].strip().rstrip(")").rstrip("'").rstrip('"')
            except Exception:
                pass
        repository.write_audit(
            "admin_query_failed",
            f"query={query[:500]} error={message[:300]}",
            actor=(get_current_user() or {}).get("username", "system"),
        )
        return error_response(f"Query SQL fallita: {message}", 400)
    repository.write_audit("admin_query", query[:1000], actor=(get_current_user() or {}).get("username", "system"))
    return success_response(result)
