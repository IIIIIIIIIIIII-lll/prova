import json

from flask import Blueprint, request

from models import Repository
from config import settings
from services.ingest_service import IngestService
from services.parser_masscan import parse_masscan_json
from services.parser_nmap import parse_nmap_xml
from services.validation_service import ValidationError, validate_ingest_payload
from utils.responses import error_response, success_response


ingest_bp = Blueprint("ingest", __name__)
repository = Repository()
ingest_service = IngestService(repository)


def _extract_file_or_field(field_name: str) -> str | None:
    uploaded = request.files.get(field_name)
    if uploaded:
        return uploaded.read().decode("utf-8", errors="ignore")

    payload = request.get_json(silent=True) or {}
    return payload.get(field_name)


def _validate_scan_id(scan_id):
    if scan_id in (None, ""):
        return None
    try:
        parsed = int(scan_id)
    except (TypeError, ValueError) as exc:
        raise ValidationError("scan_id deve essere numerico.") from exc
    if parsed < 1:
        raise ValidationError("scan_id non valido.")
    return parsed


@ingest_bp.post("/api/ingest/nmap")
def ingest_nmap():
    try:
        payload = request.get_json(silent=True) or {}
        scan_id = payload.get("scan_id", request.form.get("scan_id"))
        scan_id = _validate_scan_id(scan_id)
        xml_content = _extract_file_or_field("xml")
        if not xml_content:
            raise ValidationError("Payload Nmap mancante.")
        normalized = parse_nmap_xml(xml_content)
        summary = ingest_service.ingest_scan_results(scan_id, "nmap", "xml", xml_content, normalized)
        return success_response(summary, 201)
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except Exception as exc:
        return error_response(f"Ingest Nmap fallito: {exc}", 500)


@ingest_bp.post("/api/ingest/masscan")
def ingest_masscan():
    try:
        payload = request.get_json(silent=True) or {}
        scan_id = payload.get("scan_id", request.form.get("scan_id"))
        scan_id = _validate_scan_id(scan_id)
        json_content = _extract_file_or_field("json")
        if not json_content:
            raise ValidationError("Payload Masscan mancante.")
        normalized = parse_masscan_json(json_content)
        summary = ingest_service.ingest_scan_results(scan_id, "masscan", "json", json_content, normalized)
        return success_response(summary, 201)
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except Exception as exc:
        return error_response(f"Ingest Masscan fallito: {exc}", 500)


@ingest_bp.post("/api/ingest/generic")
def ingest_generic():
    try:
        payload = request.get_json(silent=True) or {}
        source = payload.get("source", "custom-agent")
        payload_format = payload.get("format", "json")
        events = payload.get("events", [])
        validate_ingest_payload(source, payload_format)
        if not isinstance(events, list):
            raise ValidationError("Il campo events deve essere una lista.")
        if len(events) > settings.max_ingest_events:
            raise ValidationError(f"Numero massimo eventi per ingest: {settings.max_ingest_events}.")
        summary = ingest_service.ingest_generic_events(source, payload_format, events)
        repository.write_audit("ingest_generic", json.dumps({"source": source, "count": len(events)}))
        return success_response(summary, 201)
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except Exception as exc:
        return error_response(f"Ingest generic fallito: {exc}", 500)
