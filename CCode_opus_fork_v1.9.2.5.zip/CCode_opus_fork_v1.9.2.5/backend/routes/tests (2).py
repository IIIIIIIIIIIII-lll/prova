from flask import Blueprint, request

from models import Repository
from services.connectivity_service import http_test, ping_target
from services.validation_service import ValidationError
from utils.responses import error_response, success_response


tests_bp = Blueprint("tests", __name__)
repository = Repository()


@tests_bp.post("/api/ping")
def ping():
    payload = request.get_json(silent=True) or {}
    target = payload.get("target")
    try:
        result = ping_target(target)
        repository.create_test_result(
            target=result["target"],
            test_type="ping",
            result=result["result"],
            latency_ms=result["latency_ms"],
            details=result["details"],
        )
        return success_response(result)
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except Exception as exc:
        return error_response(f"Ping fallito: {exc}", 500)


@tests_bp.post("/api/http-test")
def http_check():
    payload = request.get_json(silent=True) or {}
    url = payload.get("url")
    try:
        result = http_test(url)
        repository.create_test_result(
            target=result["target"],
            test_type="http",
            result=result["result"],
            latency_ms=result["latency_ms"],
            details=result["details"],
        )
        return success_response(result)
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except Exception as exc:
        return error_response(f"HTTP test fallito: {exc}", 500)
