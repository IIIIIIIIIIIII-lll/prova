from flask import Blueprint, request

from models import Repository
from utils.responses import error_response, success_response


nodes_bp = Blueprint("nodes", __name__)
repository = Repository()


@nodes_bp.get("/api/nodes")
def list_nodes():
    status = request.args.get("status")
    return success_response(repository.list_nodes(status))


@nodes_bp.get("/api/nodes/<int:node_id>")
def get_node(node_id: int):
    node = repository.get_node(node_id)
    if not node:
        return error_response("Nodo non trovato.", 404)
    return success_response(node)


@nodes_bp.get("/api/nodes/<int:node_id>/services")
def get_node_services(node_id: int):
    if not repository.get_node(node_id):
        return error_response("Nodo non trovato.", 404)
    return success_response(repository.get_node_services(node_id))


@nodes_bp.get("/api/nodes/<int:node_id>/alerts")
def get_node_alerts(node_id: int):
    if not repository.get_node(node_id):
        return error_response("Nodo non trovato.", 404)
    return success_response(repository.get_node_alerts(node_id))


@nodes_bp.get("/api/nodes/<int:node_id>/logins")
def get_node_logins(node_id: int):
    if not repository.get_node(node_id):
        return error_response("Nodo non trovato.", 404)
    return success_response(repository.get_node_logins(node_id))
