from flask import Blueprint, request

from models import Repository
from utils.responses import error_response, success_response
from utils.security import role_required


nodes_bp = Blueprint("nodes", __name__)
repository = Repository()


@nodes_bp.get("/api/nodes")
@role_required("admin", "user")
def list_nodes():
    status = request.args.get("status")
    return success_response(repository.list_nodes(status))


@nodes_bp.get("/api/nodes/<int:node_id>")
@role_required("admin", "user")
def get_node(node_id: int):
    node = repository.get_node(node_id)
    if not node:
        return error_response("Nodo non trovato.", 404)
    return success_response(node)


@nodes_bp.get("/api/nodes/<int:node_id>/services")
@role_required("admin", "user")
def get_node_services(node_id: int):
    if not repository.get_node(node_id):
        return error_response("Nodo non trovato.", 404)
    return success_response(repository.get_node_services(node_id))


@nodes_bp.get("/api/nodes/<int:node_id>/alerts")
@role_required("admin", "user")
def get_node_alerts(node_id: int):
    if not repository.get_node(node_id):
        return error_response("Nodo non trovato.", 404)
    return success_response(repository.get_node_alerts(node_id))


@nodes_bp.get("/api/nodes/<int:node_id>/logins")
@role_required("admin", "user")
def get_node_logins(node_id: int):
    if not repository.get_node(node_id):
        return error_response("Nodo non trovato.", 404)
    return success_response(repository.get_node_logins(node_id))
