from flask import Blueprint, request

from models import Repository
from services.scan_job_service import ScanJobService
from services.validation_service import ValidationError
from utils.responses import error_response, success_response
from utils.security import get_current_user, get_request_ip, get_user_agent, role_required


scans_bp = Blueprint("scans", __name__)
repository = Repository()
service = ScanJobService(repository)


@scans_bp.post("/api/scan")
@scans_bp.post("/api/admin/scans/manual")
@role_required("admin")
def create_scan():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(
            service.run_manual_scan(payload, actor=get_current_user(), ip_address=get_request_ip(), user_agent=get_user_agent()),
            201,
        )
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except Exception as exc:
        return error_response(f"Scansione fallita: {exc}", 500)


@scans_bp.post("/api/scans/manual")
@role_required("admin")
def create_manual_scan():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(
            service.run_manual_scan(payload, actor=get_current_user(), ip_address=get_request_ip(), user_agent=get_user_agent()),
            201,
        )
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except Exception as exc:
        return error_response(f"Scansione fallita: {exc}", 500)


@scans_bp.get("/api/scans")
@role_required("admin", "user")
def list_scans():
    return success_response(repository.list_scans())


@scans_bp.get("/api/scans/<int:scan_id>")
@role_required("admin", "user")
def get_scan(scan_id: int):
    scan = repository.get_scan(scan_id)
    if not scan:
        return error_response("Scan non trovata.", 404)
    return success_response(scan)


@scans_bp.get("/api/scans/<int:scan_id>/events")
@role_required("admin", "user")
def get_scan_events(scan_id: int):
    if not repository.get_scan(scan_id):
        return error_response("Scan non trovata.", 404)
    return success_response(repository.get_scan_events(scan_id))


@scans_bp.get("/api/scans/<int:scan_id>/raw")
@role_required("admin", "user")
def get_scan_raw(scan_id: int):
    if not repository.get_scan(scan_id):
        return error_response("Scan non trovata.", 404)
    return success_response(repository.get_scan_raw(scan_id))
