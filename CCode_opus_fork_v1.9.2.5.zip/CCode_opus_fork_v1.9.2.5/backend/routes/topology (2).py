from flask import Blueprint

from models import Repository
from utils.responses import success_response


topology_bp = Blueprint("topology", __name__)
repository = Repository()


@topology_bp.get("/api/topology")
def topology():
    return success_response(repository.get_topology())
