from flask import Blueprint, request

from models import Repository
from services.agent_service import AgentService
from services.validation_service import ValidationError
from utils.responses import error_response, success_response
from utils.security import role_required


agents_bp = Blueprint("agents", __name__)
repository = Repository()
service = AgentService(repository)


@agents_bp.post("/api/agents/register")
def register_agent():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(service.register(payload), 201)
    except ValidationError as exc:
        return error_response(str(exc), 400)


@agents_bp.post("/api/agents/heartbeat")
def agent_heartbeat():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(service.heartbeat(payload))
    except ValidationError as exc:
        return error_response(str(exc), 400)


@agents_bp.post("/api/agents/metrics")
def agent_metrics():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(service.ingest_metrics(payload), 201)
    except ValidationError as exc:
        return error_response(str(exc), 400)


@agents_bp.post("/api/agents/services")
def agent_services():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(service.ingest_services(payload))
    except ValidationError as exc:
        return error_response(str(exc), 400)


@agents_bp.post("/api/agents/events")
def agent_events():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(service.ingest_events(payload), 201)
    except ValidationError as exc:
        return error_response(str(exc), 400)


@agents_bp.get("/api/agents")
@role_required("admin", "user")
def list_agents():
    service.refresh_presence()
    return success_response(repository.list_agents())


@agents_bp.get("/api/agents/<string:agent_id>")
@role_required("admin", "user")
def get_agent(agent_id: str):
    try:
        return success_response(service.get_agent_detail(agent_id))
    except ValidationError as exc:
        return error_response(str(exc), 404)


@agents_bp.get("/api/agents/<string:agent_id>/metrics")
@role_required("admin", "user")
def get_agent_metrics(agent_id: str):
    agent = repository.get_agent(agent_id)
    if not agent:
        return error_response("Agent non trovato.", 404)
    return success_response(repository.get_agent_metrics(agent_id))


@agents_bp.get("/api/agents/<string:agent_id>/services")
@role_required("admin", "user")
def get_agent_services(agent_id: str):
    agent = repository.get_agent(agent_id)
    if not agent:
        return error_response("Agent non trovato.", 404)
    return success_response(repository.get_agent_services(agent_id))


@agents_bp.get("/api/agents/<string:agent_id>/events")
@role_required("admin", "user")
def get_agent_events(agent_id: str):
    agent = repository.get_agent(agent_id)
    if not agent:
        return error_response("Agent non trovato.", 404)
    return success_response(repository.get_agent_events(agent_id))
