from flask import Blueprint, request

from models import Repository
from services.auth_service import AuthError, AuthService
from services.validation_service import ValidationError
from utils.responses import error_response, success_response
from utils.security import get_current_user, get_request_ip, get_user_agent, role_required


users_bp = Blueprint("users", __name__)
repository = Repository()
service = AuthService(repository)


@users_bp.get("/api/users")
@role_required("admin")
def list_users():
    return success_response(repository.list_users())


@users_bp.post("/api/users")
@role_required("admin")
def create_user():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(service.create_user_account(get_current_user(), payload, get_request_ip(), get_user_agent()), 201)
    except (ValidationError, ValueError, AuthError) as exc:
        status = exc.status_code if isinstance(exc, AuthError) else 400
        return error_response(str(exc), status)


@users_bp.get("/api/users/<int:user_id>")
@role_required("admin")
def get_user(user_id: int):
    user = repository.get_user_by_id(user_id)
    if not user:
        return error_response("Utente non trovato.", 404)
    safe = dict(user)
    safe.pop("password_hash", None)
    return success_response(safe)


@users_bp.patch("/api/users/<int:user_id>")
@role_required("admin")
def update_user(user_id: int):
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(service.update_user_account(get_current_user(), user_id, payload, get_request_ip(), get_user_agent()))
    except (ValidationError, ValueError, AuthError) as exc:
        status = exc.status_code if isinstance(exc, AuthError) else 400
        return error_response(str(exc), status)


@users_bp.delete("/api/users/<int:user_id>")
@role_required("admin")
def delete_user(user_id: int):
    try:
        return success_response(service.delete_user(get_current_user(), user_id, get_request_ip(), get_user_agent()))
    except (ValidationError, ValueError, AuthError) as exc:
        status = exc.status_code if isinstance(exc, AuthError) else 400
        return error_response(str(exc), status)


@users_bp.post("/api/users/<int:user_id>/reset-password")
@role_required("admin")
def reset_password(user_id: int):
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(service.reset_user_password(get_current_user(), user_id, payload, get_request_ip(), get_user_agent()))
    except (ValidationError, ValueError, AuthError) as exc:
        status = exc.status_code if isinstance(exc, AuthError) else 400
        return error_response(str(exc), status)


@users_bp.post("/api/users/<int:user_id>/disable")
@role_required("admin")
def disable_user(user_id: int):
    try:
        return success_response(service.disable_user(get_current_user(), user_id, get_request_ip(), get_user_agent()))
    except (ValidationError, ValueError, AuthError) as exc:
        status = exc.status_code if isinstance(exc, AuthError) else 400
        return error_response(str(exc), status)


@users_bp.post("/api/users/<int:user_id>/enable")
@role_required("admin")
def enable_user(user_id: int):
    try:
        return success_response(service.enable_user(get_current_user(), user_id, get_request_ip(), get_user_agent()))
    except (ValidationError, ValueError, AuthError) as exc:
        status = exc.status_code if isinstance(exc, AuthError) else 400
        return error_response(str(exc), status)
