from flask import Blueprint, request

from models import Repository
from services.connectivity_service import http_test, ping_target
from services.validation_service import ValidationError
from utils.responses import error_response, success_response
from utils.security import get_current_user, role_required


tests_bp = Blueprint("tests", __name__)
repository = Repository()


@tests_bp.post("/api/ping")
@role_required("admin")
def ping():
    payload = request.get_json(silent=True) or {}
    target = payload.get("target")
    try:
        result = ping_target(target)
        repository.create_test_result(
            target=result["target"],
            test_type="ping",
            result=result["result"],
            latency_ms=result["latency_ms"],
            details=result["details"],
        )
        repository.write_audit("manual_health_check_started", f"ping {result['target']}", actor=(get_current_user() or {}).get("username", "system"))
        return success_response(result)
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except Exception as exc:
        return error_response(f"Ping fallito: {exc}", 500)


@tests_bp.post("/api/http-test")
@role_required("admin")
def http_check():
    """HTTP probe manuale: il risultato (success/failed) è sempre 200 con
    payload — solo URL malformati ritornano 400. ConnectionError, Timeout
    ecc. NON sono errori del controller ma esiti validi del test e devono
    finire in Tests table per audit/troubleshooting."""
    payload = request.get_json(silent=True) or {}
    url = payload.get("url")
    try:
        result = http_test(url)  # non lancia eccezioni, sempre dict valido
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except Exception as exc:
        # Last-resort: se http_test() lancia comunque qualcosa, non perdiamo
        # il 500 ma logghiamo che è un bug del nostro lato (no flow utente).
        return error_response(f"HTTP test interno fallito: {exc.__class__.__name__}", 500)

    repository.create_test_result(
        target=result["target"],
        test_type="http",
        result=result["result"],
        latency_ms=result["latency_ms"],
        details=result["details"],
    )
    repository.write_audit(
        "manual_health_check_started",
        f"http-test {result['target']} → {result['result']}",
        actor=(get_current_user() or {}).get("username", "system"),
    )
    return success_response(result)
