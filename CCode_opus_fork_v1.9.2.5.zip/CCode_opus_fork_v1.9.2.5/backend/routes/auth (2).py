import hmac

from flask import Blueprint, request

from config import settings
from models import Repository
from services.validation_service import ValidationError, validate_safe_text, validate_sql_read_query
from utils.responses import error_response, success_response
from utils.security import issue_admin_token


auth_bp = Blueprint("auth", __name__)
repository = Repository()


@auth_bp.post("/api/admin/login")
def admin_login():
    try:
        payload = request.get_json(silent=True) or {}
        username = validate_safe_text(payload.get("username"), "Username", max_length=64)
        password = payload.get("password")
        if password is None or str(password) == "":
            raise ValidationError("Password obbligatoria.")

        if not hmac.compare_digest(username, settings.admin_username) or not hmac.compare_digest(
            str(password), settings.admin_password
        ):
            return error_response("Credenziali admin non valide.", 401)

        token = issue_admin_token(username)
        return success_response(
            {
                "token": token,
                "token_type": "Bearer",
                "expires_in_minutes": settings.auth_token_ttl_minutes,
                "username": username,
            }
        )
    except ValidationError as exc:
        return error_response(str(exc), 400)


@auth_bp.post("/api/admin/query")
def admin_query():
    try:
        payload = request.get_json(silent=True) or {}
        query = validate_sql_read_query(payload.get("query"))
        result = repository.run_admin_read_query(query)
        repository.write_audit("admin_query", query[:1000], actor=settings.admin_username)
        return success_response(result)
    except ValidationError as exc:
        return error_response(str(exc), 400)
