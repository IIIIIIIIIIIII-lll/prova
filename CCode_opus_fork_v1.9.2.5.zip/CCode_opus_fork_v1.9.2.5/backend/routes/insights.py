from flask import Blueprint

from models import Repository
from services.agent_service import AgentService
from utils.responses import success_response
from utils.security import role_required


insights_bp = Blueprint("insights", __name__)
repository = Repository()
agent_service = AgentService(repository)


@insights_bp.get("/api/dashboard/operations")
@role_required("admin", "user")
def dashboard_operations():
    agent_service.refresh_presence()
    return success_response(repository.get_dashboard_operations())


@insights_bp.get("/api/connections/overview")
@role_required("admin", "user")
def connections_overview():
    return success_response(repository.get_connections_overview())


@insights_bp.get("/api/security/logins/summary")
@role_required("admin", "user")
def security_logins_summary():
    return success_response(repository.get_login_security_overview())
