from flask import Blueprint, request

from models import Repository
from services.health_check_service import HealthCheckService
from services.validation_service import ValidationError
from utils.responses import error_response, success_response
from utils.security import get_current_user, get_request_ip, get_user_agent, role_required


health_checks_bp = Blueprint("health_checks", __name__)
repository = Repository()
service = HealthCheckService(repository)


@health_checks_bp.get("/api/health-checks")
@health_checks_bp.get("/api/admin/health-checks")
@role_required("admin")
def list_health_checks():
    return success_response(repository.list_health_checks())


@health_checks_bp.post("/api/health-checks")
@health_checks_bp.post("/api/admin/health-checks")
@role_required("admin")
def create_health_check():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(
            service.create_check(payload, actor=get_current_user(), ip_address=get_request_ip(), user_agent=get_user_agent()),
            201,
        )
    except ValidationError as exc:
        return error_response(str(exc), 400)


@health_checks_bp.get("/api/health-checks/<int:check_id>")
@health_checks_bp.get("/api/admin/health-checks/<int:check_id>")
@role_required("admin")
def get_health_check(check_id: int):
    check = repository.get_health_check(check_id)
    if not check:
        return error_response("Health check non trovato.", 404)
    return success_response(check)


@health_checks_bp.patch("/api/health-checks/<int:check_id>")
@health_checks_bp.patch("/api/admin/health-checks/<int:check_id>")
@role_required("admin")
def update_health_check(check_id: int):
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(
            service.update_check(check_id, payload, actor=get_current_user(), ip_address=get_request_ip(), user_agent=get_user_agent())
        )
    except ValidationError as exc:
        status = 404 if "non trovato" in str(exc).lower() else 400
        return error_response(str(exc), status)


@health_checks_bp.delete("/api/health-checks/<int:check_id>")
@health_checks_bp.delete("/api/admin/health-checks/<int:check_id>")
@role_required("admin")
def delete_health_check(check_id: int):
    if not repository.get_health_check(check_id):
        return error_response("Health check non trovato.", 404)
    repository.delete_health_check(check_id)
    repository.write_audit("health_check_deleted", f"Health check {check_id} eliminato", actor=(get_current_user() or {}).get("username", "system"))
    return success_response({"deleted": True})


@health_checks_bp.post("/api/health-checks/<int:check_id>/run")
@health_checks_bp.post("/api/admin/health-checks/<int:check_id>/run")
@role_required("admin")
def run_health_check(check_id: int):
    try:
        return success_response(
            service.run_check(check_id, actor=get_current_user(), ip_address=get_request_ip(), user_agent=get_user_agent())
        )
    except ValidationError as exc:
        status = 404 if "non trovato" in str(exc).lower() else 400
        return error_response(str(exc), status)
    except Exception as exc:
        return error_response(f"Esecuzione health check fallita: {exc}", 500)


@health_checks_bp.get("/api/health-checks/<int:check_id>/results")
@health_checks_bp.get("/api/admin/health-checks/<int:check_id>/results")
@role_required("admin")
def list_health_check_results(check_id: int):
    if not repository.get_health_check(check_id):
        return error_response("Health check non trovato.", 404)
    return success_response(repository.list_health_check_results(check_id))


@health_checks_bp.post("/api/admin/health-checks/manual")
@role_required("admin")
def run_manual_health_check():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(
            service.run_manual_check(payload, actor=get_current_user(), ip_address=get_request_ip(), user_agent=get_user_agent())
        )
    except ValidationError as exc:
        return error_response(str(exc), 400)
    except Exception as exc:
        return error_response(f"Esecuzione health check fallita: {exc}", 500)
