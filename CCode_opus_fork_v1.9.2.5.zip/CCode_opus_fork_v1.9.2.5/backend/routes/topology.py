from flask import Blueprint, request

from models import Repository
from services.agent_service import AgentService
from utils.responses import success_response
from utils.security import role_required


topology_bp = Blueprint("topology", __name__)
repository = Repository()
agent_service = AgentService(repository)


@topology_bp.get("/api/topology")
@role_required("admin", "user")
def topology():
    try:
        time_window_hours = max(1, min(24, int(request.args.get("hours", 1))))
    except (ValueError, TypeError):
        time_window_hours = 1
    agent_service.refresh_presence()
    # NetVisor è LIVE-only: nessun parametro demo, sempre dati reali.
    return success_response(repository.get_topology(time_window_hours=time_window_hours))
