from flask import Blueprint, request

from models import Repository
from services.scan_job_service import ScanJobService
from services.validation_service import ValidationError
from utils.responses import error_response, success_response
from utils.security import get_current_user, get_request_ip, get_user_agent, role_required


scan_jobs_bp = Blueprint("scan_jobs", __name__)
repository = Repository()
service = ScanJobService(repository)


@scan_jobs_bp.get("/api/scan-jobs")
@scan_jobs_bp.get("/api/admin/scan-jobs")
@role_required("admin")
def list_scan_jobs():
    return success_response(repository.list_scan_jobs())


@scan_jobs_bp.post("/api/scan-jobs")
@scan_jobs_bp.post("/api/admin/scan-jobs")
@role_required("admin")
def create_scan_job():
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(
            service.create_job(payload, actor=get_current_user(), ip_address=get_request_ip(), user_agent=get_user_agent()),
            201,
        )
    except ValidationError as exc:
        return error_response(str(exc), 400)


@scan_jobs_bp.get("/api/scan-jobs/<int:job_id>")
@scan_jobs_bp.get("/api/admin/scan-jobs/<int:job_id>")
@role_required("admin")
def get_scan_job(job_id: int):
    job = repository.get_scan_job(job_id)
    if not job:
        return error_response("Scan job non trovato.", 404)
    return success_response(job)


@scan_jobs_bp.patch("/api/scan-jobs/<int:job_id>")
@scan_jobs_bp.patch("/api/admin/scan-jobs/<int:job_id>")
@role_required("admin")
def update_scan_job(job_id: int):
    try:
        payload = request.get_json(silent=True) or {}
        return success_response(
            service.update_job(job_id, payload, actor=get_current_user(), ip_address=get_request_ip(), user_agent=get_user_agent())
        )
    except ValidationError as exc:
        status = 404 if "non trovato" in str(exc).lower() else 400
        return error_response(str(exc), status)


@scan_jobs_bp.delete("/api/scan-jobs/<int:job_id>")
@scan_jobs_bp.delete("/api/admin/scan-jobs/<int:job_id>")
@role_required("admin")
def delete_scan_job(job_id: int):
    if not repository.get_scan_job(job_id):
        return error_response("Scan job non trovato.", 404)
    repository.delete_scan_job(job_id)
    repository.write_audit("scan_job_deleted", f"Scan job {job_id} eliminato", actor=(get_current_user() or {}).get("username", "system"))
    return success_response({"deleted": True})


@scan_jobs_bp.post("/api/scan-jobs/<int:job_id>/run")
@scan_jobs_bp.post("/api/admin/scan-jobs/<int:job_id>/run")
@role_required("admin")
def run_scan_job(job_id: int):
    try:
        return success_response(service.run_job(job_id, actor=get_current_user()))
    except ValidationError as exc:
        status = 404 if "non trovato" in str(exc).lower() else 400
        return error_response(str(exc), status)
    except Exception as exc:
        return error_response(f"Esecuzione scan job fallita: {exc}", 500)


@scan_jobs_bp.get("/api/scan-jobs/<int:job_id>/runs")
@scan_jobs_bp.get("/api/admin/scan-jobs/<int:job_id>/runs")
@role_required("admin")
def list_scan_job_runs(job_id: int):
    if not repository.get_scan_job(job_id):
        return error_response("Scan job non trovato.", 404)
    return success_response(repository.list_scan_job_runs(job_id))
