from flask import Blueprint, request

from models import Repository
from services.alert_engine import AlertEngine
from services.ingest_service import IngestService
from services.scanner_service import run_scan
from services.validation_service import ValidationError, validate_scan_mode, validate_scanner, validate_target
from utils.responses import error_response, success_response


scans_bp = Blueprint("scans", __name__)
repository = Repository()
ingest_service = IngestService(repository)
alert_engine = AlertEngine(repository)


@scans_bp.post("/api/scan")
def create_scan():
    try:
        payload = request.get_json(silent=True) or {}
        scanner = validate_scanner(payload.get("scanner", "nmap"))
        target = validate_target(payload.get("target"))
        ports = payload.get("ports")
        mode = validate_scan_mode(payload.get("mode", "safe"))
        scan_id = repository.create_scan(scanner, target or "", ports, "queued")
        repository.mark_scan_started(scan_id)
        result = run_scan(scanner=scanner, target=target, ports=ports, mode=mode)
        summary = ingest_service.ingest_scan_results(
            scan_id=scan_id,
            source=scanner,
            raw_format=result["raw_format"],
            raw_content=result["raw_output"],
            normalized_hosts=result["normalized_hosts"],
        )
        repository.finalize_scan(scan_id, "completed", result_summary=result["summary"])
        repository.write_audit("create_scan", f"Scan {scan_id} completata")
        return success_response({"scan_id": scan_id, "summary": result["summary"], "ingest": summary}, 201)
    except ValidationError as exc:
        if "scan_id" in locals():
            repository.finalize_scan(scan_id, "failed", error_message=str(exc))
        return error_response(str(exc), 400)
    except Exception as exc:
        if "scan_id" in locals():
            repository.finalize_scan(scan_id, "failed", error_message=str(exc))
            alert_engine.handle_scan_failed(scanner, scan_id, str(exc))
        return error_response(f"Scansione fallita: {exc}", 500)


@scans_bp.get("/api/scans")
def list_scans():
    return success_response(repository.list_scans())


@scans_bp.get("/api/scans/<int:scan_id>")
def get_scan(scan_id: int):
    scan = repository.get_scan(scan_id)
    if not scan:
        return error_response("Scan non trovata.", 404)
    return success_response(scan)


@scans_bp.get("/api/scans/<int:scan_id>/events")
def get_scan_events(scan_id: int):
    if not repository.get_scan(scan_id):
        return error_response("Scan non trovata.", 404)
    return success_response(repository.get_scan_events(scan_id))


@scans_bp.get("/api/scans/<int:scan_id>/raw")
def get_scan_raw(scan_id: int):
    if not repository.get_scan(scan_id):
        return error_response("Scan non trovata.", 404)
    return success_response(repository.get_scan_raw(scan_id))
