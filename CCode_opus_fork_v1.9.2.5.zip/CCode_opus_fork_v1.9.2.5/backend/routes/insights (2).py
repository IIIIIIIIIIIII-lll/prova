from flask import Blueprint

from models import Repository
from utils.responses import success_response


insights_bp = Blueprint("insights", __name__)
repository = Repository()


@insights_bp.get("/api/dashboard/operations")
def dashboard_operations():
    return success_response(repository.get_dashboard_operations())


@insights_bp.get("/api/connections/overview")
def connections_overview():
    return success_response(repository.get_connections_overview())


@insights_bp.get("/api/security/logins/summary")
def security_logins_summary():
    return success_response(repository.get_login_security_overview())
