from __future__ import annotations

from ipaddress import ip_address, ip_network
import re
from urllib.parse import urlparse

from config import settings


class ValidationError(ValueError):
    pass


_SAFE_NAME = re.compile(r"^[A-Za-z0-9_.:@/-]{1,255}$")
_SQL_ALLOWED_TABLES = {
    "nodes",
    "services",
    "alerts",
    "scans",
    "tests",
    "rawlogs",
    "securityevents",
    "auditlog",
    "logins",
}
_SQL_FORBIDDEN_TOKENS = (
    ";",
    "--",
    "/*",
    "*/",
    " xp_",
    "\txp_",
    "\n xp_",
    " sp_",
    "\tsp_",
    "\n sp_",
)
_SQL_FORBIDDEN_KEYWORDS = {
    "insert",
    "update",
    "delete",
    "drop",
    "alter",
    "truncate",
    "merge",
    "create",
    "grant",
    "revoke",
    "deny",
    "exec",
    "execute",
    "backup",
    "restore",
    "attach",
    "detach",
    "dbcc",
    "use",
    "into",
    "openrowset",
    "openquery",
    "opendatasource",
}


def validate_safe_text(value: str | None, field_name: str, max_length: int = 255, required: bool = True) -> str | None:
    if value is None or str(value).strip() == "":
        if required:
            raise ValidationError(f"{field_name} obbligatorio.")
        return None
    normalized = str(value).strip()
    if len(normalized) > max_length:
        raise ValidationError(f"{field_name} troppo lungo. Massimo {max_length} caratteri.")
    if not _SAFE_NAME.match(normalized):
        raise ValidationError(f"{field_name} contiene caratteri non consentiti.")
    return normalized


def validate_ports(ports: str | None) -> list[int]:
    if not ports:
        return []

    parsed: list[int] = []
    for item in str(ports).split(","):
        value = item.strip()
        if not value or not value.isdigit():
            raise ValidationError("Le porte devono essere numeriche e separate da virgola.")
        port = int(value)
        if port < 1 or port > 65535:
            raise ValidationError("Le porte devono essere comprese tra 1 e 65535.")
        parsed.append(port)

    if len(parsed) > settings.max_scan_ports:
        raise ValidationError(f"Numero massimo di porte consentite: {settings.max_scan_ports}.")

    return sorted(set(parsed))


def validate_scanner(scanner: str) -> str:
    normalized = (scanner or "").strip().lower()
    if normalized not in {"nmap", "masscan"}:
        raise ValidationError("Scanner non supportato. Usare 'nmap' o 'masscan'.")
    return normalized


def validate_scan_mode(mode: str | None) -> str:
    normalized = (mode or "safe").strip().lower()
    if normalized not in {"safe", "demo"}:
        raise ValidationError("Modalita scan non valida. Usare 'safe' o 'demo'.")
    return normalized


def validate_target(target: str) -> str:
    if not target or not str(target).strip():
        raise ValidationError("Target obbligatorio.")

    normalized = str(target).strip()
    try:
        if "/" in normalized:
            network = ip_network(normalized, strict=False)
            _ensure_network_allowed(network)
            if network.version == 4 and network.prefixlen < settings.max_scan_prefix_ipv4:
                raise ValidationError(
                    f"Target troppo ampio. Prefisso minimo IPv4 consentito: /{settings.max_scan_prefix_ipv4}."
                )
        else:
            address = ip_address(normalized)
            _ensure_ip_allowed(address)
    except ValueError as exc:
        raise ValidationError(f"Target non valido: {exc}") from exc

    return normalized


def validate_ingest_payload(source: str, payload_format: str):
    validate_safe_text(source, "Source ingest", max_length=50)
    if payload_format not in {"xml", "json", "text"}:
        raise ValidationError("Formato ingest non supportato.")


def validate_http_url(url: str) -> str:
    parsed = urlparse(url or "")
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValidationError("URL non valido. Usare http:// o https://.")
    try:
        hostname = parsed.hostname or ""
        address = ip_address(hostname)
        _ensure_ip_allowed(address)
    except ValueError:
        # I nomi DNS interni sono ammessi, ma non devono contenere credenziali.
        if parsed.username or parsed.password:
            raise ValidationError("URL con credenziali inline non consentito.")
        hostname = (parsed.hostname or "").lower()
        local_dns = hostname.endswith((".local", ".lan", ".internal")) or "." not in hostname
        if not settings.allow_public_scan and not local_dns:
            raise ValidationError("HTTP test verso domini pubblici disabilitato.")
    return url


def validate_sql_read_query(query: str | None, max_length: int = 4000) -> str:
    if query is None or not str(query).strip():
        raise ValidationError("Query SQL obbligatoria.")

    normalized = str(query).strip()
    if len(normalized) > max_length:
        raise ValidationError(f"Query SQL troppo lunga. Massimo {max_length} caratteri.")

    lowered = normalized.lower()
    if not (lowered.startswith("select ") or lowered.startswith("with ")):
        raise ValidationError("Sono consentite solo query SELECT o CTE di sola lettura.")

    if any(token in lowered for token in _SQL_FORBIDDEN_TOKENS):
        raise ValidationError("La query contiene token SQL non consentiti.")

    for keyword in _SQL_FORBIDDEN_KEYWORDS:
        if re.search(rf"\b{re.escape(keyword)}\b", lowered):
            raise ValidationError(f"La query contiene l'istruzione non consentita: {keyword}.")

    referenced_tables = {
        match.group(1).split(".")[-1].strip("[]").lower()
        for match in re.finditer(r"\b(?:from|join)\s+([A-Za-z0-9_.\[\]]+)", normalized, flags=re.IGNORECASE)
    }
    if not referenced_tables:
        raise ValidationError("La query deve referenziare almeno una tabella applicativa.")

    disallowed = sorted(table for table in referenced_tables if table not in _SQL_ALLOWED_TABLES)
    if disallowed:
        raise ValidationError(
            "La query puo interrogare solo le tabelle NetVisor consentite: "
            + ", ".join(sorted(_SQL_ALLOWED_TABLES))
            + f". Tabelle non consentite rilevate: {', '.join(disallowed)}."
        )

    return normalized


def _ensure_network_allowed(target_network):
    if not settings.allow_public_scan and target_network.is_global:
        raise ValidationError("Le scansioni su reti pubbliche sono disabilitate.")
    for allowed in settings.allowed_networks:
        if target_network.subnet_of(allowed):
            return
    raise ValidationError("Target fuori da SCAN_ALLOWED_CIDRS.")


def _ensure_ip_allowed(target_ip):
    if not settings.allow_public_scan and target_ip.is_global:
        raise ValidationError("Le scansioni su IP pubblici sono disabilitate.")
    for allowed in settings.allowed_networks:
        if target_ip in allowed:
            return
    raise ValidationError("Target fuori da SCAN_ALLOWED_CIDRS.")
