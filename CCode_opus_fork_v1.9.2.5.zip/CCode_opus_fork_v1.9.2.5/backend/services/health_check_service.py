from __future__ import annotations

from datetime import datetime
from ipaddress import ip_address
import re
import socket
import time
from urllib.parse import urlparse

import requests

from config import settings
from models import Repository
from services.alert_engine import AlertEngine
from services.connectivity_service import ping_target
from services.validation_service import ValidationError, validate_protocol, validate_target, validate_http_url


_DISPLAY_TEXT = re.compile(r"^[A-Za-z0-9 _.:@/-]{1,120}$")


class HealthCheckService:
    def __init__(self, repository: Repository):
        self.repository = repository
        self.alert_engine = AlertEngine(repository)

    def create_check(self, payload: dict, actor: dict | None = None, ip_address: str | None = None, user_agent: str | None = None) -> dict:
        check = self._validate_check_payload(payload)
        check_id = self.repository.create_health_check(
            name=check["name"],
            target=check["target"],
            check_type=check["check_type"],
            port=check["port"],
            label=check["label"],
            service_label=check["service_label"],
            interval_seconds=check["interval_seconds"],
            timeout_seconds=check["timeout_seconds"],
            enabled=check["enabled"],
            permanent=check["permanent"],
            created_by_user_id=(actor or {}).get("id"),
        )
        self.repository.write_audit(
            "health_check_created",
            f"target={check['target']} type={check['check_type']} port={check['port']} permanent={check['permanent']} ip={ip_address} ua={user_agent}",
            actor=(actor or {}).get("username", "system"),
        )
        return self.repository.get_health_check(check_id) or {"id": check_id}

    def update_check(self, check_id: int, payload: dict, actor: dict | None = None, ip_address: str | None = None, user_agent: str | None = None) -> dict:
        existing = self.repository.get_health_check(check_id)
        if not existing:
            raise ValidationError("Health check non trovato.")

        merged = {
            "name": payload.get("name", existing["name"]),
            "target": payload.get("target", existing["target"]),
            "check_type": payload.get("check_type", existing["check_type"]),
            "port": payload.get("port", existing["port"]),
            "label": payload.get("label", existing.get("label")),
            "service_label": payload.get("service_label", existing.get("service_label") or existing.get("label")),
            "interval_seconds": payload.get("interval_seconds", existing["interval_seconds"]),
            "timeout_seconds": payload.get("timeout_seconds", existing["timeout_seconds"]),
            "enabled": payload.get("enabled", bool(existing["enabled"])),
            "permanent": payload.get("permanent", bool(existing.get("permanent"))),
        }
        check = self._validate_check_payload(merged)
        self.repository.update_health_check(
            check_id,
            {
                "name": check["name"],
                "target": check["target"],
                "check_type": check["check_type"],
                "port": check["port"],
                "label": check["label"],
                "service_label": check["service_label"],
                "interval_seconds": check["interval_seconds"],
                "timeout_seconds": check["timeout_seconds"],
                "enabled": 1 if check["enabled"] else 0,
                "permanent": 1 if check["permanent"] else 0,
                "updated_at": datetime.utcnow(),
            },
        )
        self.repository.write_audit(
            "health_check_updated",
            f"check_id={check_id} target={check['target']} type={check['check_type']} port={check['port']} permanent={check['permanent']} ip={ip_address} ua={user_agent}",
            actor=(actor or {}).get("username", "system"),
        )
        return self.repository.get_health_check(check_id) or {"id": check_id}

    def run_check(self, check_id: int, actor: dict | None = None, ip_address: str | None = None, user_agent: str | None = None) -> dict:
        check = self.repository.get_health_check(check_id)
        if not check:
            raise ValidationError("Health check non trovato.")

        previous_status = (check.get("last_status") or "").lower()
        result = self._execute_check(check)
        error_message = None if result["result"] == "success" else result["details"]

        self.repository.create_health_check_result(
            check_id=check_id,
            target=result["target"],
            check_type=result["type"],
            port=result.get("port"),
            result=result["result"],
            latency_ms=result["latency_ms"],
            error_message=error_message,
        )
        self.repository.create_test_result(
            target=result["target"],
            test_type=result["type"],
            result=result["result"],
            latency_ms=result["latency_ms"],
            details=result["details"],
        )

        failure_count = int(check.get("failure_count") or 0)
        failure_count = 0 if result["result"] == "success" else failure_count + 1
        self.repository.update_health_check(
            check_id,
            {
                "last_status": result["result"],
                "last_latency_ms": result["latency_ms"],
                "last_checked_at": datetime.utcnow(),
                "failure_count": failure_count,
                "updated_at": datetime.utcnow(),
            },
        )

        if result["result"] != "success":
            self.alert_engine.create_rule_hit(
                "health_check_down",
                "medium",
                f"Health check '{check['name']}' fallito su {check['target']}.",
                source="health-check",
            )
        elif previous_status == "failed":
            self.alert_engine.create_rule_hit(
                "health_check_recovered",
                "info",
                f"Health check '{check['name']}' tornato disponibile.",
                source="health-check",
            )

        self.repository.write_audit(
            "manual_health_check_started",
            f"check_id={check_id} target={check['target']} type={check['check_type']} port={check.get('port')} result={result['result']} ip={ip_address} ua={user_agent}",
            actor=(actor or {}).get("username", "system"),
        )
        return result

    def run_manual_check(self, payload: dict, actor: dict | None = None, ip_address: str | None = None, user_agent: str | None = None) -> dict:
        check = self._validate_check_payload(
            {
                **payload,
                "name": payload.get("name") or "manual-check",
                "permanent": False,
                "enabled": True,
            }
        )
        result = self._execute_check(check)
        self.repository.create_health_check_result(
            check_id=None,
            target=result["target"],
            check_type=result["type"],
            port=result.get("port"),
            result=result["result"],
            latency_ms=result["latency_ms"],
            error_message=None if result["result"] == "success" else result["details"],
        )
        self.repository.create_test_result(
            target=result["target"],
            test_type=result["type"],
            result=result["result"],
            latency_ms=result["latency_ms"],
            details=result["details"],
        )
        self.repository.write_audit(
            "manual_health_check_started",
            f"target={check['target']} type={check['check_type']} port={check.get('port')} result={result['result']} ip={ip_address} ua={user_agent}",
            actor=(actor or {}).get("username", "system"),
        )
        return result

    def run_due_checks(self) -> list[dict]:
        results = []
        for check in self.repository.list_due_health_checks():
            try:
                results.append(self.run_check(int(check["id"])))
            except Exception as exc:
                results.append({"check_id": int(check["id"]), "status": "failed", "error": str(exc)})
        return results

    def _execute_check(self, check: dict) -> dict:
        check_type = check["check_type"]
        if check_type == "icmp":
            result = ping_target(check["target"])
            return {**result, "port": None}

        if check_type == "tcp":
            return self._run_tcp_check(check["target"], int(check["port"]), int(check["timeout_seconds"]))

        return self._run_http_check(check["target"], check_type, check.get("port"), int(check["timeout_seconds"]))

    @staticmethod
    def _run_tcp_check(target: str, port: int, timeout_seconds: int) -> dict:
        validate_target(target)
        started = time.perf_counter()
        try:
            with socket.create_connection((target, port), timeout=timeout_seconds):
                pass
            latency_ms = int((time.perf_counter() - started) * 1000)
            return {
                "target": target,
                "type": "tcp",
                "port": port,
                "latency_ms": latency_ms,
                "result": "success",
                "details": f"TCP {port} raggiungibile",
            }
        except OSError as exc:
            latency_ms = int((time.perf_counter() - started) * 1000)
            return {
                "target": target,
                "type": "tcp",
                "port": port,
                "latency_ms": latency_ms,
                "result": "failed",
                "details": str(exc),
            }

    @staticmethod
    def _run_http_check(target: str, scheme: str, port: int | None, timeout_seconds: int) -> dict:
        url = HealthCheckService._build_http_target(target, scheme, port)
        started = time.perf_counter()
        # User-Agent esplicito (alcuni server rifiutano UA generici "python-requests/x").
        # allow_redirects=True così nginx redirect 301/302 contano come success se 2xx finale.
        headers = {"User-Agent": "NetVisor-HealthCheck/1.0", "Accept": "*/*"}
        try:
            response = requests.get(
                url, timeout=min(timeout_seconds, 30), verify=False,
                headers=headers, allow_redirects=True,
            )
            latency_ms = int((time.perf_counter() - started) * 1000)
            # Per i monitoring HTTP consideriamo "success" anche i 3xx/4xx perché
            # vuol dire che il server risponde — fallisce solo per 5xx o connessione.
            # Però rendiamo il dettaglio ESPLICITO così l'operatore lo vede.
            is_reachable = 100 <= response.status_code < 500
            return {
                "target": url,
                "type": scheme,
                "port": port,
                "latency_ms": latency_ms,
                "result": "success" if is_reachable else "failed",
                "details": f"HTTP {response.status_code} {response.reason}",
            }
        except requests.exceptions.ConnectionError as exc:
            latency_ms = int((time.perf_counter() - started) * 1000)
            return {
                "target": url, "type": scheme, "port": port, "latency_ms": latency_ms,
                "result": "failed",
                "details": f"Connessione rifiutata o irraggiungibile: {exc.__class__.__name__}",
            }
        except requests.exceptions.Timeout as exc:
            latency_ms = int((time.perf_counter() - started) * 1000)
            return {
                "target": url, "type": scheme, "port": port, "latency_ms": latency_ms,
                "result": "failed",
                "details": f"Timeout dopo {timeout_seconds}s ({exc.__class__.__name__})",
            }
        except requests.RequestException as exc:
            latency_ms = int((time.perf_counter() - started) * 1000)
            return {
                "target": url, "type": scheme, "port": port, "latency_ms": latency_ms,
                "result": "failed",
                "details": f"Errore HTTP: {exc.__class__.__name__}: {exc}",
            }

    def _validate_check_payload(self, payload: dict) -> dict:
        check_type = str(payload.get("check_type", "icmp")).strip().lower()
        if check_type not in {"icmp", "tcp", "http", "https"}:
            raise ValidationError("check_type non valido. Usare icmp, tcp, http o https.")

        try:
            interval_seconds = int(payload.get("interval_seconds", 60))
            timeout_seconds = int(payload.get("timeout_seconds", 5))
        except (TypeError, ValueError) as exc:
            raise ValidationError("interval_seconds e timeout_seconds devono essere interi.") from exc

        if interval_seconds <= 0 or timeout_seconds <= 0:
            raise ValidationError("interval_seconds e timeout_seconds devono essere maggiori di zero.")
        permanent = self._parse_enabled(payload.get("permanent", False))
        if permanent and interval_seconds < settings.min_job_interval_seconds:
            raise ValidationError(
                f"interval_seconds deve essere almeno {settings.min_job_interval_seconds} secondi per monitor permanenti."
            )

        port = payload.get("port")
        if port in {"", None}:
            port = None
        elif not str(port).isdigit() or not 1 <= int(port) <= 65535:
            raise ValidationError("Porta non valida.")
        else:
            port = int(port)

        target = str(payload.get("target") or "").strip()
        if not target:
            raise ValidationError("Target obbligatorio.")

        if check_type in {"icmp", "tcp"}:
            target = validate_target(target)
        else:
            self._validate_http_target(target, check_type, port)

        if check_type == "tcp" and port is None:
            raise ValidationError("La porta e obbligatoria per check TCP.")

        return {
            "name": self._validate_display_text(payload.get("name"), "Nome check"),
            "target": target,
            "check_type": check_type,
            "port": port,
            "label": self._validate_display_text(payload.get("label"), "Label", required=False),
            "service_label": self._validate_display_text(payload.get("service_label"), "Service label", required=False),
            "interval_seconds": interval_seconds,
            "timeout_seconds": timeout_seconds,
            "enabled": self._parse_enabled(payload.get("enabled", True)),
            "permanent": permanent,
        }

    @staticmethod
    def _build_http_target(target: str, scheme: str, port: int | None) -> str:
        if "://" in target:
            return target
        if ":" in target and target.count(":") == 1:
            return f"{scheme}://{target}"
        port_suffix = ""
        if port and not ((scheme == "http" and port == 80) or (scheme == "https" and port == 443)):
            port_suffix = f":{port}"
        return f"{scheme}://{target}{port_suffix}"

    @staticmethod
    def _validate_http_target(target: str, scheme: str, port: int | None) -> None:
        candidate = HealthCheckService._build_http_target(target, scheme, port)
        parsed = urlparse(candidate)
        hostname = parsed.hostname or ""
        try:
            validate_target(str(ip_address(hostname)))
        except ValueError:
            pass
        validate_http_url(candidate)

    @staticmethod
    def _parse_enabled(value) -> bool:
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in {"1", "true", "yes", "on"}

    @staticmethod
    def _validate_display_text(value, field_name: str, required: bool = True) -> str | None:
        normalized = str(value or "").strip()
        if not normalized:
            if required:
                raise ValidationError(f"{field_name} obbligatorio.")
            return None
        if len(normalized) > 120 or not _DISPLAY_TEXT.match(normalized):
            raise ValidationError(f"{field_name} contiene caratteri non consentiti.")
        return normalized
