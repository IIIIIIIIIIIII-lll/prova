from __future__ import annotations

import secrets
import string

from config import settings
from services.validation_service import ValidationError

try:
    from argon2 import PasswordHasher
    from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError
except Exception:  # pragma: no cover - fallback a bcrypt quando Argon2 non e disponibile
    PasswordHasher = None
    InvalidHashError = VerificationError = VerifyMismatchError = Exception

try:
    import bcrypt
except Exception:  # pragma: no cover - se bcrypt manca e presente Argon2, non serve fallback
    bcrypt = None


COMMON_PASSWORD_FRAGMENTS = {
    "password",
    "admin",
    "changeme",
    "qwerty",
    "letmein",
    "demopassw0rd!",
}

_argon_hasher = PasswordHasher() if PasswordHasher else None


def _apply_pepper(secret: str) -> str:
    pepper = settings.auth_pepper or ""
    return f"{pepper}{secret}" if pepper else secret


def hash_password(password: str) -> str:
    candidate = _apply_pepper(password)
    if _argon_hasher:
        return _argon_hasher.hash(candidate)
    if bcrypt is None:
        raise RuntimeError("Nessun hasher password disponibile.")
    return bcrypt.hashpw(candidate.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    candidate = _apply_pepper(password)
    if password_hash.startswith("$argon2") and _argon_hasher:
        try:
            return _argon_hasher.verify(password_hash, candidate)
        except (VerifyMismatchError, VerificationError, InvalidHashError):
            return False
    if bcrypt is None:
        return False
    try:
        return bcrypt.checkpw(candidate.encode("utf-8"), password_hash.encode("utf-8"))
    except ValueError:
        return False


def validate_password_policy(password: str, username: str | None = None) -> None:
    """Verifica policy password: 12+ char, mix case, digit, simbolo, no username,
    no fragment comune. Solleva ValidationError (subclass di ValueError) per
    fornire messaggi user-friendly al client invece di crashare con 500.

    NB: ValidationError EREDITA da ValueError, quindi `except ValueError` continua
    a funzionare (retro-compat con generate_temporary_password che catcha ValueError
    in retry loop). I caller corretti dovrebbero catchare ValidationError che
    viene tradotta dalla route a 400 Bad Request.
    """
    normalized = password or ""
    lowered = normalized.lower()
    if len(normalized) < 12:
        raise ValidationError("La password deve avere almeno 12 caratteri.")
    if not any(character.islower() for character in normalized):
        raise ValidationError("La password deve contenere almeno una lettera minuscola.")
    if not any(character.isupper() for character in normalized):
        raise ValidationError("La password deve contenere almeno una lettera maiuscola.")
    if not any(character.isdigit() for character in normalized):
        raise ValidationError("La password deve contenere almeno un numero.")
    if not any(not character.isalnum() for character in normalized):
        raise ValidationError("La password deve contenere almeno un simbolo (es. ! @ # $ % ^ & *).")
    if any(fragment in lowered for fragment in COMMON_PASSWORD_FRAGMENTS):
        raise ValidationError("La password scelta è troppo comune o prevedibile.")
    if username and username.strip() and username.strip().lower() in lowered:
        raise ValidationError("La password non deve contenere lo username.")


def generate_temporary_password(length: int = 18) -> str:
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
    while True:
        password = "".join(secrets.choice(alphabet) for _ in range(length))
        try:
            validate_password_policy(password)
            return password
        except ValueError:  # cattura ValidationError (subclass) E ValueError raw
            continue
