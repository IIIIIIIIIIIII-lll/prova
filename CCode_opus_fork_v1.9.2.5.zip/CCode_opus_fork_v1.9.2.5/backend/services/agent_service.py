from __future__ import annotations

from datetime import UTC, datetime, timedelta
from ipaddress import ip_address
import re
from typing import Any

from config import settings
from models import Repository
from services.alert_engine import AlertEngine
from services.validation_service import ValidationError


_SAFE_TEXT = re.compile(r"^[A-Za-z0-9 _.:@/+-]{1,255}$")


class AgentService:
    def __init__(self, repository: Repository):
        self.repository = repository
        self.alert_engine = AlertEngine(repository)

    def register(self, payload: dict[str, Any]) -> dict[str, Any]:
        agent = self._validate_registration_payload(payload)
        existing = self.repository.get_agent(agent["agent_id"])
        agent_id, created = self.repository.upsert_agent(agent)
        current = self.repository.get_agent(agent_id) or {"agent_id": agent_id}

        self._handle_recovered_if_needed(existing, current)
        if created:
            self.repository.write_audit("agent_register", f"Agent registrato: {agent_id}", actor="agent")
        return {
            "agent_id": agent_id,
            "created": created,
            "status": current.get("status", "online"),
        }

    def heartbeat(self, payload: dict[str, Any]) -> dict[str, Any]:
        agent_id = self._validate_agent_id(payload.get("agent_id"))
        agent = self._require_agent(agent_id)
        requested_status = self._validate_status(payload.get("status", "online"), {"online", "degraded"})

        self.repository.update_agent_status(agent_id, requested_status)
        refreshed = self.repository.get_agent(agent_id) or agent
        self._handle_recovered_if_needed(agent, refreshed)
        return {"agent_id": agent_id, "status": requested_status, "timestamp": self._parse_timestamp(payload.get("timestamp"))}

    def ingest_metrics(self, payload: dict[str, Any]) -> dict[str, Any]:
        agent_id = self._validate_agent_id(payload.get("agent_id"))
        agent = self._require_agent(agent_id)

        cpu_percent = self._validate_percent(payload.get("cpu_percent"), "cpu_percent")
        ram_percent = self._validate_percent(payload.get("ram_percent"), "ram_percent")
        disk_percent = self._validate_percent(payload.get("disk_percent"), "disk_percent")
        uptime_seconds = self._validate_non_negative_int(payload.get("uptime_seconds"), "uptime_seconds")

        self.repository.create_agent_metric(agent_id, cpu_percent, ram_percent, disk_percent, uptime_seconds)
        self.repository.update_agent_status(agent_id, "online")
        refreshed = self.repository.get_agent(agent_id) or agent
        self._handle_recovered_if_needed(agent, refreshed)
        self._evaluate_metric_thresholds(refreshed, cpu_percent, ram_percent, disk_percent)
        return {
            "agent_id": agent_id,
            "cpu_percent": cpu_percent,
            "ram_percent": ram_percent,
            "disk_percent": disk_percent,
            "uptime_seconds": uptime_seconds,
        }

    def ingest_services(self, payload: dict[str, Any]) -> dict[str, Any]:
        agent_id = self._validate_agent_id(payload.get("agent_id"))
        agent = self._require_agent(agent_id)
        services = payload.get("services")
        if not isinstance(services, list) or not services:
            raise ValidationError("services deve essere una lista non vuota.")
        if len(services) > 50:
            raise ValidationError("services supera il limite massimo di 50 elementi.")

        normalized = []
        for item in services:
            if not isinstance(item, dict):
                raise ValidationError("Ogni servizio deve essere un oggetto JSON.")
            normalized.append(
                {
                    "service_name": self._validate_text(item.get("service_name"), "service_name"),
                    "display_name": self._validate_text(item.get("display_name"), "display_name", required=False),
                    "status": self._validate_status(item.get("status"), {"running", "stopped", "unknown"}),
                    "checked_at": self._parse_timestamp(item.get("checked_at")),
                }
            )

        self.repository.replace_agent_services(agent_id, normalized)
        self.repository.update_agent_status(agent_id, "online")
        refreshed = self.repository.get_agent(agent_id) or agent
        self._handle_recovered_if_needed(agent, refreshed)

        for item in normalized:
            service_label = item.get("display_name") or item["service_name"]
            if item["status"] == "stopped":
                self._ensure_agent_alert(
                    agent_id,
                    "agent_service_stopped",
                    "medium",
                    f"[agent:{agent_id}] Servizio fermo su {refreshed.get('hostname') or agent_id}: {service_label}.",
                    source="agent-service",
                )
            else:
                self._close_agent_alerts(agent_id, "agent_service_stopped", contains=service_label)

        return {"agent_id": agent_id, "services_received": len(normalized)}

    def ingest_events(self, payload: dict[str, Any]) -> dict[str, Any]:
        agent_id = self._validate_agent_id(payload.get("agent_id"))
        agent = self._require_agent(agent_id)
        events = payload.get("events")
        if not isinstance(events, list) or not events:
            raise ValidationError("events deve essere una lista non vuota.")
        if len(events) > 50:
            raise ValidationError("events supera il limite massimo di 50 elementi.")

        inserted = 0
        for item in events:
            if not isinstance(item, dict):
                raise ValidationError("Ogni evento deve essere un oggetto JSON.")
            source = self._validate_text(item.get("source") or "agent", "source", max_length=100)
            level = self._validate_status(item.get("level"), {"info", "warning", "error", "critical"})
            message = self._validate_text(item.get("message"), "message", max_length=800)
            event_time = self._parse_timestamp(item.get("event_time")) or datetime.now(UTC)
            self.repository.create_agent_event(agent_id, source, level, message, event_time)
            inserted += 1

        self.repository.update_agent_status(agent_id, "online")
        refreshed = self.repository.get_agent(agent_id) or agent
        self._handle_recovered_if_needed(agent, refreshed)

        error_events = self.repository.count_recent_agent_error_events(agent_id, minutes=15)
        if error_events >= settings.agent_event_error_threshold:
            self._ensure_agent_alert(
                agent_id,
                "agent_repeated_errors",
                "high",
                f"[agent:{agent_id}] Burst di eventi error/critical rilevato su {refreshed.get('hostname') or agent_id}: {error_events} eventi negli ultimi 15 minuti.",
                source="agent-events",
            )

        return {"agent_id": agent_id, "events_received": inserted, "recent_error_events": error_events}

    def list_agents(self) -> list[dict[str, Any]]:
        self.refresh_presence()
        return self.repository.list_agents()

    def get_agent_detail(self, agent_id: str) -> dict[str, Any]:
        self.refresh_presence()
        agent = self.repository.get_agent(agent_id)
        if not agent:
            raise ValidationError("Agent non trovato.")
        return {
            "agent": agent,
            "metrics": self.repository.get_agent_metrics(agent_id),
            "services": self.repository.get_agent_services(agent_id),
            "events": self.repository.get_agent_events(agent_id),
            "alerts": self.repository.get_agent_alerts(agent_id),
        }

    def refresh_presence(self) -> dict[str, int]:
        offline_marked = 0
        now = datetime.now(UTC)
        threshold = timedelta(seconds=max(settings.agent_offline_seconds, 30))
        for agent in self.repository.list_agents():
            last_seen = self._coerce_datetime(agent.get("last_seen"))
            if not last_seen:
                continue
            is_stale = now - last_seen >= threshold
            if is_stale and (agent.get("status") or "").lower() != "offline":
                self.repository.update_agent_status(agent["agent_id"], "offline", touch_last_seen=False)
                self._ensure_agent_alert(
                    agent["agent_id"],
                    "agent_offline",
                    "high",
                    f"[agent:{agent['agent_id']}] Agent offline: {agent.get('hostname') or agent['agent_id']} non invia heartbeat da oltre {settings.agent_offline_seconds} secondi.",
                    source="agent-heartbeat",
                )
                offline_marked += 1
        return {"offline_marked": offline_marked}

    def _evaluate_metric_thresholds(self, agent: dict[str, Any], cpu_percent: float, ram_percent: float, disk_percent: float) -> None:
        agent_id = agent["agent_id"]
        agent_label = agent.get("hostname") or agent_id

        thresholds = [
            ("agent_cpu_high", cpu_percent, settings.agent_cpu_high_threshold, "CPU"),
            ("agent_ram_high", ram_percent, settings.agent_ram_high_threshold, "RAM"),
            ("agent_disk_high", disk_percent, settings.agent_disk_high_threshold, "Disk"),
        ]
        for alert_type, value, threshold, label in thresholds:
            description = f"[agent:{agent_id}] {label} alta su {agent_label}: {value:.1f}%."
            if value >= threshold:
                self._ensure_agent_alert(agent_id, alert_type, "medium", description, source="agent-metrics")
            else:
                self._close_agent_alerts(agent_id, alert_type)

    def _handle_recovered_if_needed(self, previous_agent: dict[str, Any] | None, current_agent: dict[str, Any]) -> None:
        previous_status = (previous_agent or {}).get("status", "").lower()
        current_status = (current_agent or {}).get("status", "").lower()
        if previous_status == "offline" and current_status == "online":
            self._close_agent_alerts(current_agent["agent_id"], "agent_offline")
            self._ensure_agent_alert(
                current_agent["agent_id"],
                "agent_recovered",
                "info",
                f"[agent:{current_agent['agent_id']}] Agent tornato online: {current_agent.get('hostname') or current_agent['agent_id']}.",
                source="agent-heartbeat",
            )

    def _ensure_agent_alert(self, agent_id: str, alert_type: str, severity: str, description: str, source: str) -> None:
        for alert in self.repository.get_agent_alerts(agent_id, limit=100):
            if alert["type"] == alert_type and alert["status"] in {"open", "ack"} and alert["description"] == description:
                return
        self.alert_engine.create_rule_hit(alert_type, severity, description, source=source)

    def _close_agent_alerts(self, agent_id: str, alert_type: str, contains: str | None = None) -> None:
        for alert in self.repository.get_agent_alerts(agent_id, limit=100):
            if alert["type"] != alert_type or alert["status"] not in {"open", "ack"}:
                continue
            if contains and contains not in alert["description"]:
                continue
            self.repository.update_alert_status(int(alert["id"]), "closed")

    def _require_agent(self, agent_id: str) -> dict[str, Any]:
        agent = self.repository.get_agent(agent_id)
        if not agent:
            raise ValidationError("Agent non registrato.")
        return agent

    def _validate_registration_payload(self, payload: dict[str, Any]) -> dict[str, Any]:
        ip_value = str(payload.get("ip") or payload.get("ip_address") or "").strip()
        if not ip_value:
            raise ValidationError("ip locale obbligatorio.")
        try:
            parsed_ip = ip_address(ip_value)
        except ValueError as exc:
            raise ValidationError("IP agent non valido.") from exc
        if not settings.allow_public_scan and parsed_ip.is_global:
            raise ValidationError("IP pubblico non consentito per agent di laboratorio.")

        return {
            "agent_id": self._validate_agent_id(payload.get("agent_id")),
            "hostname": self._validate_text(payload.get("hostname"), "hostname"),
            "ip_address": str(parsed_ip),
            "os_name": self._validate_text(payload.get("os_name") or payload.get("os"), "os_name"),
            "agent_version": self._validate_text(payload.get("agent_version"), "agent_version", max_length=50),
            "status": "online",
        }

    @staticmethod
    def _validate_agent_id(value: Any) -> str:
        return AgentService._validate_text(value, "agent_id", max_length=120)

    @staticmethod
    def _validate_text(value: Any, field_name: str, max_length: int = 255, required: bool = True) -> str | None:
        normalized = str(value or "").strip()
        if not normalized:
            if required:
                raise ValidationError(f"{field_name} obbligatorio.")
            return None
        if len(normalized) > max_length or not _SAFE_TEXT.match(normalized):
            raise ValidationError(f"{field_name} contiene caratteri non consentiti.")
        return normalized

    @staticmethod
    def _validate_status(value: Any, allowed: set[str]) -> str:
        normalized = str(value or "").strip().lower()
        if normalized not in allowed:
            raise ValidationError(f"Valore non valido. Ammessi: {', '.join(sorted(allowed))}.")
        return normalized

    @staticmethod
    def _validate_percent(value: Any, field_name: str) -> float:
        try:
            percent = float(value)
        except (TypeError, ValueError) as exc:
            raise ValidationError(f"{field_name} deve essere numerico.") from exc
        if percent < 0 or percent > 100:
            raise ValidationError(f"{field_name} deve essere compreso tra 0 e 100.")
        return round(percent, 2)

    @staticmethod
    def _validate_non_negative_int(value: Any, field_name: str) -> int:
        try:
            number = int(value)
        except (TypeError, ValueError) as exc:
            raise ValidationError(f"{field_name} deve essere intero.") from exc
        if number < 0:
            raise ValidationError(f"{field_name} non puo essere negativo.")
        return number

    @staticmethod
    def _parse_timestamp(value: Any) -> datetime | None:
        if not value:
            return None
        try:
            normalized = str(value).replace("Z", "+00:00")
            parsed = datetime.fromisoformat(normalized)
        except ValueError as exc:
            raise ValidationError("Timestamp non valido. Usare ISO 8601.") from exc
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=UTC)
        return parsed.astimezone(UTC).replace(tzinfo=None)

    @staticmethod
    def _coerce_datetime(value: Any) -> datetime | None:
        if isinstance(value, datetime):
            return value if value.tzinfo else value.replace(tzinfo=UTC)
        if not value:
            return None
        try:
            parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except ValueError:
            return None
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)
