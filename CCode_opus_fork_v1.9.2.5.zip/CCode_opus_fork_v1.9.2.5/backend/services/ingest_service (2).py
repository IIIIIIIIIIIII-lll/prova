from __future__ import annotations

import json

from models import Repository
from services.alert_engine import AlertEngine


class IngestService:
    def __init__(self, repository: Repository):
        self.repository = repository
        self.alert_engine = AlertEngine(repository)

    def ingest_scan_results(
        self,
        scan_id: int | None,
        source: str,
        raw_format: str,
        raw_content: str,
        normalized_hosts: list[dict],
    ) -> dict:
        raw_log_id = self.repository.create_raw_log(source, scan_id, raw_format, raw_content)

        processed_hosts = 0
        processed_services = 0
        for host in normalized_hosts:
            existing_node = self.repository.get_node_by_ip(host["ip"])
            node_id, _is_new_host = self.repository.upsert_node(host)

            service_findings = []
            for service in host.get("services", []):
                service_id, is_new_service, previous = self.repository.upsert_service(node_id, service)
                processed_services += 1
                version_changed = bool(
                    previous
                    and (
                        (previous.get("product") or "") != (service.get("product") or "")
                        or (previous.get("version") or "") != (service.get("version") or "")
                    )
                )
                service_findings.append(
                    {
                        "service": service,
                        "service_id": service_id,
                        "is_new": is_new_service,
                        "previous": previous or {},
                        "version_changed": version_changed,
                    }
                )

            self.alert_engine.evaluate_host(
                source=source,
                host=host,
                node_id=node_id,
                raw_log_id=raw_log_id,
                existing_node=existing_node,
                service_findings=service_findings,
            )
            processed_hosts += 1

        summary = {
            "scan_id": scan_id,
            "raw_log_id": raw_log_id,
            "processed_hosts": processed_hosts,
            "processed_services": processed_services,
        }
        self.repository.write_audit("ingest_scan_results", json.dumps(summary))
        return summary

    def ingest_generic_events(self, source: str, payload_format: str, events: list[dict]) -> dict:
        raw_content = json.dumps(events, ensure_ascii=False)
        raw_log_id = self.repository.create_raw_log(source, None, payload_format, raw_content)

        created = 0
        for event in events:
            severity = event.get("severity", "info")
            message = event.get("message", "Evento generico ricevuto.")
            event_type = event.get("event_type", "generic_event")
            node_id = event.get("node_id")
            service_id = event.get("service_id")
            self.repository.create_security_event(
                source=source,
                event_type=event_type,
                node_id=node_id,
                service_id=service_id,
                severity=severity,
                message=message,
                raw_log_id=raw_log_id,
            )
            if severity in {"medium", "high", "critical"}:
                self.repository.create_alert(event_type, severity, message, node_id=node_id, service_id=service_id)
            created += 1

        self.repository.write_audit("ingest_generic_events", f"{source}: {created} eventi")
        return {"raw_log_id": raw_log_id, "created_events": created}
