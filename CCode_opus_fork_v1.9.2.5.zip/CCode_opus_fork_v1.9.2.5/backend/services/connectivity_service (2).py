from __future__ import annotations

import subprocess
import time

import requests

from config import settings
from services.validation_service import ValidationError, validate_http_url, validate_target


def ping_target(target: str) -> dict:
    validated = validate_target(target)
    started = time.perf_counter()

    command = ["ping", "-c", "1", validated]
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=settings.scan_timeout_seconds,
            check=False,
        )
    except FileNotFoundError:
        raise ValidationError("Comando ping non disponibile nel container.")

    latency_ms = int((time.perf_counter() - started) * 1000)
    result = "success" if completed.returncode == 0 else "failed"
    details = completed.stdout.strip() or completed.stderr.strip()
    return {"target": validated, "type": "ping", "latency_ms": latency_ms, "result": result, "details": details}


def http_test(url: str) -> dict:
    validated_url = validate_http_url(url)
    started = time.perf_counter()
    response = requests.get(validated_url, timeout=min(settings.scan_timeout_seconds, 10), verify=False)
    latency_ms = int((time.perf_counter() - started) * 1000)
    result = "success" if response.ok else "failed"
    return {
        "target": validated_url,
        "type": "http",
        "latency_ms": latency_ms,
        "result": result,
        "details": f"HTTP {response.status_code}",
    }
