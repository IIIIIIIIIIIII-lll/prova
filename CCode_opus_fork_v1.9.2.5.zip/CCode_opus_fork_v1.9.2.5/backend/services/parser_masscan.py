import json


def parse_masscan_json(raw_content: str) -> list[dict]:
    if not raw_content or not raw_content.strip():
        return []

    parsed = _safe_parse_json(raw_content)
    by_ip: dict[str, dict] = {}

    for item in parsed:
        ip = item.get("ip")
        ports = item.get("ports", [])
        if not ip:
            continue

        host = by_ip.setdefault(ip, {"ip": ip, "status": "online", "services": []})
        for port_info in ports:
            host["services"].append(
                {
                    "port": int(port_info.get("port", 0)),
                    "protocol": port_info.get("proto", "tcp"),
                    "state": "open",
                    "service_name": None,
                    "product": None,
                    "version": None,
                    "banner": None,
                }
            )

    return list(by_ip.values())


def _safe_parse_json(raw_content: str) -> list[dict]:
    cleaned = raw_content.strip()
    candidates = [cleaned]

    # Tenta a riparare output con virgole finali.
    candidates.append(cleaned.replace(",]", "]").replace(",}", "}"))

    # Tenta forma quasi-lineare: un oggetto JSON per riga.
    line_based = [line.strip().rstrip(",") for line in cleaned.splitlines() if line.strip()]
    if line_based and not cleaned.startswith("["):
        candidates.append("[" + ",".join(line_based) + "]")

    # Tenta a chiudere array incompleti.
    if cleaned.startswith("[") and not cleaned.endswith("]"):
        candidates.append(cleaned.rstrip(",") + "]")

    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
            if isinstance(parsed, dict):
                return [parsed]
            if isinstance(parsed, list):
                return parsed
        except json.JSONDecodeError:
            continue

    # Ultimo fallback: prova a caricare singoli oggetti.
    recovered = []
    for line in line_based:
        try:
            recovered.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return recovered
