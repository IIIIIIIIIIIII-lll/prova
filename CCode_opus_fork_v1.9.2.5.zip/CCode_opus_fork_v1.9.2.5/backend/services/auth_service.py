from __future__ import annotations

from collections import defaultdict, deque
from datetime import datetime, timedelta
import secrets

from config import settings
from models import Repository
from services.alert_engine import AlertEngine
from services.password_service import (
    generate_temporary_password,
    hash_password,
    validate_password_policy,
    verify_password,
)
from services.validation_service import ValidationError, validate_email, validate_role, validate_safe_text, validate_username
from utils.security import issue_access_token


class AuthError(Exception):
    def __init__(self, message: str, status_code: int = 400, lockout: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        # Stato lockout opzionale propagato al client per popup escalation
        # (warn → soft_lock → re_lock → disabled). Vedi auth_service._handle_failed_login.
        self.lockout = lockout


_login_attempt_windows: dict[str, deque[datetime]] = defaultdict(deque)


class AuthService:
    def __init__(self, repository: Repository):
        self.repository = repository
        self.alert_engine = AlertEngine(repository)

    def bootstrap_initial_admin_if_needed(self) -> dict | None:
        if self.repository.count_users() > 0:
            return None

        username = validate_username(settings.admin_username)
        if not settings.admin_password:
            raise RuntimeError("ADMIN_PASSWORD obbligatoria per il bootstrap del primo admin.")

        validate_password_policy(settings.admin_password, username)
        password_hash = hash_password(settings.admin_password)
        user_id = self.repository.create_user(
            username=username,
            email=None,
            display_name="Initial Administrator",
            role="admin",
            password_hash=password_hash,
            is_active=True,
            must_change_password=True,
        )
        self.repository.create_auth_audit(
            user_id=user_id,
            username=username,
            event_type="user_created",
            role="admin",
            ip_address=None,
            user_agent=None,
            success=True,
            message="Bootstrap admin creato da variabili ambiente.",
        )
        self.repository.write_audit("bootstrap_admin_user", "Creato utente admin iniziale dal bootstrap.", actor=username)
        return self.get_user_public(user_id)

    def login(self, payload: dict, ip_address: str | None, user_agent: str | None) -> dict:
        username = validate_username(payload.get("username"))
        password = payload.get("password")
        if password is None or str(password) == "":
            raise ValidationError("Password obbligatoria.")

        if self._is_login_rate_limited(username, ip_address):
            self.repository.create_auth_audit(
                user_id=None,
                username=username,
                event_type="login_failed",
                role=None,
                ip_address=ip_address,
                user_agent=user_agent,
                success=False,
                message="Rate limit login superato.",
            )
            raise AuthError("Troppi tentativi di login. Riprovare piu tardi.", 429)

        user = self.repository.get_user_by_username(username)
        generic_message = "Credenziali non valide."

        if not user or not bool(user.get("is_active")):
            self._record_failed_attempt(username, ip_address)
            self.repository.create_auth_audit(
                user_id=(user or {}).get("id"),
                username=username,
                event_type="login_failed",
                role=(user or {}).get("role"),
                ip_address=ip_address,
                user_agent=user_agent,
                success=False,
                message="Tentativo con credenziali non valide.",
            )
            raise AuthError(generic_message, 401)

        locked_until = user.get("locked_until")
        if locked_until and locked_until > datetime.utcnow():
            self._record_failed_attempt(username, ip_address)
            self.repository.create_auth_audit(
                user_id=user["id"],
                username=user["username"],
                event_type="login_failed",
                role=user["role"],
                ip_address=ip_address,
                user_agent=user_agent,
                success=False,
                message="Account temporaneamente bloccato.",
            )
            raise AuthError(generic_message, 401)

        if not verify_password(str(password), user["password_hash"]):
            self._record_failed_attempt(username, ip_address)
            lockout_state = self._handle_failed_login(user, ip_address, user_agent)
            # Messaggio specifico in base allo stato lockout, ma sempre 401.
            # NB: rivelare "username corretto, password sbagliata" è ok solo
            # quando il lockout è attivo (l'attacker già lo sa).
            msg = {
                "warn":      "Credenziali non valide. Attenzione: 3° tentativo fallito consecutivo.",
                "soft_lock": f"Account bloccato temporaneamente per {lockout_state.get('lock_minutes', 10)} minuti dopo troppi tentativi.",
                "re_lock":   f"Account ri-bloccato per {lockout_state.get('lock_minutes', 10)} minuti. Prossima riprova prematura → DISABILITAZIONE permanente.",
                "disabled":  "Account DISABILITATO. Contattare l'amministratore per la riattivazione.",
            }.get(lockout_state.get("lockout_state"), generic_message)
            raise AuthError(msg, 401, lockout=lockout_state)

        self.repository.update_user(
            int(user["id"]),
            {
                "failed_login_count": 0,
                "locked_until": None,
                "last_login_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
            },
        )

        refresh_token = self._issue_refresh_token(int(user["id"]), ip_address, user_agent)
        public_user = self._public_user(user, refresh_last_login=True)
        access_token = issue_access_token(public_user)

        self.repository.create_auth_audit(
            user_id=int(user["id"]),
            username=user["username"],
            event_type="login_success",
            role=user["role"],
            ip_address=ip_address,
            user_agent=user_agent,
            success=True,
            message="Login completato.",
        )

        response = {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "user": public_user,
        }

        if user["role"] == "admin":
            timestamp = datetime.utcnow().isoformat(timespec="seconds") + "Z"
            description = f"Admin login detected for user {user['username']} from {ip_address or 'unknown'}"
            self.repository.create_auth_audit(
                user_id=int(user["id"]),
                username=user["username"],
                event_type="admin_login",
                role="admin",
                ip_address=ip_address,
                user_agent=user_agent,
                success=True,
                message=description,
            )
            self.alert_engine.create_rule_hit("admin_login", "medium", description, source="auth")
            response["admin_login_alert"] = True
            response["admin_login_message"] = "Accesso admin registrato"
            response["admin_login_timestamp"] = timestamp
            response["admin_login_ip"] = ip_address
        else:
            response["admin_login_alert"] = False

        return response

    def logout(self, current_user: dict, refresh_token: str | None, ip_address: str | None, user_agent: str | None) -> dict:
        session_id = self._extract_refresh_session_id(refresh_token) if refresh_token else None
        if session_id is None:
            self.repository.revoke_user_sessions(int(current_user["id"]))
        else:
            self.repository.revoke_auth_session(session_id)

        self.repository.create_auth_audit(
            user_id=int(current_user["id"]),
            username=current_user["username"],
            event_type="logout",
            role=current_user["role"],
            ip_address=ip_address,
            user_agent=user_agent,
            success=True,
            message="Logout eseguito.",
        )
        return {"logged_out": True}

    def refresh(self, payload: dict, ip_address: str | None, user_agent: str | None) -> dict:
        refresh_token = validate_safe_text(payload.get("refresh_token"), "Refresh token", max_length=5000)
        if refresh_token is None:
            raise ValidationError("Refresh token obbligatorio.")
        session_id = self._extract_refresh_session_id(refresh_token)
        if session_id is None:
            self.repository.create_auth_audit(None, None, "refresh_failed", None, ip_address, user_agent, False, "Formato refresh token non valido.")
            raise AuthError("Refresh token non valido.", 401)

        session = self.repository.get_auth_session(session_id)
        if not session or session.get("revoked_at") or session.get("expires_at") < datetime.utcnow():
            self.repository.create_auth_audit(None, None, "refresh_failed", None, ip_address, user_agent, False, "Sessione refresh non valida o scaduta.")
            raise AuthError("Refresh token non valido.", 401)

        if not verify_password(refresh_token, session["refresh_token_hash"]):
            self.repository.create_auth_audit(None, None, "refresh_failed", None, ip_address, user_agent, False, "Hash refresh token non corrispondente.")
            raise AuthError("Refresh token non valido.", 401)

        user = self.repository.get_user_by_id(int(session["user_id"]))
        if not user or not bool(user.get("is_active")):
            self.repository.revoke_auth_session(session_id)
            self.repository.create_auth_audit((user or {}).get("id"), (user or {}).get("username"), "refresh_failed", (user or {}).get("role"), ip_address, user_agent, False, "Utente non attivo.")
            raise AuthError("Refresh token non valido.", 401)

        rotated_refresh_token = self._rotate_refresh_token(session_id, int(user["id"]), ip_address, user_agent)
        public_user = self._public_user(user)
        access_token = issue_access_token(public_user)
        self.repository.create_auth_audit(
            user_id=int(user["id"]),
            username=user["username"],
            event_type="refresh_success",
            role=user["role"],
            ip_address=ip_address,
            user_agent=user_agent,
            success=True,
            message="Refresh token ruotato.",
        )
        return {
            "access_token": access_token,
            "refresh_token": rotated_refresh_token,
            "user": public_user,
        }

    def get_me(self, current_user: dict) -> dict:
        fresh = self.repository.get_user_by_id(int(current_user["id"]))
        if not fresh or not bool(fresh.get("is_active")):
            raise AuthError("Utente non disponibile.", 404)
        return self._public_user(fresh)

    def change_password(self, current_user: dict, payload: dict, ip_address: str | None, user_agent: str | None) -> dict:
        current_password = payload.get("current_password")
        new_password = payload.get("new_password")
        if not current_password or not new_password:
            raise ValidationError("current_password e new_password sono obbligatori.")

        user = self.repository.get_user_by_id(int(current_user["id"]))
        if not user:
            raise AuthError("Utente non trovato.", 404)

        # ── PDF Errori_v4.2 §2.2 — IDS estesa per password change failures ──
        # Wrong current_password è un evento di sicurezza: usa la stessa state
        # machine di _handle_failed_login (3 → MEDIUM, 4 → HIGH+lock, 5 → relock,
        # 6 → CRITICAL+disable). Anche se l'utente è già loggato, un errore di
        # autenticazione qui può segnalare:
        #   - Attaccante che ha rubato la sessione ma non la password
        #   - Utente confuso con caps lock (eventi info-level via audit)
        #   - Brute force per scalare privilegi
        # Stessa logica del login: incrementa failed_login_count, alza alert,
        # blocca/disabilita l'account in escalation.
        if not verify_password(str(current_password), user["password_hash"]):
            lockout_state = self._handle_failed_login(user, ip_address, user_agent)
            msg = {
                "warn":      "Password attuale errata. Attenzione: 3° tentativo fallito.",
                "soft_lock": f"Password attuale errata ripetutamente. Account bloccato per {lockout_state.get('lock_minutes', 15)} minuti.",
                "re_lock":   f"Password attuale errata ripetutamente. Re-lock {lockout_state.get('lock_minutes', 15)} min. Prossimo errore = DISABLE.",
                "disabled":  "Account DISABILITATO per troppi errori. Contattare l'amministratore.",
            }.get(lockout_state.get("lockout_state"), "Password attuale non valida.")
            raise AuthError(msg, 401, lockout=lockout_state)

        if verify_password(str(new_password), user["password_hash"]):
            raise ValidationError("La nuova password non puo coincidere con quella attuale.")

        validate_password_policy(str(new_password), user["username"])
        self.repository.update_user(
            int(user["id"]),
            {
                "password_hash": hash_password(str(new_password)),
                "must_change_password": 0,
                "updated_at": datetime.utcnow(),
            },
        )
        self.repository.revoke_user_sessions(int(user["id"]))
        self.repository.create_auth_audit(
            user_id=int(user["id"]),
            username=user["username"],
            event_type="password_changed",
            role=user["role"],
            ip_address=ip_address,
            user_agent=user_agent,
            success=True,
            message="Password aggiornata.",
        )
        return {"password_changed": True, "reauth_required": True}

    def create_user_account(self, current_user: dict, payload: dict, ip_address: str | None, user_agent: str | None) -> dict:
        username = validate_username(payload.get("username"))
        email = validate_email(payload.get("email"), required=False)
        role = validate_role(payload.get("role"))
        display_name = validate_safe_text(payload.get("display_name"), "Display name", max_length=255, required=False)
        password = payload.get("password")
        if password is None or str(password) == "":
            raise ValidationError("Password obbligatoria.")
        validate_password_policy(str(password), username)

        if self.repository.get_user_by_username(username):
            raise ValidationError("Username gia esistente.")
        if email and self._email_exists(email):
            raise ValidationError("Email gia esistente.")

        user_id = self.repository.create_user(
            username=username,
            email=email,
            display_name=display_name,
            role=role,
            password_hash=hash_password(str(password)),
            is_active=self._parse_bool(payload.get("is_active", True)),
            must_change_password=self._parse_bool(payload.get("must_change_password", False)),
        )
        self.repository.create_auth_audit(
            user_id=user_id,
            username=username,
            event_type="user_created",
            role=role,
            ip_address=ip_address,
            user_agent=user_agent,
            success=True,
            message=f"Utente creato da {current_user['username']}.",
        )
        self.repository.write_audit("user_created", f"Creato utente {username} ruolo {role}", actor=current_user["username"])
        return self.get_user_public(user_id)

    def update_user_account(self, current_user: dict, user_id: int, payload: dict, ip_address: str | None, user_agent: str | None) -> dict:
        user = self.repository.get_user_by_id(user_id)
        if not user:
            raise AuthError("Utente non trovato.", 404)

        fields: dict = {"updated_at": datetime.utcnow()}
        if "email" in payload:
            email = validate_email(payload.get("email"), required=False)
            if email and email != user.get("email") and self._email_exists(email):
                raise ValidationError("Email gia esistente.")
            fields["email"] = email
        if "display_name" in payload:
            fields["display_name"] = validate_safe_text(payload.get("display_name"), "Display name", max_length=255, required=False)
        if "role" in payload:
            role = validate_role(payload.get("role"))
            if user["id"] == current_user["id"] and user["role"] == "admin" and role != "admin":
                raise ValidationError("Non puoi rimuovere il tuo ruolo admin.")
            if user["role"] == "admin" and role != "admin":
                self._ensure_not_last_active_admin(user)
            fields["role"] = role
        if "must_change_password" in payload:
            fields["must_change_password"] = 1 if self._parse_bool(payload.get("must_change_password")) else 0
        if "is_active" in payload:
            next_active = self._parse_bool(payload.get("is_active"))
            if user["role"] == "admin" and not next_active:
                self._ensure_not_last_active_admin(user)
            fields["is_active"] = 1 if next_active else 0

        self.repository.update_user(user_id, fields)
        updated = self.repository.get_user_by_id(user_id)
        self.repository.write_audit("user_updated", f"Aggiornato utente {updated['username']}", actor=current_user["username"])
        self.repository.create_auth_audit(
            user_id=user_id,
            username=updated["username"],
            event_type="user_updated",
            role=updated["role"],
            ip_address=ip_address,
            user_agent=user_agent,
            success=True,
            message=f"Utente aggiornato da {current_user['username']}.",
        )
        return self._public_user(updated)

    def reset_user_password(self, current_user: dict, user_id: int, payload: dict, ip_address: str | None, user_agent: str | None) -> dict:
        user = self.repository.get_user_by_id(user_id)
        if not user:
            raise AuthError("Utente non trovato.", 404)

        password = str(payload.get("new_password") or "").strip()
        generated = False
        if not password:
            password = generate_temporary_password()
            generated = True
        validate_password_policy(password, user["username"])
        if verify_password(password, user["password_hash"]):
            raise ValidationError("La nuova password non puo coincidere con quella attuale.")

        self.repository.update_user(
            user_id,
            {
                "password_hash": hash_password(password),
                "must_change_password": 1,
                "failed_login_count": 0,
                "locked_until": None,
                "updated_at": datetime.utcnow(),
            },
        )
        self.repository.revoke_user_sessions(user_id)
        self.repository.create_auth_audit(
            user_id=user_id,
            username=user["username"],
            event_type="password_changed",
            role=user["role"],
            ip_address=ip_address,
            user_agent=user_agent,
            success=True,
            message=f"Password resettata da {current_user['username']}.",
        )
        self.repository.write_audit("user_reset_password", f"Reset password per {user['username']}", actor=current_user["username"])
        return {"user_id": user_id, "temporary_password": password if generated else None, "must_change_password": True}

    def disable_user(self, current_user: dict, user_id: int, ip_address: str | None, user_agent: str | None) -> dict:
        user = self.repository.get_user_by_id(user_id)
        if not user:
            raise AuthError("Utente non trovato.", 404)
        if int(user["id"]) == int(current_user["id"]):
            raise ValidationError("Non puoi disabilitare il tuo account.")
        self._ensure_not_last_active_admin(user)

        self.repository.update_user(user_id, {"is_active": 0, "updated_at": datetime.utcnow()})
        self.repository.revoke_user_sessions(user_id)
        self.repository.create_auth_audit(
            user_id=user_id,
            username=user["username"],
            event_type="user_disabled",
            role=user["role"],
            ip_address=ip_address,
            user_agent=user_agent,
            success=True,
            message=f"Utente disabilitato da {current_user['username']}.",
        )
        self.repository.write_audit("user_disabled", f"Utente {user['username']} disabilitato", actor=current_user["username"])
        return {"user_id": user_id, "is_active": False}

    def enable_user(self, current_user: dict, user_id: int, ip_address: str | None, user_agent: str | None) -> dict:
        user = self.repository.get_user_by_id(user_id)
        if not user:
            raise AuthError("Utente non trovato.", 404)
        self.repository.update_user(user_id, {"is_active": 1, "failed_login_count": 0, "locked_until": None, "updated_at": datetime.utcnow()})
        self.repository.create_auth_audit(
            user_id=user_id,
            username=user["username"],
            event_type="user_enabled",
            role=user["role"],
            ip_address=ip_address,
            user_agent=user_agent,
            success=True,
            message=f"Utente abilitato da {current_user['username']}.",
        )
        self.repository.write_audit("user_enabled", f"Utente {user['username']} abilitato", actor=current_user["username"])
        return {"user_id": user_id, "is_active": True}

    def delete_user(self, current_user: dict, user_id: int, ip_address: str | None, user_agent: str | None) -> dict:
        user = self.repository.get_user_by_id(user_id)
        if not user:
            raise AuthError("Utente non trovato.", 404)
        if int(user["id"]) == int(current_user["id"]):
            raise ValidationError("Non puoi eliminare il tuo account.")
        self._ensure_not_last_active_admin(user)

        self.repository.create_auth_audit(
            user_id=user_id,
            username=user["username"],
            event_type="user_deleted",
            role=user["role"],
            ip_address=ip_address,
            user_agent=user_agent,
            success=True,
            message=f"Utente eliminato da {current_user['username']}.",
        )
        self.repository.write_audit("user_deleted", f"Utente {user['username']} eliminato", actor=current_user["username"])
        self.repository.delete_user(user_id)
        return {"deleted": True, "user_id": user_id}

    def list_auth_audit_entries(self, limit: int = 100) -> list[dict]:
        return self.repository.list_auth_audit(limit=limit)

    def get_user_public(self, user_id: int) -> dict:
        user = self.repository.get_user_by_id(user_id)
        if not user:
            raise AuthError("Utente non trovato.", 404)
        return self._public_user(user)

    # ── Lockout policy escalation (PDF Errori_v3 #3) ────────────────────────
    # Soglie (in numero di tentativi falliti consecutivi):
    #   3 → MEDIUM alert  (warning, no lock)
    #   4 → HIGH alert    + soft lock 10min (rearm automatico)
    #   5 → HIGH alert    + altri 10min di lock (re-armato)
    #   6 → CRITICAL alert + DISABILITAZIONE permanente account (is_active=0)
    # Costanti private — i valori sono parte del business model, non env.
    # account_lock_minutes da settings rimane il TTL del soft lock.
    _LOCK_THRESHOLD_WARN = 3       # MEDIUM
    _LOCK_THRESHOLD_LOCK = 4       # HIGH + 10min lock
    _LOCK_THRESHOLD_RELOCK = 5     # HIGH + altri 10min lock
    _LOCK_THRESHOLD_DISABLE = 6    # CRITICAL + permanent disable

    def _handle_failed_login(self, user: dict, ip_address: str | None, user_agent: str | None) -> dict:
        """Implementa la state machine di lockout.

        Ritorna un dict con `lockout_state` per la response API:
          - "warn"      → 3° fallimento, alert MEDIUM ma nessun lock
          - "soft_lock" → 4° fallimento, primo lock da 10min, popup utente
          - "re_lock"   → 5° fallimento, secondo lock da 10min, popup escalation
          - "disabled"  → 6°+ fallimento, account disabilitato, alert CRITICAL
          - "tracked"   → 1°/2° fallimento, nessun escalation (solo audit)
        """
        failed_count = int(user.get("failed_login_count") or 0) + 1
        lock_minutes = int(settings.account_lock_minutes)
        locked_until = user.get("locked_until")  # preserve esistente di default
        is_active = bool(user.get("is_active"))

        lockout_state = "tracked"
        alert_severity = None
        alert_description = None
        username = user["username"]

        if failed_count >= self._LOCK_THRESHOLD_DISABLE:
            # CRITICAL: permanente disable
            is_active = False
            locked_until = None  # non rilevante: l'account è disabilitato
            lockout_state = "disabled"
            alert_severity = "critical"
            alert_description = (
                f"Utente '{username}' DISABILITATO dopo {failed_count} tentativi falliti. "
                f"Richiesta riattivazione manuale dell'amministratore. IP={ip_address or 'unknown'}"
            )
        elif failed_count >= self._LOCK_THRESHOLD_RELOCK:
            # HIGH: re-lock 10min (refresh del lock)
            locked_until = datetime.utcnow() + timedelta(minutes=lock_minutes)
            lockout_state = "re_lock"
            alert_severity = "high"
            alert_description = (
                f"Utente '{username}' bloccato per ulteriori {lock_minutes} minuti dopo "
                f"{failed_count} tentativi. Prossima riprova prematura → DISABLE permanente. "
                f"IP={ip_address or 'unknown'}"
            )
        elif failed_count >= self._LOCK_THRESHOLD_LOCK:
            # HIGH: primo lock 10min
            locked_until = datetime.utcnow() + timedelta(minutes=lock_minutes)
            lockout_state = "soft_lock"
            alert_severity = "high"
            alert_description = (
                f"Utente '{username}' bloccato per {lock_minutes} minuti dopo "
                f"{failed_count} tentativi falliti. Soft-lock con auto-rearm. "
                f"IP={ip_address or 'unknown'}"
            )
        elif failed_count >= self._LOCK_THRESHOLD_WARN:
            # MEDIUM: warning, no lock
            lockout_state = "warn"
            alert_severity = "medium"
            alert_description = (
                f"Utente '{username}' ha 3 tentativi di login falliti consecutivi. "
                f"IP={ip_address or 'unknown'}. Nessun lock applicato (soglia warn)."
            )

        # ── Persist user state ──────────────────────────────────────────────
        update_payload = {
            "failed_login_count": failed_count,
            "locked_until": locked_until,
            "updated_at": datetime.utcnow(),
        }
        if lockout_state == "disabled":
            update_payload["is_active"] = is_active
        self.repository.update_user(int(user["id"]), update_payload)

        # ── Audit base ─────────────────────────────────────────────────────
        self.repository.create_auth_audit(
            user_id=int(user["id"]),
            username=username,
            event_type="login_failed",
            role=user["role"],
            ip_address=ip_address,
            user_agent=user_agent,
            success=False,
            message=f"Credenziali non valide (tentativo {failed_count}).",
        )

        # ── Audit + alert per escalation ───────────────────────────────────
        if alert_severity and alert_description:
            audit_event = {
                "warn": "login_threshold_warn",
                "soft_lock": "account_locked",
                "re_lock": "account_relocked",
                "disabled": "account_disabled",
            }[lockout_state]
            self.repository.create_auth_audit(
                user_id=int(user["id"]),
                username=username,
                event_type=audit_event,
                role=user["role"],
                ip_address=ip_address,
                user_agent=user_agent,
                success=False,
                message=alert_description,
            )
            # Alert nella rail destra + security event
            self.alert_engine.create_rule_hit(
                "login_anomaly", alert_severity, alert_description, source="auth",
                node_id=None,
            )

        return {
            "lockout_state": lockout_state,
            "failed_count": failed_count,
            "locked_until": locked_until.isoformat(timespec="seconds") + "Z" if locked_until else None,
            "lock_minutes": lock_minutes,
            "is_active": is_active,
        }

    def _issue_refresh_token(self, user_id: int, ip_address: str | None, user_agent: str | None) -> str:
        # Una sola passata Argon2id: creiamo la sessione con hash placeholder
        # cheap, otteniamo session_id, costruiamo raw_token = session_id.random,
        # e lo hashiamo UNA volta sola nell'UPDATE finale.
        expires_at = datetime.utcnow() + timedelta(days=int(settings.refresh_token_days))
        session_id = self.repository.create_auth_session(
            user_id=user_id,
            refresh_token_hash="__pending__",
            user_agent=user_agent,
            ip_address=ip_address,
            expires_at=expires_at,
        )
        raw_token = f"{session_id}.{secrets.token_urlsafe(64)}"
        self.repository.update_auth_session(
            session_id,
            {
                "refresh_token_hash": hash_password(raw_token),
                "last_used_at": datetime.utcnow(),
            },
        )
        return raw_token

    def _rotate_refresh_token(self, session_id: int, user_id: int, ip_address: str | None, user_agent: str | None) -> str:
        raw_token = f"{session_id}.{secrets.token_urlsafe(64)}"
        self.repository.update_auth_session(
            session_id,
            {
                "refresh_token_hash": hash_password(raw_token),
                "expires_at": datetime.utcnow() + timedelta(days=int(settings.refresh_token_days)),
                "last_used_at": datetime.utcnow(),
                "ip_address": ip_address,
                "user_agent": user_agent,
            },
        )
        self.repository.revoke_user_sessions(user_id, except_session_id=session_id)
        return raw_token

    def _extract_refresh_session_id(self, refresh_token: str | None) -> int | None:
        token = str(refresh_token or "").strip()
        prefix, separator, _rest = token.partition(".")
        if not separator or not prefix.isdigit():
            return None
        return int(prefix)

    def _is_login_rate_limited(self, username: str, ip_address: str | None) -> bool:
        key = f"{(ip_address or 'unknown').strip().lower()}::{username.strip().lower()}"
        bucket = _login_attempt_windows[key]
        now = datetime.utcnow()
        window_start = now - timedelta(minutes=10)
        while bucket and bucket[0] < window_start:
            bucket.popleft()
        return len(bucket) >= max(1, int(settings.login_rate_limit_per_minute))

    def _record_failed_attempt(self, username: str, ip_address: str | None) -> None:
        key = f"{(ip_address or 'unknown').strip().lower()}::{username.strip().lower()}"
        bucket = _login_attempt_windows[key]
        now = datetime.utcnow()
        bucket.append(now)
        window_start = now - timedelta(minutes=10)
        while bucket and bucket[0] < window_start:
            bucket.popleft()

    def _email_exists(self, email: str) -> bool:
        return bool(self.repository.fetch_one("SELECT id FROM Users WHERE email = ?", (email,)))

    def _ensure_not_last_active_admin(self, user: dict) -> None:
        if user.get("role") != "admin" or not bool(user.get("is_active")):
            return
        row = self.repository.fetch_one("SELECT COUNT(*) AS total FROM Users WHERE role = 'admin' AND is_active = 1")
        if int((row or {}).get("total") or 0) <= 1:
            raise ValidationError("Deve rimanere almeno un account admin attivo.")

    @staticmethod
    def _parse_bool(value) -> bool:
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in {"1", "true", "yes", "on"}

    @staticmethod
    def _public_user(user: dict, refresh_last_login: bool = False) -> dict:
        return {
            "id": int(user["id"]),
            "username": user["username"],
            "email": user.get("email"),
            "display_name": user.get("display_name"),
            "role": user["role"],
            "is_active": bool(user.get("is_active")),
            "must_change_password": bool(user.get("must_change_password")),
            "failed_login_count": int(user.get("failed_login_count") or 0),
            "locked_until": user.get("locked_until"),
            "last_login_at": datetime.utcnow() if refresh_last_login else user.get("last_login_at"),
            "created_at": user.get("created_at"),
            "updated_at": user.get("updated_at"),
        }
