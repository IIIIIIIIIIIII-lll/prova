import xml.etree.ElementTree as ET


def parse_nmap_xml(xml_content: str) -> list[dict]:
    if not xml_content or not xml_content.strip():
        return []

    root = ET.fromstring(xml_content)
    normalized_hosts: list[dict] = []

    for host in root.findall("./host"):
        ipv4 = None
        mac_address = None
        vendor = None

        for address in host.findall("./address"):
            addr_type = address.attrib.get("addrtype")
            if addr_type == "ipv4":
                ipv4 = address.attrib.get("addr")
            elif addr_type == "mac":
                mac_address = address.attrib.get("addr")
                vendor = address.attrib.get("vendor")

        if not ipv4:
            continue

        hostname = None
        hostname_node = host.find("./hostnames/hostname")
        if hostname_node is not None:
            hostname = hostname_node.attrib.get("name")

        status_state = "offline"
        status_node = host.find("./status")
        if status_node is not None and status_node.attrib.get("state") == "up":
            status_state = "online"

        os_guess = None
        os_node = host.find("./os/osmatch")
        if os_node is not None:
            os_guess = os_node.attrib.get("name")

        services = []
        for port_node in host.findall("./ports/port"):
            service_node = port_node.find("./service")
            state_node = port_node.find("./state")
            extra_info = service_node.attrib.get("extrainfo") if service_node is not None else None
            banner = extra_info if extra_info else None

            services.append(
                {
                    "port": int(port_node.attrib.get("portid", "0")),
                    "protocol": port_node.attrib.get("protocol", "tcp"),
                    "state": state_node.attrib.get("state", "unknown") if state_node is not None else "unknown",
                    "service_name": service_node.attrib.get("name") if service_node is not None else None,
                    "product": service_node.attrib.get("product") if service_node is not None else None,
                    "version": service_node.attrib.get("version") if service_node is not None else None,
                    "banner": banner,
                }
            )

        normalized_hosts.append(
            {
                "ip": ipv4,
                "hostname": hostname,
                "status": status_state,
                "os_guess": os_guess,
                "mac_address": mac_address,
                "vendor": vendor,
                "services": services,
            }
        )

    return normalized_hosts
