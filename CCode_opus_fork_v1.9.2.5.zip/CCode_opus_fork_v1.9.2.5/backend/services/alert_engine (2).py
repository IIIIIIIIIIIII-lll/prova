from __future__ import annotations

from models import Repository


CRITICAL_PORTS = {
    21: "FTP",
    23: "Telnet",
    445: "SMB",
    3389: "RDP",
    1433: "MSSQL",
    3306: "MySQL",
    6379: "Redis",
    9200: "Elasticsearch/OpenSearch",
}


class AlertEngine:
    def __init__(self, repository: Repository):
        self.repository = repository

    def create_rule_hit(
        self,
        alert_type: str,
        severity: str,
        description: str,
        source: str,
        node_id: int | None = None,
        service_id: int | None = None,
        raw_log_id: int | None = None,
    ):
        self.repository.create_alert(alert_type, severity, description, node_id=node_id, service_id=service_id)
        self.repository.create_security_event(
            source=source,
            event_type=alert_type,
            node_id=node_id,
            service_id=service_id,
            severity=severity,
            message=description,
            raw_log_id=raw_log_id,
        )

    def evaluate_host(
        self,
        source: str,
        host: dict,
        node_id: int,
        raw_log_id: int | None,
        existing_node: dict | None,
        service_findings: list[dict],
    ):
        if existing_node is None:
            self.create_rule_hit(
                "new_host_discovered",
                "info",
                f"Nuovo host scoperto: {host['ip']}.",
                source,
                node_id=node_id,
                raw_log_id=raw_log_id,
            )
        elif existing_node.get("status") == "online" and host.get("status") == "offline":
            self.create_rule_hit(
                "host_went_offline",
                "medium",
                f"Il nodo {host['ip']} risulta offline rispetto alla precedente osservazione.",
                source,
                node_id=node_id,
                raw_log_id=raw_log_id,
            )

        new_open_ports = 0
        for finding in service_findings:
            service = finding["service"]
            service_id = finding["service_id"]

            if finding["is_new"] and service.get("state") == "open":
                new_open_ports += 1
                self.create_rule_hit(
                    "new_open_port",
                    "medium",
                    f"Nuova porta aperta rilevata su {host['ip']}: {service['port']}/{service['protocol']}.",
                    source,
                    node_id=node_id,
                    service_id=service_id,
                    raw_log_id=raw_log_id,
                )

            if service.get("port") in CRITICAL_PORTS and service.get("state") == "open":
                self.create_rule_hit(
                    "critical_exposed_service",
                    "high",
                    f"Servizio critico esposto su {host['ip']} porta {service['port']} ({CRITICAL_PORTS[service['port']]}).",
                    source,
                    node_id=node_id,
                    service_id=service_id,
                    raw_log_id=raw_log_id,
                )

            if finding["version_changed"]:
                previous = finding["previous"]
                description = (
                    f"Versione servizio cambiata su {host['ip']} porta {service['port']}: "
                    f"{previous.get('product') or 'n/a'} {previous.get('version') or ''} -> "
                    f"{service.get('product') or 'n/a'} {service.get('version') or ''}."
                )
                self.create_rule_hit(
                    "service_version_changed",
                    "medium",
                    description.strip(),
                    source,
                    node_id=node_id,
                    service_id=service_id,
                    raw_log_id=raw_log_id,
                )

        if new_open_ports > 5:
            self.create_rule_hit(
                "too_many_new_ports",
                "high",
                f"Il nodo {host['ip']} ha aperto {new_open_ports} nuove porte in una singola scansione.",
                source,
                node_id=node_id,
                raw_log_id=raw_log_id,
            )

    def handle_scan_failed(self, source: str, scan_id: int, message: str):
        description = f"Scansione {scan_id} fallita: {message}"
        self.repository.create_alert("scan_failed", "medium", description)
        self.repository.create_security_event(source, "scan_failed", description, severity="medium")
