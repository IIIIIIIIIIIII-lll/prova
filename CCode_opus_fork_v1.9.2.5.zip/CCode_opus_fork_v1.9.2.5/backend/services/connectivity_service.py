from __future__ import annotations

import subprocess
import time

import requests

from config import settings
from services.validation_service import ValidationError, validate_http_url, validate_target


def ping_target(target: str) -> dict:
    validated = validate_target(target)
    started = time.perf_counter()

    command = ["ping", "-c", "1", validated]
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=settings.scan_timeout_seconds,
            check=False,
        )
    except FileNotFoundError:
        raise ValidationError("Comando ping non disponibile nel container.")

    latency_ms = int((time.perf_counter() - started) * 1000)
    result = "success" if completed.returncode == 0 else "failed"
    details = completed.stdout.strip() or completed.stderr.strip()
    return {"target": validated, "type": "ping", "latency_ms": latency_ms, "result": result, "details": details}


def http_test(url: str) -> dict:
    """HTTP/HTTPS smoke test: GET con timeout, ritorna sempre un dict (mai raise).

    Convenzioni:
      - input "172.23.0.4:8080" o "host.lan" → auto-prefix "http://" per UX
      - status 100..499 → success (server risponde, anche con 4xx → up & well)
      - status 5xx       → failed (server malfunzionante)
      - ConnectionError  → failed con dettaglio "Connessione rifiutata"
      - Timeout          → failed con dettaglio "Timeout dopo Ns"
      - altri requests.* → failed con classe eccezione
    Il chiamante (route /api/http-test) salva SEMPRE il risultato in Tests
    table — niente 500 silenziosi che perdono il risultato del test.
    """
    raw = (url or "").strip()
    # Auto-prefix scheme se manca: "172.23.0.4:8080" → "http://172.23.0.4:8080"
    # Solo se il valore non inizia già con http://, https:// o ftp://
    # (validate_http_url poi rifiuta tutto ciò che non è http/https).
    if raw and not raw.lower().startswith(("http://", "https://", "ftp://", "ws://")):
        raw = "http://" + raw

    validated_url = validate_http_url(raw)
    started = time.perf_counter()
    timeout_seconds = min(settings.scan_timeout_seconds, 10)
    headers = {"User-Agent": "NetVisor-HTTPTest/1.0", "Accept": "*/*"}

    try:
        response = requests.get(
            validated_url, timeout=timeout_seconds, verify=False,
            headers=headers, allow_redirects=True,
        )
        latency_ms = int((time.perf_counter() - started) * 1000)
        # 100-499 = server up (anche 4xx significa "server vivo, risorsa non
        # disponibile per quella richiesta" → l'host è raggiungibile).
        is_reachable = 100 <= response.status_code < 500
        return {
            "target": validated_url,
            "type": "http",
            "latency_ms": latency_ms,
            "result": "success" if is_reachable else "failed",
            "details": f"HTTP {response.status_code} {response.reason}".strip(),
        }
    except requests.exceptions.ConnectionError as exc:
        latency_ms = int((time.perf_counter() - started) * 1000)
        return {
            "target": validated_url, "type": "http", "latency_ms": latency_ms,
            "result": "failed",
            "details": f"Connessione rifiutata o irraggiungibile ({exc.__class__.__name__})",
        }
    except requests.exceptions.Timeout:
        latency_ms = int((time.perf_counter() - started) * 1000)
        return {
            "target": validated_url, "type": "http", "latency_ms": latency_ms,
            "result": "failed",
            "details": f"Timeout dopo {timeout_seconds}s",
        }
    except requests.RequestException as exc:
        latency_ms = int((time.perf_counter() - started) * 1000)
        return {
            "target": validated_url, "type": "http", "latency_ms": latency_ms,
            "result": "failed",
            "details": f"Errore HTTP: {exc.__class__.__name__}",
        }
