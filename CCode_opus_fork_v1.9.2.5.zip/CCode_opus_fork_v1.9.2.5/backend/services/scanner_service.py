from __future__ import annotations

import json
import os
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from config import settings
from services.parser_masscan import parse_masscan_json
from services.parser_nmap import parse_nmap_xml
from services.validation_service import validate_ports, validate_scanner, validate_target

# Persistent volume path — mounted via docker-compose named volume netvisor_scan_output
SCAN_OUTPUT_DIR = Path(os.getenv("SCAN_OUTPUT_DIR", "/app/scan_output"))


def _persist_raw_output(scanner: str, target: str, raw_output: str, raw_format: str) -> str | None:
    """Write raw scan output to named volume. Returns relative filename or None on failure."""
    try:
        SCAN_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        ext = "xml" if raw_format == "xml" else "json"
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        safe_target = target.replace("/", "_").replace(":", "-")
        filename = f"{ts}_{scanner}_{safe_target}.{ext}"
        (SCAN_OUTPUT_DIR / filename).write_text(raw_output, encoding="utf-8")
        return filename
    except Exception:
        return None


def run_scan(scanner: str, target: str, ports: str | None, mode: str = "safe", protocol: str = "tcp") -> dict:
    """Esegue una scansione single-scanner.

    Parametri:
      - protocol: "tcp" (default) usa -sT (no raw socket) — funziona in Docker
                  non-root out-of-the-box. "udp" usa -sU (RAW socket richiesto:
                  serve CAP_NET_RAW + setcap sul binario nmap, vedi Dockerfile).
    """
    validated_scanner = validate_scanner(scanner)
    validated_target = validate_target(target)
    port_list = validate_ports(ports)
    normalized_ports = ",".join(str(port) for port in port_list) if port_list else "22,80,443,8080,8443"
    proto = (protocol or "tcp").strip().lower()
    if proto not in {"tcp", "udp"}:
        proto = "tcp"
    scan_mode = (mode or "safe").strip().lower()
    if scan_mode not in {"safe", "aggressive"}:
        scan_mode = "safe"

    if validated_scanner == "nmap":
        raw_output = _run_nmap(validated_target, normalized_ports, protocol=proto, mode=scan_mode)
        normalized = parse_nmap_xml(raw_output)
        output_file = _persist_raw_output("nmap", validated_target, raw_output, "xml")
        # Conta vulnerabilità trovate (NSE script output presenti)
        vuln_count = sum(
            1 for h in normalized for s in h.get("services", [])
            for sc in s.get("scripts", []) if sc.get("cves") or sc.get("output_excerpt")
        ) if scan_mode == "aggressive" else 0
        summary_extra = f" — {vuln_count} script hit" if vuln_count else ""
        return {
            "raw_output": raw_output,
            "raw_format": "xml",
            "normalized_hosts": normalized,
            "summary": f"Scansione Nmap ({proto.upper()}/{scan_mode}) completata su {validated_target}{summary_extra}.",
            "output_file": output_file,
            "mode": scan_mode,
            "protocol": proto,
        }

    # Masscan: -p per TCP, -pU per UDP (sintassi nativa masscan)
    raw_output = _run_masscan(validated_target, normalized_ports, protocol=proto)
    normalized = parse_masscan_json(raw_output)
    output_file = _persist_raw_output("masscan", validated_target, raw_output, "json")
    return {
        "raw_output": raw_output,
        "raw_format": "json",
        "normalized_hosts": normalized,
        "summary": (
            f"Scansione Masscan ({proto.upper()}) completata su {validated_target}. "
            "Follow-up Nmap mirato disponibile sui soli IP/porte trovati."
        ),
        "output_file": output_file,
        "mode": mode,
        "protocol": proto,
    }



def run_combined_scan(target: str, ports: str | None, mode: str = "safe", protocol: str = "tcp") -> dict:
    """
    Pipeline masscan → nmap (con fallback automatico a nmap-only):
    1. Tenta masscan per discovery veloce host/porte (TCP o UDP).
    2. Se masscan non disponibile (non-root in Docker, permessi raw socket),
       cade in fallback nmap-only trasparente — nessun errore esposto.
    3. Se masscan trova host, esegue nmap -sV/-sU sui soli host/porte trovati.
    4. Merge normalized_hosts + persist output raw nel volume.

    protocol: "tcp" o "udp". UDP richiede CAP_NET_RAW + setcap su nmap/masscan.
    """
    validated_target = validate_target(target)
    port_list = validate_ports(ports)
    normalized_ports = ",".join(str(p) for p in port_list) if port_list else "22,80,443,8080,8443"
    proto = (protocol or "tcp").strip().lower()
    if proto not in {"tcp", "udp"}:
        proto = "tcp"
    scan_mode = (mode or "safe").strip().lower()
    if scan_mode not in {"safe", "aggressive"}:
        scan_mode = "safe"

    # --- Phase 1: masscan discovery (graceful fallback se non disponibile) ---
    # masscan richiede raw socket (CAP_NET_RAW) e fallisce silenziosamente
    # in container Docker con utente non-root. Il fallback a nmap-only
    # garantisce il funzionamento out-of-the-box senza modifiche al compose.
    masscan_ok = False
    raw_masscan: str | None = None
    masscan_file: str | None = None
    masscan_hosts: list[dict] = []
    ip_ports: dict[str, set[int]] = {}

    try:
        raw_masscan = _run_masscan(validated_target, normalized_ports, protocol=proto)
        masscan_file = _persist_raw_output("masscan", validated_target, raw_masscan, "json")
        masscan_hosts = parse_masscan_json(raw_masscan)

        for host in masscan_hosts:
            ip = host.get("ip")
            if not ip:
                continue
            for svc in host.get("services", []):
                p = svc.get("port")
                if p:
                    ip_ports.setdefault(ip, set()).add(int(p))

        masscan_ok = bool(ip_ports)  # True solo se ha trovato almeno un host/porta
    except Exception:
        # masscan non disponibile (permessi, Docker network) → fallback nmap
        masscan_ok = False

    if masscan_ok:
        # --- Phase 2: nmap single-invocation on all found IPs ---
        all_ports = sorted({p for ports_set in ip_ports.values() for p in ports_set})
        nmap_ports = ",".join(str(p) for p in all_ports) if all_ports else normalized_ports
        nmap_targets = list(ip_ports.keys())

        raw_nmap = _run_nmap_multi(nmap_targets, nmap_ports, protocol=proto, mode=scan_mode)
        nmap_file = _persist_raw_output("nmap", validated_target, raw_nmap, "xml")
        nmap_hosts = parse_nmap_xml(raw_nmap)

        # --- Phase 3: merge — nmap data wins (richer), masscan fills gaps ---
        nmap_by_ip = {h.get("ip"): h for h in nmap_hosts if h.get("ip")}
        masscan_by_ip = {h.get("ip"): h for h in masscan_hosts if h.get("ip")}
        merged: list[dict] = []
        for ip in {*nmap_by_ip, *masscan_by_ip}:
            if ip in nmap_by_ip:
                host = dict(nmap_by_ip[ip])
                if not host.get("hostname") and masscan_by_ip.get(ip, {}).get("hostname"):
                    host["hostname"] = masscan_by_ip[ip]["hostname"]
                merged.append(host)
            else:
                merged.append(masscan_by_ip[ip])

        hosts_found = len(ip_ports)
        summary = (
            f"Pipeline Masscan→Nmap completata su {validated_target}. "
            f"Masscan: {hosts_found} host attivi, {len(all_ports)} porte aggregate. "
            f"Nmap: {len(nmap_hosts)} host con service detection."
        )
        return {
            "raw_output": raw_nmap,
            "raw_output_masscan": raw_masscan,
            "raw_format": "xml",
            "normalized_hosts": merged,
            "output_file": nmap_file,
            "output_file_masscan": masscan_file,
            "mode": mode,
            "pipeline": "combined",
            "masscan_hosts_found": hosts_found,
            "nmap_hosts_enriched": len(nmap_hosts),
            "summary": summary,
        }

    # --- Fallback nmap-only (masscan non disponibile o 0 host trovati) ---
    raw_nmap = _run_nmap(validated_target, normalized_ports, protocol=proto, mode=scan_mode)
    nmap_file = _persist_raw_output("nmap", validated_target, raw_nmap, "xml")
    nmap_hosts = parse_nmap_xml(raw_nmap)

    if not masscan_ok and raw_masscan is None:
        # masscan ha sollevato eccezione — nmap ha fatto tutto
        pipeline_label = "nmap_only"
        summary = (
            f"Nmap completato su {validated_target} "
            f"(masscan non disponibile in questo ambiente: raw socket non accessibili). "
            f"{len(nmap_hosts)} host trovati."
        )
    else:
        # masscan ha girato ma trovato 0 host — nmap conferma
        pipeline_label = "masscan_nmap_no_hosts"
        summary = (
            f"Pipeline completata su {validated_target}: "
            f"Masscan 0 host, Nmap {len(nmap_hosts)} host trovati."
        )

    return {
        "raw_output": raw_nmap,
        "raw_output_masscan": raw_masscan,
        "raw_format": "xml",
        "normalized_hosts": nmap_hosts,
        "output_file": nmap_file,
        "output_file_masscan": masscan_file,
        "mode": mode,
        "pipeline": pipeline_label,
        "masscan_hosts_found": 0,
        "nmap_hosts_enriched": len(nmap_hosts),
        "summary": summary,
    }


def _build_nmap_command(target_or_targets, ports: str, protocol: str, mode: str) -> list[str]:
    """Costruisce il comando nmap in base a protocol e mode (DRY tra single/multi)."""
    targets = target_or_targets if isinstance(target_or_targets, list) else [target_or_targets]
    if protocol == "udp":
        cmd = ["nmap", "-sU", "-Pn", "-sV", "--version-light", "--max-retries", "1"]
    else:
        cmd = ["nmap", "-sT", "-Pn", "-sV", "--version-light"]

    # Mode "aggressive" → aggiunge NSE scripts default + vuln (CVE detection).
    # Lista whitelist invece di --script "vuln" generico:
    #  - default         → equivalente a -sC, sondaggi banner-grabbing leggeri
    #  - vuln            → vulnerability detection (es. http-vuln-*, smb-vuln-*)
    #  - safe            → script che NON modificano lo stato del target
    # Esclude "intrusive", "exploit", "dos" che possono essere distruttivi.
    if mode == "aggressive":
        cmd += ["--script", "default,vuln,safe"]
        # Aumenta timeout per script: vuln scripts possono richiedere 30-60s/host.
        # Ogni script ha il suo timeout interno, ma --script-timeout è il cap.
        cmd += ["--script-timeout", "30s"]

    cmd += ["-oX", "-", "-p", ports, *targets]
    return cmd


def _run_nmap(target: str, ports: str, protocol: str = "tcp", mode: str = "safe") -> str:
    """Esecuzione Nmap su singolo target — service detection con flag Docker-friendly.

    Flags TCP (default):
      -sT   TCP connect scan (no raw socket richiesto)
      -Pn   no host discovery (ICMP richiede raw socket)
      -sV   service/version detection (no root)

    Flags UDP (protocol="udp"):
      -sU   UDP scan (RAW SOCKET richiesto — serve CAP_NET_RAW)
      -sV   service/version detection sui pacchetti UDP che rispondono
      --max-retries 1  UDP è probabilistico, riducendo retry il timeout è prevedibile

    Mode "aggressive": aggiunge --script default,vuln,safe con --script-timeout 30s
    per fare detection CVE e vulnerabilità note (NSE). Tempi 1-3min/host.

    Se nmap segnala "Operation not permitted" significa che il container non
    ha CAP_NET_RAW oppure il binario nmap non ha setcap (vedi Dockerfile).
    """
    command = _build_nmap_command(target, ports, protocol, mode)
    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=settings.scan_timeout_seconds,
        check=False,
    )
    if completed.returncode != 0:
        stderr = completed.stderr.strip()
        # Errore tipico di permessi raw socket → messaggio user-friendly
        if "requires root" in stderr.lower() or "operation not permitted" in stderr.lower():
            raise RuntimeError(
                f"Scan {protocol.upper()} richiede privilegi raw socket non disponibili "
                "(serve CAP_NET_RAW + setcap nmap nel container). "
                "Per ora usa protocol='tcp' che funziona senza root."
            )
        raise RuntimeError(stderr or "Comando Nmap fallito.")
    return completed.stdout


def _run_masscan(target: str, ports: str, protocol: str = "tcp") -> str:
    """Esecuzione Masscan — port discovery rapida in JSON per parser dedicato.

    Sintassi porta:
      - TCP: "-p 22,80,443"
      - UDP: "-pU:53,67,123"   (prefisso "U:" su masscan)
      - Mix: "-pT:80,U:53,U:67" (non usato qui — un protocol per chiamata)

    NOTA OPERATIVA: masscan richiede CAP_NET_RAW per i socket raw. In Docker
    con utente non-root la capability può non essere effettiva: il binario
    fallisce con permission denied. Il chiamante deve gestire l'eccezione e
    cadere su nmap-only — vedi run_combined_scan() per il pattern di fallback.
    """
    rate = max(100, min(int(settings.masscan_max_rate), 100000))
    port_arg = f"U:{ports}" if protocol == "udp" else ports
    command = [
        "masscan",
        "-p", port_arg,
        "--rate", str(rate),
        "-oJ", "-",
        target,
    ]
    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=settings.scan_timeout_seconds,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr.strip() or "Comando Masscan fallito.")
    return completed.stdout


def _run_nmap_multi(targets: list[str], ports: str, protocol: str = "tcp", mode: str = "safe") -> str:
    """Single nmap invocation across multiple targets — efficient multi-host scan.

    Flags identici a _run_nmap (vedi docstring). Differenza: i targets passano
    come lista finale al comando, nmap li processa in parallelo internamente.
    """
    command = _build_nmap_command(targets, ports, protocol, mode)
    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=settings.scan_timeout_seconds,
        check=False,
    )
    if completed.returncode != 0:
        stderr = completed.stderr.strip()
        if "requires root" in stderr.lower() or "operation not permitted" in stderr.lower():
            raise RuntimeError(
                f"Scan {protocol.upper()} multi-target richiede privilegi raw socket."
            )
        raise RuntimeError(stderr or "Comando Nmap multi-target fallito.")
    return completed.stdout
