from __future__ import annotations

from datetime import datetime, timedelta
import re

from config import settings
from models import Repository
from services.alert_engine import AlertEngine
from services.ingest_service import IngestService
from services.scanner_service import run_combined_scan, run_scan
from services.validation_service import (
    ValidationError,
    validate_scan_mode,
    validate_scanner,
    validate_protocol,
    validate_target,
    validate_ports,
)

_DISPLAY_TEXT = re.compile(r"^[A-Za-z0-9 _.:@/-]{1,120}$")


class ScanJobService:
    def __init__(self, repository: Repository):
        self.repository = repository
        self.ingest_service = IngestService(repository)
        self.alert_engine = AlertEngine(repository)

    def create_job(self, payload: dict, actor: dict | None = None, ip_address: str | None = None, user_agent: str | None = None) -> dict:
        job = self._validate_job_payload(payload)
        next_run_at = self._compute_next_run_at(job["mode"], job["interval_seconds"], job["enabled"], job["permanent"])
        job_id = self.repository.create_scan_job(
            name=job["name"],
            scanner=job["scanner"],
            target=job["target"],
            ports=job["ports"],
            protocol=job["protocol"],
            mode=job["mode"],
            interval_seconds=job["interval_seconds"],
            enabled=job["enabled"],
            permanent=job["permanent"],
            created_by_user_id=(actor or {}).get("id"),
            next_run_at=next_run_at,
        )
        self.repository.write_audit(
            "scan_job_created",
            f"target={job['target']} ports={job['ports']} protocol={job['protocol']} validation=ok ip={ip_address} ua={user_agent}",
            actor=(actor or {}).get("username", "system"),
        )
        return self.repository.get_scan_job(job_id) or {"id": job_id}

    def update_job(self, job_id: int, payload: dict, actor: dict | None = None, ip_address: str | None = None, user_agent: str | None = None) -> dict:
        existing = self.repository.get_scan_job(job_id)
        if not existing:
            raise ValidationError("Scan job non trovato.")

        merged = {
            "name": payload.get("name", existing["name"]),
            "scanner": payload.get("scanner", existing["scanner"]),
            "target": payload.get("target", existing["target"]),
            "ports": payload.get("ports", existing["ports"]),
            "protocol": payload.get("protocol", existing.get("protocol", "tcp")),
            "mode": payload.get("mode", existing["mode"]),
            "interval_seconds": payload.get("interval_seconds", existing["interval_seconds"]),
            "enabled": payload.get("enabled", bool(existing["enabled"])),
            "permanent": payload.get("permanent", bool(existing.get("permanent"))),
        }
        job = self._validate_job_payload(merged)

        next_run_at = existing.get("next_run_at")
        if "mode" in payload or "interval_seconds" in payload or "enabled" in payload or "permanent" in payload:
            next_run_at = self._compute_next_run_at(job["mode"], job["interval_seconds"], job["enabled"], job["permanent"])

        self.repository.update_scan_job(
            job_id,
            {
                "name": job["name"],
                "scanner": job["scanner"],
                "target": job["target"],
                "ports": job["ports"],
                "protocol": job["protocol"],
                "mode": job["mode"],
                "interval_seconds": job["interval_seconds"],
                "enabled": 1 if job["enabled"] else 0,
                "permanent": 1 if job["permanent"] else 0,
                "next_run_at": next_run_at,
                "updated_at": datetime.utcnow(),
            },
        )
        self.repository.write_audit(
            "scan_job_updated",
            f"job_id={job_id} target={job['target']} ports={job['ports']} protocol={job['protocol']} validation=ok ip={ip_address} ua={user_agent}",
            actor=(actor or {}).get("username", "system"),
        )
        return self.repository.get_scan_job(job_id) or {"id": job_id}

    def run_manual_scan(self, payload: dict, actor: dict | None = None, ip_address: str | None = None, user_agent: str | None = None) -> dict:
        scanner = validate_scanner(payload.get("scanner", "nmap"))
        target = validate_target(payload.get("target"))
        ports = self._normalize_ports(validate_ports(payload.get("ports")))
        scan_mode = validate_scan_mode(payload.get("mode", "safe"))
        protocol = validate_protocol(payload.get("protocol", "tcp"), allow_udp=True)
        self.repository.write_audit(
            "manual_scan_started",
            f"scanner={scanner} target={target} ports={ports} protocol={protocol} validation=ok ip={ip_address} ua={user_agent}",
            actor=(actor or {}).get("username", "system"),
        )
        if scanner == "combined":
            return self._execute_combined_scan(target=target, ports=ports, scan_mode=scan_mode, protocol=protocol)
        return self._execute_scan(scanner=scanner, target=target, ports=ports, scan_mode=scan_mode, protocol=protocol)

    def run_job(self, job_id: int, actor: dict | None = None) -> dict:
        job = self.repository.get_scan_job(job_id)
        if not job:
            raise ValidationError("Scan job non trovato.")

        run_id = self.repository.create_scan_job_run(
            job_id,
            job["scanner"],
            job["target"],
            job["ports"],
            protocol=job.get("protocol", "tcp"),
            status="queued",
        )
        self.repository.mark_scan_job_run_started(run_id)
        self.repository.update_scan_job(
            job_id,
            {
                "last_status": "running",
                "last_started_at": datetime.utcnow(),
                "last_error": None,
                "updated_at": datetime.utcnow(),
            },
        )
        previous_status = (job.get("last_status") or "").lower()

        try:
            if job["scanner"] == "combined":
                result = self._execute_combined_scan(
                    target=job["target"],
                    ports=job["ports"],
                    scan_mode="safe",
                    protocol=job.get("protocol", "tcp"),
                )
            else:
                result = self._execute_scan(
                    scanner=job["scanner"],
                    target=job["target"],
                    ports=job["ports"],
                    scan_mode="safe",
                    protocol=job.get("protocol", "tcp"),
                )
            self.repository.finalize_scan_job_run(
                run_id,
                "completed",
                result_summary=result["summary"],
                raw_log_id=((result.get("ingest") or {}).get("raw_log_id"))
            )
            self.repository.update_scan_job(
                job_id,
                {
                    "last_status": "completed",
                    "last_finished_at": datetime.utcnow(),
                    "next_run_at": self._compute_next_run_at(
                        job["mode"], job.get("interval_seconds"), bool(job["enabled"]), bool(job.get("permanent"))
                    ),
                    "last_error": None,
                    "updated_at": datetime.utcnow(),
                },
            )
            if previous_status == "failed":
                self.alert_engine.create_rule_hit(
                    "scan_job_recovered",
                    "info",
                    f"Scan job '{job['name']}' tornato operativo.",
                    source=job["scanner"],
                )
            self.repository.write_audit(
                "run_scan_job",
                f"job_id={job_id} run_id={run_id} target={job['target']} ports={job['ports']} protocol={job.get('protocol', 'tcp')}",
                actor=(actor or {}).get("username", "system"),
            )
            return {"job_id": job_id, "run_id": run_id, **result}
        except Exception as exc:
            self.repository.finalize_scan_job_run(run_id, "failed", error_message=str(exc))
            self.repository.update_scan_job(
                job_id,
                {
                    "last_status": "failed",
                    "last_finished_at": datetime.utcnow(),
                    "next_run_at": self._compute_next_run_at(
                        job["mode"], job.get("interval_seconds"), bool(job["enabled"]), bool(job.get("permanent"))
                    ),
                    "last_error": str(exc),
                    "updated_at": datetime.utcnow(),
                },
            )
            self.alert_engine.create_rule_hit(
                "scan_job_failed",
                "medium",
                f"Scan job '{job['name']}' fallito: {exc}",
                source=job["scanner"],
            )
            raise

    def run_due_jobs(self) -> list[dict]:
        results = []
        for job in self.repository.list_due_scan_jobs():
            try:
                results.append(self.run_job(int(job["id"])))
            except Exception as exc:
                results.append({"job_id": int(job["id"]), "status": "failed", "error": str(exc)})
        return results

    @staticmethod
    def _normalize_ports(port_list: list[int]) -> str:
        # "1-1024" come fallback supererebbe MAX_SCAN_PORTS=25 e farebbe
        # fallire la validazione al momento dell'esecuzione del job.
        # Usiamo un set di porte comuni ragionevole come default sicuro.
        return ",".join(str(port) for port in port_list) if port_list else "22,80,443,8080,8443"

    def _execute_combined_scan(self, target: str, ports: str, scan_mode: str, protocol: str = "tcp") -> dict:
        scan_id = self.repository.create_scan("combined", target, ports, "queued")
        self.repository.mark_scan_started(scan_id)
        try:
            result = run_combined_scan(target=target, ports=ports, mode=scan_mode, protocol=protocol)
            ingest = self.ingest_service.ingest_scan_results(
                scan_id=scan_id,
                source="combined",
                raw_format=result["raw_format"],
                raw_content=result["raw_output"],
                normalized_hosts=result["normalized_hosts"],
            )
            self.repository.finalize_scan(scan_id, "completed", result_summary=result["summary"])
            return {
                "scan_id": scan_id,
                "summary": result["summary"],
                "ingest": ingest,
                "protocol": protocol,
                "output_file": result.get("output_file"),
                "output_file_masscan": result.get("output_file_masscan"),
                "pipeline": result.get("pipeline"),
                "masscan_hosts_found": result.get("masscan_hosts_found"),
                "nmap_hosts_enriched": result.get("nmap_hosts_enriched"),
                "normalized_hosts": result.get("normalized_hosts", []),
            }
        except Exception as exc:
            self.repository.finalize_scan(scan_id, "failed", error_message=str(exc))
            self.alert_engine.handle_scan_failed("combined", scan_id, str(exc))
            raise

    def _execute_scan(self, scanner: str, target: str, ports: str, scan_mode: str, protocol: str = "tcp") -> dict:
        scan_id = self.repository.create_scan(scanner, target, ports, "queued")
        self.repository.mark_scan_started(scan_id)
        try:
            result = run_scan(scanner=scanner, target=target, ports=ports, mode=scan_mode, protocol=protocol)
            ingest = self.ingest_service.ingest_scan_results(
                scan_id=scan_id,
                source=scanner,
                raw_format=result["raw_format"],
                raw_content=result["raw_output"],
                normalized_hosts=result["normalized_hosts"],
            )
            self.repository.finalize_scan(scan_id, "completed", result_summary=result["summary"])
            return {"scan_id": scan_id, "summary": result["summary"], "ingest": ingest,
                    "protocol": protocol, "output_file": result.get("output_file")}
        except Exception as exc:
            self.repository.finalize_scan(scan_id, "failed", error_message=str(exc))
            self.alert_engine.handle_scan_failed(scanner, scan_id, str(exc))
            raise

    def _validate_job_payload(self, payload: dict) -> dict:
        mode = str(payload.get("mode", "one_time")).strip().lower()
        if mode not in {"one_time", "scheduled"}:
            raise ValidationError("Mode non valido. Usare 'one_time' o 'scheduled'.")

        interval_seconds = payload.get("interval_seconds")
        if mode == "scheduled":
            if interval_seconds is None:
                raise ValidationError("interval_seconds obbligatorio per job scheduled.")
            try:
                interval_seconds = int(interval_seconds)
            except (TypeError, ValueError) as exc:
                raise ValidationError("interval_seconds deve essere intero.") from exc
            if interval_seconds < settings.min_job_interval_seconds:
                raise ValidationError(
                    f"interval_seconds deve essere almeno {settings.min_job_interval_seconds} secondi."
                )
        elif interval_seconds is not None:
            interval_seconds = int(interval_seconds)

        port_list = validate_ports(payload.get("ports"))
        permanent = self._parse_enabled(payload.get("permanent", mode == "scheduled"))
        return {
            "name": self._validate_display_text(payload.get("name"), "Nome job"),
            "scanner": validate_scanner(payload.get("scanner", "nmap")),
            "target": validate_target(payload.get("target")),
            "ports": self._normalize_ports(port_list),
            "protocol": validate_protocol(payload.get("protocol", "tcp"), allow_udp=True),
            "mode": mode,
            "interval_seconds": interval_seconds,
            "enabled": self._parse_enabled(payload.get("enabled", True)),
            "permanent": permanent,
        }

    @staticmethod
    def _compute_next_run_at(mode: str, interval_seconds: int | None, enabled: bool, permanent: bool) -> datetime | None:
        if not enabled or not permanent or mode != "scheduled" or not interval_seconds:
            return None
        return datetime.utcnow() + timedelta(seconds=int(interval_seconds))

    @staticmethod
    def _parse_enabled(value) -> bool:
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in {"1", "true", "yes", "on"}

    @staticmethod
    def _validate_display_text(value, field_name: str) -> str:
        normalized = str(value or "").strip()
        if not normalized:
            raise ValidationError(f"{field_name} obbligatorio.")
        if len(normalized) > 120 or not _DISPLAY_TEXT.match(normalized):
            raise ValidationError(f"{field_name} contiene caratteri non consentiti.")
        return normalized
