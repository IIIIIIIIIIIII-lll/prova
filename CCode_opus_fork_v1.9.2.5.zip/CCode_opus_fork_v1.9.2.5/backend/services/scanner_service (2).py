from __future__ import annotations

import json
import os
import subprocess
import tempfile

from config import settings
from services.parser_masscan import parse_masscan_json
from services.parser_nmap import parse_nmap_xml
from services.validation_service import validate_ports, validate_scanner, validate_target


def run_scan(scanner: str, target: str, ports: str | None, mode: str = "safe") -> dict:
    validated_scanner = validate_scanner(scanner)
    validated_target = validate_target(target)
    port_list = validate_ports(ports)
    normalized_ports = ",".join(str(port) for port in port_list) if port_list else "1-1024"

    if not settings.enable_real_scan:
        return _demo_scan(validated_scanner, validated_target, normalized_ports)

    if validated_scanner == "nmap":
        raw_output = _run_nmap(validated_target, normalized_ports)
        normalized = parse_nmap_xml(raw_output)
        return {
            "raw_output": raw_output,
            "raw_format": "xml",
            "normalized_hosts": normalized,
            "summary": f"Scansione Nmap completata su {validated_target}.",
            "mode": mode,
        }

    raw_output = _run_masscan(validated_target, normalized_ports)
    normalized = parse_masscan_json(raw_output)
    return {
        "raw_output": raw_output,
        "raw_format": "json",
        "normalized_hosts": normalized,
        "summary": (
            f"Scansione Masscan completata su {validated_target}. "
            "Follow-up Nmap mirato disponibile sui soli IP/porte trovati."
        ),
        "mode": mode,
    }


def _run_nmap(target: str, ports: str) -> str:
    command = ["nmap", "-sV", "--version-light", "-oX", "-", "-p", ports, target]
    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=settings.scan_timeout_seconds,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr.strip() or "Comando Nmap fallito.")
    return completed.stdout


def _run_masscan(target: str, ports: str) -> str:
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as temp_file:
        temp_path = temp_file.name

    command = [
        "masscan",
        target,
        "-p",
        ports,
        "--rate",
        str(settings.masscan_max_rate),
        "--output-format",
        "json",
        "--output-filename",
        temp_path,
    ]
    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=settings.scan_timeout_seconds,
        check=False,
    )
    if completed.returncode not in {0, 1}:
        raise RuntimeError(completed.stderr.strip() or "Comando Masscan fallito.")

    with open(temp_path, "r", encoding="utf-8", errors="ignore") as handle:
        content = handle.read()
    try:
        os.unlink(temp_path)
    except OSError:
        pass
    if not content.strip():
        raise RuntimeError("Masscan non ha prodotto output.")
    return content


def _demo_scan(scanner: str, target: str, ports: str) -> dict:
    if scanner == "nmap":
        raw_output = f"""<?xml version="1.0"?>
<nmaprun scanner="nmap">
  <host>
    <status state="up" />
    <address addr="192.168.1.1" addrtype="ipv4" />
    <address addr="AA:BB:CC:DD:EE:01" addrtype="mac" vendor="LabVendor" />
    <hostnames><hostname name="gateway-01" /></hostnames>
    <ports>
      <port protocol="tcp" portid="80">
        <state state="open" />
        <service name="http" product="nginx" version="1.24" extrainfo="demo edge proxy" />
      </port>
      <port protocol="tcp" portid="8443">
        <state state="open" />
        <service name="https-alt" product="nginx" version="1.24" extrainfo="new open port" />
      </port>
    </ports>
    <os><osmatch name="Linux 5.x" /></os>
  </host>
  <host>
    <status state="down" />
    <address addr="192.168.1.20" addrtype="ipv4" />
    <hostnames><hostname name="fileserver-01" /></hostnames>
  </host>
  <host>
    <status state="up" />
    <address addr="192.168.1.60" addrtype="ipv4" />
    <address addr="AA:BB:CC:DD:EE:60" addrtype="mac" vendor="LabVendor" />
    <hostnames><hostname name="jump-host-01" /></hostnames>
    <ports>
      <port protocol="tcp" portid="3389">
        <state state="open" />
        <service name="ms-wbt-server" product="RDP" version="10.0" extrainfo="critical demo" />
      </port>
    </ports>
    <os><osmatch name="Windows Server 2022" /></os>
  </host>
</nmaprun>"""
        return {
            "raw_output": raw_output,
            "raw_format": "xml",
            "normalized_hosts": parse_nmap_xml(raw_output),
            "summary": f"Demo Nmap eseguita su {target} porte {ports}.",
            "mode": "demo",
        }

    raw_output = json.dumps(
        [
            {"ip": "192.168.1.1", "timestamp": "2026-01-01T10:00:00", "ports": [{"port": 443, "proto": "tcp"}]},
            {"ip": "192.168.1.50", "timestamp": "2026-01-01T10:00:02", "ports": [{"port": 445, "proto": "tcp"}]},
            {"ip": "192.168.1.80", "timestamp": "2026-01-01T10:00:04", "ports": [{"port": 22, "proto": "tcp"}]},
        ]
    )
    return {
        "raw_output": raw_output,
        "raw_format": "json",
        "normalized_hosts": parse_masscan_json(raw_output),
        "summary": f"Demo Masscan eseguita su {target} porte {ports}.",
        "mode": "demo",
    }
