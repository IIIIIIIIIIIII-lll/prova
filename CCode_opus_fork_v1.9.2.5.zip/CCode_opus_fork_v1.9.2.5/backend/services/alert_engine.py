from __future__ import annotations

from models import Repository


CRITICAL_PORTS = {
    21: "FTP",
    23: "Telnet",
    445: "SMB",
    3389: "RDP",
    1433: "MSSQL",
    3306: "MySQL",
    6379: "Redis",
    9200: "Elasticsearch/OpenSearch",
}

# Deduplication windows per alert type (minutes). Le regole su servizi esposti
# persistenti usano una finestra lunga (24h) per evitare flood ad ogni scan;
# le anomalie discrete (host offline/online, nuove porte) usano 60 min.
_DEDUP_MINUTES: dict[str, int] = {
    "critical_exposed_service": 1440,
    "service_version_changed": 120,
}
_DEFAULT_DEDUP_MINUTES = 60


class AlertEngine:
    def __init__(self, repository: Repository):
        self.repository = repository

    def create_rule_hit(
        self,
        alert_type: str,
        severity: str,
        description: str,
        source: str,
        node_id: int | None = None,
        service_id: int | None = None,
        raw_log_id: int | None = None,
    ):
        # Dedup: se esiste un alert dello stesso tipo+target ancora aperto
        # nella finestra di tempo, non ne creiamo uno nuovo.
        minutes = _DEDUP_MINUTES.get(alert_type, _DEFAULT_DEDUP_MINUTES)
        if hasattr(self.repository, "has_recent_alert") and self.repository.has_recent_alert(
            alert_type, node_id, service_id, minutes
        ):
            return
        self.repository.create_alert(alert_type, severity, description, node_id=node_id, service_id=service_id)
        self.repository.create_security_event(
            source=source,
            event_type=alert_type,
            node_id=node_id,
            service_id=service_id,
            severity=severity,
            message=description,
            raw_log_id=raw_log_id,
        )

    def evaluate_host(
        self,
        source: str,
        host: dict,
        node_id: int,
        raw_log_id: int | None,
        existing_node: dict | None,
        service_findings: list[dict],
    ):
        if existing_node is None:
            self.create_rule_hit(
                "new_host_discovered",
                "info",
                f"Nuovo host scoperto: {host['ip']}.",
                source,
                node_id=node_id,
                raw_log_id=raw_log_id,
            )
        elif existing_node.get("status") == "online" and host.get("status") == "offline":
            self.create_rule_hit(
                "host_went_offline",
                "medium",
                f"Il nodo {host['ip']} risulta offline rispetto alla precedente osservazione.",
                source,
                node_id=node_id,
                raw_log_id=raw_log_id,
            )
        elif existing_node.get("status") == "offline" and host.get("status") == "online":
            self.create_rule_hit(
                "host_came_online",
                "medium",
                f"Il nodo {host['ip']} è tornato online dopo essere stato offline.",
                source,
                node_id=node_id,
                raw_log_id=raw_log_id,
            )

        new_open_ports = 0
        for finding in service_findings:
            service = finding["service"]
            service_id = finding["service_id"]

            if finding["is_new"] and service.get("state") == "open":
                new_open_ports += 1
                self.create_rule_hit(
                    "new_open_port",
                    "medium",
                    f"Nuova porta aperta rilevata su {host['ip']}: {service['port']}/{service['protocol']}.",
                    source,
                    node_id=node_id,
                    service_id=service_id,
                    raw_log_id=raw_log_id,
                )

            if service.get("port") in CRITICAL_PORTS and service.get("state") == "open":
                self.create_rule_hit(
                    "critical_exposed_service",
                    "high",
                    f"Servizio critico esposto su {host['ip']} porta {service['port']} ({CRITICAL_PORTS[service['port']]}).",
                    source,
                    node_id=node_id,
                    service_id=service_id,
                    raw_log_id=raw_log_id,
                )

            if finding["version_changed"]:
                previous = finding["previous"]
                description = (
                    f"Versione servizio cambiata su {host['ip']} porta {service['port']}: "
                    f"{previous.get('product') or 'n/a'} {previous.get('version') or ''} -> "
                    f"{service.get('product') or 'n/a'} {service.get('version') or ''}."
                )
                self.create_rule_hit(
                    "service_version_changed",
                    "medium",
                    description.strip(),
                    source,
                    node_id=node_id,
                    service_id=service_id,
                    raw_log_id=raw_log_id,
                )

        if new_open_ports > 5:
            self.create_rule_hit(
                "too_many_new_ports",
                "high",
                f"Il nodo {host['ip']} ha aperto {new_open_ports} nuove porte in una singola scansione.",
                source,
                node_id=node_id,
                raw_log_id=raw_log_id,
            )

    def handle_scan_failed(self, source: str, scan_id: int, message: str):
        # ── Severity declassata da medium → info ────────────────────────────
        # scan_failed è un evento OPERATIVO (target unreachable, timeout, host
        # down) NON una minaccia di sicurezza. Standard NIST SP 800-92 e ECS
        # (Elastic Common Schema) classificano operational failures come "low/
        # informational". Tenere "medium" floodava la coda alert e mascherava
        # le anomalie reali (porta nuova, version change, login admin, ecc.).
        description = f"Scansione {scan_id} fallita: {message}"

        # ── Best-effort: popolare node_id per link in UI ────────────────────
        # Il decoratore handle_scan_failed riceve solo scan_id; recuperiamo il
        # target dalla riga Scans e mappiamo a Nodes.id se l'host è già noto.
        # Lookup non-fatal: se fallisce, l'alert viene comunque creato senza
        # node_id (UI mostra "—" come prima).
        node_id: int | None = None
        try:
            scan_row = self.repository.fetch_one(
                "SELECT target FROM Scans WHERE id = ?", (scan_id,)
            )
            if scan_row and scan_row.get("target"):
                node = self.repository.get_node_by_ip(scan_row["target"])
                if node:
                    node_id = node.get("id")
        except Exception:
            pass  # node lookup failure must NOT break alert creation

        self.repository.create_alert("scan_failed", "info", description, node_id=node_id)
        self.repository.create_security_event(
            source, "scan_failed", description, severity="info", node_id=node_id
        )
