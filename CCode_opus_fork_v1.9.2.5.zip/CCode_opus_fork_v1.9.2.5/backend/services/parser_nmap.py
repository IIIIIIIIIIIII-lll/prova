import re
import xml.etree.ElementTree as ET


# CVE pattern standard: CVE-YYYY-NNNN(N)+ — accetta 4-7 cifre nel suffisso
# (CVE assignment policy: ID >= 5 cifre dal 2014, fino a 7 cifre dal 2024+).
_CVE_PATTERN = re.compile(r"CVE-\d{4}-\d{4,7}", re.IGNORECASE)
_OUTPUT_EXCERPT_MAX = 220  # caratteri max per output script (UI compact)


def _parse_scripts(port_node) -> list[dict]:
    """Estrae i risultati NSE script da un <port> element.

    Ogni script in nmap XML è strutturato così:
      <script id="http-vuln-cve2017-5638" output="VULNERABLE: ...">
        <table key="CVE-2017-5638"> ... </table>
      </script>
    Estraiamo:
      - id          → nome script (es. "http-vuln-cve2017-5638")
      - cves        → lista di CVE references trovate in `output` o tabelle
      - output_excerpt → primi N char di output (compatto per UI)
    """
    scripts = []
    for script_node in port_node.findall("./script"):
        script_id = script_node.attrib.get("id", "")
        output = (script_node.attrib.get("output") or "").strip()
        # CVE references anche dentro <table> annidate (alcuni script le strutturano).
        all_text_nodes = [output]
        for elem in script_node.iter():
            for v in elem.attrib.values():
                if v:
                    all_text_nodes.append(str(v))
        joined = " ".join(all_text_nodes)
        cves = sorted(set(m.group(0).upper() for m in _CVE_PATTERN.finditer(joined)))

        excerpt = output if len(output) <= _OUTPUT_EXCERPT_MAX else output[: _OUTPUT_EXCERPT_MAX] + "…"
        scripts.append(
            {
                "id": script_id,
                "cves": cves,
                "output_excerpt": excerpt,
            }
        )
    return scripts


def parse_nmap_xml(xml_content: str) -> list[dict]:
    if not xml_content or not xml_content.strip():
        return []

    root = ET.fromstring(xml_content)
    normalized_hosts: list[dict] = []

    for host in root.findall("./host"):
        ipv4 = None
        mac_address = None
        vendor = None

        for address in host.findall("./address"):
            addr_type = address.attrib.get("addrtype")
            if addr_type == "ipv4":
                ipv4 = address.attrib.get("addr")
            elif addr_type == "mac":
                mac_address = address.attrib.get("addr")
                vendor = address.attrib.get("vendor")

        if not ipv4:
            continue

        hostname = None
        hostname_node = host.find("./hostnames/hostname")
        if hostname_node is not None:
            hostname = hostname_node.attrib.get("name")

        status_state = "offline"
        status_node = host.find("./status")
        if status_node is not None and status_node.attrib.get("state") == "up":
            status_state = "online"

        os_guess = None
        os_node = host.find("./os/osmatch")
        if os_node is not None:
            os_guess = os_node.attrib.get("name")

        services = []
        for port_node in host.findall("./ports/port"):
            service_node = port_node.find("./service")
            state_node = port_node.find("./state")
            extra_info = service_node.attrib.get("extrainfo") if service_node is not None else None
            banner = extra_info if extra_info else None
            scripts = _parse_scripts(port_node)
            cve_set = sorted({cve for s in scripts for cve in s.get("cves", [])})

            services.append(
                {
                    "port": int(port_node.attrib.get("portid", "0")),
                    "protocol": port_node.attrib.get("protocol", "tcp"),
                    "state": state_node.attrib.get("state", "unknown") if state_node is not None else "unknown",
                    "service_name": service_node.attrib.get("name") if service_node is not None else None,
                    "product": service_node.attrib.get("product") if service_node is not None else None,
                    "version": service_node.attrib.get("version") if service_node is not None else None,
                    "banner": banner,
                    # NSE script results (popolato solo in mode="aggressive")
                    "scripts": scripts,
                    "cves": cve_set,
                }
            )

        normalized_hosts.append(
            {
                "ip": ipv4,
                "hostname": hostname,
                "status": status_state,
                "os_guess": os_guess,
                "mac_address": mac_address,
                "vendor": vendor,
                "services": services,
            }
        )

    return normalized_hosts
