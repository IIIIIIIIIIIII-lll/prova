from __future__ import annotations

from ipaddress import ip_address, ip_network
import re
from urllib.parse import urlparse

from config import settings


class ValidationError(ValueError):
    pass


_SAFE_NAME = re.compile(r"^[A-Za-z0-9_.:@/-]{1,255}$")
_SAFE_EMAIL = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
_SQL_ALLOWED_TABLES = {
    "nodes",
    "services",
    "alerts",
    "scans",
    "tests",
    "rawlogs",
    "securityevents",
    "auditlog",
    "logins",
    "scanjobs",
    "scanjobruns",
    "healthchecks",
    "healthcheckresults",
    "agents",
    "agentmetrics",
    "agentservices",
    "agentevents",
    "users",
    "authsessions",
    "authauditlog",
}
_SQL_FORBIDDEN_TOKENS = (
    ";",
    "--",
    "/*",
    "*/",
    " xp_",
    "\txp_",
    "\n xp_",
    " sp_",
    "\tsp_",
    "\n sp_",
)
_SQL_FORBIDDEN_KEYWORDS = {
    "insert",
    "update",
    "delete",
    "drop",
    "alter",
    "truncate",
    "merge",
    "create",
    "grant",
    "revoke",
    "deny",
    "exec",
    "execute",
    "backup",
    "restore",
    "attach",
    "detach",
    "dbcc",
    "use",
    "into",
    "openrowset",
    "openquery",
    "opendatasource",
}


def validate_safe_text(value: str | None, field_name: str, max_length: int = 255, required: bool = True) -> str | None:
    if value is None or str(value).strip() == "":
        if required:
            raise ValidationError(f"{field_name} obbligatorio.")
        return None
    normalized = str(value).strip()
    if len(normalized) > max_length:
        raise ValidationError(f"{field_name} troppo lungo. Massimo {max_length} caratteri.")
    if not _SAFE_NAME.match(normalized):
        raise ValidationError(f"{field_name} contiene caratteri non consentiti.")
    return normalized


def validate_ports(ports: str | None) -> list[int]:
    if not ports:
        return []

    parsed: list[int] = []
    for item in str(ports).split(","):
        value = item.strip()
        if not value:
            raise ValidationError("Le porte devono essere numeriche o range separati da virgola.")
        if "-" in value:
            parts = value.split("-", 1)
            if len(parts) != 2 or not parts[0].isdigit() or not parts[1].isdigit():
                raise ValidationError("I range porte devono usare il formato start-end.")
            start_port = int(parts[0])
            end_port = int(parts[1])
            if start_port < 1 or end_port > 65535 or start_port > end_port:
                raise ValidationError("Le porte devono essere comprese tra 1 e 65535.")
            parsed.extend(range(start_port, end_port + 1))
            continue
        if not value.isdigit():
            raise ValidationError("Le porte devono essere numeriche o range separati da virgola.")
        port = int(value)
        if port < 1 or port > 65535:
            raise ValidationError("Le porte devono essere comprese tra 1 e 65535.")
        parsed.append(port)

    if len(parsed) > settings.max_scan_ports:
        raise ValidationError(f"Numero massimo di porte consentite: {settings.max_scan_ports}.")

    return sorted(set(parsed))


def validate_scanner(scanner: str) -> str:
    normalized = (scanner or "").strip().lower()
    if normalized not in {"nmap", "masscan", "combined"}:
        raise ValidationError("Scanner non supportato. Usare 'nmap', 'masscan' o 'combined'.")
    return normalized


def validate_scan_mode(mode: str | None) -> str:
    """Modalità scan supportate:
      - safe        → nmap -sT -Pn -sV (TCP connect + service detection)
      - aggressive  → safe + --script "default,vuln" (NSE: default + vulnerability)
                      Estrae CVE references e altre vulnerabilità note.
                      Tempi più lunghi (1-3 min per host); attenzione al timeout.
    Alias storici (demo, service_detection) sono mappati per retro-compat.
    """
    normalized = (mode or "safe").strip().lower()
    if normalized in {"service detection", "service_detection", "default", "demo"}:
        normalized = "safe"
    if normalized in {"aggressive", "vuln", "vuln_scan", "nse"}:
        normalized = "aggressive"
    if normalized not in {"safe", "aggressive"}:
        raise ValidationError("Modalita scan non valida. Usare 'safe' o 'aggressive'.")
    return normalized


def validate_protocol(protocol: str | None, allow_udp: bool = False) -> str:
    normalized = (protocol or "tcp").strip().lower()
    allowed = {"tcp"} | ({"udp"} if allow_udp else set())
    if normalized not in allowed:
        if allow_udp:
            raise ValidationError("Protocollo non supportato. Usare tcp o udp.")
        raise ValidationError("Protocollo non supportato. Usare tcp.")
    return normalized


def validate_role(role: str | None) -> str:
    normalized = (role or "").strip().lower()
    if normalized not in {"admin", "user"}:
        raise ValidationError("Ruolo non valido. Usare 'admin' o 'user'.")
    return normalized


def validate_username(username: str | None) -> str:
    normalized = validate_safe_text(username, "Username", max_length=80)
    if normalized is None:
        raise ValidationError("Username obbligatorio.")
    return normalized


def validate_email(email: str | None, required: bool = False) -> str | None:
    normalized = validate_safe_text(email, "Email", max_length=255, required=required)
    if normalized is None:
        return None
    if not _SAFE_EMAIL.match(normalized):
        raise ValidationError("Email non valida.")
    return normalized.lower()


def validate_target(target: str) -> str:
    if not target or not str(target).strip():
        raise ValidationError("Target obbligatorio.")

    normalized = str(target).strip()
    try:
        if "/" in normalized:
            network = ip_network(normalized, strict=False)
            _ensure_network_allowed(network)
            if network.version == 4 and network.prefixlen < settings.max_scan_prefix_ipv4:
                raise ValidationError(
                    f"Target troppo ampio. Prefisso minimo IPv4 consentito: /{settings.max_scan_prefix_ipv4}."
                )
        else:
            address = ip_address(normalized)
            _ensure_ip_allowed(address)
    except ValueError as exc:
        raise ValidationError(f"Target non valido: {exc}") from exc

    return normalized


def validate_ingest_payload(source: str, payload_format: str):
    validate_safe_text(source, "Source ingest", max_length=50)
    if payload_format not in {"xml", "json", "text"}:
        raise ValidationError("Formato ingest non supportato.")


def validate_http_url(url: str) -> str:
    parsed = urlparse(url or "")
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValidationError("URL non valido. Usare http:// o https://.")
    try:
        hostname = parsed.hostname or ""
        address = ip_address(hostname)
        _ensure_ip_allowed(address)
    except ValueError:
        # I nomi DNS interni sono ammessi, ma non devono contenere credenziali.
        if parsed.username or parsed.password:
            raise ValidationError("URL con credenziali inline non consentito.")
        hostname = (parsed.hostname or "").lower()
        local_dns = hostname.endswith((".local", ".lan", ".internal")) or "." not in hostname
        if not settings.allow_public_scan and not local_dns:
            raise ValidationError("HTTP test verso domini pubblici disabilitato.")
    return url


def validate_sql_read_query(query: str | None, max_length: int = 4000) -> str:
    if query is None or not str(query).strip():
        raise ValidationError("Query SQL obbligatoria.")

    normalized = str(query).strip()
    if len(normalized) > max_length:
        raise ValidationError(f"Query SQL troppo lunga. Massimo {max_length} caratteri.")

    lowered = normalized.lower()
    if not (lowered.startswith("select ") or lowered.startswith("with ")):
        raise ValidationError("Sono consentite solo query SELECT o CTE di sola lettura.")

    if any(token in lowered for token in _SQL_FORBIDDEN_TOKENS):
        raise ValidationError("La query contiene token SQL non consentiti.")

    for keyword in _SQL_FORBIDDEN_KEYWORDS:
        if re.search(rf"\b{re.escape(keyword)}\b", lowered):
            raise ValidationError(f"La query contiene l'istruzione non consentita: {keyword}.")

    referenced_tables = {
        match.group(1).split(".")[-1].strip("[]").lower()
        for match in re.finditer(r"\b(?:from|join)\s+([A-Za-z0-9_.\[\]]+)", normalized, flags=re.IGNORECASE)
    }
    if not referenced_tables:
        raise ValidationError("La query deve referenziare almeno una tabella applicativa.")

    disallowed = sorted(table for table in referenced_tables if table not in _SQL_ALLOWED_TABLES)
    if disallowed:
        raise ValidationError(
            "La query puo interrogare solo le tabelle NetVisor consentite: "
            + ", ".join(sorted(_SQL_ALLOWED_TABLES))
            + f". Tabelle non consentite rilevate: {', '.join(disallowed)}."
        )

    return normalized


def _ensure_network_allowed(target_network):
    if not settings.allow_public_scan and target_network.is_global:
        raise ValidationError("Le scansioni su reti pubbliche sono disabilitate.")
    for allowed in settings.allowed_networks:
        if target_network.subnet_of(allowed):
            return
    raise ValidationError("Target fuori da SCAN_ALLOWED_CIDRS.")


def _ensure_ip_allowed(target_ip):
    if not settings.allow_public_scan and target_ip.is_global:
        raise ValidationError("Le scansioni su IP pubblici sono disabilitate.")
    for allowed in settings.allowed_networks:
        if target_ip in allowed:
            return
    raise ValidationError("Target fuori da SCAN_ALLOWED_CIDRS.")
