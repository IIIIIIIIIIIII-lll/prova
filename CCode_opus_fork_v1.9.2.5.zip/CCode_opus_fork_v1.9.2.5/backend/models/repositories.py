from __future__ import annotations

from typing import Any

from db import get_connection


def _row_to_dict(cursor, row) -> dict[str, Any]:
    columns = [column[0] for column in cursor.description]
    return {columns[index]: row[index] for index in range(len(columns))}


class Repository:
    # Repository piccolo e diretto per SQL Server via pyodbc.

    def fetch_all(self, query: str, params: tuple = ()) -> list[dict[str, Any]]:
        with get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()
            if not rows:
                return []
            return [_row_to_dict(cursor, row) for row in rows]

    def fetch_one(self, query: str, params: tuple = ()) -> dict[str, Any] | None:
        with get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query, params)
            row = cursor.fetchone()
            if not row:
                return None
            return _row_to_dict(cursor, row)

    def fetch_query_result(self, query: str, params: tuple = (), max_rows: int = 200, timeout_seconds: int = 10) -> dict[str, Any]:
        with get_connection() as connection:
            connection.timeout = timeout_seconds
            cursor = connection.cursor()
            cursor.execute(query, params)
            columns = [column[0] for column in cursor.description] if cursor.description else []
            rows = cursor.fetchmany(max_rows)
            extra_row = cursor.fetchone()
            return {
                "columns": columns,
                "rows": [[row[index] for index in range(len(columns))] for row in rows],
                "row_count": len(rows),
                "truncated": extra_row is not None,
            }

    def execute(self, query: str, params: tuple = ()) -> int:
        with get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query, params)
            return cursor.rowcount

    def insert_and_get_id(self, query: str, params: tuple = ()) -> int:
        with get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query, params)
            row = cursor.fetchone()
            return int(row[0])

    def _update_fields(self, table: str, record_id: int, fields: dict[str, Any], allowed_fields: set[str]) -> int:
        safe_fields = {key: value for key, value in fields.items() if key in allowed_fields}
        if not safe_fields:
            return 0
        set_clause = ", ".join(f"{column} = ?" for column in safe_fields)
        params = tuple(safe_fields.values()) + (record_id,)
        return self.execute(f"UPDATE {table} SET {set_clause} WHERE id = ?", params)

    def has_recent_alert(self, alert_type: str, node_id: int | None, service_id: int | None, minutes: int = 60) -> bool:
        """Verifica se esiste un alert open/ack dello stesso tipo per stesso node/service entro la finestra (minuti)."""
        row = self.fetch_one(
            """
            SELECT COUNT(*) AS cnt
            FROM Alerts
            WHERE type = ?
              AND status IN ('open', 'ack')
              AND ISNULL(node_id, -1) = ISNULL(?, -1)
              AND ISNULL(service_id, -1) = ISNULL(?, -1)
              AND timestamp >= DATEADD(MINUTE, ?, SYSUTCDATETIME())
            """,
            (alert_type, node_id, service_id, -abs(int(minutes))),
        ) or {}
        return int(row.get("cnt") or 0) > 0

    def get_dashboard_summary(self) -> dict[str, Any]:
        latest_scans = self.fetch_all(
            """
            SELECT TOP 5 id, date, scanner, target, ports, status, started_at, finished_at, result, result_summary
            FROM Scans
            ORDER BY id DESC
            """
        )
        counts = self.fetch_one(
            """
            SELECT
                (SELECT COUNT(*) FROM Nodes) AS total_nodes,
                (SELECT COUNT(*) FROM Nodes WHERE status = 'online') AS online_nodes,
                (SELECT COUNT(*) FROM Nodes WHERE status = 'offline') AS offline_nodes,
                (SELECT COUNT(*) FROM Alerts WHERE status IN ('open', 'ack')) AS open_alerts,
                (SELECT COUNT(*) FROM Services WHERE state = 'open') AS total_services
            """
        ) or {}
        counts["latest_scans"] = latest_scans
        return counts

    def list_nodes(self, status: str | None = None) -> list[dict[str, Any]]:
        query = """
        SELECT id, hostname, ip, status, first_seen, last_seen, os_guess, mac_address, vendor, risk_score
        FROM Nodes
        """
        params: tuple = ()
        if status:
            query += " WHERE status = ?"
            params = (status,)
        query += " ORDER BY ip"
        return self.fetch_all(query, params)

    def get_node(self, node_id: int) -> dict[str, Any] | None:
        return self.fetch_one(
            """
            SELECT id, hostname, ip, status, first_seen, last_seen, os_guess, mac_address, vendor, risk_score
            FROM Nodes WHERE id = ?
            """,
            (node_id,),
        )

    def get_node_by_ip(self, ip: str) -> dict[str, Any] | None:
        return self.fetch_one("SELECT * FROM Nodes WHERE ip = ?", (ip,))

    def get_node_services(self, node_id: int) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, node_id, port, protocol, state, service_name, product, version, banner, first_seen, last_seen
            FROM Services WHERE node_id = ?
            ORDER BY port
            """,
            (node_id,),
        )

    def get_service(self, node_id: int, port: int, protocol: str) -> dict[str, Any] | None:
        return self.fetch_one(
            """
            SELECT * FROM Services
            WHERE node_id = ? AND port = ? AND protocol = ?
            """,
            (node_id, port, protocol),
        )

    def get_node_alerts(self, node_id: int) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, type, severity, description, node_id, service_id, status, timestamp
            FROM Alerts WHERE node_id = ?
            ORDER BY id DESC
            """,
            (node_id,),
        )

    def list_alerts(self, include_deleted: bool = False) -> list[dict[str, Any]]:
        # Default: nasconde gli alert "deleted" — vivono in DeletedTasks UI separata.
        where = "" if include_deleted else "WHERE a.status <> 'deleted'"
        return self.fetch_all(
            f"""
            SELECT a.id, a.type, a.severity, a.description, a.node_id, a.service_id, a.status,
                   a.timestamp, a.acked_at, a.closed_at, a.deleted_at,
                   n.hostname, n.ip
            FROM Alerts a
            LEFT JOIN Nodes n ON n.id = a.node_id
            {where}
            ORDER BY a.id DESC
            """
        )

    def list_deleted_alerts(self) -> list[dict[str, Any]]:
        # Tabella "Deleted Tasks" — alert con status='deleted', solo i non-fantasma.
        return self.fetch_all(
            """
            SELECT a.id, a.type, a.severity, a.description, a.node_id, a.service_id, a.status,
                   a.timestamp, a.acked_at, a.closed_at, a.deleted_at,
                   n.hostname, n.ip
            FROM Alerts a
            LEFT JOIN Nodes n ON n.id = a.node_id
            WHERE a.status = 'deleted'
            ORDER BY a.deleted_at DESC, a.id DESC
            """
        )

    def get_alert(self, alert_id: int) -> dict[str, Any] | None:
        return self.fetch_one(
            "SELECT id, status FROM Alerts WHERE id = ?",
            (alert_id,),
        )

    def update_alert_status(self, alert_id: int, status: str) -> int:
        # Backwards-compat: setter generico, NON enforce la transizione.
        # Nuovi callers dovrebbero usare ack_alert / close_alert / delete_alert
        # che applicano la state machine open→ack→closed→deleted.
        return self.execute("UPDATE Alerts SET status = ? WHERE id = ?", (status, alert_id))

    def ack_alert(self, alert_id: int) -> int:
        # Ack consentito solo da status='open'. Setta acked_at se non già settato.
        return self.execute(
            """
            UPDATE Alerts SET status = 'ack', acked_at = COALESCE(acked_at, SYSUTCDATETIME())
            WHERE id = ? AND status = 'open'
            """,
            (alert_id,),
        )

    def close_alert(self, alert_id: int) -> int:
        # Close consentito solo da status='ack' (forza ACK→Close, no shortcut da open).
        return self.execute(
            """
            UPDATE Alerts SET status = 'closed', closed_at = COALESCE(closed_at, SYSUTCDATETIME())
            WHERE id = ? AND status = 'ack'
            """,
            (alert_id,),
        )

    def delete_alert(self, alert_id: int) -> int:
        # Soft-delete: status='deleted' + deleted_at. Consentito solo da status='closed'.
        # La riga rimane nel DB per la "Deleted Tasks" UI e per audit.
        return self.execute(
            """
            UPDATE Alerts SET status = 'deleted', deleted_at = SYSUTCDATETIME()
            WHERE id = ? AND status = 'closed'
            """,
            (alert_id,),
        )

    def create_scan(self, scanner: str, target: str, ports: str | None, status: str = "queued") -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO Scans (date, scanner, target, ports, status)
            OUTPUT INSERTED.id
            VALUES (SYSUTCDATETIME(), ?, ?, ?, ?)
            """,
            (scanner, target, ports, status),
        )

    def count_users(self) -> int:
        row = self.fetch_one("SELECT COUNT(*) AS total FROM Users")
        return int((row or {}).get("total") or 0)

    def list_users(self) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, username, email, display_name, role, is_active, must_change_password,
                   failed_login_count, locked_until, last_login_at, created_at, updated_at
            FROM Users
            ORDER BY username
            """
        )

    def get_user_by_id(self, user_id: int) -> dict[str, Any] | None:
        return self.fetch_one(
            """
            SELECT id, username, email, display_name, role, password_hash, is_active, must_change_password,
                   failed_login_count, locked_until, last_login_at, created_at, updated_at
            FROM Users
            WHERE id = ?
            """,
            (user_id,),
        )

    def get_user_by_username(self, username: str) -> dict[str, Any] | None:
        return self.fetch_one(
            """
            SELECT id, username, email, display_name, role, password_hash, is_active, must_change_password,
                   failed_login_count, locked_until, last_login_at, created_at, updated_at
            FROM Users
            WHERE username = ?
            """,
            (username,),
        )

    def create_user(
        self,
        username: str,
        email: str | None,
        display_name: str | None,
        role: str,
        password_hash: str,
        is_active: bool = True,
        must_change_password: bool = False,
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO Users (username, email, display_name, role, password_hash, is_active, must_change_password)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (username, email, display_name, role, password_hash, 1 if is_active else 0, 1 if must_change_password else 0),
        )

    def update_user(self, user_id: int, fields: dict[str, Any]) -> int:
        return self._update_fields(
            "Users",
            user_id,
            fields,
            {
                "email",
                "display_name",
                "role",
                "password_hash",
                "is_active",
                "must_change_password",
                "failed_login_count",
                "locked_until",
                "last_login_at",
                "updated_at",
            },
        )

    def delete_user(self, user_id: int) -> int:
        self.execute("DELETE FROM AuthSessions WHERE user_id = ?", (user_id,))
        self.execute("DELETE FROM AuthAuditLog WHERE user_id = ?", (user_id,))
        return self.execute("DELETE FROM Users WHERE id = ?", (user_id,))

    def create_auth_session(
        self,
        user_id: int,
        refresh_token_hash: str,
        user_agent: str | None,
        ip_address: str | None,
        expires_at,
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO AuthSessions (user_id, refresh_token_hash, user_agent, ip_address, expires_at)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?)
            """,
            (user_id, refresh_token_hash, user_agent, ip_address, expires_at),
        )

    def get_auth_session(self, session_id: int) -> dict[str, Any] | None:
        return self.fetch_one(
            """
            SELECT id, user_id, refresh_token_hash, user_agent, ip_address, created_at, expires_at, revoked_at, last_used_at
            FROM AuthSessions
            WHERE id = ?
            """,
            (session_id,),
        )

    def update_auth_session(self, session_id: int, fields: dict[str, Any]) -> int:
        return self._update_fields(
            "AuthSessions",
            session_id,
            fields,
            {"refresh_token_hash", "user_agent", "ip_address", "expires_at", "revoked_at", "last_used_at"},
        )

    def revoke_auth_session(self, session_id: int) -> int:
        return self.execute(
            """
            UPDATE AuthSessions
            SET revoked_at = COALESCE(revoked_at, SYSUTCDATETIME()), last_used_at = SYSUTCDATETIME()
            WHERE id = ?
            """,
            (session_id,),
        )

    def revoke_user_sessions(self, user_id: int, except_session_id: int | None = None) -> int:
        if except_session_id is None:
            return self.execute(
                """
                UPDATE AuthSessions
                SET revoked_at = COALESCE(revoked_at, SYSUTCDATETIME())
                WHERE user_id = ? AND revoked_at IS NULL
                """,
                (user_id,),
            )
        return self.execute(
            """
            UPDATE AuthSessions
            SET revoked_at = COALESCE(revoked_at, SYSUTCDATETIME())
            WHERE user_id = ? AND revoked_at IS NULL AND id <> ?
            """,
            (user_id, except_session_id),
        )

    def create_auth_audit(
        self,
        user_id: int | None,
        username: str | None,
        event_type: str,
        role: str | None,
        ip_address: str | None,
        user_agent: str | None,
        success: bool,
        message: str | None = None,
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO AuthAuditLog (user_id, username, event_type, role, ip_address, user_agent, success, message)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (user_id, username, event_type, role, ip_address, user_agent, 1 if success else 0, message),
        )

    def list_auth_audit(self, limit: int = 100) -> list[dict[str, Any]]:
        return self.fetch_all(
            f"""
            SELECT TOP {int(limit)} id, user_id, username, event_type, role, ip_address, user_agent, success, message, created_at
            FROM AuthAuditLog
            ORDER BY created_at DESC, id DESC
            """
        )

    def list_audit_log(self, limit: int = 100) -> list[dict[str, Any]]:
        return self.fetch_all(
            f"""
            SELECT TOP {int(limit)} id, actor, action, details, created_at
            FROM AuditLog
            ORDER BY created_at DESC, id DESC
            """
        )

    def list_scan_jobs(self) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT sj.id, sj.name, sj.scanner, sj.target, sj.ports, sj.protocol, sj.mode, sj.interval_seconds, sj.enabled,
                   sj.permanent, sj.last_status, sj.last_started_at, sj.last_finished_at, sj.next_run_at, sj.last_error,
                   sj.created_by_user_id, sj.created_at, sj.updated_at, u.username AS created_by_username
            FROM ScanJobs sj
            LEFT JOIN Users u ON u.id = sj.created_by_user_id
            ORDER BY sj.id DESC
            """
        )

    def get_scan_job(self, job_id: int) -> dict[str, Any] | None:
        return self.fetch_one(
            """
            SELECT sj.id, sj.name, sj.scanner, sj.target, sj.ports, sj.protocol, sj.mode, sj.interval_seconds, sj.enabled,
                   sj.permanent, sj.last_status, sj.last_started_at, sj.last_finished_at, sj.next_run_at, sj.last_error,
                   sj.created_by_user_id, sj.created_at, sj.updated_at, u.username AS created_by_username
            FROM ScanJobs sj
            LEFT JOIN Users u ON u.id = sj.created_by_user_id
            WHERE sj.id = ?
            """,
            (job_id,),
        )

    def create_scan_job(
        self,
        name: str,
        scanner: str,
        target: str,
        ports: str,
        protocol: str,
        mode: str,
        interval_seconds: int | None,
        enabled: bool,
        permanent: bool,
        created_by_user_id: int | None,
        next_run_at: str | None = None,
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO ScanJobs (name, scanner, target, ports, protocol, mode, interval_seconds, enabled, permanent, last_status, next_run_at, created_by_user_id)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                name,
                scanner,
                target,
                ports,
                protocol,
                mode,
                interval_seconds,
                1 if enabled else 0,
                1 if permanent else 0,
                "idle",
                next_run_at,
                created_by_user_id,
            ),
        )

    def update_scan_job(self, job_id: int, fields: dict[str, Any]) -> int:
        return self._update_fields(
            "ScanJobs",
            job_id,
            fields,
            {
                "name",
                "scanner",
                "target",
                "ports",
                "protocol",
                "mode",
                "interval_seconds",
                "enabled",
                "permanent",
                "last_status",
                "last_started_at",
                "last_finished_at",
                "next_run_at",
                "last_error",
                "updated_at",
            },
        )

    def delete_scan_job(self, job_id: int) -> int:
        self.execute("DELETE FROM ScanJobRuns WHERE job_id = ?", (job_id,))
        return self.execute("DELETE FROM ScanJobs WHERE id = ?", (job_id,))

    def list_due_scan_jobs(self) -> list[dict[str, Any]]:
        # WITH (UPDLOCK, READPAST): lock pessimistico per evitare race condition
        # tra scan_worker e API admin che invocano /scan-jobs/<id>/run nello
        # stesso istante. UPDLOCK marca le righe che il worker sta per
        # processare; READPAST salta righe gia' lockate da altre transazioni
        # (=> non doppio-esegue lo stesso job). I row vengono "rilasciati" al
        # commit della transazione che mark_scan_job_run_started fa.
        return self.fetch_all(
            """
            SELECT id, name, scanner, target, ports, protocol, mode, interval_seconds, enabled,
                   permanent, last_status, last_started_at, last_finished_at, next_run_at, last_error, created_by_user_id, created_at, updated_at
            FROM ScanJobs WITH (UPDLOCK, READPAST)
            WHERE enabled = 1
              AND permanent = 1
              AND mode = 'scheduled'
              AND next_run_at IS NOT NULL
              AND next_run_at <= SYSUTCDATETIME()
            ORDER BY next_run_at, id
            """
        )

    def create_scan_job_run(
        self,
        job_id: int | None,
        scanner: str,
        target: str,
        ports: str,
        protocol: str = "tcp",
        status: str = "queued",
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO ScanJobRuns (job_id, scanner, target, ports, protocol, status)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (job_id, scanner, target, ports, protocol, status),
        )

    def mark_scan_job_run_started(self, run_id: int) -> int:
        return self.execute(
            """
            UPDATE ScanJobRuns
            SET status = 'running', started_at = SYSUTCDATETIME()
            WHERE id = ?
            """,
            (run_id,),
        )

    def finalize_scan_job_run(
        self,
        run_id: int,
        status: str,
        result_summary: str | None = None,
        error_message: str | None = None,
        raw_log_id: int | None = None,
    ) -> int:
        return self.execute(
            """
            UPDATE ScanJobRuns
            SET status = ?, finished_at = SYSUTCDATETIME(), result_summary = ?, error_message = ?, raw_log_id = ?
            WHERE id = ?
            """,
            (status, result_summary, error_message, raw_log_id, run_id),
        )

    def list_scan_job_runs(self, job_id: int) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, job_id, scanner, target, ports, protocol, status, started_at, finished_at, raw_log_id, result_summary, error_message
            FROM ScanJobRuns
            WHERE job_id = ?
            ORDER BY id DESC
            """,
            (job_id,),
        )

    def list_health_checks(self) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT hc.id, hc.name, hc.target, hc.check_type, hc.port, COALESCE(hc.service_label, hc.label) AS service_label,
                   hc.label, hc.interval_seconds, hc.timeout_seconds, hc.enabled, hc.permanent, hc.last_status,
                   hc.last_latency_ms, hc.last_checked_at, hc.failure_count, hc.created_by_user_id, hc.created_at, hc.updated_at,
                   u.username AS created_by_username
            FROM HealthChecks hc
            LEFT JOIN Users u ON u.id = hc.created_by_user_id
            ORDER BY hc.id DESC
            """
        )

    def get_health_check(self, check_id: int) -> dict[str, Any] | None:
        return self.fetch_one(
            """
            SELECT hc.id, hc.name, hc.target, hc.check_type, hc.port, COALESCE(hc.service_label, hc.label) AS service_label,
                   hc.label, hc.interval_seconds, hc.timeout_seconds, hc.enabled, hc.permanent, hc.last_status,
                   hc.last_latency_ms, hc.last_checked_at, hc.failure_count, hc.created_by_user_id, hc.created_at, hc.updated_at,
                   u.username AS created_by_username
            FROM HealthChecks hc
            LEFT JOIN Users u ON u.id = hc.created_by_user_id
            WHERE hc.id = ?
            """,
            (check_id,),
        )

    def create_health_check(
        self,
        name: str,
        target: str,
        check_type: str,
        port: int | None,
        label: str | None,
        service_label: str | None,
        interval_seconds: int,
        timeout_seconds: int,
        enabled: bool,
        permanent: bool,
        created_by_user_id: int | None,
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO HealthChecks (name, target, check_type, port, label, service_label, interval_seconds, timeout_seconds, enabled, permanent, last_status, created_by_user_id)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                name,
                target,
                check_type,
                port,
                label,
                service_label,
                interval_seconds,
                timeout_seconds,
                1 if enabled else 0,
                1 if permanent else 0,
                "unknown",
                created_by_user_id,
            ),
        )

    def update_health_check(self, check_id: int, fields: dict[str, Any]) -> int:
        return self._update_fields(
            "HealthChecks",
            check_id,
            fields,
            {
                "name",
                "target",
                "check_type",
                "port",
                "label",
                "service_label",
                "interval_seconds",
                "timeout_seconds",
                "enabled",
                "permanent",
                "last_status",
                "last_latency_ms",
                "last_checked_at",
                "failure_count",
                "updated_at",
            },
        )

    def delete_health_check(self, check_id: int) -> int:
        self.execute("DELETE FROM HealthCheckResults WHERE check_id = ?", (check_id,))
        return self.execute("DELETE FROM HealthChecks WHERE id = ?", (check_id,))

    def create_health_check_result(
        self,
        check_id: int | None,
        target: str,
        check_type: str,
        port: int | None,
        result: str,
        latency_ms: int | None,
        error_message: str | None,
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO HealthCheckResults (check_id, target, check_type, port, result, latency_ms, error_message)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (check_id, target, check_type, port, result, latency_ms, error_message),
        )

    def list_due_health_checks(self) -> list[dict[str, Any]]:
        # WITH (UPDLOCK, READPAST) — stesso pattern di list_due_scan_jobs:
        # evita doppia esecuzione concorrente da worker + invocazioni manuali.
        return self.fetch_all(
            """
            SELECT hc.id, hc.name, hc.target, hc.check_type, hc.port, COALESCE(hc.service_label, hc.label) AS service_label,
                   hc.label, hc.interval_seconds, hc.timeout_seconds, hc.enabled, hc.permanent, hc.last_status,
                   hc.last_latency_ms, hc.last_checked_at, hc.failure_count, hc.created_by_user_id, hc.created_at, hc.updated_at
            FROM HealthChecks hc WITH (UPDLOCK, READPAST)
            WHERE hc.enabled = 1
              AND hc.permanent = 1
              AND (
                hc.last_checked_at IS NULL
                OR DATEADD(SECOND, hc.interval_seconds, hc.last_checked_at) <= SYSUTCDATETIME()
              )
            ORDER BY hc.last_checked_at, hc.id
            """
        )

    def list_health_check_results(self, check_id: int) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, check_id, target, check_type, port, result, latency_ms, error_message, checked_at
            FROM HealthCheckResults
            WHERE check_id = ?
            ORDER BY checked_at DESC, id DESC
            """,
            (check_id,),
        )

    def get_agent(self, agent_id: str) -> dict[str, Any] | None:
        return self.fetch_one(
            """
            SELECT id, agent_id, hostname, ip_address, os_name, agent_version, status, first_seen, last_seen
            FROM Agents
            WHERE agent_id = ?
            """,
            (agent_id,),
        )

    def list_agents(self) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT
                a.id,
                a.agent_id,
                a.hostname,
                a.ip_address,
                a.os_name,
                a.agent_version,
                a.status,
                a.first_seen,
                a.last_seen,
                latest.cpu_percent,
                latest.ram_percent,
                latest.disk_percent,
                latest.uptime_seconds
            FROM Agents a
            OUTER APPLY (
                SELECT TOP 1 cpu_percent, ram_percent, disk_percent, uptime_seconds
                FROM AgentMetrics am
                WHERE am.agent_id = a.agent_id
                ORDER BY am.collected_at DESC, am.id DESC
            ) latest
            ORDER BY a.hostname, a.agent_id
            """
        )

    def upsert_agent(self, payload: dict[str, Any]) -> tuple[str, bool]:
        existing = self.get_agent(payload["agent_id"])
        if existing:
            self.execute(
                """
                UPDATE Agents
                SET hostname = ?, ip_address = ?, os_name = ?, agent_version = ?, status = ?, last_seen = SYSUTCDATETIME()
                WHERE agent_id = ?
                """,
                (
                    payload["hostname"],
                    payload["ip_address"],
                    payload["os_name"],
                    payload["agent_version"],
                    payload.get("status", "online"),
                    payload["agent_id"],
                ),
            )
            return payload["agent_id"], False

        self.insert_and_get_id(
            """
            INSERT INTO Agents (agent_id, hostname, ip_address, os_name, agent_version, status)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                payload["agent_id"],
                payload["hostname"],
                payload["ip_address"],
                payload["os_name"],
                payload["agent_version"],
                payload.get("status", "online"),
            ),
        )
        return payload["agent_id"], True

    def update_agent_status(self, agent_id: str, status: str, touch_last_seen: bool = True) -> int:
        if touch_last_seen:
            return self.execute(
                """
                UPDATE Agents
                SET status = ?, last_seen = SYSUTCDATETIME()
                WHERE agent_id = ?
                """,
                (status, agent_id),
            )
        return self.execute(
            """
            UPDATE Agents
            SET status = ?
            WHERE agent_id = ?
            """,
            (status, agent_id),
        )

    def create_agent_metric(
        self,
        agent_id: str,
        cpu_percent: float,
        ram_percent: float,
        disk_percent: float,
        uptime_seconds: int,
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO AgentMetrics (agent_id, cpu_percent, ram_percent, disk_percent, uptime_seconds)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?)
            """,
            (agent_id, cpu_percent, ram_percent, disk_percent, uptime_seconds),
        )

    def get_agent_metrics(self, agent_id: str, limit: int = 30) -> list[dict[str, Any]]:
        return self.fetch_all(
            f"""
            SELECT TOP {int(limit)} id, agent_id, cpu_percent, ram_percent, disk_percent, uptime_seconds, collected_at
            FROM AgentMetrics
            WHERE agent_id = ?
            ORDER BY collected_at DESC, id DESC
            """,
            (agent_id,),
        )

    def replace_agent_services(self, agent_id: str, services: list[dict[str, Any]]) -> int:
        deleted = self.execute("DELETE FROM AgentServices WHERE agent_id = ?", (agent_id,))
        created = 0
        for item in services:
            self.insert_and_get_id(
                """
                INSERT INTO AgentServices (agent_id, service_name, display_name, status, checked_at)
                OUTPUT INSERTED.id
                VALUES (?, ?, ?, ?, COALESCE(?, SYSUTCDATETIME()))
                """,
                (
                    agent_id,
                    item["service_name"],
                    item.get("display_name"),
                    item["status"],
                    item.get("checked_at"),
                ),
            )
            created += 1
        return deleted + created

    def get_agent_services(self, agent_id: str) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, agent_id, service_name, display_name, status, checked_at
            FROM AgentServices
            WHERE agent_id = ?
            ORDER BY display_name, service_name
            """,
            (agent_id,),
        )

    def create_agent_event(self, agent_id: str, source: str, level: str, message: str, event_time) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO AgentEvents (agent_id, source, level, message, event_time)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?)
            """,
            (agent_id, source, level, message, event_time),
        )

    def get_agent_events(self, agent_id: str, limit: int = 50) -> list[dict[str, Any]]:
        return self.fetch_all(
            f"""
            SELECT TOP {int(limit)} id, agent_id, source, level, message, event_time, received_at
            FROM AgentEvents
            WHERE agent_id = ?
            ORDER BY received_at DESC, id DESC
            """,
            (agent_id,),
        )

    def get_agent_alerts(self, agent_id: str, limit: int = 30) -> list[dict[str, Any]]:
        return self.fetch_all(
            f"""
            SELECT TOP {int(limit)} a.id, a.type, a.severity, a.description, a.status, a.timestamp
            FROM Alerts a
            WHERE a.description LIKE ?
            ORDER BY a.id DESC
            """,
            (f"%{agent_id}%",),
        )

    def count_recent_agent_error_events(self, agent_id: str, minutes: int = 15) -> int:
        row = self.fetch_one(
            """
            SELECT COUNT(*) AS total
            FROM AgentEvents
            WHERE agent_id = ?
              AND level IN ('error', 'critical')
              AND received_at >= DATEADD(MINUTE, ?, SYSUTCDATETIME())
            """,
            (agent_id, -abs(int(minutes))),
        ) or {}
        return int(row.get("total") or 0)

    def get_agents_overview(self) -> dict[str, Any]:
        summary = self.fetch_one(
            """
            SELECT
                (SELECT COUNT(*) FROM Agents) AS total_agents,
                (SELECT COUNT(*) FROM Agents WHERE status = 'online') AS online_agents,
                (SELECT COUNT(*) FROM Agents WHERE status = 'offline') AS offline_agents,
                (SELECT COUNT(*) FROM AgentServices WHERE status <> 'running') AS services_down,
                (SELECT COUNT(*) FROM AgentEvents WHERE level IN ('error', 'critical')) AS error_events,
                (SELECT COUNT(*) FROM AgentMetrics WHERE cpu_percent >= 85 OR ram_percent >= 85 OR disk_percent >= 90) AS stressed_samples,
                (SELECT MAX(last_seen) FROM Agents) AS last_heartbeat
            """
        ) or {}

        latest_metrics = self.fetch_all(
            """
            SELECT TOP 8
                a.agent_id,
                a.hostname,
                a.status,
                latest.cpu_percent,
                latest.ram_percent,
                latest.disk_percent,
                latest.collected_at
            FROM Agents a
            OUTER APPLY (
                SELECT TOP 1 cpu_percent, ram_percent, disk_percent, collected_at
                FROM AgentMetrics am
                WHERE am.agent_id = a.agent_id
                ORDER BY collected_at DESC, id DESC
            ) latest
            ORDER BY a.last_seen DESC, a.agent_id
            """
        )

        recent_events = self.fetch_all(
            """
            SELECT TOP 12
                e.id,
                e.agent_id,
                a.hostname,
                e.source,
                e.level,
                e.message,
                e.event_time,
                e.received_at
            FROM AgentEvents e
            INNER JOIN Agents a ON a.agent_id = e.agent_id
            ORDER BY e.received_at DESC, e.id DESC
            """
        )

        recent_services = self.fetch_all(
            """
            SELECT TOP 12
                s.agent_id,
                a.hostname,
                s.service_name,
                s.display_name,
                s.status,
                s.checked_at
            FROM AgentServices s
            INNER JOIN Agents a ON a.agent_id = s.agent_id
            ORDER BY s.checked_at DESC, s.id DESC
            """
        )

        return {
            "summary": summary,
            "latest_metrics": latest_metrics,
            "recent_events": recent_events,
            "recent_services": recent_services,
        }

    def list_latest_scan_job_runs(self, limit: int = 12) -> list[dict[str, Any]]:
        return self.fetch_all(
            f"""
            SELECT TOP {int(limit)}
                r.id,
                r.job_id,
                j.name AS job_name,
                r.scanner,
                r.target,
                r.ports,
                r.status,
                r.started_at,
                r.finished_at,
                r.result_summary,
                r.error_message
            FROM ScanJobRuns r
            LEFT JOIN ScanJobs j ON j.id = r.job_id
            ORDER BY r.id DESC
            """
        )

    def list_recent_health_results(self, limit: int = 12) -> list[dict[str, Any]]:
        return self.fetch_all(
            f"""
            SELECT TOP {int(limit)}
                r.id,
                r.check_id,
                h.name,
                r.target,
                r.check_type,
                r.port,
                r.result,
                r.latency_ms,
                r.error_message,
                r.checked_at
            FROM HealthCheckResults r
            LEFT JOIN HealthChecks h ON h.id = r.check_id
            ORDER BY r.checked_at DESC, r.id DESC
            """
        )

    def mark_scan_started(self, scan_id: int):
        self.execute(
            "UPDATE Scans SET status = 'running', date = COALESCE(date, SYSUTCDATETIME()), started_at = SYSUTCDATETIME() WHERE id = ?",
            (scan_id,),
        )

    def finalize_scan(self, scan_id: int, status: str, result_summary: str | None = None, error_message: str | None = None):
        self.execute(
            """
            UPDATE Scans
            SET status = ?, finished_at = SYSUTCDATETIME(), result = ?, result_summary = ?, error_message = ?
            WHERE id = ?
            """,
            (status, result_summary or error_message, result_summary, error_message, scan_id),
        )

    def list_scans(self) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, date, scanner, target, ports, status, started_at, finished_at, result, result_summary, error_message
            FROM Scans
            ORDER BY id DESC
            """
        )

    def get_scan(self, scan_id: int) -> dict[str, Any] | None:
        return self.fetch_one(
            """
            SELECT id, date, scanner, target, ports, status, started_at, finished_at, result, result_summary, error_message
            FROM Scans WHERE id = ?
            """,
            (scan_id,),
        )

    def get_scan_events(self, scan_id: int) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT se.id, se.source, se.event_type, se.node_id, se.service_id, se.severity, se.message, se.event_time
            FROM SecurityEvents se
            LEFT JOIN RawLogs rl ON rl.id = se.raw_log_id
            WHERE rl.scan_id = ?
            ORDER BY se.id DESC
            """,
            (scan_id,),
        )

    def get_scan_raw(self, scan_id: int) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, source, scan_id, format, content, received_at
            FROM RawLogs WHERE scan_id = ?
            ORDER BY id DESC
            """,
            (scan_id,),
        )

    def create_raw_log(self, source: str, scan_id: int | None, log_format: str, content: str) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO RawLogs (source, scan_id, format, content)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?)
            """,
            (source, scan_id, log_format, content),
        )

    def create_security_event(
        self,
        source: str,
        event_type: str,
        message: str,
        severity: str = "info",
        node_id: int | None = None,
        service_id: int | None = None,
        raw_log_id: int | None = None,
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO SecurityEvents (source, event_type, node_id, service_id, severity, message, raw_log_id)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (source, event_type, node_id, service_id, severity, message, raw_log_id),
        )

    def create_alert(
        self,
        alert_type: str,
        severity: str,
        description: str,
        node_id: int | None = None,
        service_id: int | None = None,
        status: str = "open",
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO Alerts (type, severity, description, node_id, service_id, status)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (alert_type, severity, description, node_id, service_id, status),
        )

    def write_audit(self, action: str, details: str, actor: str = "system") -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO AuditLog (actor, action, details)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?)
            """,
            (actor, action, details),
        )

    def upsert_node(self, payload: dict[str, Any]) -> tuple[int, bool]:
        existing = self.get_node_by_ip(payload["ip"])
        if existing:
            self.execute(
                """
                UPDATE Nodes
                SET hostname = ?, status = ?, last_seen = CASE WHEN ? = 'offline' THEN last_seen ELSE SYSUTCDATETIME() END,
                    os_guess = ?, mac_address = ?, vendor = ?, risk_score = ?
                WHERE id = ?
                """,
                (
                    payload.get("hostname"),
                    payload.get("status", "unknown"),
                    payload.get("status", "unknown"),
                    payload.get("os_guess"),
                    payload.get("mac_address"),
                    payload.get("vendor"),
                    payload.get("risk_score", existing.get("risk_score", 0)),
                    existing["id"],
                ),
            )
            return int(existing["id"]), False

        node_id = self.insert_and_get_id(
            """
            INSERT INTO Nodes (hostname, ip, status, last_seen, os_guess, mac_address, vendor, risk_score)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, SYSUTCDATETIME(), ?, ?, ?, ?)
            """,
            (
                payload.get("hostname"),
                payload["ip"],
                payload.get("status", "unknown"),
                payload.get("os_guess"),
                payload.get("mac_address"),
                payload.get("vendor"),
                payload.get("risk_score", 0),
            ),
        )
        return node_id, True

    def upsert_service(self, node_id: int, service: dict[str, Any]) -> tuple[int, bool, dict[str, Any] | None]:
        existing = self.get_service(node_id, service["port"], service["protocol"])
        if existing:
            self.execute(
                """
                UPDATE Services
                SET state = ?, service_name = ?, product = ?, version = ?, banner = ?, last_seen = SYSUTCDATETIME()
                WHERE id = ?
                """,
                (
                    service.get("state", "unknown"),
                    service.get("service_name"),
                    service.get("product"),
                    service.get("version"),
                    service.get("banner"),
                    existing["id"],
                ),
            )
            return int(existing["id"]), False, existing

        service_id = self.insert_and_get_id(
            """
            INSERT INTO Services (node_id, port, protocol, state, service_name, product, version, banner, last_seen)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, SYSUTCDATETIME())
            """,
            (
                node_id,
                service["port"],
                service["protocol"],
                service.get("state", "unknown"),
                service.get("service_name"),
                service.get("product"),
                service.get("version"),
                service.get("banner"),
            ),
        )
        return service_id, True, None

    def create_test_result(
        self,
        target: str,
        test_type: str,
        result: str,
        latency_ms: int | None = None,
        details: str | None = None,
        node_id: int | None = None,
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO Tests (node_id, target, type, latency, latency_ms, result, details)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (node_id, target, test_type, float(latency_ms) if latency_ms is not None else None, latency_ms, result, details),
        )

    def create_login(
        self,
        node_id: int,
        username: str,
        result: str,
        source: str | None = None,
        source_ip: str | None = None,
        source_mac: str | None = None,
        auth_channel: str | None = None,
        account_type: str | None = None,
        risk_score: int = 0,
        details: str | None = None,
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO Logins (node_id, username, source, source_ip, source_mac, auth_channel, account_type, result, risk_score, details)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (node_id, username, source, source_ip, source_mac, auth_channel, account_type, result, risk_score, details),
        )

    def get_node_logins(self, node_id: int) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, node_id, username, source, source_ip, source_mac, auth_channel, account_type, result, risk_score, timestamp, details
            FROM Logins
            WHERE node_id = ?
            ORDER BY timestamp DESC
            """,
            (node_id,),
        )

    def list_latest_alerts(self, limit: int = 10) -> list[dict[str, Any]]:
        return self.fetch_all(
            f"""
            SELECT TOP {int(limit)} a.id, a.type, a.severity, a.description, a.status, a.timestamp, n.hostname, n.ip
            FROM Alerts a
            LEFT JOIN Nodes n ON n.id = a.node_id
            ORDER BY a.id DESC
            """
        )

    def list_recent_security_events(self, limit: int = 10) -> list[dict[str, Any]]:
        return self.fetch_all(
            f"""
            SELECT TOP {int(limit)} se.id, se.source, se.event_type, se.severity, se.message, se.event_time, n.hostname, n.ip
            FROM SecurityEvents se
            LEFT JOIN Nodes n ON n.id = se.node_id
            ORDER BY se.event_time DESC, se.id DESC
            """
        )

    def get_dashboard_operations(self) -> dict[str, Any]:
        counts = self.fetch_one(
            """
            SELECT
                (SELECT COUNT(*) FROM SecurityEvents) AS total_security_events,
                (SELECT COUNT(*) FROM RawLogs) AS total_raw_logs,
                (SELECT COUNT(*) FROM Nodes) AS total_devices,
                (SELECT COUNT(*) FROM Nodes WHERE status <> 'online') AS inactive_devices,
                (SELECT COUNT(*) FROM Alerts WHERE status IN ('open', 'ack')) AS open_alerts,
                (SELECT COUNT(*) FROM Alerts WHERE severity IN ('high', 'critical') AND status IN ('open', 'ack')) AS critical_alerts,
                (SELECT COUNT(*) FROM Logins) AS total_logins,
                (SELECT COUNT(*) FROM Logins WHERE result = 'failed') AS failed_logins,
                (SELECT COUNT(*) FROM Logins WHERE result = 'success') AS successful_logins,
                (SELECT COUNT(*) FROM Tests WHERE result <> 'success') AS failed_tests,
                (SELECT COUNT(*) FROM Services WHERE state = 'open') AS open_services,
                (SELECT COUNT(*) FROM Agents) AS total_agents,
                (SELECT COUNT(*) FROM Agents WHERE status = 'online') AS online_agents,
                (SELECT COUNT(*) FROM Agents WHERE status = 'offline') AS offline_agents,
                (SELECT COUNT(*) FROM AgentServices WHERE status <> 'running') AS agent_services_down,
                (SELECT COUNT(*) FROM AgentEvents WHERE level IN ('error', 'critical')) AS agent_error_events,
                (SELECT COUNT(*) FROM ScanJobs WHERE enabled = 1) AS active_scan_jobs,
                (SELECT COUNT(*) FROM HealthChecks WHERE enabled = 1) AS active_health_checks
            """
        ) or {}

        protocol_rows = self.fetch_all(
            """
            SELECT
                CASE
                    WHEN s.port = 22 OR s.service_name LIKE '%ssh%' THEN 'SSH'
                    WHEN s.port = 443 OR s.service_name LIKE '%https%' THEN 'HTTPS'
                    WHEN s.port IN (80, 8080) OR s.service_name = 'http' THEN 'HTTP'
                    WHEN s.port = 445 OR s.service_name LIKE '%microsoft-ds%' OR s.service_name LIKE '%smb%' THEN 'SMB'
                    WHEN s.port = 3389 OR s.service_name LIKE '%rdp%' OR s.service_name LIKE '%ms-wbt-server%' THEN 'RDP'
                    WHEN s.port = 1433 OR s.service_name LIKE '%mssql%' THEN 'MSSQL'
                    ELSE UPPER(COALESCE(s.protocol, 'tcp'))
                END AS protocol_name,
                COUNT(*) AS total
            FROM Services s
            WHERE s.state = 'open'
            GROUP BY
                CASE
                    WHEN s.port = 22 OR s.service_name LIKE '%ssh%' THEN 'SSH'
                    WHEN s.port = 443 OR s.service_name LIKE '%https%' THEN 'HTTPS'
                    WHEN s.port IN (80, 8080) OR s.service_name = 'http' THEN 'HTTP'
                    WHEN s.port = 445 OR s.service_name LIKE '%microsoft-ds%' OR s.service_name LIKE '%smb%' THEN 'SMB'
                    WHEN s.port = 3389 OR s.service_name LIKE '%rdp%' OR s.service_name LIKE '%ms-wbt-server%' THEN 'RDP'
                    WHEN s.port = 1433 OR s.service_name LIKE '%mssql%' THEN 'MSSQL'
                    ELSE UPPER(COALESCE(s.protocol, 'tcp'))
                END
            ORDER BY total DESC, protocol_name
            """
        )

        top_assets = self.fetch_all(
            """
            SELECT TOP 6
                n.id,
                COALESCE(n.hostname, n.ip) AS label,
                n.ip,
                n.status,
                n.risk_score,
                (SELECT COUNT(*) FROM Alerts a WHERE a.node_id = n.id AND a.status IN ('open', 'ack')) AS open_alerts,
                (SELECT COUNT(*) FROM Services s WHERE s.node_id = n.id AND s.state = 'open') AS services
            FROM Nodes n
            ORDER BY n.risk_score DESC, open_alerts DESC, services DESC, n.id DESC
            """
        )

        top_devices = self.fetch_all(
            """
            SELECT TOP 5
                COALESCE(n.hostname, n.ip) AS label,
                COUNT(s.id) AS service_count
            FROM Nodes n
            LEFT JOIN Services s ON s.node_id = n.id AND s.state = 'open'
            GROUP BY COALESCE(n.hostname, n.ip)
            ORDER BY service_count DESC, label
            """
        )

        service_ports = self.fetch_all(
            """
            SELECT TOP 8
                CAST(port AS NVARCHAR(12)) AS port_label,
                COUNT(*) AS total
            FROM Services
            WHERE state = 'open'
            GROUP BY port
            ORDER BY total DESC, port
            """
        )

        severity_distribution = self.fetch_all(
            """
            SELECT severity, COUNT(*) AS total
            FROM Alerts
            WHERE status IN ('open', 'ack')
            GROUP BY severity
            ORDER BY COUNT(*) DESC, severity
            """
        )

        recent_security = self.list_recent_security_events(8)
        recent_alerts = self.list_latest_alerts(8)
        latest_scan_runs = self.list_latest_scan_job_runs(8)
        latest_check_results = self.list_recent_health_results(8)
        agents_overview = self.get_agents_overview()
        trend_rows = self.fetch_all(
            """
            WITH days AS (
                SELECT CAST(DATEADD(DAY, -6, SYSUTCDATETIME()) AS DATE) AS day_bucket
                UNION ALL
                SELECT DATEADD(DAY, 1, day_bucket)
                FROM days
                WHERE day_bucket < CAST(SYSUTCDATETIME() AS DATE)
            )
            SELECT
                CONVERT(NVARCHAR(10), d.day_bucket, 120) AS bucket,
                ISNULL(se.events_count, 0) AS security_events,
                ISNULL(al.alert_count, 0) AS alerts_count,
                ISNULL(lo.login_count, 0) AS login_count
            FROM days d
            LEFT JOIN (
                SELECT CAST(event_time AS DATE) AS day_bucket, COUNT(*) AS events_count
                FROM SecurityEvents
                GROUP BY CAST(event_time AS DATE)
            ) se ON se.day_bucket = d.day_bucket
            LEFT JOIN (
                SELECT CAST(timestamp AS DATE) AS day_bucket, COUNT(*) AS alert_count
                FROM Alerts
                GROUP BY CAST(timestamp AS DATE)
            ) al ON al.day_bucket = d.day_bucket
            LEFT JOIN (
                SELECT CAST(timestamp AS DATE) AS day_bucket, COUNT(*) AS login_count
                FROM Logins
                GROUP BY CAST(timestamp AS DATE)
            ) lo ON lo.day_bucket = d.day_bucket
            ORDER BY d.day_bucket
            OPTION (MAXRECURSION 7)
            """
        )

        suspicious_accounts = self.fetch_all(
            """
            SELECT username, COUNT(*) AS failed_count
            FROM Logins
            WHERE result = 'failed'
            GROUP BY username
            HAVING COUNT(*) >= 2
            ORDER BY failed_count DESC, username
            """
        )
        multi_origin = self.fetch_all(
            """
            SELECT username,
                   COUNT(DISTINCT ISNULL(source_ip, source)) AS ip_origins,
                   COUNT(DISTINCT ISNULL(source_mac, source)) AS mac_origins
            FROM Logins
            GROUP BY username
            HAVING COUNT(DISTINCT ISNULL(source_ip, source)) > 1 OR COUNT(DISTINCT ISNULL(source_mac, source)) > 1
            ORDER BY username
            """
        )

        failed_logins = int(counts.get("failed_logins") or 0)
        failed_tests = int(counts.get("failed_tests") or 0)
        open_alerts = int(counts.get("open_alerts") or 0)
        critical_alerts = int(counts.get("critical_alerts") or 0)
        open_services = int(counts.get("open_services") or 0)
        total_agents = int(counts.get("total_agents") or 0)
        online_agents = int(counts.get("online_agents") or 0)

        return {
            "event_overview": {
                **counts,
                "all_events": int(counts.get("total_security_events") or 0) + int(counts.get("total_logins") or 0) + int(counts.get("agent_error_events") or 0),
                "windows_events": int(counts.get("total_logins") or 0) + int(counts.get("agent_error_events") or 0),
                "network_events": int(counts.get("total_security_events") or 0) + int(counts.get("total_raw_logs") or 0),
                "all_devices": int(counts.get("total_devices") or 0) + total_agents,
                "suspicious_accounts": len(suspicious_accounts),
                "multi_origin_accounts": len(multi_origin),
                "blocked_estimated": failed_tests + failed_logins,
                "suspicious_estimated": critical_alerts + failed_logins,
                "evaded_estimated": len(multi_origin),
                "requests_estimated": open_services + int(counts.get("total_security_events") or 0),
                "failed_checks": failed_tests,
                "online_agents": online_agents,
                "agents_online_ratio": f"{online_agents}/{max(total_agents, 1)}",
            },
            "platform_health": [
                {"id": "frontend", "label": "Frontend Console", "kind": "container", "status": "up", "detail": "Static UI su localhost:8080"},
                {"id": "backend", "label": "Flask API", "kind": "container", "status": "up", "detail": "API REST, auth admin, ingest e dashboard"},
                {"id": "sqlserver", "label": "SQL Server", "kind": "container", "status": "up", "detail": "Persistenza NetVisor e query live"},
                {"id": "scanner", "label": "Scanner Pipeline", "kind": "service", "status": "up", "detail": "Nmap/Masscan demo-safe e parser ingest"},
                {"id": "scan-worker", "label": "Scan Worker", "kind": "service", "status": "up", "detail": "Scheduler job dichiarativi e run history"},
                {"id": "sqlserver_data", "label": "Volume sqlserver_data", "kind": "volume", "status": "up", "detail": "Volume logico di persistenza"},
            ],
            "protocols": [{"protocol": row["protocol_name"], "count": int(row["total"])} for row in protocol_rows],
            "top_assets": top_assets,
            "top_devices": [{"label": row["label"], "count": int(row["service_count"])} for row in top_devices],
            "services_by_port": [{"label": row["port_label"], "count": int(row["total"])} for row in service_ports],
            "alert_severity_distribution": [{"label": row["severity"], "count": int(row["total"])} for row in severity_distribution],
            "recent_alerts": recent_alerts,
            "recent_security_events": recent_security,
            "latest_scan_runs": latest_scan_runs,
            "latest_check_results": latest_check_results,
            "agents_overview": agents_overview,
            "event_trend": [
                {
                    "label": row["bucket"],
                    "security_events": int(row["security_events"]),
                    "alerts": int(row["alerts_count"]),
                    "logins": int(row["login_count"]),
                }
                for row in trend_rows
            ],
        }


    def _build_activity_flows(self, time_window_hours: int = 1) -> list:
        # FIX: usa self.fetch_all() (Repository non ha _get_connection — l'helper
        # corretto è la funzione importata da db.py, non un metodo di istanza).
        flows: list = []
        try:
            health_rows = self.fetch_all(
                """
                SELECT TOP 50 hc.target, hcr.check_type, hcr.result, hcr.latency_ms, hcr.port, hcr.checked_at
                FROM HealthCheckResults hcr JOIN HealthChecks hc ON hc.id = hcr.check_id
                WHERE hcr.checked_at >= DATEADD(HOUR, ?, SYSUTCDATETIME())
                ORDER BY hcr.checked_at DESC
                """,
                (-abs(time_window_hours),),
            )
            for row in health_rows:
                ct = (row.get("check_type") or "tcp").lower()
                flows.append({
                    "from": "backend-monitoring-api",
                    "to": "assets-core",
                    "protocol": ct,
                    "port": int(row["port"]) if row.get("port") else None,
                    "label": f"{ct.upper()} on {row['target']}",
                    "active": (row.get("result") or "").lower() == "success",
                    "type": "health_check",
                })
            scan_rows = self.fetch_all(
                """
                SELECT TOP 30 sjr.scanner, sjr.target, sjr.status, sjr.started_at
                FROM ScanJobRuns sjr
                WHERE sjr.started_at >= DATEADD(HOUR, ?, SYSUTCDATETIME())
                ORDER BY sjr.started_at DESC
                """,
                (-abs(time_window_hours),),
            )
            for row in scan_rows:
                flows.append({
                    "from": "scanner-core",
                    "to": "assets-core",
                    "protocol": "ipv4",
                    "port": None,
                    "label": f"{(row.get('scanner') or 'nmap').upper()} scan on {row['target']}",
                    "active": (row.get("status") or "").lower() in ("success", "running", "completed"),
                    "type": "scan_run",
                })
        except Exception:
            pass
        return flows

    def get_connections_overview(self) -> dict[str, Any]:
        summary = self.fetch_one(
            """
            SELECT
                (SELECT COUNT(*) FROM Nodes WHERE status = 'online') AS active_nodes,
                (SELECT COUNT(*) FROM Nodes WHERE status <> 'online') AS inactive_nodes,
                (SELECT COUNT(*) FROM Services WHERE state = 'open') AS open_services,
                (SELECT COUNT(*) FROM Scans) AS total_scans,
                (SELECT COUNT(*) FROM RawLogs) AS total_raw_logs,
                (SELECT COUNT(*) FROM RawLogs WHERE source = 'nmap') AS nmap_raw_logs,
                (SELECT COUNT(*) FROM RawLogs WHERE source = 'masscan') AS masscan_raw_logs,
                (SELECT COUNT(*) FROM Tests WHERE result = 'success') AS successful_tests,
                (SELECT COUNT(*) FROM Tests WHERE result <> 'success') AS failed_tests,
                (SELECT COUNT(*) FROM Logins WHERE result = 'failed') AS failed_logins
            """
        ) or {}

        services = self.fetch_all(
            """
            SELECT
                n.hostname,
                n.ip,
                n.status AS node_status,
                s.port,
                s.protocol,
                s.state,
                s.service_name,
                s.product,
                s.version,
                s.last_seen
            FROM Services s
            INNER JOIN Nodes n ON n.id = s.node_id
            ORDER BY n.ip, s.port
            """
        )

        scans = self.list_scans()[:10]
        raw_logs = self.fetch_all(
            """
            SELECT TOP 10 id, source, scan_id, format, received_at, LEFT(content, 900) AS snippet
            FROM RawLogs
            ORDER BY id DESC
            """
        )
        tests = self.fetch_all(
            """
            SELECT TOP 10 target, type, latency_ms, result, checked_at, details
            FROM Tests
            ORDER BY checked_at DESC, id DESC
            """
        )
        protocols = self.fetch_all(
            """
            SELECT
                CASE
                    WHEN port = 22 OR service_name LIKE '%ssh%' THEN 'SSH'
                    WHEN port = 443 OR service_name LIKE '%https%' THEN 'HTTPS'
                    WHEN port IN (80, 8080) OR service_name = 'http' THEN 'HTTP'
                    WHEN port = 445 OR service_name LIKE '%microsoft-ds%' OR service_name LIKE '%smb%' THEN 'SMB'
                    WHEN port = 3389 OR service_name LIKE '%rdp%' OR service_name LIKE '%ms-wbt-server%' THEN 'RDP'
                    ELSE UPPER(COALESCE(protocol, 'tcp'))
                END AS protocol_name,
                COUNT(*) AS total
            FROM Services
            WHERE state = 'open'
            GROUP BY
                CASE
                    WHEN port = 22 OR service_name LIKE '%ssh%' THEN 'SSH'
                    WHEN port = 443 OR service_name LIKE '%https%' THEN 'HTTPS'
                    WHEN port IN (80, 8080) OR service_name = 'http' THEN 'HTTP'
                    WHEN port = 445 OR service_name LIKE '%microsoft-ds%' OR service_name LIKE '%smb%' THEN 'SMB'
                    WHEN port = 3389 OR service_name LIKE '%rdp%' OR service_name LIKE '%ms-wbt-server%' THEN 'RDP'
                    ELSE UPPER(COALESCE(protocol, 'tcp'))
                END
            ORDER BY total DESC
            """
        )

        failed_tests = int(summary.get("failed_tests") or 0)
        failed_logins = int(summary.get("failed_logins") or 0)

        return {
            "summary": {
                **summary,
                "blocked_estimated": failed_tests + failed_logins,
                "suspicious_estimated": len([item for item in services if item.get("port") in {445, 3389, 1433, 23, 21}]),
                "evaded_estimated": len(self.fetch_all("SELECT username FROM Logins GROUP BY username HAVING COUNT(DISTINCT ISNULL(source_ip, source)) > 1")),
            },
            "services": services,
            "protocols": [{"protocol": row["protocol_name"], "count": int(row["total"])} for row in protocols],
            "tests": tests,
            "raw_logs": raw_logs,
            "scans": scans,
        }

    def get_login_security_overview(self) -> dict[str, Any]:
        # ---- KPI da Logins (login di rete: agenti, scanner) ----------------
        net_summary = self.fetch_one(
            """
            SELECT
                COUNT(*) AS total_logins,
                SUM(CASE WHEN result = 'success' THEN 1 ELSE 0 END) AS success_logins,
                SUM(CASE WHEN result = 'failed'  THEN 1 ELSE 0 END) AS failed_logins,
                COUNT(DISTINCT username) AS unique_users,
                SUM(CASE WHEN account_type = 'admin' THEN 1 ELSE 0 END) AS admin_events
            FROM Logins
            """
        ) or {}

        # ---- KPI da AuthAuditLog (login web/API) ---------------------------
        auth_summary = self.fetch_one(
            """
            SELECT
                COUNT(*)  AS auth_total,
                SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) AS auth_success,
                SUM(CASE WHEN success = 0 THEN 1 ELSE 0 END) AS auth_failed,
                SUM(CASE WHEN event_type = N'admin_login' THEN 1 ELSE 0 END) AS auth_admin,
                COUNT(DISTINCT username) AS auth_unique
            FROM AuthAuditLog
            WHERE event_type IN (
                N'login_success', N'admin_login', N'login_failed',
                N'login_locked', N'login_rate_limited'
            )
            """
        ) or {}

        merged_summary = {
            "total_logins":   int(net_summary.get("total_logins")  or 0) + int(auth_summary.get("auth_total")   or 0),
            "success_logins": int(net_summary.get("success_logins") or 0) + int(auth_summary.get("auth_success") or 0),
            "failed_logins":  int(net_summary.get("failed_logins")  or 0) + int(auth_summary.get("auth_failed")  or 0),
            "unique_users":   int(net_summary.get("unique_users")   or 0) + int(auth_summary.get("auth_unique")  or 0),
            "admin_events":   int(net_summary.get("admin_events")   or 0) + int(auth_summary.get("auth_admin")   or 0),
        }

        # ---- Top failures da Logins (anomalie di rete) ---------------------
        top_failures = self.fetch_all(
            """
            SELECT TOP 6 username, COUNT(*) AS failed_count
            FROM Logins
            WHERE result = 'failed'
            GROUP BY username
            ORDER BY failed_count DESC, username
            """
        )

        # ---- Peak hours da Logins ------------------------------------------
        peak_hours = self.fetch_all(
            """
            SELECT
                RIGHT('0' + CAST(DATEPART(HOUR, timestamp) AS NVARCHAR(2)), 2) AS hour_bucket,
                COUNT(*) AS total
            FROM Logins
            GROUP BY DATEPART(HOUR, timestamp)
            ORDER BY hour_bucket
            """
        )

        # ---- Anomalie di rete da Logins ------------------------------------
        anomalies = self.fetch_all(
            """
            SELECT
                username,
                SUM(CASE WHEN result = 'failed' THEN 1 ELSE 0 END) AS failed_count,
                COUNT(DISTINCT ISNULL(source_ip, source)) AS source_ips,
                COUNT(DISTINCT ISNULL(source_mac, source)) AS source_macs,
                MAX(risk_score) AS max_risk
            FROM Logins
            GROUP BY username
            HAVING SUM(CASE WHEN result = 'failed' THEN 1 ELSE 0 END) >= 2
               OR COUNT(DISTINCT ISNULL(source_ip, source)) > 1
               OR COUNT(DISTINCT ISNULL(source_mac, source)) > 1
            ORDER BY max_risk DESC, failed_count DESC, username
            """
        )

        # ---- Recent activity: UNION Logins (rete) + AuthAuditLog (web/API) -
        recent_activity = self.fetch_all(
            """
            SELECT TOP 20
                id, username, source, source_ip, source_mac, auth_channel,
                account_type, result, risk_score, timestamp, hostname, ip
            FROM (
                SELECT
                    l.id,
                    l.username,
                    l.source,
                    l.source_ip,
                    l.source_mac,
                    l.auth_channel,
                    l.account_type,
                    l.result,
                    CAST(l.risk_score AS INT) AS risk_score,
                    l.timestamp,
                    n.hostname,
                    n.ip
                FROM Logins l
                INNER JOIN Nodes n ON n.id = l.node_id
                UNION ALL
                SELECT
                    a.id,
                    a.username,
                    N'web/api'        AS source,
                    a.ip_address      AS source_ip,
                    NULL              AS source_mac,
                    N'web'            AS auth_channel,
                    N'user'           AS account_type,
                    CASE WHEN a.success = 1 THEN N'success' ELSE N'failed' END AS result,
                    CAST(0 AS INT)    AS risk_score,
                    a.created_at      AS timestamp,
                    NULL              AS hostname,
                    a.ip_address      AS ip
                FROM AuthAuditLog a
                WHERE a.event_type IN (
                    N'login_success', N'admin_login', N'login_failed',
                    N'login_locked',  N'login_rate_limited'
                )
            ) combined
            ORDER BY timestamp DESC
            """
        )

        # ---- Audit activity: AuditLog + eventi auth da AuthAuditLog --------
        audit = self.fetch_all(
            """
            SELECT TOP 15 actor, action, details, created_at
            FROM (
                SELECT actor, action, details, created_at
                FROM AuditLog
                UNION ALL
                SELECT
                    username      AS actor,
                    event_type    AS action,
                    message       AS details,
                    created_at
                FROM AuthAuditLog
                WHERE event_type IN (
                    N'admin_login', N'login_success', N'login_failed',
                    N'logout', N'refresh_success', N'login_locked',
                    N'login_rate_limited', N'user_created'
                )
            ) combined
            ORDER BY created_at DESC
            """
        )

        formatted_anomalies = []
        for row in anomalies:
            anomaly_types = []
            if int(row["failed_count"]) >= 2:
                anomaly_types.append("failed-burst")
            if int(row["source_ips"]) > 1 or int(row["source_macs"]) > 1:
                anomaly_types.append("multi-origin")
            formatted_anomalies.append(
                {
                    "username":     row["username"],
                    "failed_count": int(row["failed_count"]),
                    "source_ips":   int(row["source_ips"]),
                    "source_macs":  int(row["source_macs"]),
                    "risk_score":   int(row["max_risk"] or 0),
                    "severity":     "high" if "multi-origin" in anomaly_types else "medium",
                    "types":        anomaly_types,
                }
            )

        return {
            "summary": {
                **merged_summary,
                "suspicious_accounts":   len(formatted_anomalies),
                "multi_origin_accounts": len([a for a in formatted_anomalies if "multi-origin" in a["types"]]),
            },
            "top_failures":    [{"username": row["username"], "failed_count": int(row["failed_count"])} for row in top_failures],
            "peak_hours":      [{"hour": row["hour_bucket"], "count": int(row["total"])} for row in peak_hours],
            "anomalies":       formatted_anomalies,
            "recent_activity": recent_activity,
            "audit_activity":  audit,
        }

    def get_topology(self, time_window_hours: int = 1) -> dict[str, Any]:
        rows = self.fetch_all(
            """
            SELECT
                n.id,
                n.hostname,
                n.ip,
                n.status,
                n.os_guess,
                n.vendor,
                n.risk_score,
                s.id AS service_id,
                s.port,
                s.protocol,
                s.state,
                s.service_name,
                s.product,
                s.version,
                (
                    SELECT COUNT(*)
                    FROM Alerts a
                    WHERE a.node_id = n.id AND a.status IN ('open', 'ack')
                ) AS open_alerts,
                (
                    SELECT COUNT(*)
                    FROM Logins l
                    WHERE l.node_id = n.id
                ) AS login_events
            FROM Nodes n
            LEFT JOIN Services s ON s.node_id = n.id AND s.state = 'open'
            ORDER BY n.id, s.port
            """
        )
        agents = self.list_agents()
        scan_jobs = self.list_scan_jobs()[:8]
        health_checks = self.list_health_checks()[:8]

        nodes_map: dict[int, dict[str, Any]] = {}
        traffic: list[dict[str, Any]] = []
        flow_seed: list[dict[str, Any]] = []

        for row in rows:
            node_id = int(row["id"])
            node_resource_id = f"node-{node_id}"
            if node_id not in nodes_map:
                nodes_map[node_id] = {
                    "id": node_id,
                    "resource_id": node_resource_id,
                    "label": row.get("hostname") or row["ip"],
                    "hostname": row.get("hostname"),
                    "ip": row["ip"],
                    "status": row["status"],
                    "os_guess": row.get("os_guess"),
                    "vendor": row.get("vendor"),
                    "risk_score": int(row.get("risk_score") or 0),
                    "open_alerts": int(row.get("open_alerts") or 0),
                    "login_events": int(row.get("login_events") or 0),
                    "services": [],
                    "dependencies": ["scanner", "ipv4 discovery"],
                }
                traffic.append(
                    {
                        "from": "scanner-core",
                        "to": node_resource_id,
                        "protocol": "ipv4",
                        "label": "Discovery IPv4",
                        "port": None,
                        "volume": 18,
                        "avg_mbps": 4.2,
                    }
                )

            if row.get("service_id") is None:
                continue

            inferred_protocol = self._infer_flow_protocol(row)
            estimated_volume = self._estimate_service_volume(row)
            service = {
                "id": int(row["service_id"]),
                "resource_id": f"service-{int(row['service_id'])}",
                "port": int(row["port"]),
                "protocol": row["protocol"],
                "state": row["state"],
                "service_name": row.get("service_name"),
                "product": row.get("product"),
                "version": row.get("version"),
                "flow_protocol": inferred_protocol,
                "volume": estimated_volume,
                "avg_mbps": self._estimate_avg_mbps(estimated_volume),
            }
            nodes_map[node_id]["services"].append(service)

            dependency_label = self._format_dependency_label(service)
            if dependency_label not in nodes_map[node_id]["dependencies"]:
                nodes_map[node_id]["dependencies"].append(dependency_label)

            traffic.append(
                {
                    "from": "backend-monitoring-api",
                    "to": service["resource_id"],
                    "protocol": inferred_protocol,
                    "label": dependency_label,
                    "port": service["port"],
                    "volume": estimated_volume,
                    "avg_mbps": service["avg_mbps"],
                }
            )
            flow_seed.append(
                {
                    "from": node_resource_id,
                    "to": service["resource_id"],
                    "protocol": inferred_protocol,
                    "label": f"{self._format_service_resource_label(service)} path",
                    "port": service["port"],
                    "active": service["state"] == "open",
                    "type": "service",
                    "volume": estimated_volume,
                    "avg_mbps": service["avg_mbps"],
                    "duplex_pair_key": f"{node_resource_id}|{service['resource_id']}|{inferred_protocol}|{service['port']}",
                    "direction": "out",
                }
            )
            flow_seed.append(
                {
                    "from": service["resource_id"],
                    "to": node_resource_id,
                    "protocol": inferred_protocol,
                    "label": f"{self._format_service_resource_label(service)} return",
                    "port": service["port"],
                    "active": service["state"] == "open",
                    "type": "service",
                    "volume": estimated_volume,
                    "avg_mbps": service["avg_mbps"],
                    "duplex_pair_key": f"{node_resource_id}|{service['resource_id']}|{inferred_protocol}|{service['port']}",
                    "direction": "in",
                }
            )

        edges = [{"from": "scanner", "to": node["resource_id"], "type": "discovered"} for node in nodes_map.values()]
        # PDF Errori_v4.2 §1.1: Naming univoco con prefisso CTR_ per tutti i
        # parent docker container, così l'operatore distingue "container reali"
        # (CTR_*) da gruppi logici / volumi / servizi astratti.
        resources = [
            {
                "id": "soc-console",
                "label": "CTR_frontend-1",
                "kind": "container",
                "status": "online",
                "group": "control-plane",
                "expandable": True,
                "details": "nginx unprivileged :8080 — serve frontend Vanilla JS, proxy /api → backend.",
                "level": 1,
            },
            {
                "id": "backend-core",
                "label": "CTR_backend-1",
                "kind": "container",
                "status": "online",
                "group": "control-plane",
                "expandable": True,
                "details": "Flask :5000 — API REST, orchestrazione scan, alerting, query admin.",
                "level": 1,
            },
            {
                "id": "sql-core",
                "label": "CTR_sqlserver-1",
                "kind": "database",
                "status": "online",
                "group": "control-plane",
                "expandable": True,
                "details": "MSSQL 2022 :1433 — persistenza NetVisor, SIEM events, audit log.",
                "level": 1,
            },
            {
                "id": "scanner-core",
                "label": "CTR_scan-worker-1",
                "kind": "container",
                "status": "online",
                "group": "control-plane",
                "expandable": True,
                "details": "Worker schedulato — Masscan, Nmap, parser, ingest.",
                "level": 1,
            },
            {
                "id": "assets-core",
                "label": "CTR_assets-1",
                "kind": "group",
                "status": "online",
                "group": "assets",
                "expandable": True,
                "details": (
                    f"{len(nodes_map)} host scoperti dalle scansioni · clicca per espandere"
                    if nodes_map else "Network devices, server e endpoint osservati."
                ),
                "child_count": len(nodes_map),
                "highlight": len(nodes_map) > 0,
            },
            {
                "id": "agents-core",
                "label": "CTR_agents-1",
                "kind": "group",
                "status": "online",
                "group": "control-plane",
                "expandable": True,
                "details": "Telemetry agent outbound dagli host autorizzati.",
            },
            {
                "id": "jobs-core",
                "label": "CTR_jobs-1",
                "kind": "group",
                "status": "online",
                "group": "control-plane",
                "expandable": True,
                "details": "Job dichiarativi schedulati e health checks sintetici.",
            },
            {
                "id": "pipeline-core",
                "label": "CTR_event-pipeline-1",
                "kind": "container",
                "status": "online",
                "group": "control-plane",
                "expandable": True,
                "details": "Normalizzazione raw logs, metriche agent e alerting.",
            },
            {
                "id": "api-auth",
                "label": "Auth API",
                "kind": "service",
                "status": "online",
                "parent": "backend-core",
                "details": "Login admin e rilascio token.",
            },
            {
                "id": "api-dashboard",
                "label": "Dashboard API",
                "kind": "service",
                "status": "online",
                "parent": "backend-core",
                "details": "Summary, event overview e health grid.",
            },
            {
                "id": "backend-monitoring-api",
                "label": "Monitoring API",
                "kind": "service",
                "status": "online",
                "parent": "backend-core",
                "details": "Scan manuali, test connettivita e topology feed.",
            },
            {
                "id": "alert-engine",
                "label": "Alert Engine",
                "kind": "service",
                "status": "online",
                "parent": "pipeline-core",
                "details": "Regole Mini-SIEM e security events.",
            },
            {
                "id": "db-nodes",
                "label": "Nodes + Services",
                "kind": "dataset",
                "status": "online",
                "parent": "sql-core",
                "details": "Asset inventory e servizi scoperti.",
            },
            {
                "id": "db-alerts",
                "label": "Alerts + SecurityEvents",
                "kind": "dataset",
                "status": "online",
                "parent": "sql-core",
                "details": "Alert aperti, chiusi e tracce SIEM.",
            },
            {
                "id": "db-rawlogs",
                "label": "RawLogs + Audit",
                "kind": "dataset",
                "status": "online",
                "parent": "pipeline-core",
                "details": "Raw Nmap/Masscan, audit admin e storico.",
            },
            {
                "id": "scan-masscan",
                "label": "Masscan Engine",
                "kind": "service",
                "status": "online",
                "parent": "scanner-core",
                "details": "Discovery veloce porte/IP consentiti.",
            },
            {
                "id": "scan-nmap",
                "label": "Nmap Engine",
                "kind": "service",
                "status": "online",
                "parent": "scanner-core",
                "details": "Service detection e XML ingest.",
            },
            {
                "id": "scan-ingest",
                "label": "Ingest Parser",
                "kind": "service",
                "status": "online",
                "parent": "pipeline-core",
                "details": "Normalizzazione risultati e scrittura DB.",
            },
            # ── PDF Errori_v4.2 §1.3: Volumi Docker come Storage Nodes ─────
            # Rappresentati come kind="storage_volume" (cilindri lato UI),
            # collegati al rispettivo container con flow type="volume_mount"
            # → linee tratteggiate grigie. Indicano persistenza I/O locale,
            # NON traffico TCP/IP di rete.
            {
                "id": "vol-scan-output",
                "label": "ccode_opus_fork_v1_netvisor_scan_output",
                "kind": "storage_volume",
                "status": "online",
                "parent": "scanner-core",
                "details": "Docker named volume — raw XML (nmap) / JSON (masscan) persisted by scan-worker.",
                "level": 2,
            },
            {
                "id": "vol-sqlserver-data",
                "label": "ccode_opus_fork_v1_sqlserver_data_lab",
                "kind": "storage_volume",
                "status": "online",
                "parent": "sql-core",
                "details": "Docker named volume — datafile MSSQL persisted (mdf/ldf) sopravvive ai restart container.",
                "level": 2,
            },
        ]

        for node in nodes_map.values():
            resources.append(
                {
                    "id": node["resource_id"],
                    "label": node["label"],
                    "kind": "network-device" if node["ip"].endswith(".1") else "endpoint",
                    "status": node["status"],
                    "parent": "assets-core",
                    "details": node["ip"],
                    "risk_score": node["risk_score"],
                    "open_alerts": node["open_alerts"],
                    "services": node["services"],
                    "dependencies": node["dependencies"],
                    "hostname": node["hostname"],
                    "ip": node["ip"],
                    "level": 2,
                    "expandable": bool(node["services"]),
                }
            )
            for service in node["services"]:
                details = f"{node['ip']}:{service['port']} · {service.get('product') or service.get('service_name') or service['protocol']}"
                if service.get("version"):
                    details += f" {service['version']}"
                resources.append(
                    {
                        "id": service["resource_id"],
                        "label": self._format_service_resource_label(service),
                        "kind": "service",
                        "status": "online" if service["state"] == "open" else service["state"],
                        "parent": node["resource_id"],
                        "details": details,
                        "node_ip": node["ip"],
                        "port": service["port"],
                        "transport_protocol": service["protocol"],
                        "flow_protocol": service["flow_protocol"],
                        "avg_mbps": service["avg_mbps"],
                        "volume": service["volume"],
                        "level": 3,
                    }
                )

        for agent in agents:
            resources.append(
                {
                    "id": f"agent-{agent['agent_id']}",
                    "label": agent.get("hostname") or agent["agent_id"],
                    "kind": "service",
                    "status": agent.get("status") or "unknown",
                    "parent": "agents-core",
                    "details": f"{agent.get('ip_address')} - {agent.get('os_name')}",
                    "dependencies": ["heartbeat", "metrics", "services"],
                    "metrics": {
                        "cpu": float(agent.get("cpu_percent") or 0),
                        "ram": float(agent.get("ram_percent") or 0),
                        "disk": float(agent.get("disk_percent") or 0),
                    },
                }
            )
            traffic.append(
                {
                    "from": f"agent-{agent['agent_id']}",
                    "to": "pipeline-core",
                    "protocol": "https",
                    "label": "Agent telemetry",
                    "port": 5000,
                    "volume": 22,
                    "avg_mbps": 6.8,
                }
            )

        for job in scan_jobs:
            resources.append(
                {
                    "id": f"scan-job-{job['id']}",
                    "label": job["name"],
                    "kind": "dataset",
                    "status": job.get("last_status") or "idle",
                    "parent": "jobs-core",
                    "details": f"{job['scanner']} -> {job['target']} ({job['ports']})",
                }
            )

        for check in health_checks:
            resources.append(
                {
                    "id": f"health-check-{check['id']}",
                    "label": check["name"],
                    "kind": "dataset",
                    "status": check.get("last_status") or "unknown",
                    "parent": "jobs-core",
                    "details": f"{check['check_type']} -> {check['target']}",
                }
            )

        flows = [
            {"from": "soc-console", "to": "api-auth", "protocol": "https", "port": 443, "label": "Admin login", "active": True, "type": "static"},
            {"from": "soc-console", "to": "api-dashboard", "protocol": "https", "port": 443, "label": "Dashboard fetch", "active": True, "type": "static"},
            {"from": "soc-console", "to": "backend-monitoring-api", "protocol": "https", "port": 5000, "label": "Scans / topology", "active": True, "type": "static"},
            {"from": "api-dashboard", "to": "sql-core", "protocol": "mssql", "label": "Read summary"},
            {"from": "backend-monitoring-api", "to": "sql-core", "protocol": "mssql", "port": 1433, "label": "Persist scans", "active": True, "type": "static"},
            {"from": "alert-engine", "to": "db-alerts", "protocol": "mssql", "port": 1433, "label": "Raise alerts", "active": True, "type": "static"},
            {"from": "scan-masscan", "to": "scan-ingest", "protocol": "tcp", "port": None, "label": "Raw discovery", "active": True, "type": "static"},
            {"from": "scan-nmap", "to": "scan-ingest", "protocol": "tcp", "port": None, "label": "XML service detection", "active": True, "type": "static"},
            {"from": "scan-ingest", "to": "backend-monitoring-api", "protocol": "https", "port": 5000, "label": "Ingest API", "active": True, "type": "static"},
            {"from": "jobs-core", "to": "scanner-core", "protocol": "tcp", "port": None, "label": "Scheduled scans", "active": True, "type": "static"},
            {"from": "agents-core", "to": "pipeline-core", "protocol": "https", "port": 5000, "label": "Host telemetry", "active": True, "type": "static"},
            # ── Volume mounts: type="volume_mount" → linee tratteggiate grigie
            #    (vedi §1.3 PDF). protocol="volume" così la legenda non li
            #    mette nel set protocolli di rete. ─────────────────────────
            {"from": "scanner-core", "to": "vol-scan-output", "protocol": "volume", "port": None, "label": "Volume mount: /app/scan_output", "active": True, "type": "volume_mount"},
            {"from": "sql-core",     "to": "vol-sqlserver-data", "protocol": "volume", "port": None, "label": "Volume mount: /var/opt/mssql", "active": True, "type": "volume_mount"},
            {"from": "vol-scan-output", "to": "scan-ingest",  "protocol": "tcp", "port": None, "label": "Raw file to parser","active": True, "type": "static"},
            {"from": "scan-masscan", "to": "scan-nmap",       "protocol": "tcp", "port": None, "label": "Combined: IP:port feed", "active": True, "type": "static"},
        ]
        for flow in traffic:
            flow.setdefault("active", True)
            flow.setdefault("type", "service")
        flows.extend(traffic)
        flows.extend(self._build_activity_flows(time_window_hours))
        flows.extend(flow_seed)

        duplex_specs = {
            ("soc-console", "api-auth", "https", 443),
            ("soc-console", "api-dashboard", "https", 443),
            ("soc-console", "backend-monitoring-api", "https", 5000),
            ("api-dashboard", "sql-core", "mssql", 1433),
            ("backend-monitoring-api", "sql-core", "mssql", 1433),
            ("alert-engine", "db-alerts", "mssql", 1433),
            ("scan-ingest", "backend-monitoring-api", "https", 5000),
            ("agents-core", "pipeline-core", "https", 5000),
            ("scanner-core", "vol-scan-output", "volume", None),
            ("sql-core", "vol-sqlserver-data", "volume", None),
        }
        seen_flow_keys: set[tuple[str, str, str, int | None]] = set()
        reverse_to_add: list[dict[str, Any]] = []

        for flow in flows:
            flow.setdefault("active", True)
            flow.setdefault("type", "service")
            flow.setdefault("direction", "out")
            default_volume = self._estimate_flow_volume(flow)
            flow.setdefault("volume", default_volume)
            flow.setdefault("avg_mbps", round(self._estimate_avg_mbps(flow["volume"]), 2))

            flow_key = (str(flow["from"]), str(flow["to"]), str(flow["protocol"]), flow.get("port"))
            seen_flow_keys.add(flow_key)

            pair_key = (
                min(str(flow["from"]), str(flow["to"])),
                max(str(flow["from"]), str(flow["to"])),
                str(flow["protocol"]),
                flow.get("port"),
            )
            if pair_key in duplex_specs:
                flow["duplex_pair_key"] = "|".join(
                    [pair_key[0], pair_key[1], pair_key[2], str(pair_key[3] or 0)]
                )
                reverse_key = (str(flow["to"]), str(flow["from"]), str(flow["protocol"]), flow.get("port"))
                if reverse_key not in seen_flow_keys:
                    reverse_flow = dict(flow)
                    reverse_flow["from"] = flow["to"]
                    reverse_flow["to"] = flow["from"]
                    reverse_flow["direction"] = "in"
                    reverse_flow["label"] = f"{flow['label']} return"
                    reverse_to_add.append(reverse_flow)
                    seen_flow_keys.add(reverse_key)

        flows.extend(reverse_to_add)

        return {
            "nodes": list(nodes_map.values()),
            "edges": edges,
            "traffic": traffic,
            "resources": resources,
            "flows": flows,
            "time_window_hours": time_window_hours,
            "groups": [
                {"id": "control-plane", "label": "Platform Control Plane"},
                {"id": "assets",        "label": "Network Devices & Endpoint Assets"},
            ],
        }

    def run_admin_read_query(self, query: str, max_rows: int = 200) -> dict[str, Any]:
        return self.fetch_query_result(query, max_rows=max_rows, timeout_seconds=10)

    @staticmethod
    def _format_dependency_label(service: dict[str, Any]) -> str:
        service_name = service.get("service_name") or service["protocol"]
        return f"{service_name}:{service['port']}/{service['protocol']}"

    @staticmethod
    def _format_service_resource_label(service: dict[str, Any]) -> str:
        service_name = (service.get("service_name") or service["protocol"] or "svc").upper()
        return f"{service_name}:{service['port']}"

    @staticmethod
    def _estimate_service_volume(service: dict[str, Any]) -> int:
        port = int(service["port"])
        base = 10
        if port in {80, 443, 8080}:
            base += 20
        elif port in {22, 3389, 445, 1433, 3306, 6379, 9200}:
            base += 14
        service_name = (service.get("service_name") or "").lower()
        if "http" in service_name:
            base += 5
        if "sql" in service_name or "mssql" in service_name:
            base += 4
        if service.get("product"):
            base += 2
        return min(48, base)

    @staticmethod
    def _estimate_avg_mbps(volume: int | float) -> float:
        return max(0.8, round(float(volume) * 0.28, 2))

    @staticmethod
    def _estimate_flow_volume(flow: dict[str, Any]) -> int:
        protocol = str(flow.get("protocol") or "tcp").lower()
        if protocol == "volume":
            return 10
        if protocol in {"https", "http"}:
            return 24
        if protocol in {"mssql", "smb", "rdp", "ssh"}:
            return 18
        if protocol == "ipv4":
            return 14
        return 12

    @staticmethod
    def _infer_flow_protocol(service: dict[str, Any]) -> str:
        port = int(service["port"])
        service_name = (service.get("service_name") or "").lower()
        if port == 22 or "ssh" in service_name:
            return "ssh"
        if port in {80, 8080} or "http" == service_name:
            return "http"
        if port == 443 or "https" in service_name:
            return "https"
        if port == 445 or "smb" in service_name or "microsoft-ds" in service_name:
            return "smb"
        if port == 3389 or "rdp" in service_name or "ms-wbt-server" in service_name:
            return "rdp"
        if port == 1433 or "mssql" in service_name:
            return "mssql"
        return "tcp"
