from __future__ import annotations

from typing import Any

from db import get_connection


def _row_to_dict(cursor, row) -> dict[str, Any]:
    columns = [column[0] for column in cursor.description]
    return {columns[index]: row[index] for index in range(len(columns))}


class Repository:
    # Repository piccolo e diretto per SQL Server via pyodbc.

    def fetch_all(self, query: str, params: tuple = ()) -> list[dict[str, Any]]:
        with get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()
            if not rows:
                return []
            return [_row_to_dict(cursor, row) for row in rows]

    def fetch_one(self, query: str, params: tuple = ()) -> dict[str, Any] | None:
        with get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query, params)
            row = cursor.fetchone()
            if not row:
                return None
            return _row_to_dict(cursor, row)

    def fetch_query_result(self, query: str, params: tuple = (), max_rows: int = 200, timeout_seconds: int = 10) -> dict[str, Any]:
        with get_connection() as connection:
            connection.timeout = timeout_seconds
            cursor = connection.cursor()
            cursor.execute(query, params)
            columns = [column[0] for column in cursor.description] if cursor.description else []
            rows = cursor.fetchmany(max_rows)
            extra_row = cursor.fetchone()
            return {
                "columns": columns,
                "rows": [[row[index] for index in range(len(columns))] for row in rows],
                "row_count": len(rows),
                "truncated": extra_row is not None,
            }

    def execute(self, query: str, params: tuple = ()) -> int:
        with get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query, params)
            return cursor.rowcount

    def insert_and_get_id(self, query: str, params: tuple = ()) -> int:
        with get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query, params)
            row = cursor.fetchone()
            return int(row[0])

    def get_dashboard_summary(self) -> dict[str, Any]:
        latest_scans = self.fetch_all(
            """
            SELECT TOP 5 id, date, scanner, target, ports, status, started_at, finished_at, result, result_summary
            FROM Scans
            ORDER BY id DESC
            """
        )
        counts = self.fetch_one(
            """
            SELECT
                (SELECT COUNT(*) FROM Nodes) AS total_nodes,
                (SELECT COUNT(*) FROM Nodes WHERE status = 'online') AS online_nodes,
                (SELECT COUNT(*) FROM Nodes WHERE status = 'offline') AS offline_nodes,
                (SELECT COUNT(*) FROM Alerts WHERE status IN ('open', 'ack')) AS open_alerts,
                (SELECT COUNT(*) FROM Services WHERE state = 'open') AS total_services
            """
        ) or {}
        counts["latest_scans"] = latest_scans
        return counts

    def list_nodes(self, status: str | None = None) -> list[dict[str, Any]]:
        query = """
        SELECT id, hostname, ip, status, first_seen, last_seen, os_guess, mac_address, vendor, risk_score
        FROM Nodes
        """
        params: tuple = ()
        if status:
            query += " WHERE status = ?"
            params = (status,)
        query += " ORDER BY ip"
        return self.fetch_all(query, params)

    def get_node(self, node_id: int) -> dict[str, Any] | None:
        return self.fetch_one(
            """
            SELECT id, hostname, ip, status, first_seen, last_seen, os_guess, mac_address, vendor, risk_score
            FROM Nodes WHERE id = ?
            """,
            (node_id,),
        )

    def get_node_by_ip(self, ip: str) -> dict[str, Any] | None:
        return self.fetch_one("SELECT * FROM Nodes WHERE ip = ?", (ip,))

    def get_node_services(self, node_id: int) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, node_id, port, protocol, state, service_name, product, version, banner, first_seen, last_seen
            FROM Services WHERE node_id = ?
            ORDER BY port
            """,
            (node_id,),
        )

    def get_service(self, node_id: int, port: int, protocol: str) -> dict[str, Any] | None:
        return self.fetch_one(
            """
            SELECT * FROM Services
            WHERE node_id = ? AND port = ? AND protocol = ?
            """,
            (node_id, port, protocol),
        )

    def get_node_alerts(self, node_id: int) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, type, severity, description, node_id, service_id, status, timestamp
            FROM Alerts WHERE node_id = ?
            ORDER BY id DESC
            """,
            (node_id,),
        )

    def list_alerts(self) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT a.id, a.type, a.severity, a.description, a.node_id, a.service_id, a.status, a.timestamp,
                   n.hostname, n.ip
            FROM Alerts a
            LEFT JOIN Nodes n ON n.id = a.node_id
            ORDER BY a.id DESC
            """
        )

    def update_alert_status(self, alert_id: int, status: str) -> int:
        return self.execute("UPDATE Alerts SET status = ? WHERE id = ?", (status, alert_id))

    def create_scan(self, scanner: str, target: str, ports: str | None, status: str = "queued") -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO Scans (date, scanner, target, ports, status)
            OUTPUT INSERTED.id
            VALUES (SYSUTCDATETIME(), ?, ?, ?, ?)
            """,
            (scanner, target, ports, status),
        )

    def mark_scan_started(self, scan_id: int):
        self.execute(
            "UPDATE Scans SET status = 'running', date = COALESCE(date, SYSUTCDATETIME()), started_at = SYSUTCDATETIME() WHERE id = ?",
            (scan_id,),
        )

    def finalize_scan(self, scan_id: int, status: str, result_summary: str | None = None, error_message: str | None = None):
        self.execute(
            """
            UPDATE Scans
            SET status = ?, finished_at = SYSUTCDATETIME(), result = ?, result_summary = ?, error_message = ?
            WHERE id = ?
            """,
            (status, result_summary or error_message, result_summary, error_message, scan_id),
        )

    def list_scans(self) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, date, scanner, target, ports, status, started_at, finished_at, result, result_summary, error_message
            FROM Scans
            ORDER BY id DESC
            """
        )

    def get_scan(self, scan_id: int) -> dict[str, Any] | None:
        return self.fetch_one(
            """
            SELECT id, date, scanner, target, ports, status, started_at, finished_at, result, result_summary, error_message
            FROM Scans WHERE id = ?
            """,
            (scan_id,),
        )

    def get_scan_events(self, scan_id: int) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT se.id, se.source, se.event_type, se.node_id, se.service_id, se.severity, se.message, se.event_time
            FROM SecurityEvents se
            LEFT JOIN RawLogs rl ON rl.id = se.raw_log_id
            WHERE rl.scan_id = ?
            ORDER BY se.id DESC
            """,
            (scan_id,),
        )

    def get_scan_raw(self, scan_id: int) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, source, scan_id, format, content, received_at
            FROM RawLogs WHERE scan_id = ?
            ORDER BY id DESC
            """,
            (scan_id,),
        )

    def create_raw_log(self, source: str, scan_id: int | None, log_format: str, content: str) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO RawLogs (source, scan_id, format, content)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?)
            """,
            (source, scan_id, log_format, content),
        )

    def create_security_event(
        self,
        source: str,
        event_type: str,
        message: str,
        severity: str = "info",
        node_id: int | None = None,
        service_id: int | None = None,
        raw_log_id: int | None = None,
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO SecurityEvents (source, event_type, node_id, service_id, severity, message, raw_log_id)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (source, event_type, node_id, service_id, severity, message, raw_log_id),
        )

    def create_alert(
        self,
        alert_type: str,
        severity: str,
        description: str,
        node_id: int | None = None,
        service_id: int | None = None,
        status: str = "open",
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO Alerts (type, severity, description, node_id, service_id, status)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (alert_type, severity, description, node_id, service_id, status),
        )

    def write_audit(self, action: str, details: str, actor: str = "system") -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO AuditLog (actor, action, details)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?)
            """,
            (actor, action, details),
        )

    def upsert_node(self, payload: dict[str, Any]) -> tuple[int, bool]:
        existing = self.get_node_by_ip(payload["ip"])
        if existing:
            self.execute(
                """
                UPDATE Nodes
                SET hostname = ?, status = ?, last_seen = CASE WHEN ? = 'offline' THEN last_seen ELSE SYSUTCDATETIME() END,
                    os_guess = ?, mac_address = ?, vendor = ?, risk_score = ?
                WHERE id = ?
                """,
                (
                    payload.get("hostname"),
                    payload.get("status", "unknown"),
                    payload.get("status", "unknown"),
                    payload.get("os_guess"),
                    payload.get("mac_address"),
                    payload.get("vendor"),
                    payload.get("risk_score", existing.get("risk_score", 0)),
                    existing["id"],
                ),
            )
            return int(existing["id"]), False

        node_id = self.insert_and_get_id(
            """
            INSERT INTO Nodes (hostname, ip, status, last_seen, os_guess, mac_address, vendor, risk_score)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, SYSUTCDATETIME(), ?, ?, ?, ?)
            """,
            (
                payload.get("hostname"),
                payload["ip"],
                payload.get("status", "unknown"),
                payload.get("os_guess"),
                payload.get("mac_address"),
                payload.get("vendor"),
                payload.get("risk_score", 0),
            ),
        )
        return node_id, True

    def upsert_service(self, node_id: int, service: dict[str, Any]) -> tuple[int, bool, dict[str, Any] | None]:
        existing = self.get_service(node_id, service["port"], service["protocol"])
        if existing:
            self.execute(
                """
                UPDATE Services
                SET state = ?, service_name = ?, product = ?, version = ?, banner = ?, last_seen = SYSUTCDATETIME()
                WHERE id = ?
                """,
                (
                    service.get("state", "unknown"),
                    service.get("service_name"),
                    service.get("product"),
                    service.get("version"),
                    service.get("banner"),
                    existing["id"],
                ),
            )
            return int(existing["id"]), False, existing

        service_id = self.insert_and_get_id(
            """
            INSERT INTO Services (node_id, port, protocol, state, service_name, product, version, banner, last_seen)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, SYSUTCDATETIME())
            """,
            (
                node_id,
                service["port"],
                service["protocol"],
                service.get("state", "unknown"),
                service.get("service_name"),
                service.get("product"),
                service.get("version"),
                service.get("banner"),
            ),
        )
        return service_id, True, None

    def create_test_result(
        self,
        target: str,
        test_type: str,
        result: str,
        latency_ms: int | None = None,
        details: str | None = None,
        node_id: int | None = None,
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO Tests (node_id, target, type, latency, latency_ms, result, details)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (node_id, target, test_type, float(latency_ms) if latency_ms is not None else None, latency_ms, result, details),
        )

    def create_login(
        self,
        node_id: int,
        username: str,
        result: str,
        source: str | None = None,
        source_ip: str | None = None,
        source_mac: str | None = None,
        auth_channel: str | None = None,
        account_type: str | None = None,
        risk_score: int = 0,
        details: str | None = None,
    ) -> int:
        return self.insert_and_get_id(
            """
            INSERT INTO Logins (node_id, username, source, source_ip, source_mac, auth_channel, account_type, result, risk_score, details)
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (node_id, username, source, source_ip, source_mac, auth_channel, account_type, result, risk_score, details),
        )

    def get_node_logins(self, node_id: int) -> list[dict[str, Any]]:
        return self.fetch_all(
            """
            SELECT id, node_id, username, source, source_ip, source_mac, auth_channel, account_type, result, risk_score, timestamp, details
            FROM Logins
            WHERE node_id = ?
            ORDER BY timestamp DESC
            """,
            (node_id,),
        )

    def list_latest_alerts(self, limit: int = 10) -> list[dict[str, Any]]:
        return self.fetch_all(
            f"""
            SELECT TOP {int(limit)} a.id, a.type, a.severity, a.description, a.status, a.timestamp, n.hostname, n.ip
            FROM Alerts a
            LEFT JOIN Nodes n ON n.id = a.node_id
            ORDER BY a.id DESC
            """
        )

    def list_recent_security_events(self, limit: int = 10) -> list[dict[str, Any]]:
        return self.fetch_all(
            f"""
            SELECT TOP {int(limit)} se.id, se.source, se.event_type, se.severity, se.message, se.event_time, n.hostname, n.ip
            FROM SecurityEvents se
            LEFT JOIN Nodes n ON n.id = se.node_id
            ORDER BY se.event_time DESC, se.id DESC
            """
        )

    def get_dashboard_operations(self) -> dict[str, Any]:
        counts = self.fetch_one(
            """
            SELECT
                (SELECT COUNT(*) FROM SecurityEvents) AS total_security_events,
                (SELECT COUNT(*) FROM RawLogs) AS total_raw_logs,
                (SELECT COUNT(*) FROM Nodes) AS total_devices,
                (SELECT COUNT(*) FROM Nodes WHERE status <> 'online') AS inactive_devices,
                (SELECT COUNT(*) FROM Alerts WHERE status IN ('open', 'ack')) AS open_alerts,
                (SELECT COUNT(*) FROM Alerts WHERE severity IN ('high', 'critical') AND status IN ('open', 'ack')) AS critical_alerts,
                (SELECT COUNT(*) FROM Logins) AS total_logins,
                (SELECT COUNT(*) FROM Logins WHERE result = 'failed') AS failed_logins,
                (SELECT COUNT(*) FROM Logins WHERE result = 'success') AS successful_logins,
                (SELECT COUNT(*) FROM Tests WHERE result <> 'success') AS failed_tests,
                (SELECT COUNT(*) FROM Services WHERE state = 'open') AS open_services
            """
        ) or {}

        protocol_rows = self.fetch_all(
            """
            SELECT
                CASE
                    WHEN s.port = 22 OR s.service_name LIKE '%ssh%' THEN 'SSH'
                    WHEN s.port = 443 OR s.service_name LIKE '%https%' THEN 'HTTPS'
                    WHEN s.port IN (80, 8080) OR s.service_name = 'http' THEN 'HTTP'
                    WHEN s.port = 445 OR s.service_name LIKE '%microsoft-ds%' OR s.service_name LIKE '%smb%' THEN 'SMB'
                    WHEN s.port = 3389 OR s.service_name LIKE '%rdp%' OR s.service_name LIKE '%ms-wbt-server%' THEN 'RDP'
                    WHEN s.port = 1433 OR s.service_name LIKE '%mssql%' THEN 'MSSQL'
                    ELSE UPPER(COALESCE(s.protocol, 'tcp'))
                END AS protocol_name,
                COUNT(*) AS total
            FROM Services s
            WHERE s.state = 'open'
            GROUP BY
                CASE
                    WHEN s.port = 22 OR s.service_name LIKE '%ssh%' THEN 'SSH'
                    WHEN s.port = 443 OR s.service_name LIKE '%https%' THEN 'HTTPS'
                    WHEN s.port IN (80, 8080) OR s.service_name = 'http' THEN 'HTTP'
                    WHEN s.port = 445 OR s.service_name LIKE '%microsoft-ds%' OR s.service_name LIKE '%smb%' THEN 'SMB'
                    WHEN s.port = 3389 OR s.service_name LIKE '%rdp%' OR s.service_name LIKE '%ms-wbt-server%' THEN 'RDP'
                    WHEN s.port = 1433 OR s.service_name LIKE '%mssql%' THEN 'MSSQL'
                    ELSE UPPER(COALESCE(s.protocol, 'tcp'))
                END
            ORDER BY total DESC, protocol_name
            """
        )

        top_assets = self.fetch_all(
            """
            SELECT TOP 6
                n.id,
                COALESCE(n.hostname, n.ip) AS label,
                n.ip,
                n.status,
                n.risk_score,
                (SELECT COUNT(*) FROM Alerts a WHERE a.node_id = n.id AND a.status IN ('open', 'ack')) AS open_alerts,
                (SELECT COUNT(*) FROM Services s WHERE s.node_id = n.id AND s.state = 'open') AS services
            FROM Nodes n
            ORDER BY n.risk_score DESC, open_alerts DESC, services DESC, n.id DESC
            """
        )

        recent_security = self.list_recent_security_events(8)
        recent_alerts = self.list_latest_alerts(8)
        trend_rows = self.fetch_all(
            """
            WITH days AS (
                SELECT CAST(DATEADD(DAY, -6, SYSUTCDATETIME()) AS DATE) AS day_bucket
                UNION ALL
                SELECT DATEADD(DAY, 1, day_bucket)
                FROM days
                WHERE day_bucket < CAST(SYSUTCDATETIME() AS DATE)
            )
            SELECT
                CONVERT(NVARCHAR(10), d.day_bucket, 120) AS bucket,
                ISNULL(se.events_count, 0) AS security_events,
                ISNULL(al.alert_count, 0) AS alerts_count,
                ISNULL(lo.login_count, 0) AS login_count
            FROM days d
            LEFT JOIN (
                SELECT CAST(event_time AS DATE) AS day_bucket, COUNT(*) AS events_count
                FROM SecurityEvents
                GROUP BY CAST(event_time AS DATE)
            ) se ON se.day_bucket = d.day_bucket
            LEFT JOIN (
                SELECT CAST(timestamp AS DATE) AS day_bucket, COUNT(*) AS alert_count
                FROM Alerts
                GROUP BY CAST(timestamp AS DATE)
            ) al ON al.day_bucket = d.day_bucket
            LEFT JOIN (
                SELECT CAST(timestamp AS DATE) AS day_bucket, COUNT(*) AS login_count
                FROM Logins
                GROUP BY CAST(timestamp AS DATE)
            ) lo ON lo.day_bucket = d.day_bucket
            ORDER BY d.day_bucket
            OPTION (MAXRECURSION 7)
            """
        )

        suspicious_accounts = self.fetch_all(
            """
            SELECT username, COUNT(*) AS failed_count
            FROM Logins
            WHERE result = 'failed'
            GROUP BY username
            HAVING COUNT(*) >= 2
            ORDER BY failed_count DESC, username
            """
        )
        multi_origin = self.fetch_all(
            """
            SELECT username,
                   COUNT(DISTINCT ISNULL(source_ip, source)) AS ip_origins,
                   COUNT(DISTINCT ISNULL(source_mac, source)) AS mac_origins
            FROM Logins
            GROUP BY username
            HAVING COUNT(DISTINCT ISNULL(source_ip, source)) > 1 OR COUNT(DISTINCT ISNULL(source_mac, source)) > 1
            ORDER BY username
            """
        )

        failed_logins = int(counts.get("failed_logins") or 0)
        failed_tests = int(counts.get("failed_tests") or 0)
        open_alerts = int(counts.get("open_alerts") or 0)
        critical_alerts = int(counts.get("critical_alerts") or 0)
        open_services = int(counts.get("open_services") or 0)

        return {
            "event_overview": {
                **counts,
                "suspicious_accounts": len(suspicious_accounts),
                "multi_origin_accounts": len(multi_origin),
                "blocked_estimated": failed_tests + failed_logins,
                "suspicious_estimated": critical_alerts + failed_logins,
                "evaded_estimated": len(multi_origin),
                "requests_estimated": open_services + int(counts.get("total_security_events") or 0),
            },
            "platform_health": [
                {"id": "frontend", "label": "Frontend Console", "kind": "container", "status": "up", "detail": "Static UI su localhost:8080"},
                {"id": "backend", "label": "Flask API", "kind": "container", "status": "up", "detail": "API REST, auth admin, ingest e dashboard"},
                {"id": "sqlserver", "label": "SQL Server", "kind": "container", "status": "up", "detail": "Persistenza NetVisor e query live"},
                {"id": "scanner", "label": "Scanner Pipeline", "kind": "service", "status": "up", "detail": "Nmap/Masscan demo-safe e parser ingest"},
                {"id": "sqlserver_data", "label": "Volume sqlserver_data", "kind": "volume", "status": "up", "detail": "Volume logico di persistenza"},
            ],
            "protocols": [{"protocol": row["protocol_name"], "count": int(row["total"])} for row in protocol_rows],
            "top_assets": top_assets,
            "recent_alerts": recent_alerts,
            "recent_security_events": recent_security,
            "event_trend": [
                {
                    "label": row["bucket"],
                    "security_events": int(row["security_events"]),
                    "alerts": int(row["alerts_count"]),
                    "logins": int(row["login_count"]),
                }
                for row in trend_rows
            ],
        }

    def get_connections_overview(self) -> dict[str, Any]:
        summary = self.fetch_one(
            """
            SELECT
                (SELECT COUNT(*) FROM Nodes WHERE status = 'online') AS active_nodes,
                (SELECT COUNT(*) FROM Nodes WHERE status <> 'online') AS inactive_nodes,
                (SELECT COUNT(*) FROM Services WHERE state = 'open') AS open_services,
                (SELECT COUNT(*) FROM Scans) AS total_scans,
                (SELECT COUNT(*) FROM RawLogs) AS total_raw_logs,
                (SELECT COUNT(*) FROM RawLogs WHERE source = 'nmap') AS nmap_raw_logs,
                (SELECT COUNT(*) FROM RawLogs WHERE source = 'masscan') AS masscan_raw_logs,
                (SELECT COUNT(*) FROM Tests WHERE result = 'success') AS successful_tests,
                (SELECT COUNT(*) FROM Tests WHERE result <> 'success') AS failed_tests,
                (SELECT COUNT(*) FROM Logins WHERE result = 'failed') AS failed_logins
            """
        ) or {}

        services = self.fetch_all(
            """
            SELECT
                n.hostname,
                n.ip,
                n.status AS node_status,
                s.port,
                s.protocol,
                s.state,
                s.service_name,
                s.product,
                s.version,
                s.last_seen
            FROM Services s
            INNER JOIN Nodes n ON n.id = s.node_id
            ORDER BY n.ip, s.port
            """
        )

        scans = self.list_scans()[:10]
        raw_logs = self.fetch_all(
            """
            SELECT TOP 10 id, source, scan_id, format, received_at, LEFT(content, 900) AS snippet
            FROM RawLogs
            ORDER BY id DESC
            """
        )
        tests = self.fetch_all(
            """
            SELECT TOP 10 target, type, latency_ms, result, checked_at, details
            FROM Tests
            ORDER BY checked_at DESC, id DESC
            """
        )
        protocols = self.fetch_all(
            """
            SELECT
                CASE
                    WHEN port = 22 OR service_name LIKE '%ssh%' THEN 'SSH'
                    WHEN port = 443 OR service_name LIKE '%https%' THEN 'HTTPS'
                    WHEN port IN (80, 8080) OR service_name = 'http' THEN 'HTTP'
                    WHEN port = 445 OR service_name LIKE '%microsoft-ds%' OR service_name LIKE '%smb%' THEN 'SMB'
                    WHEN port = 3389 OR service_name LIKE '%rdp%' OR service_name LIKE '%ms-wbt-server%' THEN 'RDP'
                    ELSE UPPER(COALESCE(protocol, 'tcp'))
                END AS protocol_name,
                COUNT(*) AS total
            FROM Services
            WHERE state = 'open'
            GROUP BY
                CASE
                    WHEN port = 22 OR service_name LIKE '%ssh%' THEN 'SSH'
                    WHEN port = 443 OR service_name LIKE '%https%' THEN 'HTTPS'
                    WHEN port IN (80, 8080) OR service_name = 'http' THEN 'HTTP'
                    WHEN port = 445 OR service_name LIKE '%microsoft-ds%' OR service_name LIKE '%smb%' THEN 'SMB'
                    WHEN port = 3389 OR service_name LIKE '%rdp%' OR service_name LIKE '%ms-wbt-server%' THEN 'RDP'
                    ELSE UPPER(COALESCE(protocol, 'tcp'))
                END
            ORDER BY total DESC
            """
        )

        failed_tests = int(summary.get("failed_tests") or 0)
        failed_logins = int(summary.get("failed_logins") or 0)

        return {
            "summary": {
                **summary,
                "blocked_estimated": failed_tests + failed_logins,
                "suspicious_estimated": len([item for item in services if item.get("port") in {445, 3389, 1433, 23, 21}]),
                "evaded_estimated": len(self.fetch_all("SELECT username FROM Logins GROUP BY username HAVING COUNT(DISTINCT ISNULL(source_ip, source)) > 1")),
            },
            "services": services,
            "protocols": [{"protocol": row["protocol_name"], "count": int(row["total"])} for row in protocols],
            "tests": tests,
            "raw_logs": raw_logs,
            "scans": scans,
        }

    def get_login_security_overview(self) -> dict[str, Any]:
        summary = self.fetch_one(
            """
            SELECT
                COUNT(*) AS total_logins,
                SUM(CASE WHEN result = 'success' THEN 1 ELSE 0 END) AS success_logins,
                SUM(CASE WHEN result = 'failed' THEN 1 ELSE 0 END) AS failed_logins,
                COUNT(DISTINCT username) AS unique_users,
                SUM(CASE WHEN account_type = 'admin' THEN 1 ELSE 0 END) AS admin_events
            FROM Logins
            """
        ) or {}

        top_failures = self.fetch_all(
            """
            SELECT TOP 6 username, COUNT(*) AS failed_count
            FROM Logins
            WHERE result = 'failed'
            GROUP BY username
            ORDER BY failed_count DESC, username
            """
        )
        peak_hours = self.fetch_all(
            """
            SELECT RIGHT('0' + CAST(DATEPART(HOUR, timestamp) AS NVARCHAR(2)), 2) AS hour_bucket, COUNT(*) AS total
            FROM Logins
            GROUP BY DATEPART(HOUR, timestamp)
            ORDER BY hour_bucket
            """
        )
        anomalies = self.fetch_all(
            """
            SELECT
                username,
                SUM(CASE WHEN result = 'failed' THEN 1 ELSE 0 END) AS failed_count,
                COUNT(DISTINCT ISNULL(source_ip, source)) AS source_ips,
                COUNT(DISTINCT ISNULL(source_mac, source)) AS source_macs,
                MAX(risk_score) AS max_risk
            FROM Logins
            GROUP BY username
            HAVING SUM(CASE WHEN result = 'failed' THEN 1 ELSE 0 END) >= 2
               OR COUNT(DISTINCT ISNULL(source_ip, source)) > 1
               OR COUNT(DISTINCT ISNULL(source_mac, source)) > 1
            ORDER BY max_risk DESC, failed_count DESC, username
            """
        )
        recent_activity = self.fetch_all(
            """
            SELECT TOP 20
                l.id,
                l.username,
                l.source,
                l.source_ip,
                l.source_mac,
                l.auth_channel,
                l.account_type,
                l.result,
                l.risk_score,
                l.timestamp,
                n.hostname,
                n.ip
            FROM Logins l
            INNER JOIN Nodes n ON n.id = l.node_id
            ORDER BY l.timestamp DESC, l.id DESC
            """
        )
        audit = self.fetch_all(
            """
            SELECT TOP 12 actor, action, details, created_at
            FROM AuditLog
            ORDER BY created_at DESC, id DESC
            """
        )

        formatted_anomalies = []
        for row in anomalies:
            anomaly_types = []
            if int(row["failed_count"]) >= 2:
                anomaly_types.append("failed-burst")
            if int(row["source_ips"]) > 1 or int(row["source_macs"]) > 1:
                anomaly_types.append("multi-origin")
            formatted_anomalies.append(
                {
                    "username": row["username"],
                    "failed_count": int(row["failed_count"]),
                    "source_ips": int(row["source_ips"]),
                    "source_macs": int(row["source_macs"]),
                    "risk_score": int(row["max_risk"] or 0),
                    "severity": "high" if "multi-origin" in anomaly_types else "medium",
                    "types": anomaly_types,
                }
            )

        return {
            "summary": {
                **summary,
                "suspicious_accounts": len(formatted_anomalies),
                "multi_origin_accounts": len([item for item in formatted_anomalies if "multi-origin" in item["types"]]),
            },
            "top_failures": [{"username": row["username"], "failed_count": int(row["failed_count"])} for row in top_failures],
            "peak_hours": [{"hour": row["hour_bucket"], "count": int(row["total"])} for row in peak_hours],
            "anomalies": formatted_anomalies,
            "recent_activity": recent_activity,
            "audit_activity": audit,
        }

    def get_topology(self) -> dict[str, Any]:
        rows = self.fetch_all(
            """
            SELECT
                n.id,
                n.hostname,
                n.ip,
                n.status,
                n.os_guess,
                n.vendor,
                n.risk_score,
                s.id AS service_id,
                s.port,
                s.protocol,
                s.state,
                s.service_name,
                s.product,
                s.version,
                (
                    SELECT COUNT(*)
                    FROM Alerts a
                    WHERE a.node_id = n.id AND a.status IN ('open', 'ack')
                ) AS open_alerts,
                (
                    SELECT COUNT(*)
                    FROM Logins l
                    WHERE l.node_id = n.id
                ) AS login_events
            FROM Nodes n
            LEFT JOIN Services s ON s.node_id = n.id AND s.state = 'open'
            ORDER BY n.id, s.port
            """
        )

        nodes_map: dict[int, dict[str, Any]] = {}
        traffic: list[dict[str, Any]] = []

        for row in rows:
            node_id = int(row["id"])
            if node_id not in nodes_map:
                nodes_map[node_id] = {
                    "id": node_id,
                    "label": row.get("hostname") or row["ip"],
                    "hostname": row.get("hostname"),
                    "ip": row["ip"],
                    "status": row["status"],
                    "os_guess": row.get("os_guess"),
                    "vendor": row.get("vendor"),
                    "risk_score": int(row.get("risk_score") or 0),
                    "open_alerts": int(row.get("open_alerts") or 0),
                    "login_events": int(row.get("login_events") or 0),
                    "services": [],
                    "dependencies": ["scanner", "ipv4 discovery"],
                }
                traffic.append(
                    {
                        "from": "scanner-core",
                        "to": node_id,
                        "protocol": "ipv4",
                        "label": "Discovery IPv4",
                        "port": None,
                    }
                )

            if row.get("service_id") is None:
                continue

            service = {
                "id": int(row["service_id"]),
                "port": int(row["port"]),
                "protocol": row["protocol"],
                "state": row["state"],
                "service_name": row.get("service_name"),
                "product": row.get("product"),
                "version": row.get("version"),
            }
            nodes_map[node_id]["services"].append(service)

            dependency_label = self._format_dependency_label(service)
            if dependency_label not in nodes_map[node_id]["dependencies"]:
                nodes_map[node_id]["dependencies"].append(dependency_label)

            traffic.append(
                {
                    "from": "backend-monitoring-api",
                    "to": node_id,
                    "protocol": self._infer_flow_protocol(service),
                    "label": dependency_label,
                    "port": service["port"],
                }
            )

        edges = [{"from": "scanner", "to": node_id, "type": "discovered"} for node_id in nodes_map]
        resources = [
            {
                "id": "soc-console",
                "label": "SOC Console",
                "kind": "console",
                "status": "online",
                "group": "control-plane",
                "details": "Frontend Web Vanilla JS per operatori e admin.",
            },
            {
                "id": "backend-core",
                "label": "Backend Flask",
                "kind": "container",
                "status": "online",
                "group": "control-plane",
                "expandable": True,
                "details": "API REST, orchestrazione scan, alerting e query admin.",
            },
            {
                "id": "sql-core",
                "label": "SQL Server",
                "kind": "database",
                "status": "online",
                "group": "control-plane",
                "expandable": True,
                "details": "Persistenza NetVisor, eventi SIEM e audit log.",
            },
            {
                "id": "scanner-core",
                "label": "Scanner Pipeline",
                "kind": "container",
                "status": "online",
                "group": "control-plane",
                "expandable": True,
                "details": "Masscan, Nmap, parser e ingest controllato.",
            },
            {
                "id": "assets-core",
                "label": "Lab Assets",
                "kind": "group",
                "status": "online",
                "group": "assets",
                "expandable": True,
                "details": "Network devices, server e endpoint osservati.",
            },
            {
                "id": "api-auth",
                "label": "Auth API",
                "kind": "service",
                "status": "online",
                "parent": "backend-core",
                "details": "Login admin e rilascio token.",
            },
            {
                "id": "api-dashboard",
                "label": "Dashboard API",
                "kind": "service",
                "status": "online",
                "parent": "backend-core",
                "details": "Summary, event overview e health grid.",
            },
            {
                "id": "backend-monitoring-api",
                "label": "Monitoring API",
                "kind": "service",
                "status": "online",
                "parent": "backend-core",
                "details": "Scan manuali, test connettivita e topology feed.",
            },
            {
                "id": "alert-engine",
                "label": "Alert Engine",
                "kind": "service",
                "status": "online",
                "parent": "backend-core",
                "details": "Regole Mini-SIEM e security events.",
            },
            {
                "id": "db-nodes",
                "label": "Nodes + Services",
                "kind": "dataset",
                "status": "online",
                "parent": "sql-core",
                "details": "Asset inventory e servizi scoperti.",
            },
            {
                "id": "db-alerts",
                "label": "Alerts + SecurityEvents",
                "kind": "dataset",
                "status": "online",
                "parent": "sql-core",
                "details": "Alert aperti, chiusi e tracce SIEM.",
            },
            {
                "id": "db-rawlogs",
                "label": "RawLogs + Audit",
                "kind": "dataset",
                "status": "online",
                "parent": "sql-core",
                "details": "Raw Nmap/Masscan, audit admin e storico.",
            },
            {
                "id": "scan-masscan",
                "label": "Masscan Engine",
                "kind": "service",
                "status": "online",
                "parent": "scanner-core",
                "details": "Discovery veloce porte/IP consentiti.",
            },
            {
                "id": "scan-nmap",
                "label": "Nmap Engine",
                "kind": "service",
                "status": "online",
                "parent": "scanner-core",
                "details": "Service detection e XML ingest.",
            },
            {
                "id": "scan-ingest",
                "label": "Ingest Parser",
                "kind": "service",
                "status": "online",
                "parent": "scanner-core",
                "details": "Normalizzazione risultati e scrittura DB.",
            },
        ]

        for node in nodes_map.values():
            resources.append(
                {
                    "id": node["id"],
                    "label": node["label"],
                    "kind": "network-device" if node["ip"].endswith(".1") else "endpoint",
                    "status": node["status"],
                    "parent": "assets-core",
                    "details": node["ip"],
                    "risk_score": node["risk_score"],
                    "open_alerts": node["open_alerts"],
                    "services": node["services"],
                    "dependencies": node["dependencies"],
                }
            )

        flows = [
            {"from": "soc-console", "to": "api-auth", "protocol": "https", "label": "Admin login"},
            {"from": "soc-console", "to": "api-dashboard", "protocol": "https", "label": "Dashboard fetch"},
            {"from": "soc-console", "to": "backend-monitoring-api", "protocol": "https", "label": "Scans, topology, query"},
            {"from": "api-dashboard", "to": "sql-core", "protocol": "mssql", "label": "Read summary"},
            {"from": "backend-monitoring-api", "to": "sql-core", "protocol": "mssql", "label": "Persist scans"},
            {"from": "alert-engine", "to": "db-alerts", "protocol": "mssql", "label": "Raise alerts"},
            {"from": "scan-masscan", "to": "scan-ingest", "protocol": "tcp", "label": "Raw discovery"},
            {"from": "scan-nmap", "to": "scan-ingest", "protocol": "tcp", "label": "XML service detection"},
            {"from": "scan-ingest", "to": "backend-monitoring-api", "protocol": "https", "label": "Ingest API"},
        ]
        flows.extend(traffic)

        return {
            "nodes": list(nodes_map.values()),
            "edges": edges,
            "traffic": traffic,
            "resources": resources,
            "flows": flows,
            "groups": [
                {"id": "control-plane", "label": "Platform Control Plane"},
                {"id": "assets", "label": "Network Devices & Endpoint Assets"},
            ],
        }

    def run_admin_read_query(self, query: str, max_rows: int = 200) -> dict[str, Any]:
        return self.fetch_query_result(query, max_rows=max_rows, timeout_seconds=10)

    @staticmethod
    def _format_dependency_label(service: dict[str, Any]) -> str:
        service_name = service.get("service_name") or service["protocol"]
        return f"{service_name}:{service['port']}/{service['protocol']}"

    @staticmethod
    def _infer_flow_protocol(service: dict[str, Any]) -> str:
        port = int(service["port"])
        service_name = (service.get("service_name") or "").lower()
        if port == 22 or "ssh" in service_name:
            return "ssh"
        if port in {80, 8080} or "http" == service_name:
            return "http"
        if port == 443 or "https" in service_name:
            return "https"
        if port == 445 or "smb" in service_name or "microsoft-ds" in service_name:
            return "smb"
        if port == 3389 or "rdp" in service_name or "ms-wbt-server" in service_name:
            return "rdp"
        if port == 1433 or "mssql" in service_name:
            return "mssql"
        return "tcp"
