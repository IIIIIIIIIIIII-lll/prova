import time
from contextlib import contextmanager

import pyodbc

from config import settings
from utils.logger import get_logger


logger = get_logger("db")


# ── Connessione base ──────────────────────────────────────────────────────────

@contextmanager
def _connect(database: str = "master", autocommit: bool = False):
    """Context manager interno: apre/chiude una connessione pyodbc."""
    conn_str = (
        "DRIVER={ODBC Driver 18 for SQL Server};"
        f"SERVER={settings.db_host},{settings.db_port};"
        f"DATABASE={database};"
        f"UID={settings.db_user};"
        f"PWD={settings.db_password};"
        "TrustServerCertificate=yes;"
    )
    conn = pyodbc.connect(conn_str, autocommit=autocommit)
    try:
        yield conn
    finally:
        conn.close()


@contextmanager
def get_connection():
    """Context manager pubblico: connessione all'application database (NetVisor).
    Usato da Repository e da tutti i servizi per query applicative."""
    with _connect(settings.db_name, autocommit=True) as conn:
        yield conn


# ── Inizializzazione ──────────────────────────────────────────────────────────

def initialize_database(max_attempts: int = 30, retry_delay: float = 2.0) -> None:
    """Inizializza il database al primo avvio (idempotente).

    Passi:
      1. Attende che SQL Server sia raggiungibile (retry loop con back-off).
      2. Crea il database NetVisor se non esiste ancora.
      3. Applica lo SCHEMA_SCRIPT (CREATE TABLE / ALTER TABLE IF NOT EXISTS).
      4. Bootstrap admin iniziale se la tabella Users è vuota.

    NetVisor è LIVE-only: nessun seed sintetico, nessun dato demo.
    Il DB nasce vuoto e si popola esclusivamente con dati reali.
    """
    # ── 1. Attendi SQL Server ────────────────────────────────────────────────
    for attempt in range(1, max_attempts + 1):
        try:
            with _connect("master", autocommit=True) as probe:
                probe.cursor().execute("SELECT 1")
            logger.info("SQL Server raggiungibile (tentativo %s).", attempt)
            break
        except pyodbc.Error as exc:
            logger.warning(
                "SQL Server non ancora pronto (tentativo %s/%s): %s",
                attempt, max_attempts, exc,
            )
            if attempt >= max_attempts:
                raise RuntimeError(
                    f"SQL Server non raggiungibile dopo {max_attempts} tentativi."
                ) from exc
            time.sleep(retry_delay)

    # ── 2. Crea DB se non esiste ─────────────────────────────────────────────
    with _connect("master", autocommit=True) as master_conn:
        master_conn.cursor().execute(BOOTSTRAP_SCRIPT)
    logger.info("Database '%s' verificato/creato.", settings.db_name)

    # ── 3. Applica schema (idempotente) ──────────────────────────────────────
    with _connect(settings.db_name, autocommit=True) as app_conn:
        app_conn.cursor().execute(SCHEMA_SCRIPT)
    logger.info("Schema applicato (LIVE-only, nessun seed sintetico).")

    # ── 4. Bootstrap admin ───────────────────────────────────────────────────
    # Import locale per evitare import circolari (services → models → db → services).
    from models import Repository
    from services.auth_service import AuthService
    AuthService(Repository()).bootstrap_initial_admin_if_needed()
    logger.info("Bootstrap database completato (LIVE only).")


BOOTSTRAP_SCRIPT = """
IF DB_ID(N'NetVisor') IS NULL
BEGIN
    CREATE DATABASE [NetVisor];
END
;
"""


SCHEMA_SCRIPT = """
IF OBJECT_ID(N'dbo.Nodes', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Nodes (
        id INT IDENTITY(1,1) PRIMARY KEY,
        hostname NVARCHAR(255) NULL,
        ip NVARCHAR(45) NOT NULL UNIQUE,
        status NVARCHAR(30) NOT NULL DEFAULT 'unknown',
        first_seen DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        last_seen DATETIME2 NULL,
        os_guess NVARCHAR(255) NULL,
        mac_address NVARCHAR(64) NULL,
        vendor NVARCHAR(255) NULL,
        risk_score INT NOT NULL DEFAULT 0
    );
END;
IF OBJECT_ID(N'dbo.Services', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Services (
        id INT IDENTITY(1,1) PRIMARY KEY,
        node_id INT NOT NULL,
        port INT NOT NULL,
        protocol NVARCHAR(10) NOT NULL,
        state NVARCHAR(30) NOT NULL,
        service_name NVARCHAR(120) NULL,
        product NVARCHAR(255) NULL,
        version NVARCHAR(255) NULL,
        banner NVARCHAR(MAX) NULL,
        first_seen DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        last_seen DATETIME2 NULL,
        CONSTRAINT UQ_Services_NodePortProtocol UNIQUE (node_id, port, protocol),
        CONSTRAINT FK_Services_Nodes FOREIGN KEY (node_id) REFERENCES dbo.Nodes(id)
    );
END;
IF OBJECT_ID(N'dbo.Alerts', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Alerts (
        id INT IDENTITY(1,1) PRIMARY KEY,
        type NVARCHAR(100) NOT NULL,
        severity NVARCHAR(20) NOT NULL,
        description NVARCHAR(MAX) NOT NULL,
        node_id INT NULL,
        service_id INT NULL,
        status NVARCHAR(30) NOT NULL DEFAULT 'open',
        timestamp DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_Alerts_Nodes FOREIGN KEY (node_id) REFERENCES dbo.Nodes(id),
        CONSTRAINT FK_Alerts_Services FOREIGN KEY (service_id) REFERENCES dbo.Services(id)
    );
END;
IF OBJECT_ID(N'dbo.Scans', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Scans (
        id INT IDENTITY(1,1) PRIMARY KEY,
        date DATETIME2 NULL,
        scanner NVARCHAR(50) NOT NULL,
        target NVARCHAR(255) NOT NULL,
        ports NVARCHAR(255) NULL,
        status NVARCHAR(30) NOT NULL DEFAULT 'queued',
        started_at DATETIME2 NULL,
        finished_at DATETIME2 NULL,
        result NVARCHAR(MAX) NULL,
        result_summary NVARCHAR(MAX) NULL,
        error_message NVARCHAR(MAX) NULL
    );
END;
IF COL_LENGTH('dbo.Scans', 'date') IS NULL
BEGIN
    ALTER TABLE dbo.Scans ADD date DATETIME2 NULL;
END;
IF COL_LENGTH('dbo.Scans', 'result') IS NULL
BEGIN
    ALTER TABLE dbo.Scans ADD result NVARCHAR(MAX) NULL;
END;
IF OBJECT_ID(N'dbo.Tests', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Tests (
        id INT IDENTITY(1,1) PRIMARY KEY,
        node_id INT NULL,
        target NVARCHAR(255) NOT NULL,
        type NVARCHAR(30) NOT NULL,
        latency FLOAT NULL,
        latency_ms INT NULL,
        result NVARCHAR(30) NOT NULL,
        checked_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        details NVARCHAR(MAX) NULL,
        CONSTRAINT FK_Tests_Nodes FOREIGN KEY (node_id) REFERENCES dbo.Nodes(id)
    );
END;
IF COL_LENGTH('dbo.Tests', 'latency') IS NULL
BEGIN
    ALTER TABLE dbo.Tests ADD latency FLOAT NULL;
END;
IF OBJECT_ID(N'dbo.RawLogs', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.RawLogs (
        id INT IDENTITY(1,1) PRIMARY KEY,
        source NVARCHAR(50) NOT NULL,
        scan_id INT NULL,
        format NVARCHAR(30) NOT NULL,
        content NVARCHAR(MAX) NOT NULL,
        received_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_RawLogs_Scans FOREIGN KEY (scan_id) REFERENCES dbo.Scans(id)
    );
END;
IF OBJECT_ID(N'dbo.SecurityEvents', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SecurityEvents (
        id INT IDENTITY(1,1) PRIMARY KEY,
        source NVARCHAR(50) NOT NULL,
        event_type NVARCHAR(100) NOT NULL,
        node_id INT NULL,
        service_id INT NULL,
        severity NVARCHAR(20) NOT NULL DEFAULT 'info',
        message NVARCHAR(MAX) NOT NULL,
        event_time DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        raw_log_id INT NULL,
        CONSTRAINT FK_SecurityEvents_Nodes FOREIGN KEY (node_id) REFERENCES dbo.Nodes(id),
        CONSTRAINT FK_SecurityEvents_Services FOREIGN KEY (service_id) REFERENCES dbo.Services(id),
        CONSTRAINT FK_SecurityEvents_RawLogs FOREIGN KEY (raw_log_id) REFERENCES dbo.RawLogs(id)
    );
END;
IF OBJECT_ID(N'dbo.AuditLog', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AuditLog (
        id INT IDENTITY(1,1) PRIMARY KEY,
        actor NVARCHAR(100) NULL,
        action NVARCHAR(100) NOT NULL,
        details NVARCHAR(MAX) NULL,
        created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;
IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Users (
        id INT IDENTITY(1,1) PRIMARY KEY,
        username NVARCHAR(80) NOT NULL UNIQUE,
        email NVARCHAR(255) NULL UNIQUE,
        display_name NVARCHAR(255) NULL,
        role NVARCHAR(30) NOT NULL,
        password_hash NVARCHAR(500) NOT NULL,
        is_active BIT NOT NULL DEFAULT 1,
        must_change_password BIT NOT NULL DEFAULT 0,
        failed_login_count INT NOT NULL DEFAULT 0,
        locked_until DATETIME2 NULL,
        last_login_at DATETIME2 NULL,
        created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_at DATETIME2 NULL
    );
END;
IF OBJECT_ID(N'dbo.AuthSessions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AuthSessions (
        id INT IDENTITY(1,1) PRIMARY KEY,
        user_id INT NOT NULL,
        refresh_token_hash NVARCHAR(500) NOT NULL,
        user_agent NVARCHAR(500) NULL,
        ip_address NVARCHAR(80) NULL,
        created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        expires_at DATETIME2 NOT NULL,
        revoked_at DATETIME2 NULL,
        last_used_at DATETIME2 NULL,
        CONSTRAINT FK_AuthSessions_Users FOREIGN KEY (user_id) REFERENCES dbo.Users(id)
    );
END;
IF OBJECT_ID(N'dbo.AuthAuditLog', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AuthAuditLog (
        id INT IDENTITY(1,1) PRIMARY KEY,
        user_id INT NULL,
        username NVARCHAR(80) NULL,
        event_type NVARCHAR(80) NOT NULL,
        role NVARCHAR(30) NULL,
        ip_address NVARCHAR(80) NULL,
        user_agent NVARCHAR(500) NULL,
        success BIT NOT NULL,
        message NVARCHAR(MAX) NULL,
        created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_AuthAuditLog_Users FOREIGN KEY (user_id) REFERENCES dbo.Users(id)
    );
END;
IF OBJECT_ID(N'dbo.Logins', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Logins (
        id INT IDENTITY(1,1) PRIMARY KEY,
        node_id INT NOT NULL,
        username NVARCHAR(255) NOT NULL,
        source NVARCHAR(100) NULL,
        source_ip NVARCHAR(45) NULL,
        source_mac NVARCHAR(64) NULL,
        auth_channel NVARCHAR(50) NULL,
        account_type NVARCHAR(30) NULL,
        result NVARCHAR(30) NOT NULL,
        risk_score INT NOT NULL DEFAULT 0,
        timestamp DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        details NVARCHAR(MAX) NULL,
        CONSTRAINT FK_Logins_Nodes FOREIGN KEY (node_id) REFERENCES dbo.Nodes(id)
    );
END;
IF COL_LENGTH('dbo.Logins', 'source_ip') IS NULL
BEGIN
    ALTER TABLE dbo.Logins ADD source_ip NVARCHAR(45) NULL;
END;
IF COL_LENGTH('dbo.Logins', 'source_mac') IS NULL
BEGIN
    ALTER TABLE dbo.Logins ADD source_mac NVARCHAR(64) NULL;
END;
IF COL_LENGTH('dbo.Logins', 'auth_channel') IS NULL
BEGIN
    ALTER TABLE dbo.Logins ADD auth_channel NVARCHAR(50) NULL;
END;
IF COL_LENGTH('dbo.Logins', 'account_type') IS NULL
BEGIN
    ALTER TABLE dbo.Logins ADD account_type NVARCHAR(30) NULL;
END;
IF COL_LENGTH('dbo.Logins', 'risk_score') IS NULL
BEGIN
    ALTER TABLE dbo.Logins ADD risk_score INT NOT NULL CONSTRAINT DF_Logins_RiskScore DEFAULT 0;
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Logins_NodeTimestamp' AND object_id = OBJECT_ID(N'dbo.Logins'))
BEGIN
    CREATE INDEX IX_Logins_NodeTimestamp ON dbo.Logins(node_id, timestamp DESC);
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Logins_UserTimestamp' AND object_id = OBJECT_ID(N'dbo.Logins'))
BEGIN
    CREATE INDEX IX_Logins_UserTimestamp ON dbo.Logins(username, timestamp DESC);
END;
IF OBJECT_ID(N'dbo.ScanJobs', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ScanJobs (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(120) NOT NULL,
        scanner NVARCHAR(30) NOT NULL,
        target NVARCHAR(255) NOT NULL,
        ports NVARCHAR(255) NOT NULL,
        protocol NVARCHAR(10) NOT NULL DEFAULT 'tcp',
        mode NVARCHAR(30) NOT NULL,
        interval_seconds INT NULL,
        enabled BIT NOT NULL DEFAULT 1,
        permanent BIT NOT NULL DEFAULT 0,
        last_status NVARCHAR(30) NULL,
        last_started_at DATETIME2 NULL,
        last_finished_at DATETIME2 NULL,
        next_run_at DATETIME2 NULL,
        last_error NVARCHAR(MAX) NULL,
        created_by_user_id INT NULL,
        created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_at DATETIME2 NULL,
        CONSTRAINT FK_ScanJobs_Users FOREIGN KEY (created_by_user_id) REFERENCES dbo.Users(id)
    );
END;
IF OBJECT_ID(N'dbo.ScanJobRuns', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ScanJobRuns (
        id INT IDENTITY(1,1) PRIMARY KEY,
        job_id INT NULL,
        scanner NVARCHAR(30) NOT NULL,
        target NVARCHAR(255) NOT NULL,
        ports NVARCHAR(255) NOT NULL,
        protocol NVARCHAR(10) NOT NULL DEFAULT 'tcp',
        status NVARCHAR(30) NOT NULL,
        started_at DATETIME2 NULL,
        finished_at DATETIME2 NULL,
        raw_log_id INT NULL,
        result_summary NVARCHAR(MAX) NULL,
        error_message NVARCHAR(MAX) NULL,
        CONSTRAINT FK_ScanJobRuns_ScanJobs FOREIGN KEY (job_id) REFERENCES dbo.ScanJobs(id),
        CONSTRAINT FK_ScanJobRuns_RawLogs FOREIGN KEY (raw_log_id) REFERENCES dbo.RawLogs(id)
    );
END;
IF OBJECT_ID(N'dbo.HealthChecks', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.HealthChecks (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(120) NOT NULL,
        target NVARCHAR(255) NOT NULL,
        check_type NVARCHAR(30) NOT NULL,
        port INT NULL,
        label NVARCHAR(120) NULL,
        service_label NVARCHAR(120) NULL,
        interval_seconds INT NOT NULL,
        timeout_seconds INT NOT NULL,
        enabled BIT NOT NULL DEFAULT 1,
        permanent BIT NOT NULL DEFAULT 0,
        last_status NVARCHAR(30) NULL,
        last_latency_ms INT NULL,
        last_checked_at DATETIME2 NULL,
        failure_count INT NOT NULL DEFAULT 0,
        created_by_user_id INT NULL,
        created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_at DATETIME2 NULL,
        CONSTRAINT FK_HealthChecks_Users FOREIGN KEY (created_by_user_id) REFERENCES dbo.Users(id)
    );
END;
IF OBJECT_ID(N'dbo.HealthCheckResults', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.HealthCheckResults (
        id INT IDENTITY(1,1) PRIMARY KEY,
        check_id INT NULL,
        target NVARCHAR(255) NOT NULL,
        check_type NVARCHAR(30) NOT NULL,
        port INT NULL,
        result NVARCHAR(30) NOT NULL,
        latency_ms INT NULL,
        error_message NVARCHAR(MAX) NULL,
        checked_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_HealthCheckResults_HealthChecks FOREIGN KEY (check_id) REFERENCES dbo.HealthChecks(id)
    );
END;
IF OBJECT_ID(N'dbo.Agents', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Agents (
        id INT IDENTITY(1,1) PRIMARY KEY,
        agent_id NVARCHAR(120) NOT NULL UNIQUE,
        hostname NVARCHAR(255) NOT NULL,
        ip_address NVARCHAR(45) NOT NULL,
        os_name NVARCHAR(255) NOT NULL,
        agent_version NVARCHAR(50) NOT NULL,
        status NVARCHAR(30) NOT NULL DEFAULT 'online',
        first_seen DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        last_seen DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;
IF OBJECT_ID(N'dbo.AgentMetrics', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AgentMetrics (
        id INT IDENTITY(1,1) PRIMARY KEY,
        agent_id NVARCHAR(120) NOT NULL,
        cpu_percent FLOAT NOT NULL,
        ram_percent FLOAT NOT NULL,
        disk_percent FLOAT NOT NULL,
        uptime_seconds BIGINT NOT NULL,
        collected_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_AgentMetrics_Agents FOREIGN KEY (agent_id) REFERENCES dbo.Agents(agent_id)
    );
END;
IF OBJECT_ID(N'dbo.AgentServices', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AgentServices (
        id INT IDENTITY(1,1) PRIMARY KEY,
        agent_id NVARCHAR(120) NOT NULL,
        service_name NVARCHAR(255) NOT NULL,
        display_name NVARCHAR(255) NULL,
        status NVARCHAR(30) NOT NULL,
        checked_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_AgentServices_Agents FOREIGN KEY (agent_id) REFERENCES dbo.Agents(agent_id)
    );
END;
IF OBJECT_ID(N'dbo.AgentEvents', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AgentEvents (
        id INT IDENTITY(1,1) PRIMARY KEY,
        agent_id NVARCHAR(120) NOT NULL,
        source NVARCHAR(100) NOT NULL,
        level NVARCHAR(30) NOT NULL,
        message NVARCHAR(MAX) NOT NULL,
        event_time DATETIME2 NOT NULL,
        received_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_AgentEvents_Agents FOREIGN KEY (agent_id) REFERENCES dbo.Agents(agent_id)
    );
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ScanJobs_NextRun' AND object_id = OBJECT_ID(N'dbo.ScanJobs'))
BEGIN
    CREATE INDEX IX_ScanJobs_NextRun ON dbo.ScanJobs(enabled, mode, next_run_at);
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Users_Username' AND object_id = OBJECT_ID(N'dbo.Users'))
BEGIN
    CREATE INDEX IX_Users_Username ON dbo.Users(username);
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AuthSessions_UserExpiry' AND object_id = OBJECT_ID(N'dbo.AuthSessions'))
BEGIN
    CREATE INDEX IX_AuthSessions_UserExpiry ON dbo.AuthSessions(user_id, expires_at DESC);
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AuthAuditLog_UserCreated' AND object_id = OBJECT_ID(N'dbo.AuthAuditLog'))
BEGIN
    CREATE INDEX IX_AuthAuditLog_UserCreated ON dbo.AuthAuditLog(username, created_at DESC);
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ScanJobRuns_JobId' AND object_id = OBJECT_ID(N'dbo.ScanJobRuns'))
BEGIN
    CREATE INDEX IX_ScanJobRuns_JobId ON dbo.ScanJobRuns(job_id, id DESC);
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_HealthChecks_Enabled' AND object_id = OBJECT_ID(N'dbo.HealthChecks'))
BEGIN
    CREATE INDEX IX_HealthChecks_Enabled ON dbo.HealthChecks(enabled, id DESC);
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_HealthCheckResults_CheckId' AND object_id = OBJECT_ID(N'dbo.HealthCheckResults'))
BEGIN
    CREATE INDEX IX_HealthCheckResults_CheckId ON dbo.HealthCheckResults(check_id, checked_at DESC);
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Agents_LastSeen' AND object_id = OBJECT_ID(N'dbo.Agents'))
BEGIN
    CREATE INDEX IX_Agents_LastSeen ON dbo.Agents(status, last_seen DESC);
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AgentMetrics_AgentCollected' AND object_id = OBJECT_ID(N'dbo.AgentMetrics'))
BEGIN
    CREATE INDEX IX_AgentMetrics_AgentCollected ON dbo.AgentMetrics(agent_id, collected_at DESC);
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AgentServices_AgentChecked' AND object_id = OBJECT_ID(N'dbo.AgentServices'))
BEGIN
    CREATE INDEX IX_AgentServices_AgentChecked ON dbo.AgentServices(agent_id, checked_at DESC);
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AgentEvents_AgentReceived' AND object_id = OBJECT_ID(N'dbo.AgentEvents'))
BEGIN
    CREATE INDEX IX_AgentEvents_AgentReceived ON dbo.AgentEvents(agent_id, received_at DESC);
END;
IF COL_LENGTH('dbo.ScanJobs', 'protocol') IS NULL
BEGIN
    ALTER TABLE dbo.ScanJobs ADD protocol NVARCHAR(10) NOT NULL CONSTRAINT DF_ScanJobs_Protocol DEFAULT 'tcp';
END;
IF COL_LENGTH('dbo.ScanJobs', 'permanent') IS NULL
BEGIN
    ALTER TABLE dbo.ScanJobs ADD permanent BIT NOT NULL CONSTRAINT DF_ScanJobs_Permanent DEFAULT 0;
END;
IF COL_LENGTH('dbo.ScanJobs', 'created_by_user_id') IS NULL
BEGIN
    ALTER TABLE dbo.ScanJobs ADD created_by_user_id INT NULL;
END;
IF COL_LENGTH('dbo.ScanJobs', 'updated_at') IS NULL
BEGIN
    ALTER TABLE dbo.ScanJobs ADD updated_at DATETIME2 NULL;
END;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ScanJobs_Users')
BEGIN
    ALTER TABLE dbo.ScanJobs WITH NOCHECK
    ADD CONSTRAINT FK_ScanJobs_Users FOREIGN KEY (created_by_user_id) REFERENCES dbo.Users(id);
END;
IF COL_LENGTH('dbo.ScanJobRuns', 'protocol') IS NULL
BEGIN
    ALTER TABLE dbo.ScanJobRuns ADD protocol NVARCHAR(10) NOT NULL CONSTRAINT DF_ScanJobRuns_Protocol DEFAULT 'tcp';
END;
IF COL_LENGTH('dbo.ScanJobRuns', 'raw_log_id') IS NULL
BEGIN
    ALTER TABLE dbo.ScanJobRuns ADD raw_log_id INT NULL;
END;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ScanJobRuns_RawLogs')
BEGIN
    ALTER TABLE dbo.ScanJobRuns WITH NOCHECK
    ADD CONSTRAINT FK_ScanJobRuns_RawLogs FOREIGN KEY (raw_log_id) REFERENCES dbo.RawLogs(id);
END;
IF COL_LENGTH('dbo.HealthChecks', 'service_label') IS NULL
BEGIN
    ALTER TABLE dbo.HealthChecks ADD service_label NVARCHAR(120) NULL;
END;
IF COL_LENGTH('dbo.HealthChecks', 'permanent') IS NULL
BEGIN
    ALTER TABLE dbo.HealthChecks ADD permanent BIT NOT NULL CONSTRAINT DF_HealthChecks_Permanent DEFAULT 0;
END;
IF COL_LENGTH('dbo.HealthChecks', 'created_by_user_id') IS NULL
BEGIN
    ALTER TABLE dbo.HealthChecks ADD created_by_user_id INT NULL;
END;
IF COL_LENGTH('dbo.HealthChecks', 'updated_at') IS NULL
BEGIN
    ALTER TABLE dbo.HealthChecks ADD updated_at DATETIME2 NULL;
END;
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_HealthChecks_Users')
BEGIN
    ALTER TABLE dbo.HealthChecks WITH NOCHECK
    ADD CONSTRAINT FK_HealthChecks_Users FOREIGN KEY (created_by_user_id) REFERENCES dbo.Users(id);
END;
-- ── Alerts: soft-delete + audit dell'attore che chiude/cancella ──────────────
-- deleted_at: tombstone per alert eliminati (status='deleted'). Manteniamo
-- la riga per audit e per la tabella "Deleted Tasks" della UI.
-- closed_at / acked_at: timestamp del cambio stato — utili per filtri data.
IF COL_LENGTH('dbo.Alerts', 'deleted_at') IS NULL
BEGIN
    ALTER TABLE dbo.Alerts ADD deleted_at DATETIME2 NULL;
END;
IF COL_LENGTH('dbo.Alerts', 'acked_at') IS NULL
BEGIN
    ALTER TABLE dbo.Alerts ADD acked_at DATETIME2 NULL;
END;
IF COL_LENGTH('dbo.Alerts', 'closed_at') IS NULL
BEGIN
    ALTER TABLE dbo.Alerts ADD closed_at DATETIME2 NULL;
END;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Alerts_Status_Timestamp' AND object_id = OBJECT_ID(N'dbo.Alerts'))
BEGIN
    CREATE INDEX IX_Alerts_Status_Timestamp ON dbo.Alerts(status, timestamp DESC);
END;
"""


# (Demo seed/purge/residue blocks rimossi: NetVisor è ora esclusivamente LIVE.
# Il DB nasce vuoto e si popola solo con dati reali. Vedi VERSION e CHANGELOG.)

