from datetime import datetime, timezone

from flask import jsonify


def _meta() -> dict:
    """
    Metadata iniettato in TUTTE le risposte API (success ed error).
    NetVisor è LIVE-only: tutti i dati sono reali. Il _meta espone
    solo timestamp server-side per debug e correlazione log.
    """
    return {
        "mode": "live",
        "ts": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def success_response(data=None, status_code: int = 200):
    return jsonify({"success": True, "data": data, "_meta": _meta()}), status_code


def error_response(message: str, status_code: int = 400):
    return jsonify({"success": False, "error": message, "_meta": _meta()}), status_code
