from __future__ import annotations

import hmac
import time
from collections import defaultdict, deque

from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer
from flask import request

from config import settings
from utils.responses import error_response


_rate_windows: dict[str, deque[float]] = defaultdict(deque)


def install_security_controls(app):
    app.config["MAX_CONTENT_LENGTH"] = settings.max_content_length

    @app.before_request
    def enforce_request_policy():
        if request.method == "OPTIONS":
            return None

        rate_limited = _enforce_rate_limit()
        if rate_limited:
            return rate_limited

        if _is_public_endpoint():
            return None

        if request.method in {"GET", "HEAD"}:
            return None

        if settings.require_admin_auth:
            token = _extract_admin_token()
            if not token:
                return error_response("Login admin richiesto.", 401)
            if not verify_admin_token(token):
                return error_response("Sessione admin non valida o scaduta.", 401)

        return None

    @app.after_request
    def add_security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        response.headers["Cross-Origin-Resource-Policy"] = "same-site"
        if request.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response


def _is_public_endpoint() -> bool:
    return request.path in {"/", "/api/health", "/favicon.ico", "/api/admin/login"}


def _extract_admin_token() -> str:
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        return auth_header[7:].strip()
    return request.headers.get("X-Admin-Token", "").strip()


def _serializer():
    return URLSafeTimedSerializer(settings.auth_secret, salt="netvisor-admin-auth")


def issue_admin_token(username: str) -> str:
    return _serializer().dumps({"sub": username, "role": "admin"})


def verify_admin_token(token: str) -> bool:
    try:
        payload = _serializer().loads(token, max_age=settings.auth_token_ttl_minutes * 60)
    except (BadSignature, SignatureExpired):
        return False
    return payload.get("role") == "admin" and hmac.compare_digest(payload.get("sub", ""), settings.admin_username)


def _enforce_rate_limit():
    if settings.rate_limit_per_minute <= 0:
        return None

    now = time.monotonic()
    window_start = now - 60
    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown").split(",")[0].strip()
    key = f"{client_ip}:{request.path}"
    bucket = _rate_windows[key]

    while bucket and bucket[0] < window_start:
        bucket.popleft()

    if len(bucket) >= settings.rate_limit_per_minute:
        return error_response("Rate limit superato. Riprovare piu tardi.", 429)

    bucket.append(now)
    return None
