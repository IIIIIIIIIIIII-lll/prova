from __future__ import annotations

from collections import defaultdict, deque
from functools import wraps
import hmac
import time

from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer
from flask import g, request

from config import settings
from models import Repository
from utils.responses import error_response


_rate_windows: dict[str, deque[float]] = defaultdict(deque)
_repository = Repository()


def install_security_controls(app):
    app.config["MAX_CONTENT_LENGTH"] = settings.max_content_length

    @app.before_request
    def enforce_request_policy():
        if request.method == "OPTIONS":
            return None

        rate_limited = _enforce_rate_limit()
        if rate_limited:
            return rate_limited

        if not request.path.startswith("/api/"):
            return None

        if _is_public_endpoint():
            return None

        if request.path.startswith("/api/agents/") and request.method == "POST":
            if not settings.agent_shared_key:
                return error_response("Agent key non configurata.", 503)
            if not verify_agent_key(request.headers.get("X-Agent-Key", "")):
                return error_response("Agent key mancante o non valida.", 401)
            g.current_user = None
            g.auth_mode = "agent"
            return None

        if not settings.require_auth:
            return None

        token = extract_access_token()
        if not token:
            return error_response("Autenticazione richiesta.", 401)

        payload = verify_access_token(token)
        if not payload:
            return error_response("Sessione non valida o scaduta.", 401)

        user = _repository.get_user_by_id(int(payload["sub"]))
        if not user or not bool(user.get("is_active")):
            return error_response("Sessione non valida o scaduta.", 401)

        g.current_user = {
            "id": int(user["id"]),
            "username": user["username"],
            "email": user.get("email"),
            "display_name": user.get("display_name"),
            "role": user["role"],
            "is_active": bool(user.get("is_active")),
            "must_change_password": bool(user.get("must_change_password")),
        }
        g.auth_mode = "user"
        return None

    @app.after_request
    def add_security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        response.headers["Cross-Origin-Resource-Policy"] = "same-site"
        if request.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response


def _is_public_endpoint() -> bool:
    # Endpoint che NON richiedono autenticazione:
    #  - /api/health      → readiness/liveness probe per Docker/k8s/monitoring
    #  - /api/system/info → versione + mode, usato dal banner UI prima del login
    #  - /api/auth/*      → login/refresh — devono essere raggiungibili senza token
    return request.path in {
        "/api/health",
        "/api/system/info",
        "/api/auth/login",
        "/api/auth/refresh",
        "/api/admin/login",
    } or request.path in {"/", "/favicon.ico"}


def _serializer():
    return URLSafeTimedSerializer(settings.jwt_secret_key, salt="netvisor-access-token")


def issue_access_token(user: dict) -> str:
    return _serializer().dumps(
        {
            "sub": int(user["id"]),
            "username": user["username"],
            "role": user["role"],
        }
    )


def verify_access_token(token: str) -> dict | None:
    try:
        payload = _serializer().loads(token, max_age=settings.access_token_minutes * 60)
    except (BadSignature, SignatureExpired):
        return None
    if payload.get("role") not in {"admin", "user"}:
        return None
    return payload


def extract_access_token() -> str:
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        return auth_header[7:].strip()
    return request.headers.get("X-Admin-Token", "").strip()


def verify_agent_key(token: str) -> bool:
    candidate = (token or "").strip()
    if not candidate or not settings.agent_shared_key:
        return False
    return hmac.compare_digest(candidate, settings.agent_shared_key)


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = get_current_user()
        if not user:
            return error_response("Autenticazione richiesta.", 401)
        return view(*args, **kwargs)

    return wrapped


def role_required(*allowed_roles: str):
    normalized_roles = {role.strip().lower() for role in allowed_roles if role}

    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            user = get_current_user()
            if not user:
                return error_response("Autenticazione richiesta.", 401)
            if normalized_roles and str(user.get("role", "")).lower() not in normalized_roles:
                return error_response("Operazione non autorizzata per il ruolo corrente.", 403)
            return view(*args, **kwargs)

        return wrapped

    return decorator


def get_current_user() -> dict | None:
    return getattr(g, "current_user", None)


def get_request_ip() -> str | None:
    forwarded = request.headers.get("X-Forwarded-For", "")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.remote_addr


def get_user_agent() -> str | None:
    return request.headers.get("User-Agent")


def _enforce_rate_limit():
    if settings.rate_limit_per_minute <= 0:
        return None

    now = time.monotonic()
    window_start = now - 60
    client_ip = (get_request_ip() or "unknown").split(",")[0].strip()
    key = f"{client_ip}:{request.path}"
    bucket = _rate_windows[key]

    while bucket and bucket[0] < window_start:
        bucket.popleft()

    if len(bucket) >= settings.rate_limit_per_minute:
        return error_response("Rate limit superato. Riprovare piu tardi.", 429)

    bucket.append(now)
    return None
