from __future__ import annotations

import os
import signal
import time

from db import initialize_database
from models import Repository
from services.health_check_service import HealthCheckService
from services.scan_job_service import ScanJobService
from utils.logger import get_logger


logger = get_logger("scan-worker")
repository = Repository()
scan_service = ScanJobService(repository)
health_service = HealthCheckService(repository)
POLL_INTERVAL_SECONDS = int(os.getenv("SCAN_WORKER_INTERVAL_SECONDS", "10"))
SCAN_OUTPUT_DIR = os.getenv("SCAN_OUTPUT_DIR", "/app/scan_output")


_running = True


def _handle_sigterm(signum, _frame):
    """Trap SIGTERM/SIGINT per uscita pulita: completa l'iterazione corrente
    e termina invece di farsi uccidere a metà transazione."""
    global _running
    logger.info("Segnale %s ricevuto: arresto graceful in corso...", signum)
    _running = False


def main():
    signal.signal(signal.SIGTERM, _handle_sigterm)
    signal.signal(signal.SIGINT, _handle_sigterm)

    initialize_database()
    logger.info(
        "Scan worker avviato. poll=%ss output_dir=%s",
        POLL_INTERVAL_SECONDS, SCAN_OUTPUT_DIR,
    )
    while _running:
        try:
            scan_results = scan_service.run_due_jobs()
            check_results = health_service.run_due_checks()
            if scan_results:
                logger.info("Eseguiti %s scan job dovuti.", len(scan_results))
            if check_results:
                logger.info("Eseguiti %s health check permanenti dovuti.", len(check_results))
        except Exception as exc:
            logger.exception("Errore worker scan jobs: %s", exc)

        # Sleep cooperativo: esce subito se _running diventa False durante l'attesa.
        for _ in range(POLL_INTERVAL_SECONDS):
            if not _running:
                break
            time.sleep(1)

    logger.info("Scan worker arrestato gracefully.")


if __name__ == "__main__":
    main()
