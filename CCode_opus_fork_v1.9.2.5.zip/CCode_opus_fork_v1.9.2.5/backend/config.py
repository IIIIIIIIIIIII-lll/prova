import os
from dataclasses import dataclass
from ipaddress import ip_network

from dotenv import load_dotenv


load_dotenv()


def _parse_bool(value: str, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _parse_csv(value: str) -> list[str]:
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


_PLACEHOLDER_SECRETS = {
    "",
    "change-this-long-random-jwt-secret",
    "replace-with-a-random-32-byte-secret",
    "change-this-long-random-server-side-pepper",
    "change-me-agent-key",
    "ChangeThis_StrongPassword123!",
}


@dataclass
class Settings:
    app_host: str = os.getenv("APP_HOST", "0.0.0.0")
    app_port: int = int(os.getenv("APP_PORT", "5000"))
    db_host: str = os.getenv("DB_HOST", "localhost")
    db_port: int = int(os.getenv("DB_PORT", "1433"))
    db_name: str = os.getenv("DB_NAME", "NetVisor")
    db_user: str = os.getenv("DB_USER", "sa")
    db_password: str = os.getenv("DB_PASSWORD", "")
    flask_debug: bool = _parse_bool(os.getenv("FLASK_DEBUG"), False)
    cors_origins: list[str] = None
    scan_allowed_cidrs: list[str] = None
    scan_timeout_seconds: int = int(os.getenv("SCAN_TIMEOUT_SECONDS", "60"))
    masscan_max_rate: int = int(os.getenv("MASSCAN_MAX_RATE", "1000"))
    # NetVisor è ora esclusivamente LIVE: nessuna modalità demo.
    # Il DB nasce vuoto e si popola solo con dati reali da scansioni
    # autorizzate e telemetria agent.
    allow_public_scan: bool = _parse_bool(os.getenv("ALLOW_PUBLIC_SCAN"), False)
    max_scan_ports: int = int(os.getenv("MAX_SCAN_PORTS", "25"))
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
    require_auth: bool = _parse_bool(os.getenv("REQUIRE_AUTH"), _parse_bool(os.getenv("REQUIRE_ADMIN_AUTH"), True))
    require_admin_auth: bool = _parse_bool(os.getenv("REQUIRE_ADMIN_AUTH"), True)
    admin_username: str = os.getenv("ADMIN_USERNAME", "admin")
    admin_password: str = os.getenv("ADMIN_PASSWORD", "")
    auth_pepper: str = os.getenv("AUTH_PEPPER", "")
    jwt_secret_key: str = os.getenv("JWT_SECRET_KEY", os.getenv("AUTH_SECRET", ""))
    auth_secret: str = os.getenv("AUTH_SECRET", "")
    auth_token_ttl_minutes: int = int(os.getenv("AUTH_TOKEN_TTL_MINUTES", "480"))
    access_token_minutes: int = int(os.getenv("ACCESS_TOKEN_MINUTES", "15"))
    refresh_token_days: int = int(os.getenv("REFRESH_TOKEN_DAYS", "7"))
    login_rate_limit_per_minute: int = int(os.getenv("LOGIN_RATE_LIMIT_PER_MINUTE", "5"))
    account_lock_minutes: int = int(os.getenv("ACCOUNT_LOCK_MINUTES", "15"))
    min_job_interval_seconds: int = int(os.getenv("MIN_JOB_INTERVAL_SECONDS", "60"))
    max_content_length: int = int(os.getenv("MAX_CONTENT_LENGTH", str(1024 * 1024)))
    rate_limit_per_minute: int = int(os.getenv("RATE_LIMIT_PER_MINUTE", "120"))
    max_ingest_events: int = int(os.getenv("MAX_INGEST_EVENTS", "500"))
    max_scan_prefix_ipv4: int = int(os.getenv("MAX_SCAN_PREFIX_IPV4", "24"))
    agent_shared_key: str = os.getenv("AGENT_SHARED_KEY", "")
    agent_offline_seconds: int = int(os.getenv("AGENT_OFFLINE_SECONDS", "120"))
    agent_cpu_high_threshold: int = int(os.getenv("AGENT_CPU_HIGH_THRESHOLD", "85"))
    agent_ram_high_threshold: int = int(os.getenv("AGENT_RAM_HIGH_THRESHOLD", "85"))
    agent_disk_high_threshold: int = int(os.getenv("AGENT_DISK_HIGH_THRESHOLD", "90"))
    agent_event_error_threshold: int = int(os.getenv("AGENT_EVENT_ERROR_THRESHOLD", "3"))
    strict_secrets: bool = _parse_bool(os.getenv("STRICT_SECRETS"), True)

    def __post_init__(self):
        self.cors_origins = _parse_csv(os.getenv("CORS_ORIGINS", "http://localhost:8080"))
        self.scan_allowed_cidrs = _parse_csv(
            os.getenv("SCAN_ALLOWED_CIDRS", "192.168.0.0/16,10.0.0.0/8,172.16.0.0/12")
        )

        # === Hard validations ==========================================
        if "*" in self.cors_origins and self.require_auth:
            raise ValueError("CORS_ORIGINS='*' non e consentito quando REQUIRE_AUTH=true.")
        if self.require_auth and not self.jwt_secret_key:
            raise ValueError("JWT_SECRET_KEY o AUTH_SECRET sono obbligatori quando REQUIRE_AUTH=true.")

        # === Fail-fast su placeholder secrets ==========================
        # NetVisor è LIVE-only: i secret devono essere sostituiti SEMPRE.
        # STRICT_SECRETS=false consente bypass (sconsigliato in produzione).
        if self.strict_secrets:
            offenders = []
            if self.jwt_secret_key in _PLACEHOLDER_SECRETS:
                offenders.append("JWT_SECRET_KEY")
            if self.auth_secret in _PLACEHOLDER_SECRETS and self.auth_secret:
                offenders.append("AUTH_SECRET")
            if self.auth_pepper in _PLACEHOLDER_SECRETS:
                offenders.append("AUTH_PEPPER")
            if self.agent_shared_key in _PLACEHOLDER_SECRETS:
                offenders.append("AGENT_SHARED_KEY")
            if self.admin_password in _PLACEHOLDER_SECRETS:
                offenders.append("ADMIN_PASSWORD")
            if self.db_password in _PLACEHOLDER_SECRETS:
                offenders.append("DB_PASSWORD/MSSQL_SA_PASSWORD")
            if offenders:
                raise ValueError(
                    "Secrets ancora ai placeholder default: "
                    + ", ".join(offenders)
                    + ". Sostituire in .env, oppure STRICT_SECRETS=false per bypass (NON raccomandato)."
                )

    @property
    def allowed_networks(self):
        return [ip_network(cidr, strict=False) for cidr in self.scan_allowed_cidrs]


settings = Settings()
