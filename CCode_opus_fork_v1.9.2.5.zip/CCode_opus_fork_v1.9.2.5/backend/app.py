from datetime import date, datetime
from pathlib import Path

from flask import Flask
from flask.json.provider import DefaultJSONProvider
from flask_cors import CORS
from werkzeug.exceptions import RequestEntityTooLarge

from config import settings
from db import initialize_database
from models import Repository


# ── JSON serializer ───────────────────────────────────────────────────────────
# Flask 3.x serializza datetime via http_date() → "Sat, 09 May 2026 00:00:00 GMT"
# (RFC 1123). Il frontend si aspetta ISO 8601 ("2026-05-09T00:00:00Z") perché
# parte dall'assunto "DB in UTC, UI converte a Europe/Rome con Intl.DateTimeFormat".
# Qui forziamo isoformat su tutti i datetime/date in modo che il contratto
# backend↔frontend resti coerente.
class IsoJSONProvider(DefaultJSONProvider):
    def default(self, obj):
        if isinstance(obj, datetime):
            # SQL Server (SYSUTCDATETIME) restituisce datetime senza tzinfo:
            # li trattiamo come UTC e marchiamo con suffix 'Z'.
            if obj.tzinfo is None:
                return obj.strftime("%Y-%m-%dT%H:%M:%S") + (
                    f".{obj.microsecond // 1000:03d}Z" if obj.microsecond else "Z"
                )
            return obj.isoformat()
        if isinstance(obj, date):
            return obj.isoformat()
        return super().default(obj)


# ── Versioning ────────────────────────────────────────────────────────────
# La versione applicativa è letta dal file VERSION nella root del repo
# (semver MAJOR.MINOR.PATCH). Esposta via /api/system/info per coordinarsi
# tra build frontend/backend e per il banner LIVE.
def _read_version() -> str:
    candidates = [
        Path("/app/VERSION"),
        Path(__file__).resolve().parent.parent / "VERSION",
        Path(__file__).resolve().parent / "VERSION",
    ]
    for path in candidates:
        try:
            if path.is_file():
                v = path.read_text(encoding="utf-8").strip()
                if v:
                    return v
        except Exception:
            continue
    return "0.0.0-dev"


VERSION = _read_version()
from routes.auth import auth_bp
from routes.agents import agents_bp
from routes.alerts import alerts_bp
from routes.health_checks import health_checks_bp
from routes.ingest import ingest_bp
from routes.insights import insights_bp
from routes.nodes import nodes_bp
from routes.scans import scans_bp
from routes.scan_jobs import scan_jobs_bp
from routes.tests import tests_bp
from routes.topology import topology_bp
from routes.users import users_bp
from utils.logger import get_logger
from utils.responses import error_response, success_response
from utils.security import install_security_controls, role_required


logger = get_logger("app")
repository = Repository()


def create_app():
    app = Flask(__name__)
    # Override del JSON provider PRIMA di registrare blueprint/extensions:
    # tutti i datetime escono in ISO 8601 UTC con suffix 'Z'.
    app.json = IsoJSONProvider(app)
    cors_origins = "*" if "*" in settings.cors_origins else settings.cors_origins
    CORS(
        app,
        origins=cors_origins,
        allow_headers=["Content-Type", "Authorization", "X-Admin-Token", "X-Agent-Key"],
        methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
        supports_credentials=False,
    )
    install_security_controls(app)

    app.register_blueprint(auth_bp)
    app.register_blueprint(agents_bp)
    app.register_blueprint(insights_bp)
    app.register_blueprint(nodes_bp)
    app.register_blueprint(alerts_bp)
    app.register_blueprint(scans_bp)
    app.register_blueprint(scan_jobs_bp)
    app.register_blueprint(health_checks_bp)
    app.register_blueprint(tests_bp)
    app.register_blueprint(topology_bp)
    app.register_blueprint(ingest_bp)
    app.register_blueprint(users_bp)

    @app.get("/")
    def root():
        return success_response(
            {
                "service": "NetVisor API",
                "status": "running",
                "health_url": "/api/health",
                "frontend_url": "http://localhost:8080",
                "auth": "Autenticazione Bearer richiesta per dashboard e API applicative. POST agent con X-Agent-Key.",
            }
        )

    @app.get("/api/health")
    def health():
        return success_response({"status": "ok"})

    @app.get("/api/system/info")
    def system_info():
        # Endpoint PUBBLICO — espone metadata applicativi (versione, modalità,
        # service name) per:
        #   1. Coordinare build frontend/backend (mismatch detection)
        #   2. Mostrare versione nel banner UI / footer
        # NetVisor è LIVE-only: nessuna funzionalità demo o seed sintetico.
        return success_response(
            {
                "service": "NetVisor API",
                "version": VERSION,
                "mode": "live",
                "data_policy": "real-only",
            }
        )

    @app.get("/api/dashboard/summary")
    @role_required("admin", "user")
    def dashboard_summary():
        summary = repository.get_dashboard_summary()
        summary["latest_alerts"] = repository.list_latest_alerts(5)
        return success_response(summary)

    @app.errorhandler(404)
    def not_found(_error):
        return error_response("Endpoint non trovato.", 404)

    @app.errorhandler(RequestEntityTooLarge)
    def payload_too_large(_error):
        return error_response("Payload troppo grande.", 413)

    @app.errorhandler(Exception)
    def handle_exception(error):
        logger.exception("Errore non gestito: %s", error)
        return error_response("Errore interno del server.", 500)

    return app


app = create_app()


if __name__ == "__main__":
    initialize_database()

    app.run(host=settings.app_host, port=settings.app_port, debug=settings.flask_debug)
