import os
import time

import requests


BACKEND_URL = os.getenv("BACKEND_URL", "http://backend:5000")
API_KEY = os.getenv("NETVISOR_API_KEY", "")


def wait_for_backend():
    while True:
        try:
            response = requests.get(f"{BACKEND_URL}/api/health", timeout=5)
            if response.ok:
                print("Backend raggiungibile dal worker scanner.")
                return
        except requests.RequestException:
            pass
        print("In attesa del backend...")
        time.sleep(5)


def main():
    wait_for_backend()
    if not API_KEY:
        print("NETVISOR_API_KEY non configurata: il worker potra solo verificare health.")
    print("Worker scanner pronto. Modalita estensibile per orchestrazione futura di job remoti.")
    while True:
        time.sleep(60)


if __name__ == "__main__":
    main()
