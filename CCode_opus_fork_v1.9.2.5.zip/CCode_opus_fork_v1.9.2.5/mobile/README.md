# NetVisor Mobile (.NET MAUI)

App di monitoraggio Android per la piattaforma NetVisor (NOSD) — INFORMIX
S.p.A., Project Work ITS Cybersecurity 2025-2027.

L'app è un **client read-mostly** che consuma esclusivamente le API REST del
backend Flask (`/api/auth`, `/api/nodes`, `/api/alerts`, `/api/ping`,
`/api/http-test`). Nessuna logica di scansione locale, nessun accesso
diretto al DB SQL Server: tutto passa via HttpClient + Bearer JWT.

---

## 1. Specifiche funzionali coperte

Aderenza al PDF *SPECIFICHE MASTER PROJECTWORK §3.E* (Mobile App):

| # | Specifica | Pagina app | Endpoint chiamati |
|---|-----------|------------|-------------------|
| 1 | Home: totale nodi, online/offline, alert attivi | `HomePage` | GET `/api/nodes`, GET `/api/alerts` (aggregati client-side) |
| 2 | Lista nodi: elenco, stato, IP/hostname | `NodesPage` | GET `/api/nodes` |
| 3 | Alert: lista cronologica, severità, descrizione | `AlertsPage` | GET `/api/alerts` |
| 4 | Test connettività: ping da app + test HTTP | `ConnectivityPage` | POST `/api/ping`, POST `/api/http-test` |
| 5 | Dettaglio nodo: stato, servizi, alert associati | `NodeDetailPage` | GET `/api/nodes/{id}/services`, GET `/api/nodes/{id}/alerts` |

Estensioni rispetto alle specifiche di base (non obbligatorie ma presenti):

- prefisso `CTR_` evidenziato in badge per i container Docker
- severità cromatica completa (Critical=Rosso, High=Arancione, Medium=Giallo, Low=Blu)
- filtri client-side su Nodi (testo libero) e Alert (Tutti/Aperti/Critical/High)
- pull-to-refresh su tutte le liste
- auto-login da SecureStorage se la sessione precedente è valida
- gestione lockout IDS hardened (3°/4°/5°/6° fallimento → popup escalation)
- tema dark coerente con la dashboard web QRadar-style

---

## 2. Architettura

```
NetVisorMaui/
├── Constants.cs              # Config centralizzata (BaseUrl, endpoints, storage keys)
├── App.xaml(.cs)             # Application bootstrap + risorse globali
├── AppShell.xaml(.cs)        # TabBar post-login (Home/Nodi/Alert/Test) + Logout
├── MauiProgram.cs            # DI registrations
├── ServiceHelper.cs          # Service locator per code-behind XAML
│
├── Models/                   # POCO mappati 1:1 al JSON Flask snake_case
│   ├── Node.cs               # + computed StatusColor, IsContainer, DisplayName
│   ├── Alert.cs              # + SeverityColor, SeverityLabel, TimestampLabel
│   ├── ServiceItem.cs        # porta/protocollo/servizio rilevato da nmap
│   ├── AuthUser.cs           # utente autenticato (role admin/user)
│   ├── LoginRequest.cs / LoginResponse.cs
│   ├── ConnectivityTest.cs   # risposta /api/ping e /api/http-test
│   ├── DashboardSummary.cs   # KPI aggregati Home (calcolati client-side)
│   └── ApiEnvelope.cs        # {success, data, error, _meta, lockout}
│
├── Services/                 # Layer HTTP — unico modo di parlare al backend
│   ├── ApiClient.cs          # HttpClient hardened + JWT + refresh token rotation
│   ├── AuthService.cs        # login/logout/me con gestione lockout IDS
│   ├── NodesService.cs       # GET /api/nodes + sub-endpoint
│   ├── AlertsService.cs      # GET /api/alerts
│   ├── TestsService.cs       # POST /api/ping, /api/http-test
│   └── DashboardService.cs   # aggregator client-side per la Home
│
├── ViewModels/               # MVVM con INotifyPropertyChanged + ICommand
│   ├── BaseViewModel.cs      # IsBusy, ErrorMessage, ExecuteSafeAsync helper
│   ├── LoginViewModel.cs     # + LockoutNotice per popup IDS
│   ├── HomeViewModel.cs
│   ├── NodesViewModel.cs     # + filtro testuale
│   ├── NodeDetailViewModel.cs
│   ├── AlertsViewModel.cs    # + filtri segmentati All/Open/Critical/High
│   └── ConnectivityViewModel.cs # + history in-memory ultimi 10 test
│
├── Views/                    # XAML — tema dark, touch targets ≥48dp Samsung A8
│   ├── LoginPage.xaml(.cs)
│   ├── HomePage.xaml(.cs)
│   ├── NodesPage.xaml(.cs)
│   ├── NodeDetailPage.xaml(.cs)
│   ├── AlertsPage.xaml(.cs)
│   └── ConnectivityPage.xaml(.cs)
│
├── Converters/               # IValueConverter per visibility e color binding
│   └── StringNotEmptyConverter.cs (+ Collection*/FilterActive* converters)
│
├── Resources/
│   ├── AppIcon/              # appicon.svg + appiconfg.svg (MAUI ridimensiona)
│   ├── Splash/               # splash.svg
│   ├── Images/               # vuoto, placeholder
│   └── Styles/
│       ├── Colors.xaml       # palette dark NetVisor coerente con frontend web
│       └── Styles.xaml       # ContentPage/Shell/Label/Entry/Button/Card
│
└── Platforms/
    ├── Android/
    │   ├── MainActivity.cs
    │   ├── MainApplication.cs
    │   ├── AndroidManifest.xml         # INTERNET + ACCESS_NETWORK_STATE
    │   └── Resources/xml/network_security_config.xml  # consente HTTP cleartext LAB
    └── Windows/                        # scaffolding minimo per target windows10
```

---

## 3. Configurazione BaseUrl (CRITICA)

Il backend Flask gira sul PC dello sviluppatore. Lo Samsung A8 deve poterlo
raggiungere via uno di questi scenari:

### A. Emulatore Android (raccomandato per dev)
Il magic IP `10.0.2.2` è l'alias che dall'emulatore mappa al loopback del
PC host. **Già impostato come default** in `Constants.cs`:

```csharp
DefaultBaseUrlAndroid = "http://10.0.2.2:5000";
```

Nessuna config da cambiare. Avvia il backend con `docker compose up`,
verifica `curl http://localhost:5000/api/health` dal PC, poi lancia
l'app sull'emulatore.

### B. Samsung A8 fisico in tethering USB/Hotspot
Il telefono deve essere sulla stessa rete del PC.

1. Su Windows abilita la **condivisione di rete** o connetti il phone
   all'hotspot del PC.
2. Trova l'IP LAN del PC: `ipconfig` → cerca `IPv4 Address`. Esempio: `192.168.137.1`.
3. Sul backend Flask assicurati che ascolti su `0.0.0.0`, non solo `localhost`
   (di default lo fa già: vedi `docker-compose.yml`).
4. Dal **firewall Windows** consenti TCP 5000 in inbound.
5. Sul telefono apri l'app, nella schermata di Login modifica il campo
   "Base URL backend" con l'IP del PC: `http://192.168.137.1:5000`. La
   modifica è persistita in `Preferences` e non serve ricompilare.

### C. Rete mesh Tailscale/WireGuard (production-like)
Per accedere al backend da fuori LAN senza espormi su Internet pubblico:

1. Installa **Tailscale** sul PC host del backend e sul Samsung A8.
2. Login con lo stesso account → entrambi entrano nella tua tailnet.
3. Trova l'IP Tailscale del PC: `tailscale ip -4` (es. `100.64.0.10`).
4. Nell'app, BaseUrl = `http://100.64.0.10:5000`.

Il traffico viene crittografato end-to-end con WireGuard; nessuna porta
da aprire sul router.

---

## 4. Prerequisiti dev

- **Visual Studio 2022 17.8+** con workload "**.NET Multi-platform App UI development**"
- **.NET 8 SDK** + workload MAUI installato:
  ```cmd
  dotnet workload install maui-android
  ```
- **Android SDK API 34** (Visual Studio Installer → Individual components)
- Per emulatore: **Android SDK Manager** → installa System Image (Pixel 7, API 34, Google APIs)
- Per device fisico: ADB su PC + USB debugging abilitato sul Samsung A8

---

## 5. Build & deploy

### Su emulatore Android
```bash
cd mobile/NetVisorMaui
dotnet build -f net8.0-android -c Debug
# In Visual Studio: F5 con target "Android Emulators → Pixel 5 API 34"
```

### Su Samsung A8 fisico
1. Sul phone: Impostazioni → Info → tap 7 volte su "Numero build" → attiva Opzioni sviluppatore
2. Opzioni sviluppatore → "Debug USB" ON
3. Collega via USB. Su PC: `adb devices` → deve apparire il device.
4. In Visual Studio, target = "Android Local Devices → SM-X200".
5. F5. La prima volta il build firma + installa un keystore di debug, può richiedere 2-3 min.

### Release APK (per distribuzione interna LAB)
```bash
dotnet publish -f net8.0-android -c Release \
    /p:AndroidPackageFormat=apk \
    /p:AndroidKeyStore=true \
    /p:AndroidSigningKeyStore=netvisor.keystore \
    /p:AndroidSigningStorePass=changeit \
    /p:AndroidSigningKeyAlias=netvisor \
    /p:AndroidSigningKeyPass=changeit
```
Output APK: `bin/Release/net8.0-android/publish/com.informix.netvisor-Signed.apk`.

---

## 6. Sicurezza

- **JWT in SecureStorage**: i token vivono solo in `SecureStorage` (Android
  KeyStore). Mai in `Preferences`, mai loggati. Vedi `ApiClient.PersistSessionAsync`.
- **Refresh token rotation**: alla 401 facciamo un refresh transparente
  (vedi `ApiClient.TryRefreshTokenAsync`). Singolo retry, no loop infiniti.
- **Bearer header** automatico su ogni richiesta `requireAuth: true`.
- **Cleartext HTTP** permesso solo in LAB tramite `network_security_config.xml`.
  Per production rimuovere `cleartextTrafficPermitted="true"` e usare HTTPS.
- **IDS lockout escalation**: l'app riconosce il campo `lockout` nelle
  risposte 401 e mostra popup specifici per warn / soft_lock / re_lock /
  disabled — coerenti con la state machine in `auth_service._handle_failed_login()`.
- **Validazione client-side** minima: username/password/url non vuoti
  prima del POST. La validazione "vera" è server-side.

---

## 7. Test rapidi post-build

| Test | Steps | Risultato atteso |
|------|-------|------------------|
| Login admin OK | username=admin, password corretta | Popup "Accesso amministratore rilevato" + Home con KPI |
| Login user OK | username=user, password corretta | Home con KPI, no popup admin |
| Login wrong pass 3x | password sbagliata 3 volte | Popup "3° tentativo fallito" (warn) |
| Login wrong pass 4x | password sbagliata 4 volte | Popup "Account bloccato temporaneamente N min" |
| Auto-login | chiudi e riapri app entro 15 min | Salta login, va dritto in Home |
| Backend down | spegni backend, refresh Home | Banner rosso "Timeout / Connessione fallita" |
| Nodi list | apri tab Nodi | Lista con dot colorato (verde/rosso) + badge CTR per container |
| Nodo detail | tap su un nodo | Card header + lista servizi + lista alert |
| Ping | target=8.8.8.8 → ping | Risultato success + latency in ms |
| Ping fail | target=10.255.255.1 | Risultato failed + dettaglio errore |
| HTTP test | url=https://google.com | success + latency |
| Logout | Logout dal toolbar | Torna a Login, SecureStorage svuotato |

---

## 8. Troubleshooting

| Sintomo | Causa probabile | Fix |
|---------|-----------------|-----|
| "Connessione fallita" su emulatore | BaseUrl errato | Deve essere `http://10.0.2.2:5000`, non `localhost` |
| "Connessione fallita" su device fisico | Firewall Windows blocca 5000 | `netsh advfirewall firewall add rule name="Flask" dir=in action=allow protocol=TCP localport=5000` |
| HTTP 401 al primo refresh | Refresh token scaduto | Logout + re-login |
| App crash al boot | Manca workload MAUI | `dotnet workload restore` |
| Build fail Android | SDK 34 non installato | Visual Studio Installer → Android SDK Build-Tools 34 |
| Splash bianco poi crash | Riferimento mancante a icona | Verifica che `Resources/AppIcon/*.svg` esistano |
| Token persiste dopo uninstall | KeyStore Android pulito | Su Android la SecureStorage segue l'app: uninstall pulisce |

---

## 9. Roadmap futura (fuori scope project work base)

- [ ] Push notification per alert critical/high (Firebase Cloud Messaging)
- [ ] Filtro Nodi per zone/tag (richiede arricchimento backend)
- [ ] Tema light con switcher utente in app
- [ ] iOS target (oggi commentato in csproj)
- [ ] Test automatici xUnit per ApiClient e ViewModels

---

*Documento mantenuto allineato a NetVisor backend ≥ v1.0.3.*
