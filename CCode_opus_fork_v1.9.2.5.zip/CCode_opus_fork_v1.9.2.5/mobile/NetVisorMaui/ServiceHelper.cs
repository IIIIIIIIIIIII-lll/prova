using Microsoft.Extensions.DependencyInjection;

namespace NetVisorMaui;

/// <summary>
/// Service Locator minimo per i punti dove non possiamo iniettare via
/// costruttore (es. event handlers in code-behind XAML, navigation
/// helper). Da preferire l'injection costruttore quando possibile.
/// </summary>
public static class ServiceHelper
{
    public static IServiceProvider Services { get; set; } = default!;

    public static T GetService<T>() where T : notnull
        => Services.GetRequiredService<T>();

    public static T? TryGetService<T>() where T : class
        => Services.GetService<T>();
}
