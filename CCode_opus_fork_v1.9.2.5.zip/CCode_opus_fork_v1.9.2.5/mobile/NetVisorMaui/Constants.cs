namespace NetVisorMaui;

/// <summary>
/// Configurazione centralizzata NetVisor mobile.
///
/// ## Networking
/// Il backend Flask espone l'API su porta 5000. L'app mobile deve poterlo
/// raggiungere via uno dei seguenti scenari (in ordine di priorità per la
/// demo project work ITS Cybersecurity 2025-2027):
///
///   1. Emulatore Android (Pixel/AVD su Visual Studio):
///      → http://10.0.2.2:5000  (alias speciale che mappa al localhost del PC host)
///
///   2. Dispositivo fisico Samsung A8 in tethering USB/Hotspot:
///      → http://192.168.x.y:5000  (IP LAN del PC host; controllare con `ipconfig`)
///
///   3. Rete mesh Tailscale/WireGuard (overlay VPN crittografata, scenario
///      production per accesso remoto da fuori LAN):
///      → http://100.x.y.z:5000   (IP della tailnet del PC host)
///
/// L'utente può cambiare l'URL **a runtime** dalla pagina di Login senza
/// ricompilare. Il valore viene persistito in <see cref="Preferences"/> e
/// sopravvive ai restart dell'app. Il DEFAULT (sotto) viene usato solo al
/// primo avvio o se l'utente fa "Reset configurazione".
///
/// ## SecureStorage keys
/// Gli access/refresh token JWT vivono SOLO in <see cref="SecureStorage"/>
/// (KeyStore Android / Keychain iOS). Mai in Preferences né in file.
/// La chiave AccessTokenKey è usata anche dall'header Authorization: Bearer.
/// </summary>
public static class Constants
{
    // ── Networking ────────────────────────────────────────────────────────
    // ⚠️ DEVELOPER NOTE: prima della compilazione per Samsung A8 fisico,
    // sostituire il default con l'IP LAN o Tailscale del PC che esegue il
    // backend Flask. L'emulatore Android va invece direttamente sul magic IP
    // 10.0.2.2 che mappa al loopback dell'host.
    //
    //  Emulatore Android  →  http://10.0.2.2:5000     ← DEFAULT
    //  LAN/Tethering      →  http://192.168.1.50:5000
    //  Tailscale (mesh)   →  http://100.64.0.10:5000
    //
    public const string DefaultBaseUrlAndroid  = "http://10.0.2.2:5000";
    public const string DefaultBaseUrlIos      = "http://localhost:5000";
    public const string DefaultBaseUrlWindows  = "http://localhost:5000";

    /// <summary>Timeout sulla singola richiesta HTTP (esclude refresh retry).</summary>
    public static readonly TimeSpan HttpTimeout = TimeSpan.FromSeconds(15);

    /// <summary>Polling auto-refresh delle pagine (Home/Nodes/Alerts).</summary>
    public static readonly TimeSpan AutoRefreshInterval = TimeSpan.FromSeconds(20);

    // ── API paths (tutti relativi al BaseUrl) ─────────────────────────────
    public static class Endpoints
    {
        public const string Login          = "/api/auth/login";
        public const string Logout         = "/api/auth/logout";
        public const string Refresh        = "/api/auth/refresh";
        public const string Me             = "/api/auth/me";
        public const string ChangePassword = "/api/auth/change-password";

        public const string Nodes          = "/api/nodes";
        public const string Alerts         = "/api/alerts";
        public const string Ping           = "/api/ping";
        public const string HttpTest       = "/api/http-test";
        public const string Health         = "/api/health";

        public static string NodeServices(int nodeId) => $"/api/nodes/{nodeId}/services";
        public static string NodeAlerts(int nodeId)   => $"/api/nodes/{nodeId}/alerts";
    }

    // ── SecureStorage / Preferences keys ──────────────────────────────────
    public static class StorageKeys
    {
        // SecureStorage (KeyStore Android / Keychain iOS) — solo segreti
        public const string AccessToken  = "nv.access_token";
        public const string RefreshToken = "nv.refresh_token";

        // Preferences (plain) — config non sensibile + cache user object
        public const string BaseUrl      = "nv.base_url";
        public const string CurrentUser  = "nv.current_user";
        public const string LastUsername = "nv.last_username";  // pre-fill login (no password)
    }
}
