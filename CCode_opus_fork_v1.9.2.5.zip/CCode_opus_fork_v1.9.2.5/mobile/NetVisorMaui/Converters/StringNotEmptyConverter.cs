using System.Globalization;

namespace NetVisorMaui.Converters;

/// <summary>
/// IValueConverter: ritorna true se la string non è null/whitespace.
/// Usato per la visibilità di label di feedback (status/error) — evita di
/// dover esporre una <c>HasXxx</c> bool su ogni ViewModel.
/// </summary>
public class StringNotEmptyConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => !string.IsNullOrWhiteSpace(value as string);

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}

/// <summary>
/// IValueConverter: ritorna true se la <see cref="ICollection"/> ha almeno 1 elemento.
/// Usato per mostrare "Nessun dato" placeholder quando la collection è vuota.
/// </summary>
public class CollectionNotEmptyConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is System.Collections.ICollection coll) return coll.Count > 0;
        return false;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}

/// <summary>
/// Negazione di <see cref="CollectionNotEmptyConverter"/> — true se vuota.
/// </summary>
public class CollectionEmptyConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is System.Collections.ICollection coll) return coll.Count == 0;
        return true;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}

/// <summary>
/// Converter per i pulsanti segmentati di filtro (Alerts page): se il bool
/// IsFilterXxx è true → colore accent NetVisor, altrimenti trasparente.
/// </summary>
public class FilterActiveConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var active = value is bool b && b;
        return active ? Color.FromArgb("#3B82F6") : Colors.Transparent;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}

/// <summary>
/// Colore testo del filtro attivo: bianco quando selezionato, accent quando no.
/// </summary>
public class FilterActiveTextConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var active = value is bool b && b;
        return active ? Colors.White : Color.FromArgb("#3B82F6");
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
