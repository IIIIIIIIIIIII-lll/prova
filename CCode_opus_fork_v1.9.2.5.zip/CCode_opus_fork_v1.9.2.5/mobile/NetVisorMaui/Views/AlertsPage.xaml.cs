using NetVisorMaui.ViewModels;

namespace NetVisorMaui.Views;

public partial class AlertsPage : ContentPage
{
    private readonly AlertsViewModel _vm;

    public AlertsPage(AlertsViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = _vm = viewModel;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (_vm.Alerts.Count == 0)
        {
            await _vm.LoadAsync();
        }
    }
}
