using NetVisorMaui.Models;
using NetVisorMaui.ViewModels;

namespace NetVisorMaui.Views;

/// <summary>
/// Pagina di dettaglio nodo — il Node viene ricevuto via Shell query parameters
/// dalla NodesPage (chiave "node"). In alternativa si potrebbe usare il nodeId
/// e fare GET /api/nodes/{id}, ma passare l'oggetto risparmia un roundtrip.
/// </summary>
[QueryProperty(nameof(NodeParam), "node")]
public partial class NodeDetailPage : ContentPage
{
    private readonly NodeDetailViewModel _vm;

    public NodeDetailPage(NodeDetailViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = _vm = viewModel;
    }

    /// <summary>Property target del [QueryProperty]. Riceve un <see cref="Node"/>.</summary>
    public Node? NodeParam
    {
        set
        {
            if (value is null) return;
            _vm.SetNode(value);
            Title = value.DisplayName;
        }
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _vm.LoadAsync();
    }
}
