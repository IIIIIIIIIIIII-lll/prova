using NetVisorMaui.Models;
using NetVisorMaui.ViewModels;

namespace NetVisorMaui.Views;

/// <summary>
/// Code-behind LoginPage. Compito principale:
///   - tentare l'auto-login al primo OnAppearing
///   - dirottare alla AppShell su <see cref="LoginViewModel.LoginSucceeded"/>
///   - mostrare popup specifici per:
///       * admin login (NetVisor audit trail) — campo admin_login_alert
///       * IDS lockout escalation                — campo lockout
/// </summary>
public partial class LoginPage : ContentPage
{
    private readonly LoginViewModel _vm;
    private bool _autoLoginTried;

    public LoginPage(LoginViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = _vm = viewModel;
        _vm.LoginSucceeded += OnLoginSucceeded;
        _vm.PropertyChanged += OnVmPropertyChanged;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (!_autoLoginTried)
        {
            _autoLoginTried = true;
            await _vm.TryAutoLoginAsync();
        }
    }

    private async void OnLoginSucceeded(object? sender, LoginResponse response)
    {
        // Popup admin: NetVisor traccia ogni login admin (vedi auth_service.py)
        // — la web dashboard mostra un modal, lo replichiamo qui per parità.
        if (response.AdminLoginAlert)
        {
            var msg = response.AdminLoginMessage ?? "Accesso amministratore registrato.";
            if (!string.IsNullOrEmpty(response.AdminLoginTimestamp))
            {
                msg += $"\n\nTimestamp: {response.AdminLoginTimestamp}";
            }
            if (!string.IsNullOrEmpty(response.AdminLoginIp))
            {
                msg += $"\nIP: {response.AdminLoginIp}";
            }
            await DisplayAlert("Accesso amministratore rilevato", msg, "OK");
        }

        // Navigazione: switch della MainPage a AppShell (con TabBar).
        if (Application.Current is not null)
        {
            Application.Current.MainPage = ServiceHelper.GetService<AppShell>();
        }
    }

    private async void OnVmPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        // Popup IDS lockout: quando il backend hardened escala il rate-limit
        // (3°/4°/5°/6° fail consecutivo) il ViewModel popola LockoutNotice
        // e noi mostriamo un alert specifico, non solo testo rosso.
        if (e.PropertyName == nameof(LoginViewModel.LockoutNotice) && _vm.LockoutNotice is not null)
        {
            var info = _vm.LockoutNotice;
            string title = info.State switch
            {
                "warn"      => "Attenzione: 3° tentativo fallito",
                "soft_lock" => "Account bloccato temporaneamente",
                "re_lock"   => "Account ri-bloccato",
                "disabled"  => "Account DISABILITATO",
                _           => "Avviso autenticazione"
            };
            string body = _vm.ErrorMessage;
            if (info.LockMinutes.HasValue && info.State is "soft_lock" or "re_lock")
            {
                body += $"\n\nDurata blocco: {info.LockMinutes} min.";
            }
            if (info.State == "disabled")
            {
                body += "\n\nContattare l'amministratore per la riattivazione.";
            }
            await DisplayAlert(title, body, "OK");

            // Reset per evitare loop al prossimo PropertyChanged casuale.
            _vm.LockoutNotice = null;
        }
    }
}
