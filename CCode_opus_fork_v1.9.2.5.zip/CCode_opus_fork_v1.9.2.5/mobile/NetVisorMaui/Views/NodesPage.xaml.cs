using NetVisorMaui.Models;
using NetVisorMaui.ViewModels;

namespace NetVisorMaui.Views;

public partial class NodesPage : ContentPage
{
    private readonly NodesViewModel _vm;

    public NodesPage(NodesViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = _vm = viewModel;
        NodesCollection.SelectionChanged += OnSelectionChanged;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (_vm.Nodes.Count == 0)
        {
            await _vm.LoadAsync();
        }
    }

    private async void OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.FirstOrDefault() is not Node node) return;

        // Reset selezione PRIMA della navigazione: alla tornata in pagina,
        // la stessa riga non resta evidenziata e il tap successivo funziona.
        NodesCollection.SelectedItem = null;

        // Passiamo l'intero oggetto Node alla pagina di dettaglio via
        // navigation parameters (Shell-based). Il VM destinatario può
        // chiamare SetNode(node) per evitare un GET nodes/{id} aggiuntivo.
        var parameters = new Dictionary<string, object> { ["node"] = node };
        await Shell.Current.GoToAsync(nameof(NodeDetailPage), parameters);
    }
}
