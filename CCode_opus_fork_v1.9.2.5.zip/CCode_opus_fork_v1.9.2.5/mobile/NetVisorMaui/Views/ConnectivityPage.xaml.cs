using NetVisorMaui.ViewModels;

namespace NetVisorMaui.Views;

public partial class ConnectivityPage : ContentPage
{
    public ConnectivityPage(ConnectivityViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
