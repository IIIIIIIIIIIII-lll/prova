namespace NetVisorMaui.Models;

/// <summary>
/// KPI aggregati per la pagina Home — calcolati CLIENT-SIDE a partire da
/// /api/nodes e /api/alerts. Mantenere allineato a quanto richiesto da
/// SPECIFICHE PROJECTWORK §3.E.1: totale nodi, online/offline, alert attivi.
///
/// NB: non c'è endpoint Flask /api/dashboard/summary — l'aggregazione è in
/// <see cref="Services.DashboardService"/>. Mantenere il calcolo lato client
/// riduce roundtrip e permette di mostrare anche dati derivati (% online,
/// container vs host) senza modificare il backend.
/// </summary>
public class DashboardSummary
{
    public int TotalNodes { get; set; }
    public int OnlineNodes { get; set; }
    public int OfflineNodes { get; set; }
    public int UnknownNodes { get; set; }
    public int ContainerNodes { get; set; }
    public int OpenAlerts { get; set; }
    public int CriticalAlerts { get; set; }
    public int HighAlerts { get; set; }

    public string OnlinePercent => TotalNodes > 0
        ? $"{(OnlineNodes * 100 / Math.Max(1, TotalNodes))}%"
        : "0%";
}
