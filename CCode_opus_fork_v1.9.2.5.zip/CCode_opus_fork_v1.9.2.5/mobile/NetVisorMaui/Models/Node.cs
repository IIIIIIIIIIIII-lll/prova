using System.Text.Json.Serialization;

namespace NetVisorMaui.Models;

/// <summary>
/// Nodo di rete restituito da GET /api/nodes (lista) e GET /api/nodes/{id}.
/// Mappa la tabella SQL Server <c>Nodes</c> definita nelle SPECIFICHE
/// PROJECTWORK §3.D: id, hostname, ip, status, last_seen.
///
/// Le proprietà aggiuntive (os_guess, mac_address, vendor, risk_score,
/// first_seen) sono estensioni del backend NetVisor reale ma NON
/// obbligatorie per la conformità alle specifiche di base. Sono qui
/// solo per la visualizzazione enriched nella Dettaglio nodo.
/// </summary>
public class Node
{
    public int Id { get; set; }

    /// <summary>
    /// Hostname effettivo. I container Docker hanno prefisso <c>CTR_</c>
    /// (convenzione NetVisor) per distinguerli dagli host fisici.
    /// </summary>
    public string? Hostname { get; set; }

    public string Ip { get; set; } = string.Empty;

    /// <summary>online | offline | unknown — usato per il colore della badge.</summary>
    public string Status { get; set; } = "unknown";

    [JsonPropertyName("os_guess")]
    public string? OsGuess { get; set; }

    [JsonPropertyName("mac_address")]
    public string? MacAddress { get; set; }

    public string? Vendor { get; set; }

    [JsonPropertyName("risk_score")]
    public int RiskScore { get; set; }

    [JsonPropertyName("first_seen")]
    public DateTime? FirstSeen { get; set; }

    [JsonPropertyName("last_seen")]
    public DateTime? LastSeen { get; set; }

    // ── Computed properties per il binding XAML ───────────────────────────
    // Queste NON sono serializzate (no getter pubblico nel JSON di output).
    // Sono helper UI per evitare converter XAML inutili.

    /// <summary>True se l'hostname inizia con CTR_ → è un container Docker.</summary>
    [JsonIgnore]
    public bool IsContainer => !string.IsNullOrEmpty(Hostname)
                               && Hostname.StartsWith("CTR_", StringComparison.OrdinalIgnoreCase);

    /// <summary>Etichetta tipo nodo per UI: "Container" o "Host".</summary>
    [JsonIgnore]
    public string KindLabel => IsContainer ? "Container" : "Host";

    /// <summary>Hostname mostrato in UI: hostname se presente, altrimenti IP.</summary>
    [JsonIgnore]
    public string DisplayName => string.IsNullOrWhiteSpace(Hostname) ? Ip : Hostname!;

    /// <summary>
    /// Colore semaforo della status badge — mappato sulla palette del frontend
    /// web (vedi <c>frontend/css/style.css</c> .state-ok / state-warn / state-bad).
    /// </summary>
    [JsonIgnore]
    public string StatusColor => Status?.ToLowerInvariant() switch
    {
        "online"  => "#22C55E",  // verde
        "offline" => "#EF4444",  // rosso
        "warn"    => "#F97316",  // arancione
        _         => "#94A3B8"   // grigio (unknown)
    };

    /// <summary>Etichetta normalizzata per display ("ONLINE", "OFFLINE", "UNKNOWN").</summary>
    [JsonIgnore]
    public string StatusLabel => (Status ?? "unknown").ToUpperInvariant();
}
