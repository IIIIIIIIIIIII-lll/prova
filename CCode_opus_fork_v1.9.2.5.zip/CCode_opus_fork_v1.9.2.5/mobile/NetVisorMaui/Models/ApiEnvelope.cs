using System.Text.Json.Serialization;

namespace NetVisorMaui.Models;

/// <summary>
/// Envelope universale di NetVisor backend (Flask utils/responses.py):
///   {"success": bool, "data": T, "error": string?, "_meta": {...}, "lockout": {...}?}
///
/// L'<see cref="ApiClient"/> usa <see cref="ApiEnvelope{T}"/> sia per il
/// success path che per leggere il <see cref="Error"/> nelle 4xx/5xx.
/// </summary>
public class ApiEnvelope<T>
{
    [JsonPropertyName("success")]
    public bool Success { get; set; }

    [JsonPropertyName("data")]
    public T? Data { get; set; }

    [JsonPropertyName("error")]
    public string? Error { get; set; }

    /// <summary>
    /// Presente sulle 401 di login/change-password quando l'IDS hardened scatta:
    ///   { "lockout_state": "warn"|"soft_lock"|"re_lock"|"disabled",
    ///     "lock_minutes": 10, "attempts": 3 }
    /// </summary>
    [JsonPropertyName("lockout")]
    public LockoutInfo? Lockout { get; set; }
}

public class LockoutInfo
{
    [JsonPropertyName("lockout_state")]
    public string? State { get; set; }

    [JsonPropertyName("lock_minutes")]
    public int? LockMinutes { get; set; }

    [JsonPropertyName("attempts")]
    public int? Attempts { get; set; }
}
