using System.Text.Json.Serialization;

namespace NetVisorMaui.Models;

/// <summary>
/// Risposta a POST /api/auth/login e POST /api/auth/refresh.
///
/// Il backend NetVisor (hardened) può aggiungere campi opzionali se l'utente
/// è admin: admin_login_alert/message/timestamp/ip — usati dall'app per
/// mostrare il popup "Accesso amministratore rilevato".
/// </summary>
public class LoginResponse
{
    [JsonPropertyName("access_token")]
    public string AccessToken { get; set; } = string.Empty;

    [JsonPropertyName("refresh_token")]
    public string RefreshToken { get; set; } = string.Empty;

    [JsonPropertyName("user")]
    public AuthUser User { get; set; } = new();

    [JsonPropertyName("admin_login_alert")]
    public bool AdminLoginAlert { get; set; }

    [JsonPropertyName("admin_login_message")]
    public string? AdminLoginMessage { get; set; }

    [JsonPropertyName("admin_login_timestamp")]
    public string? AdminLoginTimestamp { get; set; }

    [JsonPropertyName("admin_login_ip")]
    public string? AdminLoginIp { get; set; }
}
