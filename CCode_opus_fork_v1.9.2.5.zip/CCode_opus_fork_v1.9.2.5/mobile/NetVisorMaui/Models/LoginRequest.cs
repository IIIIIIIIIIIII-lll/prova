using System.Text.Json.Serialization;

namespace NetVisorMaui.Models;

/// <summary>
/// Payload POST /api/auth/login.
/// I JsonPropertyName forzano snake_case anche se la naming policy fosse diversa.
/// </summary>
public class LoginRequest
{
    [JsonPropertyName("username")]
    public string Username { get; set; } = string.Empty;

    [JsonPropertyName("password")]
    public string Password { get; set; } = string.Empty;
}
