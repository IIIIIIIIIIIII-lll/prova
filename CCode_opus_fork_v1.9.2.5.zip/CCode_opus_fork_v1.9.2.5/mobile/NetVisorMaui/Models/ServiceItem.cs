using System.Text.Json.Serialization;

namespace NetVisorMaui.Models;

/// <summary>
/// Servizio osservato su un nodo. GET /api/nodes/{id}/services.
/// Tabella SQL <c>Services</c>: id, node_id, port, protocol, service_name.
/// </summary>
public class ServiceItem
{
    public int Id { get; set; }

    [JsonPropertyName("node_id")]
    public int NodeId { get; set; }

    public int Port { get; set; }
    public string Protocol { get; set; } = "tcp";

    /// <summary>open | closed | filtered — dato da nmap/masscan.</summary>
    public string State { get; set; } = "unknown";

    [JsonPropertyName("service_name")]
    public string? ServiceName { get; set; }

    public string? Product { get; set; }
    public string? Version { get; set; }
    public string? Banner { get; set; }

    // ── Computed UI ──────────────────────────────────────────────────────
    [JsonIgnore]
    public string PortProtoLabel => $"{Port}/{Protocol}".ToLowerInvariant();

    [JsonIgnore]
    public string ProductLabel =>
        string.IsNullOrWhiteSpace(Product) && string.IsNullOrWhiteSpace(Version)
            ? "-"
            : $"{Product} {Version}".Trim();

    [JsonIgnore]
    public string StateColor => State?.ToLowerInvariant() switch
    {
        "open"     => "#22C55E",
        "closed"   => "#94A3B8",
        "filtered" => "#F97316",
        _          => "#64748B"
    };
}
