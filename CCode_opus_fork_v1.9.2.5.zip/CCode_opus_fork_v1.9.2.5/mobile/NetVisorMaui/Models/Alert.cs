using System.Globalization;
using System.Text.Json.Serialization;

namespace NetVisorMaui.Models;

/// <summary>
/// Alert restituito da GET /api/alerts (con join Nodes) e da GET /api/nodes/{id}/alerts.
///
/// Mappa la tabella SQL Server <c>Alerts</c> definita nelle SPECIFICHE
/// PROJECTWORK §3.D: id, type, severity, description, timestamp.
///
/// Le severities seguono la convenzione NetVisor (vedi CLAUDE.md):
///   critical → #EF4444 rosso
///   high     → #F97316 arancione
///   medium   → #EAB308 giallo
///   low      → #3B82F6 blu
///   info     → #94A3B8 grigio
/// </summary>
public class Alert
{
    public int Id { get; set; }
    public string Type { get; set; } = string.Empty;
    public string Severity { get; set; } = "info";
    public string Description { get; set; } = string.Empty;

    [JsonPropertyName("node_id")]
    public int? NodeId { get; set; }

    [JsonPropertyName("service_id")]
    public int? ServiceId { get; set; }

    public string Status { get; set; } = "open";

    [JsonPropertyName("timestamp")]
    public DateTime? Timestamp { get; set; }

    [JsonPropertyName("acked_at")]
    public DateTime? AckedAt { get; set; }

    [JsonPropertyName("closed_at")]
    public DateTime? ClosedAt { get; set; }

    [JsonPropertyName("deleted_at")]
    public DateTime? DeletedAt { get; set; }

    /// <summary>Hostname del nodo correlato (join Nodes lato backend).</summary>
    public string? Hostname { get; set; }

    /// <summary>IP del nodo correlato (join Nodes lato backend).</summary>
    public string? Ip { get; set; }

    // ── Computed properties UI ───────────────────────────────────────────
    [JsonIgnore]
    public string SeverityColor => Severity?.ToLowerInvariant() switch
    {
        "critical" => "#EF4444",
        "high"     => "#F97316",
        "medium"   => "#EAB308",
        "warning"  => "#EAB308",
        "low"      => "#3B82F6",
        _          => "#94A3B8"
    };

    [JsonIgnore]
    public string SeverityLabel => (Severity ?? "info").ToUpperInvariant();

    [JsonIgnore]
    public string SourceLabel => Hostname ?? Ip ?? "system";

    /// <summary>Timestamp formattato per la UI mobile in locale corrente.</summary>
    [JsonIgnore]
    public string TimestampLabel => Timestamp.HasValue
        ? Timestamp.Value.ToLocalTime().ToString("dd/MM HH:mm", CultureInfo.InvariantCulture)
        : "-";

    /// <summary>True se l'alert è nello stato "open" (non ack/closed/deleted).</summary>
    [JsonIgnore]
    public bool IsOpen => string.Equals(Status, "open", StringComparison.OrdinalIgnoreCase);
}
