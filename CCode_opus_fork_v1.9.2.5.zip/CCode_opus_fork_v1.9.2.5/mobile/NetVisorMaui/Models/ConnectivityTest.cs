using System.Text.Json.Serialization;

namespace NetVisorMaui.Models;

/// <summary>
/// Risultato di POST /api/ping e POST /api/http-test.
/// ⚠️ NB: l'esecuzione è server-side (Flask) — il mobile NON pinga
/// localmente come da specifica utente: il test va delegato all'API.
/// </summary>
public class ConnectivityTest
{
    public string Target { get; set; } = string.Empty;

    /// <summary>"ping" | "http"</summary>
    public string Type { get; set; } = string.Empty;

    [JsonPropertyName("latency_ms")]
    public double? LatencyMs { get; set; }

    /// <summary>"success" | "failed" | "error"</summary>
    public string Result { get; set; } = string.Empty;

    public string? Details { get; set; }

    // ── UI helpers ───────────────────────────────────────────────────────
    [JsonIgnore]
    public bool IsSuccess => string.Equals(Result, "success", StringComparison.OrdinalIgnoreCase);

    [JsonIgnore]
    public string ResultColor => IsSuccess ? "#22C55E" : "#EF4444";

    [JsonIgnore]
    public string LatencyLabel => LatencyMs.HasValue
        ? $"{LatencyMs.Value:0.0} ms"
        : "n/a";
}
