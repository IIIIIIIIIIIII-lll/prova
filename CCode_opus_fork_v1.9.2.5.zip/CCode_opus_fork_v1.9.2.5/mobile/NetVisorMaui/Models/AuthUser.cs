using System.Text.Json.Serialization;

namespace NetVisorMaui.Models;

/// <summary>
/// Utente autenticato. Restituito da:
///   - POST /api/auth/login    (nel campo response.user)
///   - GET  /api/auth/me       (oggetto root)
///   - POST /api/auth/refresh  (nel campo response.user)
/// </summary>
public class AuthUser
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string? Email { get; set; }

    [JsonPropertyName("display_name")]
    public string? DisplayName { get; set; }

    /// <summary>"admin" | "user"</summary>
    public string Role { get; set; } = "user";

    [JsonPropertyName("is_active")]
    public bool IsActive { get; set; }

    [JsonPropertyName("must_change_password")]
    public bool MustChangePassword { get; set; }

    [JsonPropertyName("last_login_at")]
    public DateTime? LastLoginAt { get; set; }

    // ── UI helpers ───────────────────────────────────────────────────────
    [JsonIgnore]
    public string DisplayNameOrUsername =>
        string.IsNullOrWhiteSpace(DisplayName) ? Username : DisplayName!;

    [JsonIgnore]
    public bool IsAdmin => string.Equals(Role, "admin", StringComparison.OrdinalIgnoreCase);
}
