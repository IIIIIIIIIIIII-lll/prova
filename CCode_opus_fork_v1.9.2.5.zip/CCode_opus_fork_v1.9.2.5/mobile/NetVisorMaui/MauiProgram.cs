using Microsoft.Extensions.Logging;
using NetVisorMaui.Services;
using NetVisorMaui.ViewModels;
using NetVisorMaui.Views;

namespace NetVisorMaui;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();
        // NB: niente AddFont() — usiamo i font di sistema. Per aggiungere
        // OpenSans/Inter/altri, droppare i .ttf in Resources/Fonts e
        // referenziarli con ConfigureFonts(fonts => fonts.AddFont(...)).

        // ── Services (singleton — stato condiviso: session, baseUrl, cache) ──
        builder.Services.AddSingleton<ApiClient>();
        builder.Services.AddSingleton<AuthService>();
        builder.Services.AddSingleton<NodesService>();
        builder.Services.AddSingleton<AlertsService>();
        builder.Services.AddSingleton<TestsService>();
        builder.Services.AddSingleton<DashboardService>();

        // ── ViewModels (transient — istanza fresca ad ogni risoluzione) ─────
        builder.Services.AddTransient<LoginViewModel>();
        builder.Services.AddTransient<HomeViewModel>();
        builder.Services.AddTransient<NodesViewModel>();
        builder.Services.AddTransient<AlertsViewModel>();
        builder.Services.AddTransient<NodeDetailViewModel>();
        builder.Services.AddTransient<ConnectivityViewModel>();

        // ── Pages ───────────────────────────────────────────────────────────
        builder.Services.AddSingleton<AppShell>();
        builder.Services.AddTransient<LoginPage>();
        builder.Services.AddTransient<HomePage>();
        builder.Services.AddTransient<NodesPage>();
        builder.Services.AddTransient<AlertsPage>();
        builder.Services.AddTransient<NodeDetailPage>();
        builder.Services.AddTransient<ConnectivityPage>();

#if DEBUG
        builder.Logging.AddDebug();
#endif

        var app = builder.Build();
        ServiceHelper.Services = app.Services;
        return app;
    }
}
