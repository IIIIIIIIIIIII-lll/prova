namespace NetVisorMaui;

/// <summary>
/// Entry point Application. La <see cref="MainPage"/> iniziale è SEMPRE la
/// LoginPage: dentro la LoginPage il VM prova l'auto-login da SecureStorage,
/// e se la sessione è valida fa lui lo switch a <see cref="AppShell"/>.
/// </summary>
public partial class App : Application
{
    public App(Views.LoginPage loginPage)
    {
        InitializeComponent();
        MainPage = new NavigationPage(loginPage)
        {
            BarBackgroundColor = (Color)Resources["BgSurface"],
            BarTextColor = (Color)Resources["TextPrimary"],
        };
    }
}
