using System.Collections.ObjectModel;
using System.Windows.Input;
using NetVisorMaui.Models;
using NetVisorMaui.Services;

namespace NetVisorMaui.ViewModels;

/// <summary>
/// ViewModel della pagina Test connettività. Espone due input (target ping
/// e URL HTTP) e due comandi che delegano al backend Flask
/// (vincolo SPECIFICHE: "non eseguire localmente dal cellulare").
///
/// Mantiene uno storico dei test eseguiti nella sessione corrente
/// (in-memory, non persistente) per audit visivo immediato.
/// </summary>
public class ConnectivityViewModel : BaseViewModel
{
    private readonly TestsService _tests;
    private string _pingTarget = "8.8.8.8";
    private string _httpUrl = "https://example.com";
    private ConnectivityTest? _lastResult;

    public ConnectivityViewModel(TestsService tests)
    {
        _tests = tests;
        History = new ObservableCollection<ConnectivityTest>();
        PingCommand = new Command(async () => await RunAsync("ping"));
        HttpCommand = new Command(async () => await RunAsync("http"));
    }

    public string PingTarget
    {
        get => _pingTarget;
        set => SetProperty(ref _pingTarget, value);
    }

    public string HttpUrl
    {
        get => _httpUrl;
        set => SetProperty(ref _httpUrl, value);
    }

    public ConnectivityTest? LastResult
    {
        get => _lastResult;
        set
        {
            if (SetProperty(ref _lastResult, value))
            {
                OnPropertyChanged(nameof(HasResult));
            }
        }
    }

    public bool HasResult => _lastResult is not null;

    public ObservableCollection<ConnectivityTest> History { get; }

    public ICommand PingCommand { get; }
    public ICommand HttpCommand { get; }

    private async Task RunAsync(string kind)
    {
        await ExecuteSafeAsync(async () =>
        {
            ConnectivityTest? result;
            if (kind == "ping")
            {
                if (string.IsNullOrWhiteSpace(PingTarget))
                {
                    ErrorMessage = "Inserire un host/IP da pingare.";
                    return;
                }
                StatusMessage = $"Ping a {PingTarget} (server-side)…";
                result = await _tests.PingAsync(PingTarget.Trim());
            }
            else
            {
                if (string.IsNullOrWhiteSpace(HttpUrl))
                {
                    ErrorMessage = "Inserire una URL http(s).";
                    return;
                }
                StatusMessage = $"HTTP test su {HttpUrl} (server-side)…";
                result = await _tests.HttpTestAsync(HttpUrl.Trim());
            }

            if (result is null)
            {
                ErrorMessage = "Il backend non ha restituito un risultato.";
                return;
            }

            LastResult = result;
            History.Insert(0, result);
            // Mantieni gli ultimi 10 nella history.
            while (History.Count > 10) History.RemoveAt(History.Count - 1);

            StatusMessage = result.IsSuccess
                ? $"OK · {result.Type} · {result.LatencyLabel}"
                : $"Fallito · {result.Type} · {result.Details}";
        });
    }
}
