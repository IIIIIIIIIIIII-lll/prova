using System.Collections.ObjectModel;
using System.Windows.Input;
using NetVisorMaui.Models;
using NetVisorMaui.Services;

namespace NetVisorMaui.ViewModels;

/// <summary>
/// ViewModel della Dettaglio Nodo — carica in parallelo servizi e alert.
/// SPECIFICHE PROJECTWORK §3.E.5: stato, servizi, alert associati.
/// </summary>
public class NodeDetailViewModel : BaseViewModel
{
    private readonly NodesService _nodes;
    private int _nodeId;
    private Node? _node;

    public NodeDetailViewModel(NodesService nodes)
    {
        _nodes = nodes;
        Services = new ObservableCollection<ServiceItem>();
        Alerts = new ObservableCollection<Alert>();
        RefreshCommand = new Command(async () => await LoadAsync());
    }

    public int NodeId
    {
        get => _nodeId;
        set => SetProperty(ref _nodeId, value);
    }

    public Node? Node
    {
        get => _node;
        set
        {
            if (SetProperty(ref _node, value))
            {
                OnPropertyChanged(nameof(HasNode));
            }
        }
    }

    public bool HasNode => _node is not null;

    public ObservableCollection<ServiceItem> Services { get; }
    public ObservableCollection<Alert> Alerts { get; }

    public ICommand RefreshCommand { get; }

    /// <summary>
    /// Imposta il nodo direttamente quando la navigazione lo passa pre-caricato
    /// (evita un GET nodes/{id} aggiuntivo).
    /// </summary>
    public void SetNode(Node node)
    {
        Node = node;
        NodeId = node.Id;
    }

    public async Task LoadAsync()
    {
        if (NodeId <= 0) return;

        await ExecuteSafeAsync(async () =>
        {
            var servicesTask = _nodes.GetNodeServicesAsync(NodeId);
            var alertsTask = _nodes.GetNodeAlertsAsync(NodeId);
            await Task.WhenAll(servicesTask, alertsTask);

            Services.Clear();
            foreach (var s in await servicesTask) Services.Add(s);

            Alerts.Clear();
            foreach (var a in await alertsTask) Alerts.Add(a);

            StatusMessage = $"Servizi: {Services.Count} · Alert: {Alerts.Count}";
        }, loadingMessage: "Carico dettaglio nodo…");
    }
}
