using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace NetVisorMaui.ViewModels;

/// <summary>
/// Base MVVM con <see cref="INotifyPropertyChanged"/>, gestione busy/error/status
/// + helper <see cref="ExecuteSafeAsync"/> per centralizzare try/catch nelle
/// operazioni async delle ViewModels figlie.
///
/// Convenzioni:
///   IsBusy        → mostra spinner / disabilita pulsanti
///   StatusMessage → messaggio neutro/positivo ("Caricati 12 nodi.")
///   ErrorMessage  → messaggio rosso di errore. Mutualmente esclusivo con StatusMessage.
/// </summary>
public abstract class BaseViewModel : INotifyPropertyChanged
{
    private bool _isBusy;
    private string _statusMessage = string.Empty;
    private string _errorMessage = string.Empty;

    public event PropertyChangedEventHandler? PropertyChanged;

    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (SetProperty(ref _isBusy, value))
            {
                OnPropertyChanged(nameof(IsNotBusy));
            }
        }
    }

    public bool IsNotBusy => !_isBusy;

    public string StatusMessage
    {
        get => _statusMessage;
        set => SetProperty(ref _statusMessage, value);
    }

    public string ErrorMessage
    {
        get => _errorMessage;
        set
        {
            if (SetProperty(ref _errorMessage, value))
            {
                OnPropertyChanged(nameof(HasError));
            }
        }
    }

    public bool HasError => !string.IsNullOrWhiteSpace(_errorMessage);

    /// <summary>
    /// Helper che esegue un'azione async marcando IsBusy, catturando le
    /// eccezioni e popolando ErrorMessage con un testo umano. Le
    /// <see cref="Services.ApiException"/> portano già un messaggio italiano
    /// dal backend; le altre vengono mostrate con .Message.
    /// </summary>
    protected async Task ExecuteSafeAsync(Func<Task> action, string? loadingMessage = null)
    {
        if (IsBusy) return;
        IsBusy = true;
        ErrorMessage = string.Empty;
        if (!string.IsNullOrEmpty(loadingMessage)) StatusMessage = loadingMessage;
        try
        {
            await action();
        }
        catch (Services.ApiException apiEx)
        {
            ErrorMessage = apiEx.Message;
            StatusMessage = string.Empty;
        }
        catch (Exception ex)
        {
            ErrorMessage = "Errore inatteso: " + ex.Message;
            StatusMessage = string.Empty;
        }
        finally
        {
            IsBusy = false;
        }
    }

    protected bool SetProperty<T>(ref T backingField, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(backingField, value)) return false;
        backingField = value;
        OnPropertyChanged(propertyName);
        return true;
    }

    protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
