using System.Windows.Input;
using NetVisorMaui.Models;
using NetVisorMaui.Services;

namespace NetVisorMaui.ViewModels;

/// <summary>
/// ViewModel della Home — espone i KPI aggregati richiesti da SPECIFICHE
/// PROJECTWORK §3.E.1: totale nodi, online/offline, alert attivi.
/// </summary>
public class HomeViewModel : BaseViewModel
{
    private readonly DashboardService _dashboard;
    private readonly AuthService _auth;
    private DashboardSummary _summary = new();
    private string _greeting = "NetVisor";

    public HomeViewModel(DashboardService dashboard, AuthService auth)
    {
        _dashboard = dashboard;
        _auth = auth;
        RefreshCommand = new Command(async () => await LoadAsync());
    }

    public DashboardSummary Summary
    {
        get => _summary;
        set => SetProperty(ref _summary, value);
    }

    public string Greeting
    {
        get => _greeting;
        set => SetProperty(ref _greeting, value);
    }

    public ICommand RefreshCommand { get; }

    public async Task LoadAsync()
    {
        var user = _auth.GetCachedUser();
        Greeting = user is not null
            ? $"Ciao, {user.DisplayNameOrUsername}"
            : "NetVisor — NOSD";

        await ExecuteSafeAsync(async () =>
        {
            Summary = await _dashboard.GetSummaryAsync();
            StatusMessage = $"Dashboard aggiornata · {DateTime.Now:HH:mm:ss}";
        }, loadingMessage: "Aggiorno KPI…");
    }
}
