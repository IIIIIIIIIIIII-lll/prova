using System.Collections.ObjectModel;
using System.Windows.Input;
using NetVisorMaui.Models;
using NetVisorMaui.Services;

namespace NetVisorMaui.ViewModels;

/// <summary>
/// ViewModel pagina Alert — lista cronologica con filtro client-side per
/// severità (segments: All / Critical / High / Open).
///
/// SPECIFICHE PROJECTWORK §3.E.3: lista alert + severità + descrizione.
/// SPECIFICHE UTENTE: severità cromatica Giallo/Arancione/Rosso → gestita
/// nel binding XAML via <see cref="Alert.SeverityColor"/>.
/// </summary>
public class AlertsViewModel : BaseViewModel
{
    public enum SeverityFilter { All, OpenOnly, Critical, High }

    private readonly AlertsService _alerts;
    private readonly List<Alert> _all = new();
    private SeverityFilter _filter = SeverityFilter.All;

    public AlertsViewModel(AlertsService alerts)
    {
        _alerts = alerts;
        Alerts = new ObservableCollection<Alert>();
        RefreshCommand = new Command(async () => await LoadAsync());
        ShowAllCommand = new Command(() => Filter = SeverityFilter.All);
        ShowOpenCommand = new Command(() => Filter = SeverityFilter.OpenOnly);
        ShowCriticalCommand = new Command(() => Filter = SeverityFilter.Critical);
        ShowHighCommand = new Command(() => Filter = SeverityFilter.High);
    }

    public ObservableCollection<Alert> Alerts { get; }

    public SeverityFilter Filter
    {
        get => _filter;
        set
        {
            if (SetProperty(ref _filter, value))
            {
                ApplyFilter();
                OnPropertyChanged(nameof(IsFilterAll));
                OnPropertyChanged(nameof(IsFilterOpen));
                OnPropertyChanged(nameof(IsFilterCritical));
                OnPropertyChanged(nameof(IsFilterHigh));
            }
        }
    }

    public bool IsFilterAll => _filter == SeverityFilter.All;
    public bool IsFilterOpen => _filter == SeverityFilter.OpenOnly;
    public bool IsFilterCritical => _filter == SeverityFilter.Critical;
    public bool IsFilterHigh => _filter == SeverityFilter.High;

    public ICommand RefreshCommand { get; }
    public ICommand ShowAllCommand { get; }
    public ICommand ShowOpenCommand { get; }
    public ICommand ShowCriticalCommand { get; }
    public ICommand ShowHighCommand { get; }

    public async Task LoadAsync()
    {
        await ExecuteSafeAsync(async () =>
        {
            var alerts = await _alerts.GetAlertsAsync();
            _all.Clear();
            _all.AddRange(alerts);
            ApplyFilter();
            StatusMessage = $"Caricati {_all.Count} alert.";
        }, loadingMessage: "Carico alert…");
    }

    private void ApplyFilter()
    {
        Alerts.Clear();
        IEnumerable<Alert> filtered = _all;
        filtered = _filter switch
        {
            SeverityFilter.OpenOnly => _all.Where(a => a.IsOpen),
            SeverityFilter.Critical => _all.Where(a => string.Equals(a.Severity, "critical", StringComparison.OrdinalIgnoreCase)),
            SeverityFilter.High     => _all.Where(a => string.Equals(a.Severity, "high",     StringComparison.OrdinalIgnoreCase)),
            _                        => _all,
        };
        foreach (var a in filtered) Alerts.Add(a);
    }
}
