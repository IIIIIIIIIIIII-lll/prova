using System.Collections.ObjectModel;
using System.Windows.Input;
using NetVisorMaui.Models;
using NetVisorMaui.Services;

namespace NetVisorMaui.ViewModels;

/// <summary>
/// ViewModel pagina Nodi — lista con filtro testuale client-side.
/// Mostra hostname (con prefisso CTR_ per i container, evidenziato), IP, status.
/// </summary>
public class NodesViewModel : BaseViewModel
{
    private readonly NodesService _nodes;
    private readonly List<Node> _all = new();
    private string _filter = string.Empty;

    public NodesViewModel(NodesService nodes)
    {
        _nodes = nodes;
        Nodes = new ObservableCollection<Node>();
        RefreshCommand = new Command(async () => await LoadAsync());
        ClearFilterCommand = new Command(() => Filter = string.Empty);
    }

    public ObservableCollection<Node> Nodes { get; }

    public string Filter
    {
        get => _filter;
        set
        {
            if (SetProperty(ref _filter, value))
            {
                ApplyFilter();
            }
        }
    }

    public ICommand RefreshCommand { get; }
    public ICommand ClearFilterCommand { get; }

    public async Task LoadAsync()
    {
        await ExecuteSafeAsync(async () =>
        {
            var nodes = await _nodes.GetNodesAsync();
            _all.Clear();
            _all.AddRange(nodes);
            ApplyFilter();
            StatusMessage = $"Caricati {_all.Count} nodi.";
        }, loadingMessage: "Carico nodi…");
    }

    private void ApplyFilter()
    {
        Nodes.Clear();
        IEnumerable<Node> filtered = _all;
        if (!string.IsNullOrWhiteSpace(_filter))
        {
            var f = _filter.Trim();
            filtered = _all.Where(n =>
                (n.Hostname?.Contains(f, StringComparison.OrdinalIgnoreCase) ?? false) ||
                (n.Ip?.Contains(f, StringComparison.OrdinalIgnoreCase) ?? false) ||
                (n.Status?.Contains(f, StringComparison.OrdinalIgnoreCase) ?? false));
        }
        foreach (var n in filtered) Nodes.Add(n);
    }
}
