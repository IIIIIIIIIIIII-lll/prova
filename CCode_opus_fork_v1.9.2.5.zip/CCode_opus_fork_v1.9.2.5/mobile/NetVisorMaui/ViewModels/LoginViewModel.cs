using System.Windows.Input;
using NetVisorMaui.Models;
using NetVisorMaui.Services;

namespace NetVisorMaui.ViewModels;

/// <summary>
/// ViewModel della LoginPage. Espone Username/Password/BaseUrl + comando login,
/// e propaga il <see cref="LoginSucceeded"/> alla View per la navigazione.
///
/// Gestisce inoltre l'IDS hardened: se l'<see cref="ApiException.Lockout"/>
/// è popolato (warn/soft_lock/re_lock/disabled), <see cref="LockoutNotice"/>
/// contiene info dettagliate per popup escalation. La View è libera di
/// mostrare un DisplayAlert specifico.
/// </summary>
public class LoginViewModel : BaseViewModel
{
    private readonly AuthService _auth;
    private string _username = string.Empty;
    private string _password = string.Empty;
    private string _baseUrl = string.Empty;
    private LockoutInfo? _lockoutNotice;

    public LoginViewModel(AuthService auth)
    {
        _auth = auth;
        _baseUrl = _auth.GetBaseUrl();
        _username = _auth.GetLastUsername();   // pre-fill comodo, MAI la password
        LoginCommand = new Command(async () => await LoginAsync(), () => !IsBusy);
    }

    public event EventHandler<LoginResponse>? LoginSucceeded;

    public string Username
    {
        get => _username;
        set => SetProperty(ref _username, value);
    }

    public string Password
    {
        get => _password;
        set => SetProperty(ref _password, value);
    }

    public string BaseUrl
    {
        get => _baseUrl;
        set => SetProperty(ref _baseUrl, value);
    }

    public LockoutInfo? LockoutNotice
    {
        get => _lockoutNotice;
        set
        {
            if (SetProperty(ref _lockoutNotice, value))
            {
                OnPropertyChanged(nameof(HasLockoutNotice));
            }
        }
    }

    public bool HasLockoutNotice => _lockoutNotice is not null;

    public ICommand LoginCommand { get; }

    /// <summary>
    /// All'avvio prova a riprendere la sessione (se SecureStorage ha access
    /// token valido) senza chiedere credenziali. Se ok, scatena
    /// <see cref="LoginSucceeded"/> con un LoginResponse minimal contenente
    /// l'utente fresco dal /api/auth/me.
    /// </summary>
    public async Task<bool> TryAutoLoginAsync()
    {
        if (IsBusy) return false;
        IsBusy = true;
        try
        {
            StatusMessage = "Verifica sessione salvata…";
            var ok = await _auth.TryRestoreSessionAsync();
            if (!ok)
            {
                StatusMessage = "Inserire le credenziali per accedere.";
                return false;
            }
            var user = await _auth.GetCurrentUserAsync();
            if (user is null)
            {
                StatusMessage = "Sessione non disponibile.";
                return false;
            }
            LoginSucceeded?.Invoke(this, new LoginResponse { User = user });
            return true;
        }
        catch
        {
            StatusMessage = "Verifica sessione fallita: login necessario.";
            return false;
        }
        finally
        {
            IsBusy = false;
        }
    }

    public async Task LoginAsync()
    {
        if (IsBusy) return;

        // Validazione client minima — evita roundtrip inutili.
        if (string.IsNullOrWhiteSpace(Username))
        {
            ErrorMessage = "Inserire lo username.";
            return;
        }
        if (string.IsNullOrEmpty(Password))
        {
            ErrorMessage = "Inserire la password.";
            return;
        }
        if (string.IsNullOrWhiteSpace(BaseUrl))
        {
            ErrorMessage = "BaseUrl mancante. Esempio: http://10.0.2.2:5000";
            return;
        }

        IsBusy = true;
        ErrorMessage = string.Empty;
        LockoutNotice = null;

        try
        {
            _auth.SetBaseUrl(BaseUrl.Trim());
            StatusMessage = "Autenticazione in corso…";

            var response = await _auth.LoginAsync(Username.Trim(), Password);

            if (response.User.MustChangePassword)
            {
                StatusMessage = "Login OK. Aggiornare la password al più presto.";
            }
            else
            {
                StatusMessage = $"Bentornato {response.User.DisplayNameOrUsername}.";
            }

            // Pulizia campo password (mai persistito).
            Password = string.Empty;

            LoginSucceeded?.Invoke(this, response);
        }
        catch (ApiException apiEx)
        {
            ErrorMessage = apiEx.Message;
            StatusMessage = string.Empty;
            if (apiEx.Lockout is not null)
            {
                LockoutNotice = apiEx.Lockout;
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = "Errore inatteso: " + ex.Message;
            StatusMessage = string.Empty;
        }
        finally
        {
            IsBusy = false;
        }
    }
}
