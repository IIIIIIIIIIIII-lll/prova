using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using NetVisorMaui.Models;

namespace NetVisorMaui.Services;

/// <summary>
/// HTTP client centralizzato per il backend Flask NetVisor.
///
/// ## Sicurezza
/// - Bearer JWT iniettato in ogni richiesta autenticata da SecureStorage
///   (KeyStore Android / Keychain iOS). Mai loggato.
/// - Refresh token rotato lato server: alla 401 facciamo UNA volta sola un
///   POST /api/auth/refresh; se fallisce, ripuliamo la sessione locale.
/// - Timeout 15 s di default (configurable via <see cref="Constants.HttpTimeout"/>):
///   evita app freeze in caso di rete down o backend hung.
///
/// ## Envelope
/// Tutte le response Flask hanno forma {success, data, error, _meta}.
/// Vedi <see cref="ApiEnvelope{T}"/>. Sui 2xx ritorniamo <c>Data</c>,
/// su tutto il resto lanciamo <see cref="ApiException"/> con il campo
/// <c>error</c> del JSON quando presente (così la UI mostra messaggi
/// human-friendly italiani invece di "InternalServerError").
///
/// ## Base URL dinamico
/// Cambiabile a runtime dalla schermata di Login senza ricompilare. Vedi
/// <see cref="GetBaseUrl"/> / <see cref="SetBaseUrl"/>. Persiste in
/// <see cref="Preferences"/>.
/// </summary>
public class ApiClient
{
    private readonly HttpClient _http;
    private readonly JsonSerializerOptions _json;
    private readonly SemaphoreSlim _refreshLock = new(1, 1);

    public ApiClient()
    {
        _http = new HttpClient
        {
            Timeout = Constants.HttpTimeout,
        };

        // ⚠️ IMPORTANTE: Flask serializza in snake_case (access_token,
        // refresh_token, last_seen, …). Senza SnakeCaseLower i [JsonPropertyName]
        // sui Models lavorerebbero comunque ma il refactor sarebbe meno
        // robusto. Usiamo entrambi per cintura+bretelle.
        _json = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
            PropertyNameCaseInsensitive = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        };
    }

    // ── Base URL management ──────────────────────────────────────────────
    public string GetBaseUrl()
    {
        var stored = Preferences.Default.Get(Constants.StorageKeys.BaseUrl, string.Empty);
        if (!string.IsNullOrWhiteSpace(stored)) return stored.TrimEnd('/');

        // Default per piattaforma: solo Android emulatore ha bisogno del 10.0.2.2
        return DeviceInfo.Platform == DevicePlatform.Android
            ? Constants.DefaultBaseUrlAndroid
            : DeviceInfo.Platform == DevicePlatform.iOS
                ? Constants.DefaultBaseUrlIos
                : Constants.DefaultBaseUrlWindows;
    }

    public void SetBaseUrl(string? baseUrl)
    {
        if (string.IsNullOrWhiteSpace(baseUrl)) return;
        // Normalizziamo: niente trailing slash, niente whitespace.
        Preferences.Default.Set(Constants.StorageKeys.BaseUrl, baseUrl.Trim().TrimEnd('/'));
    }

    // ── Session management ───────────────────────────────────────────────
    public async Task<bool> HasStoredSessionAsync()
    {
        try
        {
            var access = await SecureStorage.Default.GetAsync(Constants.StorageKeys.AccessToken);
            return !string.IsNullOrWhiteSpace(access);
        }
        catch
        {
            return false;
        }
    }

    public async Task PersistSessionAsync(LoginResponse response)
    {
        await SecureStorage.Default.SetAsync(Constants.StorageKeys.AccessToken, response.AccessToken);
        await SecureStorage.Default.SetAsync(Constants.StorageKeys.RefreshToken, response.RefreshToken);
        Preferences.Default.Set(
            Constants.StorageKeys.CurrentUser,
            JsonSerializer.Serialize(response.User, _json));
        if (!string.IsNullOrWhiteSpace(response.User?.Username))
        {
            Preferences.Default.Set(Constants.StorageKeys.LastUsername, response.User!.Username);
        }
    }

    public Task ClearSessionAsync()
    {
        SecureStorage.Default.Remove(Constants.StorageKeys.AccessToken);
        SecureStorage.Default.Remove(Constants.StorageKeys.RefreshToken);
        Preferences.Default.Remove(Constants.StorageKeys.CurrentUser);
        return Task.CompletedTask;
    }

    public AuthUser? GetCachedUser()
    {
        var json = Preferences.Default.Get(Constants.StorageKeys.CurrentUser, string.Empty);
        if (string.IsNullOrWhiteSpace(json)) return null;
        try { return JsonSerializer.Deserialize<AuthUser>(json, _json); }
        catch { return null; }
    }

    public string GetLastUsername() => Preferences.Default.Get(Constants.StorageKeys.LastUsername, string.Empty);

    // ── Public HTTP API ──────────────────────────────────────────────────
    public Task<T?> GetAsync<T>(string path, bool requireAuth = true)
        => SendAsync<T>(HttpMethod.Get, path, body: null, requireAuth);

    public Task<T?> PostAsync<T>(string path, object? body, bool requireAuth = true)
        => SendAsync<T>(HttpMethod.Post, path, body, requireAuth);

    public Task<T?> PatchAsync<T>(string path, object? body, bool requireAuth = true)
        => SendAsync<T>(new HttpMethod("PATCH"), path, body, requireAuth);

    public Task<T?> DeleteAsync<T>(string path, bool requireAuth = true)
        => SendAsync<T>(HttpMethod.Delete, path, body: null, requireAuth);

    // ── Core send pipeline ───────────────────────────────────────────────
    private async Task<T?> SendAsync<T>(HttpMethod method, string path, object? body, bool requireAuth, bool isRetry = false)
    {
        using var request = await BuildRequestAsync(method, path, body, requireAuth);

        HttpResponseMessage response;
        try
        {
            response = await _http.SendAsync(request);
        }
        catch (TaskCanceledException tcex)
        {
            throw new ApiException("Timeout: il backend non risponde entro " +
                $"{Constants.HttpTimeout.TotalSeconds:0}s. Verifica BaseUrl e rete.", tcex);
        }
        catch (HttpRequestException hrex)
        {
            throw new ApiException(
                $"Connessione fallita verso {GetBaseUrl()}. " +
                "Backend offline, IP errato o firewall? Dettagli: " + hrex.Message, hrex);
        }

        // Refresh-and-retry su 401, una volta sola, mai per la stessa /refresh
        if (response.StatusCode == HttpStatusCode.Unauthorized
            && requireAuth && !isRetry
            && !path.EndsWith("/refresh", StringComparison.OrdinalIgnoreCase))
        {
            response.Dispose();
            if (await TryRefreshTokenAsync())
            {
                return await SendAsync<T>(method, path, body, requireAuth, isRetry: true);
            }
        }

        return await ReadEnvelopeAsync<T>(response);
    }

    private async Task<HttpRequestMessage> BuildRequestAsync(HttpMethod method, string path, object? body, bool requireAuth)
    {
        // Costruiamo URL assoluto per evitare race condition su BaseAddress
        // condivisa nel singleton HttpClient.
        var url = $"{GetBaseUrl()}{path}";
        var req = new HttpRequestMessage(method, url);

        if (requireAuth)
        {
            var token = await SecureStorage.Default.GetAsync(Constants.StorageKeys.AccessToken);
            if (!string.IsNullOrWhiteSpace(token))
            {
                req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
        }

        if (body is not null)
        {
            var json = JsonSerializer.Serialize(body, _json);
            req.Content = new StringContent(json, Encoding.UTF8, "application/json");
        }

        return req;
    }

    private async Task<T?> ReadEnvelopeAsync<T>(HttpResponseMessage response)
    {
        // Leggiamo SEMPRE il body — anche sulle 4xx contiene il campo "error"
        // umano italiano dal backend (utils/responses.py:error_response).
        string raw;
        try { raw = await response.Content.ReadAsStringAsync(); }
        catch { raw = string.Empty; }
        finally { response.Dispose(); }

        if (string.IsNullOrWhiteSpace(raw))
        {
            if (response.IsSuccessStatusCode) return default;
            throw new ApiException(
                $"Risposta vuota dal server (HTTP {(int)response.StatusCode} {response.ReasonPhrase}).");
        }

        ApiEnvelope<T>? envelope = null;
        try
        {
            envelope = JsonSerializer.Deserialize<ApiEnvelope<T>>(raw, _json);
        }
        catch (JsonException)
        {
            // Backend ha ritornato qualcosa di non-JSON (es. proxy nginx error page).
            // Mostriamo il body come errore tecnico per troubleshooting LAB.
            throw new ApiException(
                $"Risposta non-JSON dal server (HTTP {(int)response.StatusCode}): " +
                raw.Substring(0, Math.Min(raw.Length, 300)));
        }

        if (envelope is null)
        {
            throw new ApiException($"Envelope mancante (HTTP {(int)response.StatusCode}).");
        }

        if (!response.IsSuccessStatusCode || envelope.Success == false)
        {
            var msg = envelope.Error ?? $"HTTP {(int)response.StatusCode} {response.ReasonPhrase}";
            throw new ApiException(msg, statusCode: response.StatusCode, lockout: envelope.Lockout);
        }

        return envelope.Data;
    }

    // ── Refresh token rotation ──────────────────────────────────────────
    private async Task<bool> TryRefreshTokenAsync()
    {
        // Lock per evitare refresh paralleli da più chiamate concorrenti.
        await _refreshLock.WaitAsync();
        try
        {
            var refreshToken = await SecureStorage.Default.GetAsync(Constants.StorageKeys.RefreshToken);
            if (string.IsNullOrWhiteSpace(refreshToken))
            {
                await ClearSessionAsync();
                return false;
            }

            try
            {
                var refreshed = await SendAsync<LoginResponse>(
                    HttpMethod.Post,
                    Constants.Endpoints.Refresh,
                    new { refresh_token = refreshToken },
                    requireAuth: false,
                    isRetry: true); // isRetry=true → no ricorsione infinita

                if (refreshed is null || string.IsNullOrEmpty(refreshed.AccessToken))
                {
                    await ClearSessionAsync();
                    return false;
                }

                await PersistSessionAsync(refreshed);
                return true;
            }
            catch (ApiException)
            {
                await ClearSessionAsync();
                return false;
            }
        }
        finally
        {
            _refreshLock.Release();
        }
    }
}

/// <summary>
/// Eccezione applicativa lanciata dall'<see cref="ApiClient"/>.
/// <see cref="Message"/> è già pronto per la UI (testo italiano umano).
/// <see cref="Lockout"/> è popolato dall'IDS hardened backend al 3°/4°/5°/6°
/// fallimento login per scatenare il popup escalation lato app.
/// </summary>
public class ApiException : Exception
{
    public HttpStatusCode? StatusCode { get; }
    public LockoutInfo? Lockout { get; }

    public ApiException(string message, Exception? inner = null,
                        HttpStatusCode? statusCode = null, LockoutInfo? lockout = null)
        : base(message, inner)
    {
        StatusCode = statusCode;
        Lockout = lockout;
    }
}
