using NetVisorMaui.Models;

namespace NetVisorMaui.Services;

/// <summary>
/// Servizio Nodi — consuma /api/nodes e i sub-endpoint per services/alerts.
/// È l'unica via di accesso al dominio nodi: VIETATO accedere al DB SQL
/// direttamente come da SPECIFICHE PROJECTWORK §3.E "Requisiti tecnici mobile".
/// </summary>
public class NodesService
{
    private readonly ApiClient _api;

    public NodesService(ApiClient api)
    {
        _api = api;
    }

    /// <summary>GET /api/nodes — lista completa, ordinata per IP lato server.</summary>
    public async Task<List<Node>> GetNodesAsync()
        => await _api.GetAsync<List<Node>>(Constants.Endpoints.Nodes) ?? new();

    /// <summary>GET /api/nodes/{id}/services — porte/servizi rilevati.</summary>
    public async Task<List<ServiceItem>> GetNodeServicesAsync(int nodeId)
        => await _api.GetAsync<List<ServiceItem>>(Constants.Endpoints.NodeServices(nodeId)) ?? new();

    /// <summary>GET /api/nodes/{id}/alerts — alert specifici del nodo.</summary>
    public async Task<List<Alert>> GetNodeAlertsAsync(int nodeId)
        => await _api.GetAsync<List<Alert>>(Constants.Endpoints.NodeAlerts(nodeId)) ?? new();
}
