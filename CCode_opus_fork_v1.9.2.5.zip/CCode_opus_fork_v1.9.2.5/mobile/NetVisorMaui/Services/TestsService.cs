using NetVisorMaui.Models;

namespace NetVisorMaui.Services;

/// <summary>
/// Servizio Test Connettività — invoca SEMPRE le API Flask, MAI esegue
/// ping/HTTP localmente dal cellulare (SPECIFICHE PROJECTWORK §3.E.4 +
/// vincolo esplicito utente: "l'azione deve essere delegata alle API
/// Flask, non eseguita localmente dal cellulare").
///
/// Vantaggi del delegare server-side:
///   - il PC ha accesso a tutta la rete aziendale, il cellulare no
///   - audit centralizzato (Tests table) sul backend
///   - bypass policy Android che limita ping ICMP da userspace
/// </summary>
public class TestsService
{
    private readonly ApiClient _api;
    public TestsService(ApiClient api) { _api = api; }

    /// <summary>POST /api/ping {target}</summary>
    public Task<ConnectivityTest?> PingAsync(string target)
        => _api.PostAsync<ConnectivityTest>(Constants.Endpoints.Ping, new { target });

    /// <summary>POST /api/http-test {url}</summary>
    public Task<ConnectivityTest?> HttpTestAsync(string url)
        => _api.PostAsync<ConnectivityTest>(Constants.Endpoints.HttpTest, new { url });
}
