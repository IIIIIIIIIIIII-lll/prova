using NetVisorMaui.Models;

namespace NetVisorMaui.Services;

/// <summary>
/// Servizio aggregato per la Home — calcola i KPI richiesti dalle
/// SPECIFICHE PROJECTWORK §3.E.1 (totale nodi, online/offline, alert attivi)
/// a partire da /api/nodes + /api/alerts.
///
/// L'aggregazione è client-side per evitare di toccare il backend (la
/// dashboard web richiama endpoint diversi /api/dashboard/operations
/// con payload più ricco e diverso schema). Per il mobile è sufficiente
/// fare 2 GET piccoli in parallelo.
/// </summary>
public class DashboardService
{
    private readonly NodesService _nodes;
    private readonly AlertsService _alerts;

    public DashboardService(NodesService nodes, AlertsService alerts)
    {
        _nodes = nodes;
        _alerts = alerts;
    }

    public async Task<DashboardSummary> GetSummaryAsync()
    {
        // Parallel fetch — i due endpoint sono indipendenti.
        var nodesTask = _nodes.GetNodesAsync();
        var alertsTask = _alerts.GetAlertsAsync();
        await Task.WhenAll(nodesTask, alertsTask);

        var nodes = await nodesTask;
        var alerts = await alertsTask;

        return new DashboardSummary
        {
            TotalNodes      = nodes.Count,
            OnlineNodes     = nodes.Count(n => string.Equals(n.Status, "online",  StringComparison.OrdinalIgnoreCase)),
            OfflineNodes    = nodes.Count(n => string.Equals(n.Status, "offline", StringComparison.OrdinalIgnoreCase)),
            UnknownNodes    = nodes.Count(n => !string.Equals(n.Status, "online",  StringComparison.OrdinalIgnoreCase)
                                            && !string.Equals(n.Status, "offline", StringComparison.OrdinalIgnoreCase)),
            ContainerNodes  = nodes.Count(n => n.IsContainer),
            // "Alert attivi" = open + ack (non risolti). 'deleted' è già escluso lato server.
            OpenAlerts      = alerts.Count(a =>
                                   string.Equals(a.Status, "open", StringComparison.OrdinalIgnoreCase)
                                || string.Equals(a.Status, "ack",  StringComparison.OrdinalIgnoreCase)),
            CriticalAlerts  = alerts.Count(a => string.Equals(a.Severity, "critical", StringComparison.OrdinalIgnoreCase)),
            HighAlerts      = alerts.Count(a => string.Equals(a.Severity, "high",     StringComparison.OrdinalIgnoreCase)),
        };
    }
}
