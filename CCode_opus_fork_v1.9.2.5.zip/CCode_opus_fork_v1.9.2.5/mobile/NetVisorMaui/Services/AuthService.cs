using NetVisorMaui.Models;

namespace NetVisorMaui.Services;

/// <summary>
/// Wrapper di alto livello su <see cref="ApiClient"/> per il flusso di
/// autenticazione. Espone i metodi usati dalle ViewModel (Login/Logout/Me)
/// e centralizza la gestione di errori IDS (lockout escalation).
///
/// La policy hardened del backend (vedi services/auth_service.py) è:
///   3° fail   → warn        (HTTP 401, lockout.state="warn")
///   4° fail   → soft_lock   (HTTP 401, lockout.state="soft_lock", lock_minutes)
///   5° fail   → re_lock     (HTTP 401, lockout.state="re_lock")
///   6° fail   → disabled    (HTTP 401, lockout.state="disabled")
/// Il LoginViewModel mostra popup specifico in base a questo campo.
/// </summary>
public class AuthService
{
    private readonly ApiClient _api;

    public AuthService(ApiClient api)
    {
        _api = api;
    }

    // ── BaseUrl proxy ─────────────────────────────────────────────────────
    public string GetBaseUrl() => _api.GetBaseUrl();
    public void SetBaseUrl(string? baseUrl) => _api.SetBaseUrl(baseUrl);

    // ── Session state ─────────────────────────────────────────────────────
    public Task<bool> HasStoredSessionAsync() => _api.HasStoredSessionAsync();
    public AuthUser? GetCachedUser() => _api.GetCachedUser();
    public string GetLastUsername() => _api.GetLastUsername();

    /// <summary>
    /// POST /api/auth/login. Persiste token + user su success.
    /// In caso di fallimento lancia <see cref="ApiException"/> con
    /// <see cref="ApiException.Lockout"/> popolato se l'IDS è scattato.
    /// </summary>
    public async Task<LoginResponse> LoginAsync(string username, string password)
    {
        var response = await _api.PostAsync<LoginResponse>(
            Constants.Endpoints.Login,
            new LoginRequest { Username = username, Password = password },
            requireAuth: false);

        if (response is null || string.IsNullOrEmpty(response.AccessToken))
        {
            throw new ApiException("Risposta login vuota dal server.");
        }

        await _api.PersistSessionAsync(response);
        return response;
    }

    /// <summary>GET /api/auth/me — verifica sessione e ritorna l'utente.</summary>
    public Task<AuthUser?> GetCurrentUserAsync() =>
        _api.GetAsync<AuthUser>(Constants.Endpoints.Me);

    /// <summary>
    /// All'avvio prova a ripristinare la sessione: se il token è ancora valido
    /// (o si refresha automaticamente), evitiamo di rimandare alla login.
    /// </summary>
    public async Task<bool> TryRestoreSessionAsync()
    {
        if (!await _api.HasStoredSessionAsync()) return false;

        try
        {
            var user = await GetCurrentUserAsync();
            return user is not null;
        }
        catch
        {
            await _api.ClearSessionAsync();
            return false;
        }
    }

    /// <summary>POST /api/auth/logout — best effort, sempre ripulisce locale.</summary>
    public async Task LogoutAsync()
    {
        try
        {
            await _api.PostAsync<object>(
                Constants.Endpoints.Logout,
                new { refresh_token = (string?)null });
        }
        catch
        {
            // logout best-effort: anche se il server non risponde, ripuliamo locale.
        }
        finally
        {
            await _api.ClearSessionAsync();
        }
    }
}
