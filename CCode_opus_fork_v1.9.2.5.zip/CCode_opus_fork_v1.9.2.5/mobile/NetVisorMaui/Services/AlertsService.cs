using NetVisorMaui.Models;

namespace NetVisorMaui.Services;

/// <summary>
/// Servizio Alert — consuma /api/alerts (joined con Nodes per hostname/ip).
/// Il backend ordina già DESC per id; noi opzionalmente ri-ordiniamo per
/// severity in UI per dare priorità visiva ai critical/high.
/// </summary>
public class AlertsService
{
    private readonly ApiClient _api;
    public AlertsService(ApiClient api) { _api = api; }

    /// <summary>
    /// GET /api/alerts — non include i soft-deleted (status='deleted').
    /// Per SPECIFICHE PROJECTWORK §3.E.3 mostriamo lista cronologica con
    /// severità cromatica: il sort cronologico è già fatto dal backend.
    /// </summary>
    public async Task<List<Alert>> GetAlertsAsync()
        => await _api.GetAsync<List<Alert>>(Constants.Endpoints.Alerts) ?? new();
}
