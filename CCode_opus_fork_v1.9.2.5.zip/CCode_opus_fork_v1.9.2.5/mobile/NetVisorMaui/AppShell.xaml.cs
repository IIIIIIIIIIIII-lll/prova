using NetVisorMaui.Services;
using NetVisorMaui.Views;

namespace NetVisorMaui;

/// <summary>
/// Shell principale dell'app post-login. Registra la rotta extra per
/// <see cref="NodeDetailPage"/> (raggiungibile via Shell.Current.GoToAsync)
/// e gestisce il pulsante Logout in alto a destra.
/// </summary>
public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
        // Pagine non in tab bar — registrate per la navigation stack.
        Routing.RegisterRoute(nameof(NodeDetailPage), typeof(NodeDetailPage));
    }

    private async void OnLogoutClicked(object? sender, EventArgs e)
    {
        var confirm = await DisplayAlert("Conferma logout",
            "Vuoi disconnetterti? Il token verrà rimosso da SecureStorage.",
            "Esci", "Annulla");
        if (!confirm) return;

        var auth = ServiceHelper.GetService<AuthService>();
        await auth.LogoutAsync();

        // Torna alla LoginPage. Risolto da DI così tutti i binding/event subscriber
        // ripartono freschi (no stale references al precedente utente).
        if (Application.Current is not null)
        {
            Application.Current.MainPage = new NavigationPage(ServiceHelper.GetService<LoginPage>())
            {
                BarBackgroundColor = (Color)Application.Current.Resources["BgSurface"],
                BarTextColor = (Color)Application.Current.Resources["TextPrimary"],
            };
        }
    }
}
