# NetVisor Changelog

Tutte le modifiche significative al progetto sono tracciate qui in formato
[Keep a Changelog](https://keepachangelog.com/it/1.1.0/) e versionate secondo
[Semantic Versioning 2.0.0](https://semver.org/lang/it/).

Convenzione: `MAJOR.MINOR.PATCH`
- **MAJOR** = breaking change API/schema DB/CSS classes pubbliche
- **MINOR** = nuova feature backward-compatible
- **PATCH** = bug fix, ottimizzazioni, refactor interno

Il file `VERSION` nella root del repo contiene la versione attiva ed è letto
da `backend/app.py` (esposta via `/api/system/info`) e dal frontend
(mostrata nel chip in topbar).

---

## [1.0.2] — 2026-05-09

Refactoring critico UI/UX e fix sicurezza richiesti da PDF Errori_v4.2.
Backward-compatible al 100% — nessuna breaking change pubblica.

### Fixed (CRITICAL)
- **HTTP 500 su cambio password** (`/api/auth/change-password`): la
  `validate_password_policy` lanciava `ValueError` non catturato dal route
  handler che gestiva solo `ValidationError`. Risultato: ogni password che
  violava la policy (no simbolo, troppo corta, contiene username, ecc.)
  generava un 500 generico invece di un 400 con messaggio specifico.
  Fix: `validate_password_policy` ora lancia `ValidationError`
  (subclass di `ValueError`, retro-compat con `generate_temporary_password`).

### Added
- **IDS estesa per password change failures** (PDF §2.2): la state machine
  `_handle_failed_login` viene ora invocata anche dal `change_password()` quando
  la `current_password` è errata. Soglie 3/4/5/6 → warn/soft_lock/re_lock/disabled
  con alert MEDIUM/HIGH/HIGH/CRITICAL e popup escalation in `settings.js`.
- **Topology naming CTR_** (PDF §1.1): rinominati i parent docker container con
  prefisso univoco (CTR_frontend-1, CTR_backend-1, CTR_sqlserver-1,
  CTR_scan-worker-1) per distinguere container reali da gruppi logici.
- **Storage Volumes come Storage Nodes** (PDF §1.3): aggiunti
  `vol-scan-output` e `vol-sqlserver-data` come kind=`storage_volume`,
  rendering a cilindro (drawCylinder) collegati ai container con linee
  tratteggiate grigie (`type=volume_mount`, `protocol=volume`).
- **Drill-down 3 livelli con breadcrumb** (PDF §1.2): drillStack accumula
  la genealogia L1→L2→L3 (es. "CTR_Backend ›  Node_172.23.0.4 ›  SSH:22").
  Il back button pop-pa un livello alla volta invece di saltare all'overview.
- **Legenda Statica overlay** (PDF §1.5): box flottante in alto a destra del
  topology canvas con pallini colore per ogni protocollo
  (HTTP, HTTPS, SSH, RDP, SMB, MSSQL, IPv4, TCP, UDP, ICMP, volume).
- **Edge width = volume/throughput** (PDF §1.6): aggregazione
  `(from,to,protocol)` nei flows, larghezza linea = `2+log2(1+count)*1.4`
  con cap a `_MAX_FLOW_WIDTH=8` per evitare overlapping.
- **Filtro semantico Events vs Alerts** (PDF §3): `renderRailAlerts` mostra
  solo anomalie/fallimenti (severity≥warning OR status=failed);
  `renderRailEvents` mostra solo info/success.
- **Global Search live** (PDF §4.3): listener su `topbarSearchInput` filtra in
  realtime tutti i `<tr>` delle tabelle visibili (debounce 120ms).
- **Login session box** (PDF §2.3): box "Username: nome | Ruolo: ruolo |
  Stato: stato" formattato con label/value/separator esplicito invece
  del precedente "**forema**Username" attaccato.

### Changed
- **Chip LIVE spaziatura** (PDF §4.1): "LIVE v1.0.1" con gap 0.55rem fra
  label e version-pill, e version-pill stilizzata con background distinto.
- **Dropdown range temporale** (PDF §4.2): rinominate opzioni
  "Last X" → "Ultimi X" / "Ultima ora" / "Ultime 24 ore" / "Ultimi 7 giorni"
  con tooltip esplicativo.
- **Filtro Both direzionale** (PDF §1.4): refactor di `flowVisible()` —
  drawFlows ora usa il filtro centrale invece del proprio filtro locale che
  ignorava la direction. Semantica corretta: con anchor selezionato,
  Both = flussi che TOCCANO l'anchor (in OR out); senza anchor =  no filter.
- **Edge color = protocol esclusivo** (PDF §1.5): rimossa qualsiasi override
  per active/selected che alterasse il colore base. Volume mount: grigio
  fisso (#94a3b8). Tutti gli altri: lookup `FLOW_COLORS[protocol]`.
- **Active menu pulse spegnimento** (PDF §4.5): quando una card è
  selezionata, il pulse verde sui badge degli altri card si spegne
  (`.topology-cards.has-selection .topology-card:not(.topology-card-active)`).
- **Quick Connection Test grid** (PDF §4.4): 12-col grid 8/4 split
  (`#tab-availability .hero-band` → `2fr 1fr`), form-grid interno limitato
  a 2 colonne per evitare schiacciamento della tabella sotto.

---

## [1.0.1] — 2026-05-09

Release post-deploy che chiude i punti aperti dei PDF Errori_v2 (image) ed
Errori_v3. Nessuna breaking change pubblica — backward-compatible al 100%.

### Added
- **Scanner UDP** (`-sU`): nuovo parametro `protocol=udp` accettato da `/api/scans/manual`,
  `/api/scan-jobs` e `/api/scan-jobs/{id}/run`. Selector `tcp`/`udp` in scan-jobs.html.
  In container non-root genera errore user-friendly (raw socket non disponibili).
- **Scanner aggressive mode** (NSE/CVE): nuova modalità `aggressive` che aggiunge
  `--script default,vuln,safe` al comando nmap. Estrazione automatica delle
  CVE references nel `parser_nmap.py` (regex su output e tabelle annidate).
  UI: nuova colonna "Sec. Scripts / CVE" nella host detail con badge cliccabili.
- **Topology direction filter**: selector IN/OUT/BOTH in topology toolbar.
  Filtra i flussi rispetto al nodo selezionato (priorità) o al focus drill-down.
  Il filtro è client-side (no rifetch), live nel rendering loop.
- **Alert state machine** (open→ack→closed→deleted) con enforcement SQL.
  Endpoint nuovi: `DELETE /api/alerts/{id}` (soft-delete, status='deleted'),
  `GET /api/alerts/deleted` (lista Deleted Tasks per audit).
  Nuovi campi DB: `Alerts.acked_at`, `Alerts.closed_at`, `Alerts.deleted_at`
  (migration idempotente in `db.py`).
- **Alert Queue UI overhaul**: pulsante Delete con popup conferma + popup
  blocco se prematuro. Colonna Date nella tabella, filtro date con formati
  `YYYY-MM-DD | today | yesterday | Nd`. Nuovo pannello "Deleted Tasks".
- **Login lockout policy escalation**: 3 tentativi → MEDIUM warn, 4° → HIGH +
  10min lock, 5° → HIGH + relock, 6° → CRITICAL + DISABLE permanente.
  Backend: `auth_service._handle_failed_login` con state machine.
  Frontend: popup specifici per ogni stato (vedi `login.js:showLockoutPopup`).
  AuthError ora porta `lockout` dict serializzato nella response API.
- **Reports cleanup**: tooltip esplicativi su tutti i KPI (Active/Inactive Nodes,
  Open Services, Blocked, Suspicious). Manual Scan: protocol selector tcp/udp,
  mode aggressive, preset porte (Common/Web/DB/Remote-admin).
- **Agent visibility**: info panel introduttivo in agents.html che spiega il
  sottosistema telemetry come canale reale (no scena), tooltip su tutti i KPI
  e su Resource Pressure.
- **HTTP test resilient** (`connectivity_service.http_test`): catch esplicito di
  ConnectionError/Timeout/RequestException, auto-prefix `http://` se manca lo
  schema. Il risultato viene SEMPRE salvato in `Tests` table — niente 500
  silenziosi che perdono l'esito del test.

### Changed
- **`scan_failed` severity**: da `medium` → `info`. Allineamento con NIST SP 800-92
  e ECS: scan failure è evento operativo, non minaccia di sicurezza. Riduce
  drasticamente il flood nella coda alert.
- **`scan_failed.node_id`**: best-effort lookup dal target dello scan (era sempre
  null). Migliora il drill-down dalla coda alert al nodo coinvolto.
- **`/api/system/info`** ora **pubblico** (era 401 per dimenticanza in
  `_is_public_endpoint`). Necessario per il banner versione pre-login.
- **JSON datetime serializer** (`IsoJSONProvider` in `app.py`): emette ISO 8601
  UTC con suffix `Z` invece di RFC 1123 (`Sat, 09 May 2026 00:00:00 GMT`).
  Correlato fix nel frontend `_toDate` come defense-in-depth.

### Fixed
- **`db.py` truncated**: ripristinate `_connect()`, `get_connection()`,
  `initialize_database()` accidentalmente rimosse durante la pulizia v1.0.0.
- **ODBC driver mismatch**: connection string ora usa `ODBC Driver 18 for SQL Server`
  (Dockerfile installa msodbcsql18). Allineato.
- **`_run_nmap` / `_run_masscan` not defined**: ripristinate funzioni accidentalmente
  rimosse insieme a `_demo_scan`. Aggiunto `_build_nmap_command` helper DRY tra
  single/multi target con supporto protocol+mode.
- **`_run_nmap_multi` mode**: ora accetta e propaga `mode="aggressive"` per scansioni
  multi-target con NSE.
- **`tendina Mode demo`** in `reports.html`: rimossa definitivamente l'opzione
  `demo` (residuo v1.0.0). Sostituita con `aggressive`.

### Notes operative
- UDP/SYN scan in container non-root: il `setcap cap_net_raw` ha effetto
  collaterale di attivare ld.so secure-execution mode che rompe nmap completamente
  con read_only filesystem. Per ora l'errore "Operation not permitted" viene
  intercettato e tradotto in messaggio user-friendly. Per UDP abilitato in
  produzione, usare immagine custom con `USER root` o privileged container.

---

## [1.0.0] — 2026-05-08

Prima release stabile **LIVE-only**: rimossa completamente la funzionalità
demo / dati sintetici.

### Removed (BREAKING)
- **Demo mode**: variabili env `NETVISOR_DEMO_MODE`, `NETVISOR_DEMO_SEED`,
  `ENABLE_REAL_SCAN` — eliminate. Da ora il backend è **esclusivamente LIVE**:
  nessuna scansione emulata, nessun seed sintetico, nessun residuo da pulire.
- **Funzioni rimosse** in backend: `count_demo_residue()`, `purge_demo_data()`,
  `_demo_scan()`, `_demo_combined()`, `_build_demo_flows()`,
  `_resolve_demo_mode()`, `Settings.mode_label()`, `Settings.demo_mode`,
  `Settings.demo_seed`, `Settings.enable_real_scan`.
- **Endpoint rimossi**: `POST /api/admin/demo/purge`, `GET /api/system/mode`.
- **Modal "Esegui purge"** nel banner UI — non serve più.
- **Banner DEMO MODE** giallo — sempre LIVE, l'app non ha più modalità
  ambigue.
- `_meta.demo` rimosso dalle risposte API (resta solo `_meta.mode = "live"`
  e `_meta.ts`).

### Added
- File `VERSION` in root + endpoint `GET /api/system/info` che espone
  `{service, version, mode, data_policy}` per coordinarsi tra build
  frontend/backend e per la chip versione in topbar.
- `CHANGELOG.md` (questo file) per tracciare le release.

### Changed
- `Settings.strict_secrets` ora si applica **sempre** (prima richiedeva
  anche `demo_mode=False`).
- `validate_scan_mode()`: gli alias `demo` / `service detection` collassano
  su `safe`, l'unica modalità reale.
- `get_topology()`: rimosso parametro `demo_mode`, query string `?demo=`
  ignorata.
- Banner UI semplificato: chip verde **LIVE v1.0.0** in topbar, nessun
  banner sticky.

### Fixed
- Bug timezone: tutti i timestamp ora formattati in `Europe/Rome`.
- Bug click su righe tabelle: event delegation sul `<tbody>` (resiste ai
  re-render automatici).
- Bug `Cannot read properties of null (reading 'reset')`: il form
  reference è catturato prima dello `await api.createScanJob`.
- Bug `Latest Events` rail-panel destro che sbordava.
- Errori SQL (es. `Invalid column name`) ora ritornano 400 con messaggio
  leggibile, non 500 generico.
- Scan combined fa fallback automatico a nmap-only se masscan non ha raw
  socket (Docker non-root).
- Nmap usa `-sT -Pn -sV` per funzionare senza CAP_NET_RAW.

### Security
- Eliminati pattern di marker demo (`192.168.1.x`, `vendor='LabVendor'`,
  `scanner='demo'`) — non più necessari per distinguere dati sintetici
  da dati reali, perché ora **non ci sono mai dati sintetici**.

---

## Convenzioni di versioning per i prossimi commit

Quando applichi un fix significativo:
1. Decidi se è MAJOR/MINOR/PATCH (vedi sopra).
2. Aggiorna il file `VERSION`.
3. Aggiungi una sezione qui sotto con la nuova versione e le modifiche.
4. Commit message:
   ```
   chore(release): vX.Y.Z

   - bullet sintetico delle modifiche
   ```
