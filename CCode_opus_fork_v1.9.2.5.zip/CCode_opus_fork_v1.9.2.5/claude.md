## NetVisor – Project Context & Instructions

### Identità del progetto
NetVisor è un Mini-SIEM / NOSD (Network Operations & Security Dashboard)
didattico per esame ITS Cybersecurity 2025-2027.
Stile target: SIEM enterprise (IBM QRadar, ManageEngine Log360, ADAudit Plus).
Cliente fittizio: INFORMIX S.p.A.

### DEMO MODE — interruttore I/O netto
Variabile master: NETVISOR_DEMO_MODE in .env (default: true = lab safety).
- true  → dati sintetici, scan emulati, seed demo nel DB,
          banner GIALLO "DEMO MODE" persistente in UI (login + shell).
- false → solo dati reali, scan reali su CIDR autorizzati,
          NESSUN seed sintetico, banner VERDE "LIVE — Production data",
          fail-fast all'avvio se i secret sono ancora placeholder.

Endpoint pubblico: GET /api/system/mode → {mode, demo, demo_seed, ...}
Tutte le risposte API includono _meta: {mode, demo, ts}.
Pulizia dati demo via POST /api/admin/demo/purge (admin only).

NETVISOR_DEMO_SEED può essere disaccoppiato da NETVISOR_DEMO_MODE
per QA con DB pulito ma scanner emulato.

### Ruolo dell'assistente
Lead Developer + DevSecOps Engineer.
Mantieni architettura, convenzioni e stile già stabiliti nella codebase.
Quando modifichi file esistenti, preserva tutto ciò che funziona.

---

### Stack OBBLIGATORIO (nessuna deroga)
- Frontend : HTML + CSS + JavaScript Vanilla (fetch nativo)
             NO React / Vue / Angular / jQuery
- Backend  : Python + Flask (REST API JSON) + pyodbc
- Database : Microsoft SQL Server
- Mobile   : C# + .NET MAUI — pattern MVVM
             (Models / Services / ViewModels / Views)
- DevOps   : Docker + Docker Compose

---

### Architettura Docker
Frontend nginx :8080 (unico servizio esposto all'esterno)
  └─► Backend Flask :5000 (rete interna Docker)
        └─► SQL Server :1433 (rete interna, mai esposto)
Scan-worker: processo separato, stesso image backend
Scanner: profilo opzionale --profile scanner
Tutti i container: read_only, no-new-privileges, CAP_DROP ALL
Backend + scan-worker: CAP_ADD NET_RAW (ping/nmap)

---

### Backend — Stato attuale (v1 completo)
Blueprints attivi: auth, agents, alerts, nodes, scans, scan_jobs,
health_checks, tests, topology, ingest, insights, users

Auth layer (seconda iterazione — completo):
- JWT Bearer (access token breve) + refresh token opaco ruotato
- Argon2id primaria, bcrypt fallback, pepper da env
- RBAC: @login_required, @role_required("admin") / ("admin","user")
- Tabelle: Users, AuthSessions, AuthAuditLog
- Bootstrap admin automatico al primo avvio
- Account lockout, audit log, alert su login admin

Servizi principali: auth_service, agent_service, scan_job_service,
health_check_service, alert_engine, scanner_service, validation_service

Pattern risposta: sempre success_response() / error_response()
Variabili sensibili: SOLO da .env, mai hardcoded

---

### Database — Tabelle principali
Nodes, Services, Alerts, Scans, ScanJobs, Tests, RawLogs,
Users, AuthSessions, AuthAuditLog,
Agents, AgentMetrics, AgentServices, AgentEvents,
HealthChecks

---

### Frontend — Convenzioni e target UI
Shell globale: js/shell.js (sidebar sinistra, topbar, right-rail alerts)
Ogni pagina: modulo JS dedicato + fetch con Bearer token da sessionStorage

TARGET VISUAL (reference: QRadar, Log360, ADAudit Plus, Tanzu):
- Dark theme obbligatorio: bg #0a0e1a, card #111827, accent #3b82f6
- KPI cards: numero grande + delta/trend + sparkline
- Sidebar: icone + label, badge contatore alert
- Grafici: Chart.js — line (tempo reale), bar orizzontale (top-N),
  donut/pie (categorie severity)
- Alert feed: colonna destra, color-coded per severity
  Critical=#ef4444, High=#f97316, Medium=#eab308, Low=#3b82f6
- Tabelle: righe alternate, hover highlight, badge severity colorati
- Topology: zone logiche cloud-like, nodi clickable, connessioni animate
- NO loghi commerciali (IBM, ManageEngine, ecc.) — stile libero

Pagine esistenti: index (dashboard), topology, alerts, nodes,
scan-jobs, scans, agents, users, settings, logs, reports,
login, admin-console (operations)

---

### Mobile .NET MAUI — Stato attuale
Struttura MVVM presente ma NON completamente testata.
Pagine: LoginPage, HomePage, NodesPage, NodeDetailPage,
        AlertsPage, ConnectivityPage
Auth: JWT Bearer in SecureStorage, refresh sessione, logout
ApiClient.cs: unico punto accesso API
Su emulatore Android: usare 10.0.2.2 al posto di localhost
DA FARE: completare ViewModel logic, test end-to-end, gestione errori

---

### Sicurezza (requisiti espliciti consegna)
Obbligatori: variabili env per segreti, validazione input,
gestione errori API (no stack trace), separazione container,
CORS_ORIGINS da env
Consigliati: logging, sanitizzazione input (già in validation_service)

---

### Deliverables (stato)
✅ Codice backend + frontend + mobile + DB init.sql + docker-compose
✅ docs/API.md, ARCHITECTURE.md, SECURITY.md, DATABASE.md
✅ docs/MANUAL.md (manuale operativo)
✅ docs/COSTS.md (valutazione economica)
🔄 UI/UX da portare a livello enterprise reference
🔄 Mobile: da completare e testare
❌ Presentazione PowerPoint (commerciale + tecnica) — da fare

### Pesi valutazione
Dashboard Web 25% | Backend/API 20% | Docker 15% |
Mobile MAUI 15% | Presentazione 15% | Codice/Docs 10%