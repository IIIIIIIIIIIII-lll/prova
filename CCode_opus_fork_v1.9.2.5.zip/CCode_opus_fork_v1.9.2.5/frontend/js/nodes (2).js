import { api, notifyError, renderSeverityBadge, renderStatus } from "./api.js";

let activeStatus = "";

async function loadNodes() {
  try {
    const nodes = await api.getNodes(activeStatus);
    document.getElementById("nodesCount").textContent = `${nodes.length} nodi`;
    document.getElementById("nodesTable").innerHTML = nodes
      .map(
        (node) => `
          <tr class="clickable-row" data-node-id="${node.id}">
            <td>#${node.id}</td>
            <td>${node.hostname || "-"}</td>
            <td>${node.ip}</td>
            <td>${renderStatus(node.status)}</td>
            <td>${node.os_guess || "-"}</td>
            <td>${node.risk_score}</td>
          </tr>
        `
      )
      .join("");

    document.querySelectorAll("[data-node-id]").forEach((row) => {
      row.addEventListener("click", () => loadNodeDetail(row.dataset.nodeId));
    });
  } catch (error) {
    notifyError(error);
  }
}

async function loadNodeDetail(nodeId) {
  try {
    const [node, services, alerts, logins] = await Promise.all([
      api.getNode(nodeId),
      api.getNodeServices(nodeId),
      api.getNodeAlerts(nodeId),
      api.getNodeLogins(nodeId),
    ]);

    document.getElementById("nodeSelectionLabel").textContent = `${node.hostname || node.ip} • ${node.ip}`;
    document.getElementById("nodeServicesTable").innerHTML = services
      .map(
        (service) => `
          <tr>
            <td>${service.port}</td>
            <td>${service.protocol}</td>
            <td>${renderStatus(service.state)}</td>
            <td>${service.service_name || "-"}</td>
            <td>${[service.product, service.version].filter(Boolean).join(" ") || "-"}</td>
          </tr>
        `
      )
      .join("");

    document.getElementById("nodeAlertsTable").innerHTML = alerts
      .map(
        (alert) => `
          <tr>
            <td>#${alert.id}</td>
            <td>${renderSeverityBadge(alert.severity)}</td>
            <td>${alert.description}</td>
          </tr>
        `
      )
      .join("");

    document.getElementById("nodeLoginsTable").innerHTML = logins
      .map(
        (login) => `
          <tr>
            <td>${login.username}</td>
            <td>${login.source || "-"}</td>
            <td>${login.result}</td>
            <td>${login.timestamp || "-"}</td>
          </tr>
        `
      )
      .join("");
  } catch (error) {
    notifyError(error);
  }
}

document.querySelectorAll("[data-status]").forEach((button) => {
  button.addEventListener("click", async () => {
    document.querySelectorAll("[data-status]").forEach((item) => item.classList.remove("active-filter"));
    button.classList.add("active-filter");
    activeStatus = button.dataset.status;
    await loadNodes();
  });
});

loadNodes();
