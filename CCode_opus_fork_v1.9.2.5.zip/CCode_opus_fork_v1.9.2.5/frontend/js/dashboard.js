import { api, notifyError, renderSeverityBadge, renderStatus } from "./api.js";

// XSS-safe HTML escape per dati user-controlled iniettati in innerHTML.
function esc(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

// ── Sparkline (mini canvas line chart) ───────────────────────────────────────
function drawSparkline(canvasId, values, color = "#3b82f6") {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const W = canvas.width, H = canvas.height;
  ctx.clearRect(0, 0, W, H);
  if (!values || values.length < 2) return;
  const max = Math.max(...values, 1);
  const step = W / (values.length - 1);
  ctx.beginPath();
  values.forEach((v, i) => {
    const x = i * step;
    const y = H - (v / max) * (H - 4) - 2;
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.8;
  ctx.stroke();
  // fill area
  ctx.lineTo((values.length - 1) * step, H);
  ctx.lineTo(0, H);
  ctx.closePath();
  ctx.fillStyle = color + "22";
  ctx.fill();
}

function deltaLabel(current, previous) {
  if (previous == null || previous === 0) return null;
  const pct = Math.round(((current - previous) / previous) * 100);
  if (pct === 0) return null;
  return pct > 0 ? `▲ ${pct}%` : `▼ ${Math.abs(pct)}%`;
}

function setDelta(id, current, previous, dangerUp = false) {
  const el = document.getElementById(id);
  if (!el) return;
  const label = deltaLabel(current, previous);
  if (!label) return;
  const up = label.startsWith("▲");
  const good = dangerUp ? !up : up;
  el.textContent = label;
  el.style.color = good ? "var(--success)" : "var(--danger)";
}

// ── Trend chart (canvas bar+line combo) ──────────────────────────────────────
function renderTrendChart(rows) {
  const canvas = document.getElementById("trendChart");
  if (!canvas || !rows.length) return;
  const ctx = canvas.getContext("2d");
  const W = canvas.offsetWidth || canvas.parentElement.offsetWidth || 600;
  canvas.width = W;
  const H = 160;
  ctx.clearRect(0, 0, W, H);

  const pad = { l: 8, r: 8, t: 8, b: 28 };
  const cols = rows.length;
  const barW = Math.floor((W - pad.l - pad.r) / cols) - 4;
  const maxVal = Math.max(1, ...rows.flatMap(r => [r.security_events||0, r.alerts||0, r.logins||0]));
  const chartH = H - pad.t - pad.b;

  rows.forEach((row, i) => {
    const x = pad.l + i * ((W - pad.l - pad.r) / cols);
    const events = row.security_events || 0;
    const alerts = row.alerts || 0;
    const logins = row.logins || 0;

    // stacked effect — draw 3 segments
    [[events, "#3b82f688"], [alerts, "#ef444488"], [logins, "#22c55e88"]].forEach(([val, color]) => {
      const h = Math.max(2, (val / maxVal) * chartH);
      ctx.fillStyle = color;
      ctx.fillRect(x + 2, pad.t + chartH - h, barW, h);
    });

    // x-axis label
    ctx.fillStyle = "#93a8c4";
    ctx.font = "10px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(row.label ? row.label.slice(5) : "", x + barW / 2 + 2, H - 8);
  });
}

// ── Progress list ─────────────────────────────────────────────────────────────
function renderProgressList(targetId, rows, labelKey = "label", valueKey = "count") {
  const target = document.getElementById(targetId);
  if (!target) return;
  const max = Math.max(1, ...rows.map(r => r[valueKey] || 0));
  const COLORS = ["#3b82f6","#22c55e","#f97316","#a855f7","#ef4444","#06b6d4"];
  target.innerHTML = rows.map((r, i) => `
    <div class="progress-row">
      <span>${r[labelKey]}</span>
      <div class="progress-track">
        <div class="progress-fill" style="width:${Math.max(8,(r[valueKey]||0)/max*100)}%;background:${COLORS[i%6]}"></div>
      </div>
      <strong>${r[valueKey] || 0}</strong>
    </div>`).join("");
}

// ── Recent Alerts feed (right column, stile Log360) ───────────────────────────
function renderRecentAlertsFeed(alerts) {
  const feed = document.getElementById("recentAlertsFeed");
  const badge = document.getElementById("recentAlertsCount");
  if (!feed) return;
  const SEV_COLOR = { critical:"#ef4444", high:"#f97316", medium:"#eab308", low:"#3b82f6", info:"#6b7280" };
  const items = alerts.slice(0, 20);
  if (badge) badge.textContent = items.length;
  feed.innerHTML = items.length ? items.map(a => {
    const color = SEV_COLOR[a.severity?.toLowerCase()] || "#6b7280";
    return `<article class="alert-feed-item" style="border-left-color:${color}">
      <div class="alert-feed-row">
        <strong class="alert-feed-type">${esc(a.type || "alert")}</strong>
        <span class="badge" style="background:${color}22;color:${color};border-color:${color}44">${esc(a.severity||"")}</span>
      </div>
      <p class="alert-feed-desc">${esc(a.description || "")}</p>
      <small class="muted">${esc(a.node_label || a.source || "system")} · ${esc(a.status || "open")}</small>
    </article>`;
  }).join("") : `<p class="muted" style="padding:.75rem">Nessun alert recente.</p>`;
}

// ── Tables ────────────────────────────────────────────────────────────────────
function renderAgentHealth(rows) {
  const t = document.getElementById("agentHealthTable");
  if (!t) return;
  t.innerHTML = rows.map(a => `<tr>
    <td>${esc(a.hostname||a.agent_id)}</td>
    <td>${renderStatus(a.status)}</td>
    <td>${a.cpu_percent==null?"-":Number(a.cpu_percent).toFixed(0)+"%"}</td>
    <td>${a.ram_percent==null?"-":Number(a.ram_percent).toFixed(0)+"%"}</td>
    <td>${a.disk_percent==null?"-":Number(a.disk_percent).toFixed(0)+"%"}</td>
  </tr>`).join("");
}

function renderTopAssets(rows) {
  const t = document.getElementById("topAssetsTable");
  if (!t) return;
  t.innerHTML = rows.map(a => `<tr>
    <td>${esc(a.label)}</td><td class="mono">${esc(a.ip)}</td>
    <td>${Number(a.risk_score)||0}</td><td>${Number(a.open_alerts)||0}</td>
    <td>${Number(a.services)||0}</td><td>${renderStatus(a.status)}</td>
  </tr>`).join("");
}

function renderLatestScanRuns(rows) {
  const t = document.getElementById("latestScanRunsTable");
  if (!t) return;
  t.innerHTML = rows.map(r => `<tr>
    <td>#${Number(r.id)||0}</td>
    <td><span class="badge badge-info">${esc(r.scanner||"nmap")}</span></td>
    <td>${renderStatus(r.status)}</td>
    <td class="mono">${esc(r.target)}</td>
    <td>${esc(r.result_summary||r.error_message||"-")}</td>
  </tr>`).join("");
}

function renderLatestChecks(rows) {
  const target = document.getElementById("latestChecksFeed");
  if (!target) return;
  target.innerHTML = rows.map(item => `
    <article class="feed-item feed-item-compact">
      <div class="feed-item-top">
        <strong>${esc(item.name||item.target)}</strong>
        ${renderStatus(item.result)}
      </div>
      <p>${esc(item.check_type)}${item.port?":"+esc(item.port):""} · ${esc(item.target)}</p>
      <small>${item.latency_ms==null?"-":Number(item.latency_ms)+" ms"} · ${esc(item.checked_at)}</small>
    </article>`).join("");
}

// ── Persistent sparkline history (session memory) ─────────────────────────────
const _spark = {};
function pushSpark(key, val) {
  if (!_spark[key]) _spark[key] = [];
  _spark[key].push(val ?? 0);
  if (_spark[key].length > 20) _spark[key].shift();
  return _spark[key];
}

// ── Main load ─────────────────────────────────────────────────────────────────
let _prevOverview = null;

async function loadDashboard() {
  try {
    const [operations, alertsData] = await Promise.all([
      api.getDashboardOperations(),
      api.getAlerts().catch(() => ({ data: [] })),
    ]);

    const overview = operations.event_overview || {};
    const agentSummary = (operations.agents_overview?.summary) || {};

    // KPI paint + sparklines + delta
    const kpis = [
      ["allEvents",      overview.all_events,      "sparkAllEvents",      "deltaAllEvents",      "#3b82f6", false],
      ["windowsEvents",  overview.windows_events,  "sparkWindowsEvents",  "deltaWindowsEvents",  "#06b6d4", false],
      ["networkEvents",  overview.network_events,  "sparkNetworkEvents",  "deltaNetworkEvents",  "#a855f7", false],
      ["allDevices",     overview.all_devices,     "sparkAllDevices",     "deltaAllDevices",     "#22c55e", false],
      ["activeAlerts",   overview.open_alerts,     "sparkActiveAlerts",   "deltaActiveAlerts",   "#ef4444", true],
      ["onlineAgents",   overview.online_agents,   "sparkOnlineAgents",   null,                  "#22c55e", false],
      ["failedChecks",   overview.failed_checks,   "sparkFailedChecks",   "deltaFailedChecks",   "#f97316", true],
      ["openServices",   overview.open_services,   "sparkOpenServices",   "deltaOpenServices",   "#3b82f6", false],
    ];

    kpis.forEach(([id, val, sparkId, deltaId, color, dangerUp]) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val ?? 0;
      const hist = pushSpark(id, val ?? 0);
      drawSparkline(sparkId, hist, color);
      if (deltaId && _prevOverview) {
        const prevKey = id.replace(/^[a-z]/, c => c) // same key mapping
        setDelta(deltaId, val ?? 0, _prevOverview[id] ?? 0, dangerUp);
      }
    });

    // agent ratio
    const ratio = document.getElementById("agentRatio");
    if (ratio) ratio.textContent = overview.agents_online_ratio || "-";

    _prevOverview = { allEvents: overview.all_events, windowsEvents: overview.windows_events,
      networkEvents: overview.network_events, allDevices: overview.all_devices,
      activeAlerts: overview.open_alerts, onlineAgents: overview.online_agents,
      failedChecks: overview.failed_checks, openServices: overview.open_services };

    renderTrendChart(operations.event_trend || []);
    renderProgressList("topDevicesList", operations.top_devices || []);
    renderProgressList("alertSeverityPanel", operations.alert_severity_distribution || []);
    renderProgressList("servicesByPortPanel", operations.services_by_port || []);
    renderProgressList("windowsSeverityChart", [
      { label: "Failed Logins",   count: overview.failed_logins || 0 },
      { label: "Suspicious",      count: overview.suspicious_estimated || 0 },
      { label: "Agent Errors",    count: agentSummary.error_events || 0 },
      { label: "Services Down",   count: agentSummary.services_down || 0 },
    ]);
    renderLatestScanRuns(operations.latest_scan_runs || []);
    renderAgentHealth(operations.agents_overview?.latest_metrics || []);
    renderTopAssets(operations.top_assets || []);
    renderLatestChecks(operations.latest_check_results || []);

    // Recent alerts feed (right column)
    const alerts = Array.isArray(alertsData) ? alertsData : (alertsData?.data || alertsData?.alerts || []);
    renderRecentAlertsFeed(alerts);

    // timestamp
    const ts = document.getElementById("lastUpdatedAt");
    if (ts) ts.textContent = "ultimo aggiornamento " + new Intl.DateTimeFormat("it-IT", {timeZone:"Europe/Rome",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false}).format(new Date());

  } catch (error) {
    notifyError(error);
  }
}

window.addEventListener("netvisor:manual-refresh", loadDashboard);
loadDashboard();
window.setInterval(loadDashboard, 8000);
