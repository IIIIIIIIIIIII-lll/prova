import { api, notifyError, renderSeverityBadge } from "./api.js";

function renderFailureBars(rows) {
  const total = rows.reduce((sum, item) => sum + item.failed_count, 0) || 1;
  document.getElementById("topFailureBars").innerHTML = rows
    .map(
      (item, index) => `
        <div class="protocol-bar-row">
          <span>${item.username}</span>
          <div class="protocol-bar-track">
            <div class="protocol-bar-fill protocol-color-${index % 6}" style="width:${Math.max(8, (item.failed_count / total) * 100)}%"></div>
          </div>
          <strong>${item.failed_count}</strong>
        </div>
      `
    )
    .join("");
}

function renderPeakHours(rows) {
  const maxValue = Math.max(1, ...rows.map((item) => item.count));
  document.getElementById("peakHoursChart").innerHTML = rows
    .map(
      (item) => `
        <div class="trend-day">
          <div class="trend-bars-stack">
            <span class="trend-bar trend-bar-events" style="height:${Math.max(8, (item.count / maxValue) * 120)}px"></span>
          </div>
          <small>${item.hour}</small>
        </div>
      `
    )
    .join("");
}

function renderAnomalies(rows) {
  document.getElementById("loginAnomaliesFeed").innerHTML = rows
    .map(
      (item) => `
        <article class="feed-item">
          <div class="feed-item-top">
            <strong>${item.username}</strong>
            ${renderSeverityBadge(item.severity)}
          </div>
          <p>Tipi: ${item.types.join(", ") || "-"}</p>
          <small>failed: ${item.failed_count} · source IP: ${item.source_ips} · source MAC: ${item.source_macs} · risk: ${item.risk_score}</small>
        </article>
      `
    )
    .join("");
}

function renderAudit(rows) {
  document.getElementById("auditActivityFeed").innerHTML = rows
    .map(
      (item) => `
        <article class="feed-item feed-item-compact">
          <div class="feed-item-top">
            <strong>${item.action}</strong>
            <span class="badge severity-info">${item.actor || "system"}</span>
          </div>
          <p>${item.details || "-"}</p>
          <small>${item.created_at}</small>
        </article>
      `
    )
    .join("");
}

function renderLoginActivity(rows) {
  document.getElementById("loginActivityTable").innerHTML = rows
    .map(
      (item) => `
        <tr>
          <td>${item.username}</td>
          <td>${item.account_type || "-"}</td>
          <td>${item.hostname || item.ip}</td>
          <td>${item.source || "-"}</td>
          <td>${item.source_ip || "-"}</td>
          <td>${item.source_mac || "-"}</td>
          <td>${item.auth_channel || "-"}</td>
          <td>${item.result}</td>
          <td>${item.risk_score ?? 0}</td>
          <td>${item.timestamp}</td>
        </tr>
      `
    )
    .join("");
}

async function loadSecuritySummary() {
  try {
    const data = await api.getSecurityLoginSummary();
    const summary = data.summary || {};
    document.getElementById("totalLogins").textContent = summary.total_logins ?? 0;
    document.getElementById("successLogins").textContent = summary.success_logins ?? 0;
    document.getElementById("failedLogins").textContent = summary.failed_logins ?? 0;
    document.getElementById("adminEvents").textContent = summary.admin_events ?? 0;
    document.getElementById("suspiciousAccounts").textContent = summary.suspicious_accounts ?? 0;
    document.getElementById("multiOriginAccounts").textContent = summary.multi_origin_accounts ?? 0;

    renderFailureBars(data.top_failures || []);
    renderPeakHours(data.peak_hours || []);
    renderAnomalies(data.anomalies || []);
    renderAudit(data.audit_activity || []);
    renderLoginActivity(data.recent_activity || []);
  } catch (error) {
    notifyError(error);
  }
}

async function loadAlerts() {
  try {
    const alerts = await api.getAlerts();
    document.getElementById("alertsTable").innerHTML = alerts
      .map(
        (alert) => `
          <tr>
            <td>#${alert.id}</td>
            <td>${renderSeverityBadge(alert.severity)}</td>
            <td>${alert.type}</td>
            <td>${alert.hostname || alert.ip || "-"}</td>
            <td>${alert.description}</td>
            <td>${alert.status}</td>
            <td class="action-cell">
              <button class="ghost-button action-button" data-action="ack" data-id="${alert.id}">ACK</button>
              <button class="ghost-button action-button" data-action="close" data-id="${alert.id}">Close</button>
            </td>
          </tr>
        `
      )
      .join("");

    document.querySelectorAll(".action-button").forEach((button) => {
      button.addEventListener("click", async () => {
        try {
          if (button.dataset.action === "ack") {
            await api.ackAlert(button.dataset.id);
          } else {
            await api.closeAlert(button.dataset.id);
          }
          await loadAlerts();
        } catch (error) {
          notifyError(error);
        }
      });
    });
  } catch (error) {
    notifyError(error);
  }
}

document.getElementById("reloadAlertsButton").addEventListener("click", async () => {
  await Promise.all([loadSecuritySummary(), loadAlerts()]);
});

await Promise.all([loadSecuritySummary(), loadAlerts()]);
