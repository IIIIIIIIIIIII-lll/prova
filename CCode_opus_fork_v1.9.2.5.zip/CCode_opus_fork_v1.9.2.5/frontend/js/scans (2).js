import { api, notifyError, renderStatus } from "./api.js";

function renderSummary(summary) {
  document.getElementById("activeNodes").textContent = summary.active_nodes ?? 0;
  document.getElementById("inactiveNodes").textContent = summary.inactive_nodes ?? 0;
  document.getElementById("openServices").textContent = summary.open_services ?? 0;
  document.getElementById("blockedConnections").textContent = summary.blocked_estimated ?? 0;
  document.getElementById("suspiciousConnections").textContent = summary.suspicious_estimated ?? 0;
  document.getElementById("evadedConnections").textContent = summary.evaded_estimated ?? 0;
}

function renderProtocols(protocols) {
  const total = protocols.reduce((sum, item) => sum + item.count, 0) || 1;
  document.getElementById("connectionProtocolBars").innerHTML = protocols
    .map(
      (item, index) => `
        <div class="protocol-bar-row">
          <span>${item.protocol}</span>
          <div class="protocol-bar-track">
            <div class="protocol-bar-fill protocol-color-${index % 6}" style="width:${Math.max(8, (item.count / total) * 100)}%"></div>
          </div>
          <strong>${item.count}</strong>
        </div>
      `
    )
    .join("");
}

function renderServices(services) {
  document.getElementById("servicesMatrixTable").innerHTML = services
    .map(
      (service) => `
        <tr>
          <td>${service.hostname || "-"}</td>
          <td>${service.ip}</td>
          <td>${renderStatus(service.node_status)}</td>
          <td>${service.port}</td>
          <td>${service.protocol}</td>
          <td>${service.service_name || "-"}</td>
          <td>${[service.product, service.version].filter(Boolean).join(" ") || "-"}</td>
        </tr>
      `
    )
    .join("");
}

function renderTests(tests) {
  document.getElementById("recentTestsTable").innerHTML = tests
    .map(
      (test) => `
        <tr>
          <td>${test.target}</td>
          <td>${test.type}</td>
          <td>${test.latency_ms == null ? "-" : `${test.latency_ms} ms`}</td>
          <td>${renderStatus(test.result)}</td>
          <td>${test.checked_at}</td>
        </tr>
      `
    )
    .join("");
}

function renderRawSnippets(rawLogs) {
  document.getElementById("rawSnippetFeed").innerHTML = rawLogs
    .map(
      (item) => `
        <article class="feed-item feed-item-compact">
          <div class="feed-item-top">
            <strong>${item.source}</strong>
            <span class="badge severity-info">${item.format}</span>
          </div>
          <p>scan_id: ${item.scan_id || "-"}</p>
          <pre class="inline-pre">${item.snippet}</pre>
        </article>
      `
    )
    .join("");
}

async function loadConnectionsOverview() {
  try {
    const overview = await api.getConnectionsOverview();
    renderSummary(overview.summary || {});
    renderProtocols(overview.protocols || []);
    renderServices(overview.services || []);
    renderTests(overview.tests || []);
    renderRawSnippets(overview.raw_logs || []);

    document.getElementById("scansTable").innerHTML = (overview.scans || [])
      .map(
        (scan) => `
          <tr class="clickable-row" data-scan-id="${scan.id}">
            <td>#${scan.id}</td>
            <td>${scan.scanner}</td>
            <td>${scan.target}</td>
            <td>${scan.ports || "-"}</td>
            <td>${renderStatus(scan.status)}</td>
          </tr>
        `
      )
      .join("");

    document.querySelectorAll("[data-scan-id]").forEach((row) => {
      row.addEventListener("click", () => loadScanDetail(row.dataset.scanId));
    });
  } catch (error) {
    notifyError(error);
  }
}

async function loadScanDetail(scanId) {
  try {
    const [scan, raw, events] = await Promise.all([api.getScan(scanId), api.getScanRaw(scanId), api.getScanEvents(scanId)]);
    document.getElementById("scanDetailTitle").textContent = `Scan #${scan.id} · ${scan.scanner} · ${scan.target}`;
    document.getElementById("scanRawOutput").textContent = raw.length ? raw[0].content : "Nessun raw log.";
    document.getElementById("scanEventsOutput").textContent = JSON.stringify(events, null, 2);
  } catch (error) {
    notifyError(error);
  }
}

document.getElementById("scanForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  document.getElementById("scanFeedback").textContent = "Scansione in esecuzione...";
  try {
    const payload = Object.fromEntries(new FormData(event.currentTarget).entries());
    const result = await api.createScan(payload);
    document.getElementById("scanFeedback").textContent = `Scansione #${result.scan_id} completata.`;
    await loadConnectionsOverview();
    await loadScanDetail(result.scan_id);
  } catch (error) {
    document.getElementById("scanFeedback").textContent = "Errore scan.";
    notifyError(error);
  }
});

document.getElementById("reloadScansButton").addEventListener("click", loadConnectionsOverview);

loadConnectionsOverview();
