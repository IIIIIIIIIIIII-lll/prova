import { api, ensureAuthenticated, notifyError, notifySuccess, renderSeverityBadge, renderStatus } from "./api.js";

const state = {
  jobs: [],
  checks: [],
  activeTab: "manual-scan",
};

function asBool(value) {
  return String(value).toLowerCase() === "true";
}

function setMessage(id, value) {
  const target = document.getElementById(id);
  if (target) {
    target.textContent = value;
  }
}

function readForm(form) {
  return Object.fromEntries(new FormData(form).entries());
}

function activateTab(tabKey) {
  state.activeTab = tabKey;
  document.querySelectorAll("[data-console-tab]").forEach((button) => {
    button.classList.toggle("active", button.dataset.consoleTab === tabKey);
  });
  document.querySelectorAll("[data-tab-panel]").forEach((panel) => {
    panel.classList.toggle("active", panel.dataset.tabPanel === tabKey);
  });
}

function updateKpis() {
  document.getElementById("adminJobsTotalKpi").textContent = state.jobs.length;
  document.getElementById("adminJobsEnabledKpi").textContent = state.jobs.filter((item) => item.enabled).length;
  document.getElementById("adminChecksTotalKpi").textContent = state.checks.length;
  document.getElementById("adminChecksDownKpi").textContent = state.checks.filter((item) => item.last_status === "failed").length;
}

function renderJobs() {
  const table = document.getElementById("adminScanJobsTable");
  if (!table) {
    return;
  }
  table.innerHTML = state.jobs
    .map(
      (job) => `
        <tr>
          <td>#${job.id}</td>
          <td>${job.name}</td>
          <td>${job.scanner}</td>
          <td>${job.target}</td>
          <td>${job.ports}</td>
          <td>${job.interval_seconds || "-"}</td>
          <td>${renderStatus(job.last_status || "idle")}</td>
          <td>${job.next_run_at || "-"}</td>
          <td>
            <div class="table-actions">
              <button class="ghost-button" type="button" data-job-action="run" data-job-id="${job.id}">Run now</button>
              <button class="ghost-button" type="button" data-job-action="toggle" data-job-id="${job.id}" data-enabled="${job.enabled}">
                ${job.enabled ? "Disable" : "Enable"}
              </button>
              <button class="ghost-button" type="button" data-job-action="delete" data-job-id="${job.id}">Delete</button>
            </div>
          </td>
        </tr>
      `
    )
    .join("");

  table.querySelectorAll("[data-job-action]").forEach((button) => {
    button.addEventListener("click", async () => {
      const jobId = Number(button.dataset.jobId);
      try {
        if (button.dataset.jobAction === "run") {
          await api.runScanJob(jobId);
          notifySuccess(`Job #${jobId} eseguito.`);
        } else if (button.dataset.jobAction === "toggle") {
          await api.updateScanJob(jobId, { enabled: !asBool(button.dataset.enabled) });
          notifySuccess(`Job #${jobId} aggiornato.`);
        } else if (button.dataset.jobAction === "delete") {
          await api.deleteScanJob(jobId);
          notifySuccess(`Job #${jobId} eliminato.`);
        }
        await loadJobsAndRuns();
      } catch (error) {
        notifyError(error);
      }
    });
  });
}

function renderChecks() {
  const table = document.getElementById("adminHealthChecksTable");
  if (!table) {
    return;
  }
  table.innerHTML = state.checks
    .map(
      (check) => `
        <tr>
          <td>#${check.id}</td>
          <td>${check.name}</td>
          <td>${check.target}</td>
          <td>${check.check_type}</td>
          <td>${check.port || "-"}</td>
          <td>${renderStatus(check.last_status || "unknown")}</td>
          <td>${check.last_latency_ms == null ? "-" : `${check.last_latency_ms} ms`}</td>
          <td>
            <div class="table-actions">
              <button class="ghost-button" type="button" data-check-action="run" data-check-id="${check.id}">Run now</button>
              <button class="ghost-button" type="button" data-check-action="toggle" data-check-id="${check.id}" data-enabled="${check.enabled}">
                ${check.enabled ? "Disable" : "Enable"}
              </button>
              <button class="ghost-button" type="button" data-check-action="delete" data-check-id="${check.id}">Delete</button>
            </div>
          </td>
        </tr>
      `
    )
    .join("");

  table.querySelectorAll("[data-check-action]").forEach((button) => {
    button.addEventListener("click", async () => {
      const checkId = Number(button.dataset.checkId);
      try {
        if (button.dataset.checkAction === "run") {
          await api.runHealthCheck(checkId);
          notifySuccess(`Check #${checkId} eseguito.`);
        } else if (button.dataset.checkAction === "toggle") {
          await api.updateHealthCheck(checkId, { enabled: !asBool(button.dataset.enabled) });
          notifySuccess(`Check #${checkId} aggiornato.`);
        } else if (button.dataset.checkAction === "delete") {
          await api.deleteHealthCheck(checkId);
          notifySuccess(`Check #${checkId} eliminato.`);
        }
        await loadChecksAndHistory();
      } catch (error) {
        notifyError(error);
      }
    });
  });
}

function sortByDateDescending(rows, key) {
  return [...rows].sort((left, right) => String(right[key] || "").localeCompare(String(left[key] || "")));
}

function renderRunHistory(scanRuns, checkResults) {
  const scanTable = document.getElementById("adminRunHistoryTable");
  const checkTable = document.getElementById("adminCheckHistoryTable");
  document.getElementById("adminRunsMeta").textContent = `${scanRuns.length} rows`;
  document.getElementById("adminCheckResultsMeta").textContent = `${checkResults.length} rows`;

  scanTable.innerHTML = sortByDateDescending(scanRuns, "started_at")
    .slice(0, 20)
    .map(
      (run) => `
        <tr>
          <td>#${run.id}</td>
          <td>${run.job_name || `#${run.job_id || "-"}`}</td>
          <td>${run.scanner}</td>
          <td>${run.target}</td>
          <td>${renderStatus(run.status)}</td>
          <td>${run.started_at || "-"}</td>
          <td>${run.finished_at || "-"}</td>
          <td>${run.result_summary || run.error_message || "-"}</td>
          <td>${run.output_file
            ? `<span class="output-file-chip" title="/app/scan_output/${run.output_file}">
                 <span class="output-file-icon">💾</span>${run.output_file}
               </span>`
            : '<span class="muted">—</span>'}</td>
        </tr>
      `
    )
    .join("");

  checkTable.innerHTML = sortByDateDescending(checkResults, "checked_at")
    .slice(0, 20)
    .map(
      (result) => `
        <tr>
          <td>#${result.id}</td>
          <td>${result.check_name || `#${result.check_id || "-"}`}</td>
          <td>${result.target}</td>
          <td>${result.check_type}</td>
          <td>${renderStatus(result.result)}</td>
          <td>${result.latency_ms == null ? "-" : `${result.latency_ms} ms`}</td>
          <td>${result.checked_at}</td>
          <td>${result.error_message || "-"}</td>
        </tr>
      `
    )
    .join("");
}

function renderAudit(authAudit, opsAudit) {
  document.getElementById("adminAuthAuditFeed").innerHTML = authAudit
    .slice(0, 20)
    .map(
      (item) => `
        <article class="feed-item">
          <div class="feed-item-top">
            <strong>${item.event_type}</strong>
            <span class="badge micro-badge">${item.success ? "success" : "failed"}</span>
          </div>
          <p>${item.username || "system"} - ${item.message || "-"}</p>
          <small>${item.ip_address || "-"} - ${item.created_at}</small>
        </article>
      `
    )
    .join("");

  document.getElementById("adminOpsAuditFeed").innerHTML = opsAudit
    .slice(0, 20)
    .map(
      (item) => `
        <article class="feed-item">
          <div class="feed-item-top">
            <strong>${item.action}</strong>
            ${renderSeverityBadge("info")}
          </div>
          <p>${item.details || "-"}</p>
          <small>${item.actor || "system"} - ${item.created_at}</small>
        </article>
      `
    )
    .join("");
}

async function loadJobsAndRuns() {
  state.jobs = await api.getScanJobs();
  renderJobs();
  updateKpis();

  const scanRuns = (
    await Promise.all(
      state.jobs.slice(0, 12).map(async (job) =>
        (await api.getScanJobRuns(job.id)).map((run) => ({
          ...run,
          job_name: job.name,
        }))
      )
    )
  ).flat();

  const existingCheckResults = document.getElementById("adminCheckHistoryTable")?.dataset.cachedResults;
  renderRunHistory(scanRuns, parseCachedRows(existingCheckResults));
}

async function loadChecksAndHistory() {
  state.checks = await api.getHealthChecks();
  renderChecks();
  updateKpis();

  const checkResults = (
    await Promise.all(
      state.checks.slice(0, 12).map(async (check) =>
        (await api.getHealthCheckResults(check.id)).map((result) => ({
          ...result,
          check_name: check.name,
        }))
      )
    )
  ).flat();

  const table = document.getElementById("adminCheckHistoryTable");
  if (table) {
    table.dataset.cachedResults = JSON.stringify(checkResults);
  }
  const existingScanRuns = document.getElementById("adminRunHistoryTable")?.dataset.cachedRuns;
  renderRunHistory(parseCachedRows(existingScanRuns), checkResults);
}

function parseCachedRows(serialized) {
  try {
    return serialized ? JSON.parse(serialized) : [];
  } catch (_error) {
    return [];
  }
}

async function loadHistory() {
  const [jobs, checks] = await Promise.all([api.getScanJobs(), api.getHealthChecks()]);
  const [scanRuns, checkResults] = await Promise.all([
    Promise.all(
      jobs.slice(0, 12).map(async (job) =>
        (await api.getScanJobRuns(job.id)).map((run) => ({ ...run, job_name: job.name }))
      )
    ).then((rows) => rows.flat()),
    Promise.all(
      checks.slice(0, 12).map(async (check) =>
        (await api.getHealthCheckResults(check.id)).map((result) => ({ ...result, check_name: check.name }))
      )
    ).then((rows) => rows.flat()),
  ]);
  document.getElementById("adminRunHistoryTable").dataset.cachedRuns = JSON.stringify(scanRuns);
  document.getElementById("adminCheckHistoryTable").dataset.cachedResults = JSON.stringify(checkResults);
  renderRunHistory(scanRuns, checkResults);
}

async function loadAudit() {
  const [authAudit, opsAudit] = await Promise.all([api.getAuthAudit(60), api.getAuditLog(60)]);
  renderAudit(authAudit, opsAudit);
}

async function loadAll() {
  const [jobs, checks] = await Promise.all([api.getScanJobs(), api.getHealthChecks()]);
  state.jobs = jobs;
  state.checks = checks;
  renderJobs();
  renderChecks();
  updateKpis();
  await Promise.all([loadHistory(), loadAudit()]);
}

async function submitManualScan(event) {
  event.preventDefault();
  const resultPanel   = document.getElementById("manualScanResult");
  const badgeEl       = document.getElementById("manualScanResultBadge");
  const summaryEl     = document.getElementById("manualScanResultSummary");
  const pipelineEl    = document.getElementById("manualScanResultPipeline");
  const tbody         = document.querySelector("#manualScanResultTable tbody");
  if (resultPanel) resultPanel.hidden = true;

  setMessage("manualScanConsoleMessage", "Scansione in esecuzione...");
  try {
    const payload = readForm(event.currentTarget);
    const result  = await api.runManualScan(payload);

    setMessage("manualScanConsoleMessage", `Scan #${result.scan_id} completata.`);
    notifySuccess(`Scan #${result.scan_id} completata.`);

    // ── Inline result panel ──────────────────────────────────────────────
    if (resultPanel) {
      const isCombined = result.pipeline === "combined";
      badgeEl.textContent  = isCombined ? "masscan→nmap" : (payload.scanner || "nmap");
      badgeEl.className    = `badge ${isCombined ? "badge-accent" : "badge-info"}`;
      summaryEl.textContent = result.summary || "";

      // Pipeline stats row (combined only)
      if (isCombined && pipelineEl) {
        pipelineEl.hidden = false;
        pipelineEl.innerHTML = `
          <span class="pipeline-stat">
            <strong>${result.masscan_hosts_found ?? "—"}</strong>
            <small>Masscan host trovati</small>
          </span>
          <span class="pipeline-stat">
            <strong>${result.nmap_hosts_enriched ?? "—"}</strong>
            <small>Nmap enriched</small>
          </span>
          ${result.output_file_masscan
            ? `<span class="output-file-chip" title="/app/scan_output/${result.output_file_masscan}">
                💾 ${result.output_file_masscan}
               </span>`
            : ""}
          ${result.output_file
            ? `<span class="output-file-chip" title="/app/scan_output/${result.output_file}">
                💾 ${result.output_file}
               </span>`
            : ""}
        `;
      } else if (pipelineEl) {
        pipelineEl.hidden = true;
      }

      // Normalized hosts table
      const hosts = result.normalized_hosts || [];
      tbody.innerHTML = hosts.length
        ? hosts.map((h) => {
            const services = (h.services || [])
              .map((s) => `<span class="svc-chip">${s.service_name || s.protocol}:${s.port}</span>`)
              .join(" ");
            return `<tr>
              <td class="mono">${h.ip || "—"}</td>
              <td>${h.hostname || "—"}</td>
              <td>${renderStatus(h.status || "unknown")}</td>
              <td class="muted">${h.os_guess || "—"}</td>
              <td>${services || "<span class='muted'>—</span>"}</td>
              <td><span class="badge badge-info">${h.source || payload.scanner || "scan"}</span></td>
            </tr>`;
          }).join("")
        : `<tr><td colspan="6" class="muted center">Nessun host trovato.</td></tr>`;

      resultPanel.hidden = false;
    }
    await loadAll();
  } catch (error) {
    setMessage("manualScanConsoleMessage", error.message || "Errore scansione.");
    notifyError(error);
  }
}

async function submitManualCheck(event) {
  event.preventDefault();
  setMessage("manualCheckConsoleMessage", "Check in esecuzione...");
  try {
    const payload = readForm(event.currentTarget);
    payload.port = payload.port ? Number(payload.port) : null;
    const result = await api.runManualHealthCheck(payload);
    setMessage(
      "manualCheckConsoleMessage",
      `${result.type.toUpperCase()} ${result.result} ${result.latency_ms == null ? "" : `- ${result.latency_ms} ms`}`.trim()
    );
    notifySuccess("Manual check completato.");
    await loadAll();
  } catch (error) {
    setMessage("manualCheckConsoleMessage", error.message || "Errore check.");
    notifyError(error);
  }
}

async function submitJob(event) {
  event.preventDefault();
  setMessage("scanJobConsoleMessage", "Salvataggio job...");
  try {
    const payload = readForm(event.currentTarget);
    const runImmediately = asBool(payload.run_immediately);
    delete payload.run_immediately;
    payload.enabled = asBool(payload.enabled);
    payload.permanent = asBool(payload.permanent);
    payload.interval_seconds = Number(payload.interval_seconds || 60);
    const created = await api.createScanJob(payload);
    if (runImmediately) {
      await api.runScanJob(created.id);
    }
    setMessage("scanJobConsoleMessage", `Job #${created.id} salvato.`);
    notifySuccess(`Job #${created.id} salvato.`);
    event.currentTarget.reset();
    await loadAll();
  } catch (error) {
    setMessage("scanJobConsoleMessage", error.message || "Errore salvataggio job.");
    notifyError(error);
  }
}

async function submitCheck(event) {
  event.preventDefault();
  setMessage("healthCheckConsoleMessage", "Salvataggio check...");
  try {
    const payload = readForm(event.currentTarget);
    payload.port = payload.port ? Number(payload.port) : null;
    payload.interval_seconds = Number(payload.interval_seconds || 60);
    payload.timeout_seconds = Number(payload.timeout_seconds || 5);
    payload.enabled = asBool(payload.enabled);
    payload.permanent = asBool(payload.permanent);
    const created = await api.createHealthCheck(payload);
    setMessage("healthCheckConsoleMessage", `Check #${created.id} salvato.`);
    notifySuccess(`Check #${created.id} salvato.`);
    event.currentTarget.reset();
    await loadAll();
  } catch (error) {
    setMessage("healthCheckConsoleMessage", error.message || "Errore salvataggio check.");
    notifyError(error);
  }
}

async function init() {
  const guard = await ensureAuthenticated({ adminOnly: true });
  if (!guard.authenticated || !guard.authorized || document.body.dataset.forbidden === "true") {
    return;
  }

  document.querySelectorAll("[data-console-tab]").forEach((button) => {
    button.addEventListener("click", () => activateTab(button.dataset.consoleTab));
  });
  document.getElementById("adminManualScanForm")?.addEventListener("submit", submitManualScan);
  document.getElementById("adminManualCheckForm")?.addEventListener("submit", submitManualCheck);
  document.getElementById("adminScanJobForm")?.addEventListener("submit", submitJob);
  document.getElementById("adminHealthCheckForm")?.addEventListener("submit", submitCheck);
  document.getElementById("reloadAdminJobsButton")?.addEventListener("click", loadJobsAndRuns);
  document.getElementById("reloadAdminChecksButton")?.addEventListener("click", loadChecksAndHistory);
  window.addEventListener("netvisor:manual-refresh", loadAll);

  await loadAll();
}

init().catch(notifyError);
