import { api, ensureAuthenticated, escapeHtml, formatDateTime, formatDateTimeShort, notifyError, renderStatus } from "./api.js";

// ── Stato ────────────────────────────────────────────────────────────────────
let selectedJobId   = null;
let selectedCheckId = null;
let _delegationBound = false; // event-delegation flag (one-time bind)

function parseBoolean(value) {
  return String(value).toLowerCase() === "true";
}

// ── Event delegation per click su righe tabella ─────────────────────────────
// Le tabelle vengono riscritte ad ogni loadJobs/loadHealthChecks, quindi gli
// addEventListener attaccati alle righe vanno persi. Con la delegation sul
// tbody-parent (il container che NON viene ricreato), il click sulla riga
// continua a funzionare anche dopo i refresh.
function bindRowDelegationOnce() {
  if (_delegationBound) return;
  _delegationBound = true;

  // Click sul corpo tabella ScanJobs → seleziona job, mostra Run History
  const jobsTable = document.getElementById("scanJobsTable");
  if (jobsTable) {
    jobsTable.addEventListener("click", (event) => {
      // Ignora click sui bottoni interni (hanno la propria action)
      if (event.target.closest("button")) return;
      const row = event.target.closest("tr[data-job-id]");
      if (row) loadRuns(row.dataset.jobId);
    });
  }

  // Click sul corpo tabella HealthChecks → seleziona check, mostra Last Results
  const checksTable = document.getElementById("healthChecksTable");
  if (checksTable) {
    checksTable.addEventListener("click", (event) => {
      if (event.target.closest("button")) return;
      const row = event.target.closest("tr[data-check-id]");
      if (row) loadCheckResults(row.dataset.checkId);
    });
  }
}

// Helper per il feedback colorato (success/warn/error/info)
function setFeedback(elId, message, kind = "info") {
  const el = document.getElementById(elId);
  if (!el) return;
  el.textContent = message;
  // Reset classi precedenti, poi applica quella nuova
  el.classList.remove("feedback-ok", "feedback-warn", "feedback-error", "feedback-info");
  el.classList.add(`feedback-${kind === "success" ? "ok" : kind}`);
}

// ── Tab switching ─────────────────────────────────────────────────────────────
function initTabs() {
  document.querySelectorAll(".tab-btn[data-tab]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetTab = btn.dataset.tab;
      document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      document.querySelectorAll(".tab-panel[id]").forEach((panel) => {
        panel.hidden = panel.id !== `tab-${targetTab}`;
      });
      if (targetTab === "availability") loadHealthChecks();
    });
  });

  // Mostra/nascondi "Interval seconds" in base alla modalità job
  const modeSelect = document.getElementById("scanJobMode");
  const intervalLabel = document.getElementById("intervalLabel");
  if (modeSelect && intervalLabel) {
    const toggleInterval = () => { intervalLabel.hidden = modeSelect.value !== "scheduled"; };
    modeSelect.addEventListener("change", toggleInterval);
    toggleInterval();
  }
}

// ════════════════════════════════════════════════════════════════════════════
// TAB 1 — SCAN JOBS
// ════════════════════════════════════════════════════════════════════════════

function renderRuns(runs) {
  document.getElementById("scanJobRunsTable").innerHTML = runs.length
    ? runs.map((run) => `
        <tr>
          <td>#${run.id}</td>
          <td>${renderStatus(run.status)}</td>
          <td>${escapeHtml(formatDateTimeShort(run.started_at))}</td>
          <td>${escapeHtml(formatDateTimeShort(run.finished_at))}</td>
          <td>${escapeHtml(run.result_summary || run.error_message || "-")}</td>
        </tr>`
      ).join("")
    : `<tr><td colspan="5" class="muted" style="text-align:center;padding:.6rem">Nessuna run disponibile.</td></tr>`;
}

async function loadRuns(jobId) {
  selectedJobId = jobId;
  document.getElementById("scanJobRunsTitle").textContent = `Job #${jobId}`;
  try {
    renderRuns(await api.getScanJobRuns(jobId));
  } catch (error) {
    notifyError(error);
  }
}

async function loadJobs() {
  try {
    const jobs = await api.getScanJobs();
    document.getElementById("scanJobsTable").innerHTML = jobs.length
      ? jobs.map((job) => `
          <tr data-job-id="${job.id}">
            <td>#${job.id}</td>
            <td>${escapeHtml(job.name)}</td>
            <td>${escapeHtml(job.scanner)}</td>
            <td>${escapeHtml(job.target)}</td>
            <td>${escapeHtml(job.ports)}</td>
            <td>${escapeHtml(job.mode)}</td>
            <td>${renderStatus(job.last_status || "idle")}</td>
            <td>${escapeHtml(formatDateTimeShort(job.next_run_at))}</td>
            <td>
              <div class="table-actions">
                <button class="ghost-button" type="button" data-action="run"    data-job-id="${job.id}">Run now</button>
                <button class="ghost-button" type="button" data-action="toggle" data-job-id="${job.id}" data-enabled="${job.enabled}">
                  ${job.enabled ? "Disable" : "Enable"}
                </button>
                <button class="ghost-button" type="button" data-action="delete" data-job-id="${job.id}">Delete</button>
              </div>
            </td>
          </tr>`
        ).join("")
      : `<tr><td colspan="9" class="muted" style="text-align:center;padding:.6rem">Nessun job dichiarato.</td></tr>`;

    document.querySelectorAll("#scanJobsTable [data-action='run'],#scanJobsTable [data-action='toggle'],#scanJobsTable [data-action='delete']").forEach((btn) => {
      btn.addEventListener("click", async (event) => {
        event.stopPropagation();
        const { action, jobId, enabled } = btn.dataset;
        try {
          if (action === "run")    await api.runScanJob(jobId);
          if (action === "toggle") await api.updateScanJob(jobId, { enabled: !parseBoolean(enabled) });
          if (action === "delete") await api.deleteScanJob(jobId);
          await loadJobs();
          if (selectedJobId === jobId) await loadRuns(jobId);
        } catch (error) {
          notifyError(error);
        }
      });
    });

    // Click riga: gestito via event delegation in bindRowDelegationOnce()

    if (selectedJobId) {
      const exists = jobs.some((j) => String(j.id) === String(selectedJobId));
      if (exists) await loadRuns(selectedJobId);
    }
  } catch (error) {
    notifyError(error);
  }
}

// ════════════════════════════════════════════════════════════════════════════
// TAB 2 — AVAILABILITY CHECKS (ex-Connections / health-checks)
// ════════════════════════════════════════════════════════════════════════════

function renderCheckResults(results) {
  document.getElementById("healthCheckResultsTable").innerHTML = results.length
    ? results.map((item) => `
        <tr>
          <td>#${item.id}</td>
          <td>${renderStatus(item.result)}</td>
          <td>${item.latency_ms == null ? "-" : `${item.latency_ms} ms`}</td>
          <td>${escapeHtml(formatDateTimeShort(item.checked_at))}</td>
          <td>${escapeHtml(item.error_message || "-")}</td>
        </tr>`
      ).join("")
    : `<tr><td colspan="5" class="muted" style="text-align:center;padding:.6rem">Nessun risultato.</td></tr>`;
}

async function loadCheckResults(checkId) {
  selectedCheckId = checkId;
  document.getElementById("healthCheckResultsTitle").textContent = `Check #${checkId}`;
  try {
    renderCheckResults(await api.getHealthCheckResults(checkId));
  } catch (error) {
    notifyError(error);
  }
}

async function loadHealthChecks() {
  try {
    const checks = await api.getHealthChecks();

    // KPI cards
    const up  = checks.filter((c) => c.last_status === "success").length;
    const down = checks.filter((c) => c.last_status === "failed").length;
    const latencies = checks.map((c) => Number(c.last_latency_ms)).filter(Number.isFinite);
    const avgLat = latencies.length
      ? `${Math.round(latencies.reduce((s, v) => s + v, 0) / latencies.length)} ms`
      : "-";
    document.getElementById("checksTotalKpi").textContent   = checks.length;
    document.getElementById("checksUpKpi").textContent      = up;
    document.getElementById("checksDownKpi").textContent    = down;
    document.getElementById("checksLatencyKpi").textContent = avgLat;

    // Protocol mix bars
    const byType = Object.entries(
      checks.reduce((acc, c) => { acc[c.check_type] = (acc[c.check_type] || 0) + 1; return acc; }, {})
    ).map(([label, count]) => ({ label: label.toUpperCase(), count }));
    const maxCount = Math.max(1, ...byType.map((i) => i.count));
    document.getElementById("checksProtocolBars").innerHTML = byType.length
      ? byType.map((item, idx) => `
          <div class="protocol-bar-row">
            <span>${item.label}</span>
            <div class="protocol-bar-track">
              <div class="protocol-bar-fill protocol-color-${idx % 6}" style="width:${Math.max(8, (item.count / maxCount) * 100)}%"></div>
            </div>
            <strong>${item.count}</strong>
          </div>`).join("")
      : `<p class="muted" style="padding:.5rem 0">Nessun check configurato.</p>`;

    // Tabella monitor
    document.getElementById("healthChecksTable").innerHTML = checks.length
      ? checks.map((check) => `
          <tr data-check-id="${check.id}">
            <td>#${check.id}</td>
            <td>${escapeHtml(check.name)}</td>
            <td>${escapeHtml(check.target)}</td>
            <td>${escapeHtml(check.check_type)}</td>
            <td>${check.port || "-"}</td>
            <td>${renderStatus(check.last_status || "unknown")}</td>
            <td>${check.last_latency_ms == null ? "-" : `${check.last_latency_ms} ms`}</td>
            <td>
              <div class="table-actions">
                <button class="ghost-button" type="button" data-action="run-check"    data-check-id="${check.id}">Run</button>
                <button class="ghost-button" type="button" data-action="toggle-check" data-check-id="${check.id}" data-enabled="${check.enabled}">
                  ${check.enabled ? "Disable" : "Enable"}
                </button>
                <button class="ghost-button" type="button" data-action="delete-check" data-check-id="${check.id}">Delete</button>
              </div>
            </td>
          </tr>`
        ).join("")
      : `<tr><td colspan="8" class="muted" style="text-align:center;padding:.6rem">Nessun monitor configurato.</td></tr>`;

    document.querySelectorAll("#healthChecksTable [data-action='run-check'],#healthChecksTable [data-action='toggle-check'],#healthChecksTable [data-action='delete-check']").forEach((btn) => {
      btn.addEventListener("click", async (event) => {
        event.stopPropagation();
        const { action, checkId, enabled } = btn.dataset;
        try {
          if (action === "run-check")    await api.runHealthCheck(checkId);
          if (action === "toggle-check") await api.updateHealthCheck(checkId, { enabled: !parseBoolean(enabled) });
          if (action === "delete-check") await api.deleteHealthCheck(checkId);
          await loadHealthChecks();
          if (selectedCheckId === checkId) await loadCheckResults(checkId);
        } catch (error) {
          notifyError(error);
        }
      });
    });

    // Click riga: gestito via event delegation in bindRowDelegationOnce()

    if (selectedCheckId) {
      const exists = checks.some((c) => String(c.id) === String(selectedCheckId));
      if (exists) await loadCheckResults(selectedCheckId);
    }
  } catch (error) {
    notifyError(error);
  }
}

// ════════════════════════════════════════════════════════════════════════════
// INIT
// ════════════════════════════════════════════════════════════════════════════

async function init() {
  const guard = await ensureAuthenticated({ adminOnly: true });
  if (!guard.authenticated || !guard.authorized || document.body.dataset.forbidden === "true") {
    return;
  }

  initTabs();
  bindRowDelegationOnce();

  // Form: Scan Job dichiarativo
  // BUG fix: event.currentTarget può diventare null durante l'await
  // (es. dopo un re-render della tabella). Cattura il form PRIMA del fetch.
  document.getElementById("scanJobForm")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const formEl = event.currentTarget; // riferimento stabile
    setFeedback("scanJobFeedback", "Creazione job...", "info");
    try {
      const payload = Object.fromEntries(new FormData(formEl).entries());
      const runImmediately = parseBoolean(payload.run_immediately);
      delete payload.run_immediately; // non lo manda al backend per createScanJob
      payload.enabled   = parseBoolean(payload.enabled);
      payload.protocol  = payload.protocol || "tcp";
      payload.permanent = parseBoolean(payload.permanent ?? true);
      if (payload.mode !== "scheduled") payload.interval_seconds = null;
      const created = await api.createScanJob(payload);
      if (runImmediately) {
        setFeedback("scanJobFeedback", `Job #${created.id} creato — avvio immediato…`, "info");
        try { await api.runScanJob(created.id); } catch (e) { /* no-op */ }
        setFeedback("scanJobFeedback", `Job #${created.id} creato e avviato.`, "success");
      } else {
        setFeedback("scanJobFeedback", `Job #${created.id} creato.`, "success");
      }
      // formEl può essere stato rimosso dal DOM se la pagina è cambiata; reset è safe.
      try { formEl?.reset(); } catch (_) { /* ignored */ }
      await loadJobs();
    } catch (error) {
      setFeedback("scanJobFeedback", `Errore creazione job: ${error?.message || error}`, "error");
      notifyError(error);
    }
  });

  // Form: One-time manual scan
  document.getElementById("manualScanForm")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const formEl = event.currentTarget;
    setFeedback("manualScanFeedback", "Scansione in esecuzione…", "info");
    try {
      const payload = Object.fromEntries(new FormData(formEl).entries());
      payload.protocol = payload.protocol || "tcp";
      const result = await api.runManualScan(payload);
      setFeedback("manualScanFeedback", `Scan #${result.scan_id} completata.`, "success");
    } catch (error) {
      setFeedback("manualScanFeedback", `Errore scansione: ${error?.message || error}`, "error");
      notifyError(error);
    }
  });

  // Form: Availability Check (permanente)
  document.getElementById("healthCheckForm")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const formEl = event.currentTarget;
    setFeedback("healthCheckFeedback", "Creazione controllo…", "info");
    try {
      const payload = Object.fromEntries(new FormData(formEl).entries());
      payload.enabled   = parseBoolean(payload.enabled);
      payload.permanent = parseBoolean(payload.permanent ?? true);
      payload.port      = payload.port ? Number(payload.port) : null;
      const created = await api.createHealthCheck(payload);
      // Mostra successo PRIMA di chiamare loadHealthChecks: se quello fallisce,
      // l'utente ha comunque il messaggio corretto sull'esito del create.
      setFeedback("healthCheckFeedback", `Check #${created.id} creato.`, "success");
      try { formEl?.reset(); } catch (_) { /* ignored */ }
      try {
        await loadHealthChecks();
      } catch (loadErr) {
        notifyError(loadErr);
      }
    } catch (error) {
      setFeedback("healthCheckFeedback", `Errore creazione controllo: ${error?.message || error}`, "error");
      notifyError(error);
    }
  });

  // Form: Quick Connection Test (one-shot, non salva)
  document.getElementById("quickCheckForm")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const formEl = event.currentTarget;
    const resultBox  = document.getElementById("quickCheckResult");
    const resultBadge = document.getElementById("quickCheckResultBadge");
    const resultSummary = document.getElementById("quickCheckResultSummary");
    setFeedback("quickCheckFeedback", "Test in corso…", "info");
    resultBox.hidden = true;
    try {
      const payload = Object.fromEntries(new FormData(formEl).entries());
      payload.port = payload.port ? Number(payload.port) : null;
      payload.timeout_seconds = Number(payload.timeout_seconds) || 5;
      const result = await api.runManualHealthCheck(payload);
      const ok = result?.result === "success";
      resultBadge.textContent = ok ? "SUCCESS" : (result?.result || "FAILED").toUpperCase();
      resultBadge.className = `badge ${ok ? "badge-success" : "badge-critical"}`;
      const lat = result?.latency_ms != null ? `${result.latency_ms} ms` : "-";
      // Il backend usa il campo `details` per il messaggio (errore o status code).
      // Il fallback a error_message preserva compatibilità con risposte storiche.
      const detail = result?.details || result?.error_message;
      const detailText = detail ? ` · ${detail}` : "";
      resultSummary.textContent = `${payload.target} (${payload.check_type}) · latency: ${lat}${detailText}`;
      resultBox.hidden = false;
      setFeedback("quickCheckFeedback", ok ? "Completato." : "Test eseguito (esito negativo).", ok ? "success" : "warn");
    } catch (error) {
      setFeedback("quickCheckFeedback", `Errore test: ${error?.message || error}`, "error");
      notifyError(error);
    }
  });

  // Refresh buttons
  document.getElementById("reloadScanJobsButton")?.addEventListener("click", loadJobs);
  document.getElementById("reloadHealthChecksButton")?.addEventListener("click", loadHealthChecks);

  // Global refresh event
  window.addEventListener("netvisor:manual-refresh", () => {
    loadJobs();
    const availTab = document.getElementById("tab-availability");
    if (availTab && !availTab.hidden) loadHealthChecks();
  });

  // Caricamento iniziale tab attivo (Scan Jobs)
  loadJobs();
  window.setInterval(loadJobs, 10000);
}

init().catch(notifyError);
