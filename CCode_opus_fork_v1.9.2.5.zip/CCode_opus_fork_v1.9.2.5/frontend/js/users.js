import { api, ensureAuthenticated, escapeHtml, notifyError, notifySuccess, renderStatus } from "./api.js";

const createForm = document.getElementById("createUserForm");
const editForm = document.getElementById("editUserForm");
const createMessage = document.getElementById("createUserMessage");
const editMessage = document.getElementById("editUserMessage");
const tableBody = document.getElementById("usersTable");
const auditFeed = document.getElementById("usersAuditFeed");
const toggleButton = document.getElementById("toggleUserButton");
const deleteButton = document.getElementById("deleteUserButton");
const resetButton = document.getElementById("resetPasswordButton");

let currentUsers = [];

function asBool(value) {
  return String(value).toLowerCase() === "true";
}

function selectedUser() {
  const userId = Number(editForm?.elements.id?.value || 0);
  return currentUsers.find((item) => Number(item.id) === userId) || null;
}

function updateKpis(users) {
  document.getElementById("usersTotalKpi").textContent = users.length;
  document.getElementById("usersAdminKpi").textContent = users.filter((item) => item.role === "admin").length;
  document.getElementById("usersActiveKpi").textContent = users.filter((item) => item.is_active).length;
  document.getElementById("usersMustChangeKpi").textContent = users.filter((item) => item.must_change_password).length;
}

function renderAudit(entries) {
  auditFeed.innerHTML = entries
    .slice(0, 12)
    .map(
      (item) => `
        <article class="feed-item">
          <div class="feed-item-top">
            <strong>${escapeHtml(item.event_type)}</strong>
            <span class="badge micro-badge">${item.success ? "success" : "failed"}</span>
          </div>
          <p>${escapeHtml(item.username || "system")} - ${escapeHtml(item.message || "-")}</p>
          <small>${escapeHtml(item.created_at)}</small>
        </article>
      `
    )
    .join("");
}

function fillEditForm(user) {
  if (!user || !editForm) {
    return;
  }
  editForm.elements.id.value = user.id;
  editForm.elements.username.value = user.username;
  editForm.elements.email.value = user.email || "";
  editForm.elements.display_name.value = user.display_name || "";
  editForm.elements.role.value = user.role;
  editForm.elements.is_active.value = user.is_active ? "true" : "false";
  editForm.elements.must_change_password.value = user.must_change_password ? "true" : "false";
  toggleButton.textContent = user.is_active ? "Disable" : "Enable";
}

function renderUsers(users) {
  currentUsers = users;
  updateKpis(users);
  tableBody.innerHTML = users
    .map(
      (user) => `
        <tr class="clickable-row" data-user-id="${Number(user.id) || 0}">
          <td>#${Number(user.id) || 0}</td>
          <td>${escapeHtml(user.username)}</td>
          <td><span class="badge micro-badge ${user.role === "admin" ? "severity-medium" : "severity-info"}">${escapeHtml(user.role)}</span></td>
          <td>${escapeHtml(user.email || "-")}</td>
          <td>${renderStatus(user.is_active ? "active" : "disabled")}</td>
          <td>${escapeHtml(user.last_login_at || "-")}</td>
          <td>${user.must_change_password ? "yes" : "no"}</td>
        </tr>
      `
    )
    .join("");

  tableBody.querySelectorAll("[data-user-id]").forEach((row) => {
    row.addEventListener("click", () => {
      const user = currentUsers.find((item) => Number(item.id) === Number(row.dataset.userId));
      fillEditForm(user);
    });
  });

  if (users[0] && !selectedUser()) {
    fillEditForm(users[0]);
  }
}

async function loadUsers() {
  try {
    const [users, audit] = await Promise.all([api.getUsers(), api.getAuthAudit(40)]);
    renderUsers(users);
    renderAudit(audit);
  } catch (error) {
    notifyError(error);
  }
}

async function handleCreate(event) {
  event.preventDefault();
  createMessage.textContent = "Creazione utente...";
  try {
    const payload = Object.fromEntries(new FormData(createForm).entries());
    payload.is_active = asBool(payload.is_active);
    payload.must_change_password = asBool(payload.must_change_password);
    const created = await api.createUser(payload);
    createMessage.textContent = `Utente ${created.username} creato.`;
    notifySuccess(`Creato utente ${created.username}.`);
    createForm.reset();
    await loadUsers();
  } catch (error) {
    createMessage.textContent = error.message || "Errore creazione utente.";
    notifyError(error);
  }
}

async function handleEdit(event) {
  event.preventDefault();
  const user = selectedUser();
  if (!user) {
    editMessage.textContent = "Seleziona un utente.";
    return;
  }
  editMessage.textContent = "Salvataggio modifiche...";
  try {
    const payload = {
      email: editForm.elements.email.value.trim() || null,
      display_name: editForm.elements.display_name.value.trim() || null,
      role: editForm.elements.role.value,
      is_active: asBool(editForm.elements.is_active.value),
      must_change_password: asBool(editForm.elements.must_change_password.value),
    };
    const updated = await api.updateUser(user.id, payload);
    editMessage.textContent = `Utente ${updated.username} aggiornato.`;
    notifySuccess(`Aggiornato ${updated.username}.`);
    await loadUsers();
  } catch (error) {
    editMessage.textContent = error.message || "Errore aggiornamento utente.";
    notifyError(error);
  }
}

async function handleToggle() {
  const user = selectedUser();
  if (!user) {
    return;
  }
  try {
    if (user.is_active) {
      await api.disableUser(user.id);
      notifySuccess(`Utente ${user.username} disabilitato.`);
    } else {
      await api.enableUser(user.id);
      notifySuccess(`Utente ${user.username} abilitato.`);
    }
    await loadUsers();
  } catch (error) {
    notifyError(error);
  }
}

async function handleResetPassword() {
  const user = selectedUser();
  if (!user) {
    return;
  }
  try {
    const result = await api.resetUserPassword(user.id, {});
    const extra = result.temporary_password ? ` Password temporanea: ${result.temporary_password}` : "";
    editMessage.textContent = `Password resettata.${extra}`;
    notifySuccess(`Reset password completato per ${user.username}.`);
    await loadUsers();
  } catch (error) {
    notifyError(error);
  }
}

async function handleDelete() {
  const user = selectedUser();
  if (!user) {
    return;
  }
  if (!window.confirm(`Eliminare l'utente ${user.username}?`)) {
    return;
  }
  try {
    await api.deleteUser(user.id);
    notifySuccess(`Utente ${user.username} eliminato.`);
    editForm.reset();
    await loadUsers();
  } catch (error) {
    notifyError(error);
  }
}

async function init() {
  const guard = await ensureAuthenticated({ adminOnly: true });
  if (!guard.authenticated || !guard.authorized || document.body.dataset.forbidden === "true") {
    return;
  }
  createForm?.addEventListener("submit", handleCreate);
  editForm?.addEventListener("submit", handleEdit);
  toggleButton?.addEventListener("click", handleToggle);
  resetButton?.addEventListener("click", handleResetPassword);
  deleteButton?.addEventListener("click", handleDelete);
  document.getElementById("reloadUsersButton")?.addEventListener("click", loadUsers);
  window.addEventListener("netvisor:manual-refresh", loadUsers);
  await loadUsers();
}

init().catch(notifyError);
