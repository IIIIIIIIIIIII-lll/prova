import { api, notifyError, renderSeverityBadge, renderStatus } from "./api.js";

const summaryTargets = {
  totalDevices: document.getElementById("totalDevices"),
  totalSecurityEvents: document.getElementById("totalSecurityEvents"),
  openAlerts: document.getElementById("openAlerts"),
  criticalAlerts: document.getElementById("criticalAlerts"),
  failedLogins: document.getElementById("failedLogins"),
  estimatedRequests: document.getElementById("estimatedRequests"),
  inactiveDevices: document.getElementById("inactiveDevices"),
  blockedEstimated: document.getElementById("blockedEstimated"),
  suspiciousEstimated: document.getElementById("suspiciousEstimated"),
  evadedEstimated: document.getElementById("evadedEstimated"),
};

function paintStat(element, value) {
  if (element) {
    element.textContent = `${value ?? 0}`;
  }
}

function renderHealthGrid(healthItems) {
  document.getElementById("platformHealthGrid").innerHTML = healthItems
    .map(
      (item) => `
        <article class="health-card">
          <div class="health-top">
            <span class="health-kind">${item.kind}</span>
            <span class="health-pill health-${item.status}">${item.status.toUpperCase()}</span>
          </div>
          <h4>${item.label}</h4>
          <p class="muted">${item.detail}</p>
        </article>
      `
    )
    .join("");
}

function renderTrendChart(trend) {
  const maxValue = Math.max(
    1,
    ...trend.flatMap((item) => [item.security_events || 0, item.alerts || 0, item.logins || 0])
  );
  document.getElementById("eventTrendChart").innerHTML = trend
    .map(
      (item) => `
        <div class="trend-day">
          <div class="trend-bars-stack">
            <span class="trend-bar trend-bar-events" style="height:${Math.max(8, ((item.security_events || 0) / maxValue) * 150)}px"></span>
            <span class="trend-bar trend-bar-alerts" style="height:${Math.max(8, ((item.alerts || 0) / maxValue) * 150)}px"></span>
            <span class="trend-bar trend-bar-logins" style="height:${Math.max(8, ((item.logins || 0) / maxValue) * 150)}px"></span>
          </div>
          <small>${item.label.slice(5)}</small>
        </div>
      `
    )
    .join("");
}

function renderProtocols(protocols) {
  const total = protocols.reduce((sum, item) => sum + (item.count || 0), 0) || 1;
  document.getElementById("protocolBreakdown").innerHTML = protocols
    .map(
      (item, index) => `
        <div class="protocol-chip">
          <span class="protocol-swatch protocol-color-${index % 6}"></span>
          <strong>${item.protocol}</strong>
          <span>${item.count}</span>
        </div>
      `
    )
    .join("");

  document.getElementById("protocolBars").innerHTML = protocols
    .map(
      (item, index) => `
        <div class="protocol-bar-row">
          <span>${item.protocol}</span>
          <div class="protocol-bar-track">
            <div class="protocol-bar-fill protocol-color-${index % 6}" style="width:${Math.max(8, (item.count / total) * 100)}%"></div>
          </div>
          <strong>${item.count}</strong>
        </div>
      `
    )
    .join("");
}

function renderTopAssets(rows) {
  document.getElementById("topAssetsTable").innerHTML = rows
    .map(
      (asset) => `
        <tr>
          <td>${asset.label}</td>
          <td>${asset.ip}</td>
          <td>${asset.risk_score}</td>
          <td>${asset.open_alerts}</td>
          <td>${asset.services}</td>
          <td>${renderStatus(asset.status)}</td>
        </tr>
      `
    )
    .join("");
}

function renderRecentAlerts(alerts) {
  document.getElementById("recentAlertsList").innerHTML = alerts
    .map(
      (alert) => `
        <article class="feed-item">
          <div class="feed-item-top">
            <strong>${alert.hostname || alert.ip || "Asset"}</strong>
            ${renderSeverityBadge(alert.severity)}
          </div>
          <p>${alert.description}</p>
          <small>${alert.type} - ${alert.status}</small>
        </article>
      `
    )
    .join("");
}

function renderRecentEvents(events) {
  document.getElementById("recentEventsFeed").innerHTML = events
    .map(
      (event) => `
        <article class="feed-item feed-item-compact">
          <div class="feed-item-top">
            <strong>${event.event_type}</strong>
            ${renderSeverityBadge(event.severity)}
          </div>
          <p>${event.message}</p>
          <small>${event.hostname || event.ip || event.source} - ${event.event_time}</small>
        </article>
      `
    )
    .join("");
}

function renderLatestScans(scans) {
  const table = document.getElementById("latestScansTable");
  if (!table) {
    return;
  }
  table.innerHTML = scans
    .map(
      (scan) => `
        <tr>
          <td>#${scan.id}</td>
          <td>${scan.scanner}</td>
          <td>${scan.target}</td>
          <td>${renderStatus(scan.status)}</td>
          <td>${scan.result_summary || scan.error_message || "-"}</td>
        </tr>
      `
    )
    .join("");
}

function updateRefreshTimestamp() {
  const target = document.getElementById("lastUpdatedAt");
  if (target) {
    target.textContent = `Ultimo aggiornamento: ${new Date().toLocaleTimeString("it-IT")}`;
  }
}

async function loadDashboard() {
  try {
    const [summary, operations] = await Promise.all([api.getDashboardSummary(), api.getDashboardOperations()]);
    const overview = operations.event_overview || {};

    paintStat(summaryTargets.totalDevices, overview.total_devices ?? summary.total_nodes);
    paintStat(summaryTargets.totalSecurityEvents, overview.total_security_events);
    paintStat(summaryTargets.openAlerts, overview.open_alerts ?? summary.open_alerts);
    paintStat(summaryTargets.criticalAlerts, overview.critical_alerts);
    paintStat(summaryTargets.failedLogins, overview.failed_logins);
    paintStat(summaryTargets.estimatedRequests, overview.requests_estimated);
    paintStat(summaryTargets.inactiveDevices, overview.inactive_devices ?? summary.offline_nodes);
    paintStat(summaryTargets.blockedEstimated, overview.blocked_estimated);
    paintStat(summaryTargets.suspiciousEstimated, overview.suspicious_estimated);
    paintStat(summaryTargets.evadedEstimated, overview.evaded_estimated);

    renderHealthGrid(operations.platform_health || []);
    renderTrendChart(operations.event_trend || []);
    renderProtocols(operations.protocols || []);
    renderTopAssets(operations.top_assets || []);
    renderRecentAlerts(operations.recent_alerts || []);
    renderRecentEvents(operations.recent_security_events || []);
    renderLatestScans(summary.latest_scans || []);
    updateRefreshTimestamp();
  } catch (error) {
    notifyError(error);
  }
}

loadDashboard();
window.setInterval(loadDashboard, 8000);
