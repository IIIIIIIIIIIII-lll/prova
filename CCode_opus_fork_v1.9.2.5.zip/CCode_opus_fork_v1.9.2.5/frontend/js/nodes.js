import { api, escapeHtml, notifyError, renderSeverityBadge, renderStatus } from "./api.js";

let activeStatus = "";

async function loadNodes() {
  try {
    const nodes = await api.getNodes(activeStatus);
    document.getElementById("nodesCount").textContent = `${nodes.length} assets`;
    document.getElementById("nodesTable").innerHTML = nodes
      .map(
        (node) => `
          <tr class="clickable-row" data-node-id="${Number(node.id) || 0}">
            <td>#${Number(node.id) || 0}</td>
            <td>${escapeHtml(node.hostname || "-")}</td>
            <td>${escapeHtml(node.ip)}</td>
            <td>${renderStatus(node.status)}</td>
            <td>${escapeHtml(node.os_guess || "-")}</td>
            <td>${Number(node.risk_score) || 0}</td>
          </tr>
        `
      )
      .join("");

    document.querySelectorAll("[data-node-id]").forEach((row) => {
      row.addEventListener("click", () => loadNodeDetail(row.dataset.nodeId));
    });
  } catch (error) {
    notifyError(error);
  }
}

async function loadNodeDetail(nodeId) {
  try {
    const [node, services, alerts, logins] = await Promise.all([
      api.getNode(nodeId),
      api.getNodeServices(nodeId),
      api.getNodeAlerts(nodeId),
      api.getNodeLogins(nodeId),
    ]);

    document.getElementById("nodeSelectionLabel").textContent = `${node.hostname || node.ip} - ${node.ip}`;
    document.getElementById("nodeServicesTable").innerHTML = services
      .map(
        (service) => `
          <tr>
            <td>${Number(service.port) || 0}</td>
            <td>${escapeHtml(service.protocol)}</td>
            <td>${renderStatus(service.state)}</td>
            <td>${escapeHtml(service.service_name || "-")}</td>
            <td>${escapeHtml([service.product, service.version].filter(Boolean).join(" ") || "-")}</td>
          </tr>
        `
      )
      .join("");

    document.getElementById("nodeAlertsTable").innerHTML = alerts
      .map(
        (alert) => `
          <tr>
            <td>#${Number(alert.id) || 0}</td>
            <td>${renderSeverityBadge(alert.severity)}</td>
            <td>${escapeHtml(alert.description)}</td>
          </tr>
        `
      )
      .join("");

    document.getElementById("nodeLoginsTable").innerHTML = logins
      .map(
        (login) => `
          <tr>
            <td>${escapeHtml(login.username)}</td>
            <td>${escapeHtml(login.source || "-")}</td>
            <td>${escapeHtml(login.result)}</td>
            <td>${escapeHtml(login.timestamp || "-")}</td>
          </tr>
        `
      )
      .join("");
  } catch (error) {
    notifyError(error);
  }
}

document.querySelectorAll("[data-status]").forEach((button) => {
  button.addEventListener("click", async () => {
    document.querySelectorAll("[data-status]").forEach((item) => item.classList.remove("active-filter"));
    button.classList.add("active-filter");
    activeStatus = button.dataset.status;
    await loadNodes();
  });
});

window.addEventListener("netvisor:manual-refresh", loadNodes);
loadNodes();
