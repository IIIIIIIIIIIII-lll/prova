import {
  api,
  consumeAdminLoginNotice,
  ensureAuthenticated,
  escapeHtml,
  formatDateTimeShort,
  formatTimeOnly,
  getCurrentUserSync,
  isAdminUser,
  mountApiPopover,
  renderSeverityBadge,
  renderStatus,
} from "./api.js";
import { mountModeBanner } from "./mode-banner.js";

// NetVisor è LIVE-only: il banner non ha più stati dinamici (DEMO/clean/warn).
// L'event "netvisor:mode-meta" è ignorato; mountModeBanner mostra solo
// il chip "LIVE vX.Y.Z" una volta al boot e al re-mount della topbar.

const NAV_ITEMS = [
  { key: "dashboard",     label: "Dashboard",       href: "index.html",         icon: "⬛" },
  { key: "topology",      label: "Topology",         href: "topology.html",      icon: "🌐" },
  { key: "scan-jobs",     label: "Scan & Monitor",   href: "scan-jobs.html",     icon: "🔍", adminOnly: true },
  // Agents page hidden from nav — backend agent endpoints remain fully active.
  // To restore: uncomment the line below and rebuild frontend.
  // { key: "agents", label: "Agents", href: "agents.html", icon: "💻" },
  { key: "alerts",        label: "Alerts",           href: "alerts.html",        icon: "🔔" },
  { key: "logs",          label: "Logs",             href: "logs.html",          icon: "📋" },
  { key: "reports",       label: "Reports",          href: "reports.html",       icon: "📊" },
  { key: "settings",      label: "Settings",         href: "settings.html",      icon: "🛡️" },
  { key: "users",         label: "Users",            href: "users.html",         icon: "👥", adminOnly: true },
];

const PAGE_META = {
  dashboard: {
    eyebrow: "NetVisor Command Center",
    title: "Enterprise SIEM Dashboard",
    subtitle: "Overview NOC/SOC con KPI, trend eventi, recent alerts e stato servizi di laboratorio.",
  },
  topology: {
    eyebrow: "NetVisor Topology",
    title: "Cloud & Container Topology",
    subtitle: "Vista a zone logiche, cloud drill-down e flow read-only tra componenti.",
  },
  "admin-console": {
    eyebrow: "NetVisor Admin",
    title: "Console Migrata",
    subtitle: "Le funzioni admin sono state consolidate in Scan & Monitor e Logs. Clicca per andare su Scan & Monitor.",
  },
  agents: {
    eyebrow: "NetVisor Endpoint Telemetry",
    title: "Agent Monitoring & Alerting",
    subtitle: "Heartbeat, metriche host, servizi osservati e segnali di rischio dagli endpoint autorizzati.",
  },
  alerts: {
    eyebrow: "NetVisor Alert Center",
    title: "Offenses, Alerts & Response",
    subtitle: "Alerting operativo con filtri, severity, stato, ack/close e contesto tecnico.",
  },
  logs: {
    eyebrow: "NetVisor Security Activity",
    title: "Login, Audit & User Activity",
    subtitle: "Vista chiara per audit, login, attivita utenti e riepilogo anomalie.",
  },
  reports: {
    eyebrow: "NetVisor Operations Reports",
    title: "Network Activity & Scan Reports",
    subtitle: "Scans recenti, raw snippets, servizi esposti e risultati tecnici in forma densa.",
  },
  settings: {
    eyebrow: "NetVisor Platform Settings",
    title: "Security Controls & Identity",
    subtitle: "Password policy, sessioni, auth hardening e configurazioni di laboratorio.",
  },
  users: {
    eyebrow: "NetVisor Identity",
    title: "Users & Roles Administration",
    subtitle: "Gestione account, ruoli, reset password e stato attivazione per admin.",
  },
  "scan-jobs": {
    eyebrow: "NetVisor Scheduler",
    title: "Scan Jobs & Availability Checks",
    subtitle: "Job di scansione dichiarativi (nmap/masscan) e monitor di disponibilità ICMP/TCP/HTTP in un'unica console.",
  },
  connections: {
    eyebrow: "NetVisor Network Overview",
    title: "Connection Monitoring",
    subtitle: "Controlli di disponibilità ICMP/TCP/HTTP — ora integrati in Scan & Monitor.",
  },
};

const ADMIN_ONLY_PAGES = new Set(["users", "scan-jobs"]);

function renderNav(activeKey) {
  const admin = isAdminUser();
  return NAV_ITEMS.filter((item) => !item.adminOnly || admin)
    .map((item) => `
      <a class="sidebar-link ${item.key === activeKey ? "active" : ""}" href="${item.href}">
        <span class="sidebar-icon">${item.icon || "·"}</span>
        <span class="sidebar-label">${item.label}</span>
        ${item.key === "alerts" ? '<span id="navAlertBadge" class="nav-badge" hidden>0</span>' : ""}
      </a>
    `).join("");
}

function renderUserBadge() {
  const user = getCurrentUserSync();
  if (!user) {
    return `<span class="badge micro-badge state-bad">guest</span>`;
  }
  // ── Box session info ─────────────────────────────────────────────────────
  // Formato richiesto: "Username: [nome] | Ruolo: [ruolo] | Stato: [stato]"
  // (vedi PDF Errori_v4.2 §2.3). Ogni coppia label:value ha whitespace esplicito
  // e separatore "|" per evitare il bug "forema""Username" attaccato.
  const stateLabel = user.is_active === false ? "inactive" : "active";
  const stateBadgeClass = user.is_active === false ? "state-bad" : "state-ok";
  const roleBadgeClass = user.role === "admin" ? "severity-medium" : "severity-info";
  const displayName = user.display_name || user.username;
  return `
    <span class="topbar-user-box">
      <span class="topbar-user-pair"><small>Username:</small> <strong>${displayName}</strong></span>
      <span class="topbar-user-sep">|</span>
      <span class="topbar-user-pair"><small>Ruolo:</small> <span class="badge micro-badge ${roleBadgeClass}">${user.role}</span></span>
      <span class="topbar-user-sep">|</span>
      <span class="topbar-user-pair"><small>Stato:</small> <span class="badge micro-badge ${stateBadgeClass}">${stateLabel}</span></span>
    </span>
  `;
}

function renderForbiddenState(content) {
  document.body.dataset.forbidden = "true";
  content.innerHTML = `
    <section class="panel forbidden-panel">
      <p class="eyebrow">Access Control</p>
      <h2>403 - Operazione non autorizzata</h2>
      <p class="muted">La pagina richiesta e disponibile solo per utenti con ruolo admin.</p>
      <div class="table-actions">
        <a class="primary-button inline-button" href="index.html">Torna alla dashboard</a>
        <a class="ghost-button inline-button" href="settings.html">Profilo</a>
      </div>
    </section>
  `;
}

function renderShellFrame(pageKey, meta, content) {
  const shell = document.createElement("div");
  shell.className = "app-shell";
  shell.innerHTML = `
    <aside class="app-sidebar">
      <div class="sidebar-brand">
        <div class="brand-mark">NV</div>
        <div>
          <strong>NetVisor</strong>
          <small>Lab SIEM Console</small>
        </div>
      </div>
      <nav class="sidebar-nav">${renderNav(pageKey)}</nav>
      <div class="sidebar-foot">
        <span class="subtle">Authorized lab only</span>
        <span class="sidebar-status-dot"></span>
      </div>
    </aside>
    <div class="app-main">
      <header class="app-topbar">
        <div class="topbar-heading">
          <h1>${meta.title}</h1>
        </div>
        <div class="topbar-actions">
          <span id="apiStateChip" class="badge micro-badge state-idle">API checking</span>
          <span id="refreshTimeChip" class="topbar-meta">ultimo refresh --:--:--</span>
          <label class="topbar-select" title="Finestra temporale per i dati mostrati nelle tabelle/grafici della pagina corrente">
            <span>Mostra dati di</span>
            <select id="timeRangeSelect">
              <option value="15m">Ultimi 15 min</option>
              <option value="1h" selected>Ultima ora</option>
              <option value="24h">Ultime 24 ore</option>
              <option value="7d">Ultimi 7 giorni</option>
            </select>
          </label>
          <label class="topbar-search">
            <span>Search</span>
            <input id="topbarSearchInput" type="text" placeholder="log, host, service">
          </label>
          <button id="manualRefreshButton" class="topbar-button" type="button">↺ Refresh</button>
          <button id="notificationButton" class="topbar-button" type="button">🔔 Alerts</button>
          <button id="themeToggleButton" class="topbar-button icon-button" type="button" title="Cambia tema">🌛</button>
          <div class="topbar-profile">${renderUserBadge()}</div>
          <button id="logoutButton" class="topbar-button ghost-button" type="button" title="Logout">⏏</button>
          <div id="apiPopoverSlot"></div>
        </div>
      </header>
      <div class="app-workspace">
        <section class="workspace-main"></section>
        <aside class="workspace-rail">
          <section class="rail-panel">
            <div class="rail-head">
              <h3>Recent Alerts</h3>
              <span id="railAlertCount" class="subtle">0</span>
            </div>
            <div id="railAlerts" class="rail-feed"></div>
          </section>
          <section class="rail-panel">
            <div class="rail-head">
              <h3>Latest Events</h3>
              <span class="subtle">live GET</span>
            </div>
            <div id="railEvents" class="rail-feed"></div>
          </section>
          <section class="rail-panel">
            <div class="rail-head">
              <h3>Platform State</h3>
            </div>
            <div id="railHealth" class="rail-grid"></div>
          </section>
        </aside>
      </div>
    </div>
  `;

  document.body.insertBefore(shell, content);
  shell.querySelector(".workspace-main").appendChild(content);
  mountApiPopover(shell.querySelector("#apiPopoverSlot"));
  bindShellInteractions();
  return shell;
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  localStorage.setItem("nv-theme", theme);
  const btn = document.getElementById("themeToggleButton");
  if (btn) btn.textContent = theme === "light" ? "🔆" : "🌛";
}

// ── Global Search (PDF Errori_v4.2 §4.3) ──────────────────────────────────
// Filtra in tempo reale TUTTI i <tr> dentro le table > tbody nella workspace
// principale: nasconde le righe il cui textContent non contiene la query
// (case-insensitive). Termine vuoto → ripristina tutte le righe.
//
// Performance: debounce 120ms per evitare reflow su input grossi.
// Scope: limitato a `.app-workspace` e a tabelle visibili. Non tocca i tr
// nelle rail (Recent Alerts/Latest Events) per mantenere lo state real-time.
let _globalSearchDebounce = null;
function applyGlobalSearch(rawTerm) {
  const term = (rawTerm || "").trim().toLowerCase();
  const tables = document.querySelectorAll(".app-workspace table tbody, .workspace-main table tbody");
  tables.forEach((tbody) => {
    if (!tbody.children.length) return;
    Array.from(tbody.children).forEach((tr) => {
      if (tr.tagName !== "TR") return;
      // Skip placeholder messaggi tipo "<tr><td colspan>Nessun dato</td></tr>"
      // (questi hanno classi muted o un solo td con colspan).
      if (!term) {
        tr.style.display = "";
        return;
      }
      const text = (tr.textContent || "").toLowerCase();
      tr.style.display = text.includes(term) ? "" : "none";
    });
  });
}

function bindShellInteractions() {
  document.getElementById("manualRefreshButton")?.addEventListener("click", () => {
    refreshShellData();
    window.dispatchEvent(new CustomEvent("netvisor:manual-refresh"));
  });
  document.getElementById("notificationButton")?.addEventListener("click", () => {
    window.location.href = "alerts.html";
  });
  document.getElementById("themeToggleButton")?.addEventListener("click", () => {
    const current = document.documentElement.dataset.theme || "dark";
    applyTheme(current === "dark" ? "light" : "dark");
  });
  document.getElementById("logoutButton")?.addEventListener("click", async () => {
    try { await api.logout(); } catch(_) {}
    sessionStorage.clear();
    window.location.href = "login.html";
  });
  // Global Search live filter
  document.getElementById("topbarSearchInput")?.addEventListener("input", (e) => {
    const value = e.target.value;
    if (_globalSearchDebounce) clearTimeout(_globalSearchDebounce);
    _globalSearchDebounce = setTimeout(() => applyGlobalSearch(value), 120);
  });
}

// ── PDF Errori_v4.2 §3 — Filtro semantico Recent Alerts vs Latest Events ──
// Per evitare ridondanza visiva nella sidebar destra:
//   Recent Alerts → SOLO anomalie / fallimenti / soglie superate
//                   (severity warning/medium/high/critical o status='failed')
//   Latest Events → SOLO log informativi / test conclusi con successo
//                   (severity info/low o test result='success')
// Il filtro è lato frontend (server-side resterebbe più pulito ma richiederebbe
// parametri API; lato client è sufficiente per la rail e mantiene flessibilità).

const _ALERT_SEVERITY_RANK = { critical: 4, high: 3, warning: 2, medium: 2, low: 1, info: 0 };
function _isAnomalous(item) {
  // Criterio: severity >= warning/medium OPPURE status indica fallimento
  const sev = String(item.severity || "").toLowerCase();
  const status = String(item.status || "").toLowerCase();
  const result = String(item.result || "").toLowerCase();
  if (status === "failed" || result === "failed" || result === "error") return true;
  return (_ALERT_SEVERITY_RANK[sev] ?? 0) >= 2;
}
function _isInformational(item) {
  // Criterio: severity info/low (NON warning+) E nessuna status fallimento
  const sev = String(item.severity || "").toLowerCase();
  const status = String(item.status || "").toLowerCase();
  const result = String(item.result || "").toLowerCase();
  if (status === "failed" || result === "failed" || result === "error") return false;
  return (_ALERT_SEVERITY_RANK[sev] ?? 0) <= 1;
}

function renderRailAlerts(alerts) {
  const container = document.getElementById("railAlerts");
  const count = document.getElementById("railAlertCount");
  if (!container || !count) {
    return;
  }
  // Filtro semantico: solo anomalie/fallimenti/soglie nei Recent Alerts.
  // Esclude alert in stato 'closed'/'deleted' (già processati).
  const filtered = (alerts || []).filter((a) => {
    const status = String(a.status || "").toLowerCase();
    if (status === "closed" || status === "deleted") return false;
    return _isAnomalous(a);
  });
  const rows = filtered.slice(0, 6);
  count.textContent = `${rows.length}`;
  container.innerHTML = rows
    .map(
      (item) => `
        <article class="rail-item">
          <div class="rail-item-top">
            <strong>${escapeHtml(item.type)}</strong>
            ${renderSeverityBadge(item.severity)}
          </div>
          <p>${escapeHtml(item.description)}</p>
          <small>${escapeHtml(item.hostname || item.ip || "system")} - ${escapeHtml(item.status)}</small>
        </article>
      `
    )
    .join("") || `<p class="muted" style="padding:.5rem">Nessuna anomalia attiva.</p>`;
}

function renderRailEvents(events) {
  const container = document.getElementById("railEvents");
  if (!container) {
    return;
  }
  // Filtro semantico: solo eventi info/success nel Latest Events feed.
  const filtered = (events || []).filter(_isInformational);
  const rows = filtered.slice(0, 6);
  container.innerHTML = rows
    .map(
      (item) => `
        <article class="rail-item rail-item-compact">
          <div class="rail-item-top">
            <strong>${escapeHtml(item.event_type || item.level || item.action || "event")}</strong>
            <span class="badge micro-badge">${escapeHtml(item.hostname || item.agent_id || item.source || item.actor || "feed")}</span>
          </div>
          <p>${escapeHtml(item.message || item.details || "-")}</p>
          <small>${escapeHtml(formatDateTimeShort(item.event_time || item.received_at || item.created_at))}</small>
        </article>
      `
    )
    .join("") || `<p class="muted" style="padding:.5rem">Nessun evento informativo recente.</p>`;
}

function renderRailHealth(items) {
  const container = document.getElementById("railHealth");
  if (!container) {
    return;
  }
  container.innerHTML = (items || [])
    .slice(0, 5)
    .map(
      (item) => `
        <div class="rail-health-card">
          <span>${item.label}</span>
          <strong class="state-${item.status === "up" ? "ok" : item.status === "warn" ? "warn" : "bad"}">${item.status.toUpperCase()}</strong>
          <small>${item.kind}</small>
        </div>
      `
    )
    .join("");
}

function showAdminLoginModal(notice) {
  if (!notice) {
    return;
  }
  const modal = document.createElement("div");
  modal.className = "auth-modal-backdrop";
  modal.innerHTML = `
    <div class="auth-modal">
      <p class="eyebrow">Accesso amministratore rilevato</p>
      <h3>Login admin effettuato: ${notice.username}</h3>
      <p class="muted">${notice.message}</p>
      <dl class="auth-modal-meta">
        <div><dt>Timestamp</dt><dd>${notice.timestamp}</dd></div>
        <div><dt>IP</dt><dd>${notice.ip || "unknown"}</dd></div>
      </dl>
      <div class="table-actions">
        <button id="dismissAdminLoginModal" class="primary-button inline-button" type="button">OK</button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
  modal.addEventListener("click", (event) => {
    if (event.target === modal) {
      modal.remove();
    }
  });
  modal.querySelector("#dismissAdminLoginModal")?.addEventListener("click", () => modal.remove());
}

async function refreshShellData() {
  try {
    const [health, alerts, operations] = await Promise.all([
      api.getHealth(),
      api.getAlerts(),
      api.getDashboardOperations(),
    ]);
    const apiState = document.getElementById("apiStateChip");
    const refreshChip = document.getElementById("refreshTimeChip");
    if (apiState) {
      apiState.textContent = `API ${health.status}`;
      apiState.className = "badge micro-badge state-ok";
    }
    if (refreshChip) {
      refreshChip.textContent = `ultimo refresh ${formatTimeOnly(new Date())}`;
    }
    renderRailAlerts(alerts);
    renderRailEvents(
      [
        ...(operations.recent_security_events || []),
        ...((operations.agents_overview && operations.agents_overview.recent_events) || []),
      ].slice(0, 6)
    );
    renderRailHealth(operations.platform_health || []);
  } catch (_error) {
    const apiState = document.getElementById("apiStateChip");
    if (apiState) {
      apiState.textContent = "API down";
      apiState.className = "badge micro-badge state-bad";
    }
  }
}

async function renderShell() {
  const body = document.body;
  const pageKey = body.dataset.page || "dashboard";
  const content = document.getElementById("pageContent");
  if (!content) {
    return;
  }

  const guard = await ensureAuthenticated({ adminOnly: ADMIN_ONLY_PAGES.has(pageKey) });
  if (!guard.authenticated) {
    return;
  }

  const meta = PAGE_META[pageKey] || PAGE_META.dashboard;
  body.classList.add("netvisor-body");
  const savedTheme = localStorage.getItem("nv-theme") || "dark";
  document.documentElement.dataset.theme = savedTheme;

  renderShellFrame(pageKey, meta, content);

  if (ADMIN_ONLY_PAGES.has(pageKey) && !guard.authorized) {
    renderForbiddenState(content);
  }

  refreshShellData();
  window.setInterval(refreshShellData, 8000);

  const notice = consumeAdminLoginNotice();
  if (notice && isAdminUser()) {
    showAdminLoginModal(notice);
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    renderShell().catch(console.error);
  }, { once: true });
} else {
  renderShell().catch(console.error);
}
