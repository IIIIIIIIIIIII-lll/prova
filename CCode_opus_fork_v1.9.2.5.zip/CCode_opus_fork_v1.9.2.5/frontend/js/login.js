import { api, ensureAuthenticated, getApiBaseUrl, notifyError, setApiBaseUrl } from "./api.js";

const form = document.getElementById("loginForm");
const message = document.getElementById("loginMessage");
const baseUrlInput = document.getElementById("loginBaseUrlInput");

function nextDestination() {
  const params = new URLSearchParams(window.location.search);
  return params.get("next") || "index.html";
}

async function bootstrapExistingSession() {
  const result = await ensureAuthenticated();
  if (!result.authenticated) {
    return;
  }
  window.location.href = nextDestination();
}

// ── Popup escalation per login lockout policy (PDF Errori_v3 #3) ───────────
// Stati ricevuti dal backend in error.lockout:
//   warn       → 3° tentativo: warning, no lock
//   soft_lock  → 4° tentativo: 10min lock, primo blocco
//   re_lock    → 5° tentativo: altri 10min, prossima volta = DISABLE
//   disabled   → 6°+ tentativo: account disabilitato, contattare admin
function showLockoutPopup(lockout) {
  if (!lockout || !lockout.lockout_state) return;
  const lockMin = lockout.lock_minutes || 10;
  const messages = {
    warn:
      "⚠ Attenzione: 3° tentativo di login fallito.\n\n" +
      "Al prossimo errore l'account verrà BLOCCATO temporaneamente per " + lockMin + " minuti.",
    soft_lock:
      "🔒 Account bloccato temporaneamente.\n\n" +
      "Per motivi di sicurezza è stato applicato un blocco di " + lockMin + " minuti.\n" +
      "Si prega di NON tentare l'accesso in questo intervallo.\n" +
      "L'account verrà sbloccato automaticamente allo scadere del tempo.",
    re_lock:
      "🔒🔒 Account ri-bloccato per altri " + lockMin + " minuti.\n\n" +
      "ATTENZIONE: il prossimo tentativo di login prima dello scadere del lock\n" +
      "comporterà la DISABILITAZIONE permanente dell'account.\n" +
      "Sarà necessario contattare l'amministratore per riattivarlo.",
    disabled:
      "⛔ ACCOUNT DISABILITATO\n\n" +
      "Troppi tentativi di accesso non consentiti hanno comportato\n" +
      "la disabilitazione permanente dell'account.\n" +
      "Contattare l'amministratore di sistema per la riattivazione.",
  };
  const text = messages[lockout.lockout_state];
  if (text) window.alert(text);
}

async function handleLogin(event) {
  event.preventDefault();
  message.textContent = "Login in corso...";

  try {
    const data = new FormData(form);
    setApiBaseUrl(data.get("base_url"));
    const auth = await api.login(data.get("username"), data.get("password"));
    message.textContent = auth.user.must_change_password
      ? "Password iniziale valida. Reindirizzamento al cambio password..."
      : "Accesso completato. Reindirizzamento...";
    const destination = auth.user.must_change_password ? "settings.html?force_password_change=1" : nextDestination();
    window.location.href = destination;
  } catch (error) {
    message.textContent = error.message || "Credenziali non valide.";
    // Se il backend ha allegato info lockout, mostra il popup specifico.
    if (error.lockout) {
      showLockoutPopup(error.lockout);
    } else {
      notifyError(error);
    }
  }
}

baseUrlInput.value = getApiBaseUrl();
form?.addEventListener("submit", handleLogin);
bootstrapExistingSession().catch(() => {});
