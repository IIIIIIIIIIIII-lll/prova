import { api, getCurrentUserSync, notifyError, notifySuccess } from "./api.js";

const profileCard = document.getElementById("settingsProfileCard");
const passwordForm = document.getElementById("changePasswordForm");
const passwordMessage = document.getElementById("changePasswordMessage");

function renderProfile() {
  const user = getCurrentUserSync();
  if (!profileCard || !user) {
    return;
  }

  const dataDb = user.last_login_at;
  const dataOggetto = new Date(dataDb);
  const formattatore = new Intl.DateTimeFormat('it-IT', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
  const giorno = String(dataOggetto.getDate()).padStart(2, '0');
  const mese = String(dataOggetto.getMonth() + 1).padStart(2, '0');
  const anno = dataOggetto.getFullYear();

  const dataNormale = `${giorno}/${mese}/${anno}`;

  profileCard.className = "detail-stack";
  profileCard.innerHTML = `
    <div class="detail-kpi-row">
      <span class="detail-kpi"><small>Username: </small><strong>${user.username}</strong></span>
      <span class="detail-kpi"><small>Ruolo: </small><strong>${user.role}</strong></span>
      <span class="detail-kpi"><small>Stato: </small><strong>${user.is_active ? "active" : "disabled"}</strong></span>
    </div>
    <div class="detail-grid">
      <div>
        <h4>${user.display_name || user.username}</h4>
        <p>${user.email || "Email non impostata"}</p>
      </div>
      <div>
        <h4>Ultimo login</h4>
        <p>${dataNormale || "-"}</p>
      </div>
      <div>
        <h4>Policy bootstrap</h4>
        <p class="${user.must_change_password ? "warning-text" : "muted"}">
          ${user.must_change_password ? "Cambio password obbligatorio prima dell'uso continuativo." : "Password aggiornata regolarmente."}
        </p>
      </div>
    </div>
  `;
}

async function loadProfile() {
  try {
    await api.getMe();
    renderProfile();
  } catch (error) {
    notifyError(error);
  }
}

async function changePassword(event) {
  event.preventDefault();
  passwordMessage.textContent = "Aggiornamento password in corso...";
  const formData = new FormData(passwordForm);
  const currentPassword = String(formData.get("current_password") || "");
  const newPassword = String(formData.get("new_password") || "");
  const confirmPassword = String(formData.get("confirm_password") || "");

  if (newPassword !== confirmPassword) {
    passwordMessage.textContent = "Le password non coincidono.";
    return;
  }

  try {
    await api.changePassword({
      current_password: currentPassword,
      new_password: newPassword,
    });
    notifySuccess("Password aggiornata. Esegui di nuovo il login.");
    passwordMessage.textContent = "Password aggiornata. Reindirizzamento al login...";
    await api.logout();
    window.location.href = "login.html";
  } catch (error) {
    passwordMessage.textContent = error.message || "Errore aggiornamento password.";
    // PDF Errori_v4.2 §2.2: se il backend ha inviato lockout escalation
    // (warn/soft_lock/re_lock/disabled), mostra popup specifico come per la
    // login. Allertiamo l'utente che ulteriori tentativi falliti porteranno
    // a lock progressivi e infine al disable permanente.
    if (error.lockout && error.lockout.lockout_state) {
      const lockMin = error.lockout.lock_minutes || 15;
      const popups = {
        warn:
          "⚠ Attenzione: 3° tentativo di password ATTUALE errata.\n\n" +
          "Al prossimo errore l'account verrà bloccato per " + lockMin + " minuti.",
        soft_lock:
          "🔒 Account bloccato.\n\n" +
          "Per " + lockMin + " minuti non potrai effettuare login né cambio password.\n" +
          "Il blocco si rilascia automaticamente — non insistere prima dello scadere.",
        re_lock:
          "🔒🔒 Re-lock " + lockMin + " minuti.\n\n" +
          "ATTENZIONE: il prossimo errore prima dello scadere\n" +
          "comporterà la DISABILITAZIONE permanente dell'account.",
        disabled:
          "⛔ ACCOUNT DISABILITATO\n\n" +
          "Troppi errori di password attuale. L'account è stato disattivato.\n" +
          "Contattare l'amministratore di sistema.",
      };
      const text = popups[error.lockout.lockout_state];
      if (text) window.alert(text);
      // Se disabled, force logout perché l'account è morto
      if (error.lockout.lockout_state === "disabled") {
        try { await api.logout(); } catch (_) {}
        sessionStorage.clear();
        window.location.href = "login.html";
      }
    } else {
      notifyError(error);
    }
  }
}

passwordForm?.addEventListener("submit", changePassword);
loadProfile();
