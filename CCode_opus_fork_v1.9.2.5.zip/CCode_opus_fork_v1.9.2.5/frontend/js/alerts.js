import { api, escapeHtml, exportTableToCSV, formatDateTime, formatDateTimeShort, isAdminUser, notifyError, renderSeverityBadge, renderStatus } from "./api.js";

let allAlerts = [];
let deletedAlerts = [];

function summarize(alerts) {
  // KPI escludono già i deleted (la API list_alerts li nasconde di default).
  // Total Alerts ora DECRESCE quando un alert viene eliminato (vedi PDF #1).
  const open = alerts.filter((item) => item.status === "open").length;
  const ack = alerts.filter((item) => item.status === "ack").length;
  const high = alerts.filter((item) => ["high", "critical"].includes(item.severity)).length;
  document.getElementById("alertsOpenKpi").textContent = open;
  document.getElementById("alertsAckKpi").textContent = ack;
  document.getElementById("alertsHighKpi").textContent = high;
  document.getElementById("alertsTotalKpi").textContent = alerts.length;
}

function renderSeverityMix(alerts) {
  const counts = ["critical", "high", "medium", "low", "info"].map((severity) => ({
    label: severity,
    count: alerts.filter((item) => item.severity === severity).length,
  }));
  const total = Math.max(1, ...counts.map((item) => item.count));
  document.getElementById("alertsSeverityBars").innerHTML = counts
    .map(
      (item, index) => `
        <div class="protocol-bar-row">
          <span>${item.label}</span>
          <div class="protocol-bar-track">
            <div class="protocol-bar-fill protocol-color-${index % 6}" style="width:${Math.max(6, (item.count / total) * 100)}%"></div>
          </div>
          <strong>${item.count}</strong>
        </div>
      `
    )
    .join("");
}

// ── Date filter parsing ───────────────────────────────────────────────────
// Formati accettati:
//   "" / null         → no filter
//   "today"           → oggi (dalla mezzanotte locale)
//   "yesterday"       → ieri (00:00 → 23:59)
//   "Nd" (es. "7d")   → ultimi N giorni (rolling)
//   "YYYY-MM-DD"      → quel giorno specifico (00:00 → 23:59)
function parseDateFilter(raw) {
  const v = (raw || "").trim().toLowerCase();
  if (!v) return null;
  const now = new Date();
  const startOfDay = (d) => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; };
  const endOfDay = (d) => { const x = new Date(d); x.setHours(23, 59, 59, 999); return x; };
  if (v === "today") {
    return { from: startOfDay(now), to: endOfDay(now) };
  }
  if (v === "yesterday") {
    const y = new Date(now); y.setDate(y.getDate() - 1);
    return { from: startOfDay(y), to: endOfDay(y) };
  }
  const dayMatch = v.match(/^(\d+)d$/);
  if (dayMatch) {
    const days = parseInt(dayMatch[1], 10);
    const from = new Date(now); from.setDate(from.getDate() - days);
    return { from: startOfDay(from), to: endOfDay(now) };
  }
  // Formato YYYY-MM-DD (con o senza giorno valido)
  const isoMatch = v.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (isoMatch) {
    const [, y, m, d] = isoMatch;
    const date = new Date(parseInt(y, 10), parseInt(m, 10) - 1, parseInt(d, 10));
    if (isNaN(date.getTime())) return null;
    return { from: startOfDay(date), to: endOfDay(date) };
  }
  return null;
}

function getFilteredAlerts() {
  const severity = document.getElementById("severityFilter").value;
  const status = document.getElementById("statusFilter").value;
  const search = document.getElementById("alertSearchInput").value.trim().toLowerCase();
  const dateFilter = parseDateFilter(document.getElementById("alertDateFilter")?.value);
  return allAlerts.filter((item) => {
    if (severity && item.severity !== severity) return false;
    if (status && item.status !== status) return false;
    if (search) {
      const haystack = [item.type, item.hostname, item.ip, item.description, item.status].join(" ").toLowerCase();
      if (!haystack.includes(search)) return false;
    }
    if (dateFilter && item.timestamp) {
      const ts = new Date(item.timestamp);
      if (isNaN(ts.getTime())) return false;
      if (ts < dateFilter.from || ts > dateFilter.to) return false;
    }
    return true;
  });
}

function renderCriticalFeed(alerts) {
  document.getElementById("criticalAlertsFeed").innerHTML = alerts
    .filter((item) => ["high", "critical"].includes(item.severity))
    .slice(0, 8)
    .map(
      (alert) => `
        <article class="feed-item">
          <div class="feed-item-top">
            <strong>${escapeHtml(alert.type)}</strong>
            ${renderSeverityBadge(alert.severity)}
          </div>
          <p>${escapeHtml(alert.description)}</p>
          <small>${escapeHtml(alert.hostname || alert.ip || "system")} — ${escapeHtml(formatDateTimeShort(alert.timestamp))}</small>
        </article>
      `
    )
    .join("");
}

// ── Action handler con state machine + popup conferma Delete ──────────────
async function handleAlertAction(action, alertId, currentStatus) {
  if (action === "delete" && currentStatus !== "closed") {
    // Popup di sicurezza accidentale: il flusso è ACK → Close → Delete.
    alert(
      "Task non elaborato!\n\n" +
      "L'alert deve essere in stato 'closed' per poterlo eliminare.\n" +
      "Procedi con il flusso ACK → Close prima di eliminare."
    );
    return;
  }
  if (action === "delete") {
    // Conferma eliminazione (anche per closed, per evitare delete accidentali)
    if (!window.confirm(`Eliminare definitivamente l'alert #${alertId}?\n\n` +
                        "L'alert sarà spostato nella tabella 'Deleted Tasks' (soft-delete).\n" +
                        "I contatori OPEN ALERTS e TOTAL ALERTS si aggiornano di conseguenza.")) {
      return;
    }
  }
  try {
    if (action === "ack") await api.ackAlert(alertId);
    else if (action === "close") await api.closeAlert(alertId);
    else if (action === "delete") await api.deleteAlert(alertId);
    await loadAlerts();
  } catch (error) {
    notifyError(error);
  }
}

function bindActions() {
  if (!isAdminUser()) return;
  document.querySelectorAll("#alertsTable [data-alert-action]").forEach((button) => {
    button.addEventListener("click", (event) => {
      event.stopPropagation();
      const action = button.dataset.alertAction;
      const alertId = button.dataset.alertId;
      const currentStatus = button.dataset.alertStatus;
      handleAlertAction(action, alertId, currentStatus);
    });
  });
}

function renderActionButtons(alert, admin) {
  if (!admin) return `<span class="muted">read only</span>`;
  const id = Number(alert.id) || 0;
  const status = alert.status;
  // Logica enable: ACK abilitato solo da open, Close solo da ack, Delete solo da closed.
  // I disabilitati hanno l'attributo `disabled` e tooltip esplicativo.
  const ackDisabled = status !== "open";
  const closeDisabled = status !== "ack";
  const deleteDisabled = status !== "closed";
  return `
    <div class="table-actions">
      <button class="ghost-button" type="button"
              data-alert-action="ack" data-alert-id="${id}" data-alert-status="${escapeHtml(status)}"
              ${ackDisabled ? "disabled" : ""}
              title="${ackDisabled ? "ACK consentito solo da stato 'open'" : "Acknowledge"}">ACK</button>
      <button class="ghost-button" type="button"
              data-alert-action="close" data-alert-id="${id}" data-alert-status="${escapeHtml(status)}"
              ${closeDisabled ? "disabled" : ""}
              title="${closeDisabled ? "Close richiede ACK preventivo" : "Close"}">Close</button>
      <button class="ghost-button" type="button"
              data-alert-action="delete" data-alert-id="${id}" data-alert-status="${escapeHtml(status)}"
              title="${deleteDisabled ? "Delete consentito solo da stato 'closed'" : "Delete (soft, va in Deleted Tasks)"}"
              style="${deleteDisabled ? "opacity:.5" : "border-color:#dc2626;color:#fca5a5"}">Delete</button>
    </div>
  `;
}

function renderTable() {
  const rows = getFilteredAlerts();
  const admin = isAdminUser();
  document.getElementById("alertsQueueMeta").textContent = `${rows.length} rows`;
  document.getElementById("alertsTable").innerHTML = rows
    .map(
      (alert) => `
        <tr>
          <td>#${Number(alert.id) || 0}</td>
          <td>${renderSeverityBadge(alert.severity)}</td>
          <td>${escapeHtml(alert.type)}</td>
          <td>${escapeHtml(alert.hostname || alert.ip || "-")}</td>
          <td>${escapeHtml(alert.description)}</td>
          <td>${escapeHtml(formatDateTimeShort(alert.timestamp))}</td>
          <td>${renderStatus(alert.status)}</td>
          <td>${renderActionButtons(alert, admin)}</td>
        </tr>
      `
    )
    .join("");
  bindActions();
}

function renderDeletedTable() {
  const tbody = document.getElementById("deletedAlertsTable");
  const meta = document.getElementById("deletedAlertsMeta");
  if (!tbody) return;
  meta && (meta.textContent = `${deletedAlerts.length} rows`);
  if (!deletedAlerts.length) {
    tbody.innerHTML = `<tr><td colspan="8" class="muted">Nessun task eliminato.</td></tr>`;
    return;
  }
  tbody.innerHTML = deletedAlerts
    .map(
      (alert) => `
        <tr>
          <td>#${Number(alert.id) || 0}</td>
          <td>${renderSeverityBadge(alert.severity)}</td>
          <td>${escapeHtml(alert.type)}</td>
          <td>${escapeHtml(alert.hostname || alert.ip || "-")}</td>
          <td>${escapeHtml(alert.description)}</td>
          <td>${escapeHtml(formatDateTimeShort(alert.timestamp))}</td>
          <td>${escapeHtml(formatDateTimeShort(alert.closed_at))}</td>
          <td>${escapeHtml(formatDateTimeShort(alert.deleted_at))}</td>
        </tr>
      `
    )
    .join("");
}

async function loadAlerts() {
  try {
    // Carico in parallelo: la lista principale (esclude deleted) e i deleted per la tabella separata.
    const [active, deleted] = await Promise.all([
      api.getAlerts(),
      api.getDeletedAlerts().catch(() => []),  // gracefully tolerate older backends
    ]);
    allAlerts = active || [];
    deletedAlerts = deleted || [];
    summarize(allAlerts);
    renderSeverityMix(allAlerts);
    renderCriticalFeed(allAlerts);
    renderTable();
    renderDeletedTable();
  } catch (error) {
    notifyError(error);
  }
}

document.getElementById("reloadAlertsButton").addEventListener("click", loadAlerts);
document.getElementById("severityFilter").addEventListener("change", renderTable);
document.getElementById("statusFilter").addEventListener("change", renderTable);
document.getElementById("alertSearchInput").addEventListener("input", renderTable);
document.getElementById("alertDateFilter")?.addEventListener("input", renderTable);
window.addEventListener("netvisor:manual-refresh", loadAlerts);

// ── Toggle collapse Alert Queue ───────────────────────────────────────────
// Quando la coda alert ha centinaia di righe, occupa tutta la viewport e
// nasconde Latest Criticals e Deleted Tasks sotto. Il bottone freccia
// (▲/▼) consente di comprimere/espandere preservando lo stato in
// sessionStorage così la preferenza sopravvive ai page reload.
const ALERT_QUEUE_COLLAPSED_KEY = "netvisor.alerts.queueCollapsed";
function applyAlertQueueCollapsed(collapsed) {
  const wrap = document.getElementById("alertQueueTableWrap");
  const btn = document.getElementById("toggleAlertQueueButton");
  if (!wrap || !btn) return;
  if (collapsed) {
    wrap.hidden = true;
    btn.textContent = "▼";
    btn.setAttribute("aria-expanded", "false");
    btn.title = "Espandi tabella Alert Queue";
  } else {
    wrap.hidden = false;
    btn.textContent = "▲";
    btn.setAttribute("aria-expanded", "true");
    btn.title = "Comprimi tabella per raggiungere Latest Criticals / Deleted Tasks";
  }
}
document.getElementById("toggleAlertQueueButton")?.addEventListener("click", () => {
  const currentlyCollapsed = sessionStorage.getItem(ALERT_QUEUE_COLLAPSED_KEY) === "1";
  const next = !currentlyCollapsed;
  sessionStorage.setItem(ALERT_QUEUE_COLLAPSED_KEY, next ? "1" : "0");
  applyAlertQueueCollapsed(next);
});
applyAlertQueueCollapsed(sessionStorage.getItem(ALERT_QUEUE_COLLAPSED_KEY) === "1");

// ── Export CSV Alert Queue ────────────────────────────────────────────────
// Esporta solo le righe attualmente filtrate/visibili nella tabella
// (la utility skippa style.display="none" → coerente con i filtri attivi
// severity/status/search/date).
document.getElementById("exportAlertsCsvButton")?.addEventListener("click", () => {
  const table = document.getElementById("alertQueueTable");
  if (!table) return;
  try {
    const stamp = new Date().toISOString().slice(0, 16).replace(/[-T:]/g, "");
    exportTableToCSV(table, `netvisor-alerts-${stamp}.csv`);
  } catch (error) {
    notifyError(error);
  }
});

// ── Status filter: aggiungo "deleted" come opzione per ispezionare i tombstone
//    (alternativa al pannello Deleted Tasks separato).
const statusFilterEl = document.getElementById("statusFilter");
if (statusFilterEl && ![...statusFilterEl.options].some((o) => o.value === "deleted")) {
  const opt = document.createElement("option");
  opt.value = "deleted"; opt.textContent = "deleted";
  statusFilterEl.appendChild(opt);
}

loadAlerts();
window.setInterval(loadAlerts, 8000);
