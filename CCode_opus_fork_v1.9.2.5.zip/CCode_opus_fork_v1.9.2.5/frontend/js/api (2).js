const DEFAULT_BASE_URL = "http://localhost:5000";

function getBaseUrlValue() {
  return localStorage.getItem("netvisorApiBaseUrl") || DEFAULT_BASE_URL;
}

function getAdminTokenValue() {
  return sessionStorage.getItem("netvisorAdminToken") || "";
}

function setConnectionSettings(baseUrl) {
  localStorage.setItem("netvisorApiBaseUrl", baseUrl || DEFAULT_BASE_URL);
}

function setAdminSession(token) {
  sessionStorage.setItem("netvisorAdminToken", token || "");
  localStorage.removeItem("netvisorAdminToken");
}

function clearAdminSession() {
  sessionStorage.removeItem("netvisorAdminToken");
  localStorage.removeItem("netvisorAdminToken");
}

async function request(path, options = {}, authMode = "public") {
  const baseUrl = getBaseUrlValue();
  const adminToken = getAdminTokenValue();
  const headers = {
    "Content-Type": "application/json",
    ...(authMode === "admin" && adminToken ? { Authorization: `Bearer ${adminToken}` } : {}),
    ...(options.headers || {}),
  };

  const response = await fetch(`${baseUrl}${path}`, {
    headers,
    ...options,
  });

  const payload = await response.json().catch(() => ({ success: false, error: "Risposta non valida." }));
  if (!response.ok || payload.success === false) {
    if (response.status === 401 && authMode === "admin" && !adminToken) {
      throw new Error("Login admin richiesto per questa operazione.");
    }
    throw new Error(payload.error || `Errore HTTP ${response.status}`);
  }
  return payload.data;
}

export const api = {
  getBaseUrl() {
    return getBaseUrlValue();
  },
  isAdminAuthenticated() {
    return Boolean(getAdminTokenValue());
  },
  getHealth() {
    return request("/api/health");
  },
  getDashboardSummary() {
    return request("/api/dashboard/summary");
  },
  getDashboardOperations() {
    return request("/api/dashboard/operations");
  },
  getNodes(status = "") {
    const suffix = status ? `?status=${encodeURIComponent(status)}` : "";
    return request(`/api/nodes${suffix}`);
  },
  getNode(nodeId) {
    return request(`/api/nodes/${nodeId}`);
  },
  getNodeServices(nodeId) {
    return request(`/api/nodes/${nodeId}/services`);
  },
  getNodeAlerts(nodeId) {
    return request(`/api/nodes/${nodeId}/alerts`);
  },
  getNodeLogins(nodeId) {
    return request(`/api/nodes/${nodeId}/logins`);
  },
  getAlerts() {
    return request("/api/alerts");
  },
  ackAlert(alertId) {
    return request(`/api/alerts/${alertId}/ack`, { method: "PATCH" }, "admin");
  },
  closeAlert(alertId) {
    return request(`/api/alerts/${alertId}/close`, { method: "PATCH" }, "admin");
  },
  getScans() {
    return request("/api/scans");
  },
  getConnectionsOverview() {
    return request("/api/connections/overview");
  },
  getScan(scanId) {
    return request(`/api/scans/${scanId}`);
  },
  getScanEvents(scanId) {
    return request(`/api/scans/${scanId}/events`);
  },
  getScanRaw(scanId) {
    return request(`/api/scans/${scanId}/raw`);
  },
  createScan(payload) {
    return request("/api/scan", {
      method: "POST",
      body: JSON.stringify(payload),
    }, "admin");
  },
  ping(target) {
    return request("/api/ping", {
      method: "POST",
      body: JSON.stringify({ target }),
    }, "admin");
  },
  httpTest(url) {
    return request("/api/http-test", {
      method: "POST",
      body: JSON.stringify({ url }),
    }, "admin");
  },
  getTopology() {
    return request("/api/topology");
  },
  getSecurityLoginSummary() {
    return request("/api/security/logins/summary");
  },
  adminLogin(username, password) {
    return request(
      "/api/admin/login",
      {
        method: "POST",
        body: JSON.stringify({ username, password }),
      },
      "public"
    );
  },
  runAdminQuery(query) {
    return request(
      "/api/admin/query",
      {
        method: "POST",
        body: JSON.stringify({ query }),
      },
      "admin"
    );
  },
};

export function renderSeverityBadge(severity) {
  const safe = severity || "info";
  return `<span class="badge severity-${safe}">${safe}</span>`;
}

export function renderStatus(status) {
  const safe = status || "unknown";
  return `<span class="status-${safe}">${safe}</span>`;
}

export function notifyError(error) {
  window.alert(error.message || String(error));
}

function mountConnectionPanel() {
  if (document.getElementById("connectionPopover")) {
    return;
  }

  const shell = document.createElement("div");
  shell.className = "connection-shell";
  shell.innerHTML = `
    <button id="connectionToggleButton" class="connection-toggle" type="button" aria-expanded="false" aria-controls="connectionPopover">
      <span>API</span>
      <span id="connectionToggleBadge" class="connection-badge">${api.isAdminAuthenticated() ? "admin" : "read only"}</span>
    </button>
    <aside id="connectionPopover" class="connection-popover" hidden>
    <div class="connection-head">
      <strong>Connessione API</strong>
        <button id="connectionCloseButton" class="icon-button" type="button" aria-label="Chiudi pannello connessione">x</button>
    </div>
      <span id="connectionStatusBadge" class="connection-badge">${api.isAdminAuthenticated() ? "admin" : "read only"}</span>
    <label>
      Base URL
      <input id="connectionBaseUrl" type="text" value="${api.getBaseUrl()}">
    </label>
    <label>
      Admin username
      <input id="connectionAdminUser" type="text" value="admin">
    </label>
    <label>
      Admin password
      <input id="connectionAdminPassword" type="password" value="">
    </label>
    <div class="connection-actions">
      <button id="saveConnectionButton" class="ghost-button" type="button">Salva URL</button>
      <button id="loginConnectionButton" class="primary-button" type="button">Login admin</button>
      <button id="logoutConnectionButton" class="ghost-button" type="button">Logout</button>
      <button id="testConnectionButton" class="ghost-button" type="button">Test</button>
    </div>
    <p id="connectionMessage" class="muted">Lettura pubblica. Scrittura riservata ad admin.</p>
    </aside>
  `;

  document.body.appendChild(shell);

  const toggleButton = document.getElementById("connectionToggleButton");
  const popover = document.getElementById("connectionPopover");
  const baseUrlInput = document.getElementById("connectionBaseUrl");
  const adminUserInput = document.getElementById("connectionAdminUser");
  const adminPasswordInput = document.getElementById("connectionAdminPassword");
  const badge = document.getElementById("connectionStatusBadge");
  const toggleBadge = document.getElementById("connectionToggleBadge");
  const message = document.getElementById("connectionMessage");

  const refreshBadge = () => {
    const label = api.isAdminAuthenticated() ? "admin" : "read only";
    badge.textContent = label;
    toggleBadge.textContent = label;
  };
  const setOpen = (isOpen) => {
    popover.hidden = !isOpen;
    toggleButton.setAttribute("aria-expanded", String(isOpen));
  };

  toggleButton.addEventListener("click", (event) => {
    event.stopPropagation();
    setOpen(popover.hidden);
  });

  document.getElementById("connectionCloseButton").addEventListener("click", () => setOpen(false));
  document.addEventListener("click", (event) => {
    if (!shell.contains(event.target)) {
      setOpen(false);
    }
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      setOpen(false);
    }
  });

  document.getElementById("saveConnectionButton").addEventListener("click", () => {
    setConnectionSettings(baseUrlInput.value.trim());
    message.textContent = "URL backend salvato.";
  });

  document.getElementById("loginConnectionButton").addEventListener("click", async () => {
    try {
      setConnectionSettings(baseUrlInput.value.trim());
      const result = await api.adminLogin(adminUserInput.value.trim(), adminPasswordInput.value);
      setAdminSession(result.token);
      refreshBadge();
      adminPasswordInput.value = "";
      message.textContent = `Sessione admin attiva per ${result.username}.`;
    } catch (error) {
      message.textContent = error.message || String(error);
    }
  });

  document.getElementById("logoutConnectionButton").addEventListener("click", () => {
    clearAdminSession();
    refreshBadge();
    message.textContent = "Sessione admin rimossa.";
  });

  document.getElementById("testConnectionButton").addEventListener("click", async () => {
    try {
      setConnectionSettings(baseUrlInput.value.trim());
      const health = await api.getHealth();
      refreshBadge();
      message.textContent = `Backend raggiungibile: ${health.status}`;
    } catch (error) {
      message.textContent = error.message || String(error);
    }
  });
}

if (typeof document !== "undefined") {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mountConnectionPanel, { once: true });
  } else {
    mountConnectionPanel();
  }
}
