const STORAGE_KEYS = {
  baseUrl: "netvisor.base_url",
  accessToken: "netvisor.access_token",
  refreshToken: "netvisor.refresh_token",
  currentUser: "netvisor.current_user",
  adminNotice: "netvisor.admin_login_notice",
};

const state = {
  baseUrl: normalizeBaseUrl(sessionStorage.getItem(STORAGE_KEYS.baseUrl) || window.location.origin),
  currentUser: parseJson(sessionStorage.getItem(STORAGE_KEYS.currentUser)),
  refreshPromise: null,
  popover: null,
};

function parseJson(value) {
  try {
    return value ? JSON.parse(value) : null;
  } catch (_error) {
    return null;
  }
}

function normalizeBaseUrl(value) {
  const candidate = String(value || window.location.origin).trim();
  return candidate.replace(/\/+$/, "");
}

function buildUrl(path) {
  if (/^https?:\/\//i.test(path)) {
    return path;
  }
  return `${state.baseUrl}${path.startsWith("/") ? path : `/${path}`}`;
}

export function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

// ── Timezone helpers (Europe/Rome) ─────────────────────────────────────────
// Tutti i timestamp DB sono UTC (SYSUTCDATETIME). La UI li formatta nel fuso
// di Roma. ISO senza 'Z' → li trattiamo come UTC (default backend).
const TZ_ROME = "Europe/Rome";
const _DTF_FULL = new Intl.DateTimeFormat("it-IT", {
  timeZone: TZ_ROME, year: "numeric", month: "2-digit", day: "2-digit",
  hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
});
const _DTF_TIME = new Intl.DateTimeFormat("it-IT", {
  timeZone: TZ_ROME, hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
});
const _DTF_SHORT = new Intl.DateTimeFormat("it-IT", {
  timeZone: TZ_ROME, day: "2-digit", month: "2-digit",
  hour: "2-digit", minute: "2-digit", hour12: false,
});

function _toDate(value) {
  if (!value) return null;
  if (value instanceof Date) return value;
  let s = String(value).trim();
  if (!s) return null;
  // ── Defense-in-depth: il backend ora serializza in ISO 8601 con suffix 'Z',
  // ma per retro-compatibilità riconosciamo anche il formato RFC 1123/2822
  // ("Sat, 09 May 2026 00:00:00 GMT") che Flask emette di default — JS lo
  // parsa nativamente, basta NON corromperlo con replace(" ", "T").
  if (/^[A-Z][a-z]{2},\s/.test(s)) {
    const d = new Date(s);
    return isNaN(d.getTime()) ? null : d;
  }
  // Se è ISO senza timezone (es. "2026-05-08T13:21:09" o "2026-05-08 13:21:09.123"),
  // assumiamo UTC e aggiungiamo 'Z'. Altrimenti rispettiamo il TZ già presente.
  const hasTz = /Z|[+-]\d{2}:?\d{2}$/.test(s);
  if (!hasTz) {
    s = s.replace(" ", "T");
    // Tronca microsecondi extra (SQL Server può ritornare 7 cifre, JS ne supporta 3)
    s = s.replace(/(\.\d{3})\d+/, "$1");
    s += "Z";
  }
  const d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
}

/** Formato completo "08/05/2026, 15:21:09" — fuso Roma. Vuoto → "-". */
export function formatDateTime(value) {
  const d = _toDate(value);
  return d ? _DTF_FULL.format(d) : "-";
}

/** Formato breve "08/05, 15:21" — per tabelle dense, fuso Roma.
 *  Se il valore non è parsabile come data ma è una stringa non vuota,
 *  ritorna la stringa raw — più informativo di "-" per debug. */
export function formatDateTimeShort(value) {
  const d = _toDate(value);
  if (d) return _DTF_SHORT.format(d);
  if (value && typeof value === "string" && value.trim()) return value.trim().slice(0, 19);
  return "-";
}

/** Solo orario "15:21:09" — per chip di refresh, fuso Roma. */
export function formatTimeOnly(value) {
  const d = _toDate(value || new Date());
  return d ? _DTF_TIME.format(d) : "-";
}

// ── CSV export utilities (PDF Errori_v4.x quick wins) ─────────────────────
// Tre call site distinte (alerts, topology SQL console, logs login activity,
// reports scan detail) hanno bisogno di esportare dati tabellari. Unico
// codice → tre wiring point. Conformità RFC 4180:
//   - separatore virgola
//   - campi con , " o newline racchiusi fra doppie virgolette
//   - doppie virgolette interne raddoppiate ""
//   - BOM UTF-8 per Excel italiano (legge CSV come UTF-8 solo con BOM)

function _csvEscape(value) {
  if (value === null || value === undefined) return "";
  const s = String(value);
  if (s.includes(",") || s.includes('"') || s.includes("\n") || s.includes("\r")) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

function _triggerDownload(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  // Best-effort cleanup (Firefox may need a tick).
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/**
 * Esporta i dati di una <table> in CSV scaricato.
 * - tableEl: l'elemento <table> nel DOM. Legge <thead> per gli header e
 *   <tbody> per le righe. Le righe con style.display="none" (filtro globale
 *   live search, attuali in shell.js) sono ESCLUSE — esporta solo quanto
 *   l'utente sta vedendo.
 * - filename: nome del file (default "export-YYYYMMDD-HHmm.csv").
 * - opts: { includeHidden:false, encoding:"utf-8-bom" }
 */
export function exportTableToCSV(tableEl, filename, opts = {}) {
  if (!tableEl || !tableEl.querySelector) {
    throw new Error("exportTableToCSV: elemento table non valido.");
  }
  const includeHidden = !!opts.includeHidden;

  // Headers
  const headerCells = Array.from(tableEl.querySelectorAll("thead th"));
  const headers = headerCells.length
    ? headerCells.map((th) => (th.textContent || "").trim())
    : [];

  // Rows (skip hidden a meno di opts.includeHidden)
  const bodyRows = Array.from(tableEl.querySelectorAll("tbody tr")).filter((tr) => {
    if (includeHidden) return true;
    return tr.style.display !== "none";
  });

  const lines = [];
  if (headers.length) lines.push(headers.map(_csvEscape).join(","));
  for (const tr of bodyRows) {
    const cells = Array.from(tr.children).map((td) => (td.textContent || "").trim());
    lines.push(cells.map(_csvEscape).join(","));
  }

  // BOM UTF-8 per Excel ita: il file viene letto come UTF-8 senza chiedere.
  const csv = "﻿" + lines.join("\r\n") + "\r\n";
  const stamp = new Date().toISOString().slice(0, 16).replace(/[-T:]/g, "");
  const finalName = filename || `export-${stamp}.csv`;
  _triggerDownload(new Blob([csv], { type: "text/csv;charset=utf-8" }), finalName);
}

/**
 * Esporta una lista di record (array di oggetti) in CSV.
 * Usato per dati strutturati che NON sono già in una <table>
 * (es. host/services parsed dall'XML nmap). Le colonne sono dedotte
 * dalle keys del primo record (o passate via opts.columns).
 */
export function exportRecordsToCSV(records, filename, opts = {}) {
  const list = Array.isArray(records) ? records : [];
  if (!list.length) {
    throw new Error("exportRecordsToCSV: nessun record da esportare.");
  }
  const columns = Array.isArray(opts.columns) && opts.columns.length
    ? opts.columns
    : Object.keys(list[0]);

  const lines = [columns.map(_csvEscape).join(",")];
  for (const rec of list) {
    lines.push(columns.map((c) => _csvEscape(rec[c])).join(","));
  }
  const csv = "﻿" + lines.join("\r\n") + "\r\n";
  const stamp = new Date().toISOString().slice(0, 16).replace(/[-T:]/g, "");
  const finalName = filename || `export-${stamp}.csv`;
  _triggerDownload(new Blob([csv], { type: "text/csv;charset=utf-8" }), finalName);
}

function dispatchAuthChanged() {
  window.dispatchEvent(
    new CustomEvent("netvisor:auth-changed", {
      detail: {
        user: state.currentUser,
        isAdmin: isAdminUser(),
      },
    })
  );
}

function persistUser(user) {
  state.currentUser = user || null;
  if (user) {
    sessionStorage.setItem(STORAGE_KEYS.currentUser, JSON.stringify(user));
  } else {
    sessionStorage.removeItem(STORAGE_KEYS.currentUser);
  }
  dispatchAuthChanged();
  refreshApiPopover();
}

function persistTokens(accessToken, refreshToken) {
  if (accessToken) {
    sessionStorage.setItem(STORAGE_KEYS.accessToken, accessToken);
  }
  if (refreshToken) {
    sessionStorage.setItem(STORAGE_KEYS.refreshToken, refreshToken);
  }
}

function clearSession() {
  sessionStorage.removeItem(STORAGE_KEYS.accessToken);
  sessionStorage.removeItem(STORAGE_KEYS.refreshToken);
  sessionStorage.removeItem(STORAGE_KEYS.currentUser);
  persistUser(null);
}

function getAccessToken() {
  return sessionStorage.getItem(STORAGE_KEYS.accessToken) || "";
}

function getRefreshToken() {
  return sessionStorage.getItem(STORAGE_KEYS.refreshToken) || "";
}

function storeAdminLoginNotice(payload) {
  const notice = {
    username: payload?.user?.username,
    timestamp: payload?.admin_login_timestamp || new Date().toISOString(),
    ip: payload?.admin_login_ip || "unknown",
    message: payload?.admin_login_message || "Accesso admin registrato",
  };
  sessionStorage.setItem(STORAGE_KEYS.adminNotice, JSON.stringify(notice));
}

export function consumeAdminLoginNotice() {
  const notice = parseJson(sessionStorage.getItem(STORAGE_KEYS.adminNotice));
  sessionStorage.removeItem(STORAGE_KEYS.adminNotice);
  return notice;
}

export function setApiBaseUrl(url) {
  state.baseUrl = normalizeBaseUrl(url || window.location.origin);
  sessionStorage.setItem(STORAGE_KEYS.baseUrl, state.baseUrl);
  refreshApiPopover();
}

export function getApiBaseUrl() {
  return state.baseUrl;
}

export function getCurrentUserSync() {
  return state.currentUser;
}

export function isAdminUser() {
  return String(state.currentUser?.role || "").toLowerCase() === "admin";
}

function isLoginPage() {
  return window.location.pathname.endsWith("/login.html") || window.location.pathname.endsWith("login.html");
}

function redirectToLogin() {
  if (isLoginPage()) {
    return;
  }
  const next = `${window.location.pathname.split("/").pop() || "index.html"}${window.location.search || ""}`;
  window.location.href = `login.html?next=${encodeURIComponent(next)}`;
}

async function parseEnvelope(response) {
  const text = await response.text();
  let payload = null;
  try {
    payload = text ? JSON.parse(text) : null;
  } catch (_error) {
    payload = null;
  }

  // NetVisor è LIVE-only: il _meta non ha più informazioni di stato
  // dinamico, quindi non lo dispatch-iamo più (no listeners).

  if (!response.ok) {
    const message = payload?.error || payload?.message || response.statusText || "Errore API.";
    const error = new Error(message);
    error.status = response.status;
    // Login lockout escalation: il backend allega lockout={state, locked_until,...}
    // → propagato come error.lockout, login.js mostra popup specifici per ogni stato.
    if (payload?.lockout) error.lockout = payload.lockout;
    throw error;
  }

  if (payload && payload.success === false) {
    const error = new Error(payload.error || "Errore API.");
    error.status = response.status;
    if (payload.lockout) error.lockout = payload.lockout;
    throw error;
  }

  return payload?.data ?? payload;
}

async function refreshAccessToken() {
  if (state.refreshPromise) {
    return state.refreshPromise;
  }
  const refreshToken = getRefreshToken();
  if (!refreshToken) {
    clearSession();
    throw new Error("Sessione scaduta.");
  }

  state.refreshPromise = fetch(buildUrl("/api/auth/refresh"), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: refreshToken }),
  })
    .then(parseEnvelope)
    .then((data) => {
      persistTokens(data.access_token, data.refresh_token);
      persistUser(data.user);
      return data;
    })
    .catch((error) => {
      clearSession();
      if (!isLoginPage()) {
        redirectToLogin();
      }
      throw error;
    })
    .finally(() => {
      state.refreshPromise = null;
    });

  return state.refreshPromise;
}

async function request(path, options = {}) {
  const {
    method = "GET",
    auth = true,
    body = undefined,
    headers = {},
    retryOn401 = true,
  } = options;

  const resolvedHeaders = new Headers(headers);
  if (body !== undefined && !(body instanceof FormData) && !resolvedHeaders.has("Content-Type")) {
    resolvedHeaders.set("Content-Type", "application/json");
  }
  if (auth && getAccessToken()) {
    resolvedHeaders.set("Authorization", `Bearer ${getAccessToken()}`);
  }

  const response = await fetch(buildUrl(path), {
    method,
    headers: resolvedHeaders,
    body:
      body === undefined
        ? undefined
        : body instanceof FormData || typeof body === "string"
          ? body
          : JSON.stringify(body),
  });

  if (response.status === 401 && auth && retryOn401 && getRefreshToken()) {
    await refreshAccessToken();
    return request(path, { ...options, retryOn401: false });
  }

  if (response.status === 401 && auth && !isLoginPage()) {
    clearSession();
    redirectToLogin();
  }

  return parseEnvelope(response);
}

export async function ensureAuthenticated({ adminOnly = false } = {}) {
  if (!getAccessToken() && getRefreshToken()) {
    try {
      await refreshAccessToken();
    } catch (_error) {
      return { authenticated: false, authorized: false, user: null };
    }
  }

  if (!getAccessToken()) {
    redirectToLogin();
    return { authenticated: false, authorized: false, user: null };
  }

  try {
    const user = await api.getMe();
    persistUser(user);
    const authorized = !adminOnly || String(user.role).toLowerCase() === "admin";
    return { authenticated: true, authorized, user };
  } catch (_error) {
    return { authenticated: false, authorized: false, user: null };
  }
}

function getToastRoot() {
  let root = document.getElementById("toastRoot");
  if (!root) {
    root = document.createElement("div");
    root.id = "toastRoot";
    root.className = "toast-root";
    document.body.appendChild(root);
  }
  return root;
}

function pushToast(message, type = "info") {
  const toast = document.createElement("div");
  toast.className = `toast-item toast-${type}`;
  toast.textContent = message;
  getToastRoot().appendChild(toast);
  window.setTimeout(() => toast.classList.add("toast-visible"), 20);
  window.setTimeout(() => {
    toast.classList.remove("toast-visible");
    window.setTimeout(() => toast.remove(), 220);
  }, 4200);
}

export function notifyError(error) {
  const message = error?.message || String(error || "Errore.");
  pushToast(message, "error");
  console.error(error);
}

export function notifySuccess(message) {
  pushToast(message, "success");
}

export function renderSeverityBadge(severity) {
  const normalized = String(severity || "info").toLowerCase();
  return `<span class="badge badge-severity severity-${escapeHtml(normalized)}">${escapeHtml(normalized)}</span>`;
}

export function renderStatus(status) {
  const normalized = String(status || "unknown").toLowerCase().replace(/\s+/g, "-");
  return `<span class="badge status-badge status-${escapeHtml(normalized)}">${escapeHtml(status || "unknown")}</span>`;
}

function profileMarkup() {
  const user = getCurrentUserSync();
  if (!user) {
    return `
      <div class="api-popover-card">
        <p class="muted">Nessuna sessione attiva.</p>
        <a class="primary-button inline-button" href="login.html">Apri login</a>
      </div>
    `;
  }

  return `
    <div class="api-popover-card">
      <div class="api-popover-row">
        <strong>${escapeHtml(user.display_name || user.username)}</strong>
        <span class="badge micro-badge ${isAdminUser() ? "severity-medium" : "severity-info"}">${escapeHtml(user.role)}</span>
      </div>
      <p class="muted">username: ${escapeHtml(user.username)}</p>
      <p class="muted">must_change_password: ${user.must_change_password ? "true" : "false"}</p>
      <div class="api-popover-actions">
        <a class="ghost-button inline-button" href="settings.html">Profilo</a>
        <button id="apiPopoverLogout" class="ghost-button inline-button" type="button">Logout</button>
      </div>
    </div>
  `;
}

function bindPopoverEvents(popover) {
  popover.querySelector("#saveApiUrlButton")?.addEventListener("click", () => {
    const input = popover.querySelector("#apiBaseUrlInput");
    setApiBaseUrl(input?.value || window.location.origin);
    notifySuccess("Base URL aggiornata.");
  });

  popover.querySelector("#apiPopoverLogout")?.addEventListener("click", async () => {
    try {
      await api.logout();
    } catch (_error) {
      clearSession();
    }
    window.location.href = "login.html";
  });
}

function refreshApiPopover() {
  if (!state.popover) {
    return;
  }
  const { panel, stateChip } = state.popover;
  const connected = Boolean(getCurrentUserSync());
  stateChip.textContent = connected ? "connected" : "disconnected";
  stateChip.className = `badge micro-badge ${connected ? "state-ok" : "state-bad"}`;
  panel.innerHTML = `
    <div class="api-popover-head">
      <div>
        <strong>Sessione API</strong>
        <p class="muted">Bearer token breve + refresh token ruotato.</p>
      </div>
      <button id="closeApiPopover" class="icon-button" type="button" aria-label="Chiudi">x</button>
    </div>
    <label class="query-label">
      Base URL
      <input id="apiBaseUrlInput" type="text" value="${escapeHtml(getApiBaseUrl())}">
    </label>
    <div class="api-popover-actions">
      <button id="saveApiUrlButton" class="ghost-button inline-button" type="button">Salva URL</button>
      <span class="badge micro-badge ${connected ? "state-ok" : "state-bad"}">${connected ? "sessione attiva" : "login richiesto"}</span>
    </div>
    ${profileMarkup()}
  `;
  panel.querySelector("#closeApiPopover")?.addEventListener("click", () => {
    state.popover.wrapper.classList.remove("open");
  });
  bindPopoverEvents(panel);
}

export function mountApiPopover(slot) {
  if (!slot) return;
  const wrapper = document.createElement("div");
  wrapper.className = "api-popover-wrap";
  wrapper.innerHTML = `
    <button id="apiPopoverToggle" class="topbar-button api-toggle" type="button">API</button>
  `;
  slot.replaceChildren(wrapper);

  // Panel attaches to body — fixed position, avoids topbar overflow clipping
  const panel = document.createElement("div");
  panel.id = "apiPopoverPanel";
  panel.className = "api-popover-panel";
  panel.hidden = true;
  document.body.appendChild(panel);

  const toggle = wrapper.querySelector("#apiPopoverToggle");
  const stateChip = document.createElement("span");
  stateChip.className = "badge micro-badge state-idle";
  toggle.appendChild(stateChip);

  state.popover = { wrapper, toggle, panel, stateChip };
  refreshApiPopover();

  function closePopover() {
    wrapper.classList.remove("open");
    panel.hidden = true;
  }

  function openPopover() {
    wrapper.classList.add("open");
    panel.hidden = false;
    refreshApiPopover();
  }

  toggle.addEventListener("click", (event) => {
    event.stopPropagation();
    if (wrapper.classList.contains("open")) {
      closePopover();
      return;
    }
    openPopover();
  });

  document.addEventListener("click", (event) => {
    if (!wrapper.contains(event.target)) {
      closePopover();
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closePopover();
    }
  });
}

export const api = {
  getHealth: () => request("/api/health", { auth: false }),
  getSystemInfo: () => request("/api/system/info", { auth: false }),
  getDashboardSummary: () => request("/api/dashboard/summary"),
  getDashboardOperations: () => request("/api/dashboard/operations"),
  getAlerts: () => request("/api/alerts"),
  getDeletedAlerts: () => request("/api/alerts/deleted"),
  ackAlert: (alertId) => request(`/api/alerts/${alertId}/ack`, { method: "PATCH" }),
  closeAlert: (alertId) => request(`/api/alerts/${alertId}/close`, { method: "PATCH" }),
  deleteAlert: (alertId) => request(`/api/alerts/${alertId}`, { method: "DELETE" }),
  getNodes: (status = "") => request(`/api/nodes${status ? `?status=${encodeURIComponent(status)}` : ""}`),
  getNode: (nodeId) => request(`/api/nodes/${nodeId}`),
  getNodeServices: (nodeId) => request(`/api/nodes/${nodeId}/services`),
  getNodeAlerts: (nodeId) => request(`/api/nodes/${nodeId}/alerts`),
  getNodeLogins: (nodeId) => request(`/api/nodes/${nodeId}/logins`),
  getSecurityLoginSummary: () => request("/api/security/logins/summary"),
  getConnectionsOverview: () => request("/api/connections/overview"),
  getScanJobs: () => request("/api/admin/scan-jobs"),
  createScanJob: (payload) => request("/api/admin/scan-jobs", { method: "POST", body: payload }),
  getScanJob: (jobId) => request(`/api/admin/scan-jobs/${jobId}`),
  updateScanJob: (jobId, payload) => request(`/api/admin/scan-jobs/${jobId}`, { method: "PATCH", body: payload }),
  deleteScanJob: (jobId) => request(`/api/admin/scan-jobs/${jobId}`, { method: "DELETE" }),
  runScanJob: (jobId) => request(`/api/admin/scan-jobs/${jobId}/run`, { method: "POST", body: {} }),
  getScanJobRuns: (jobId) => request(`/api/admin/scan-jobs/${jobId}/runs`),
  runManualScan: (payload) => request("/api/admin/scans/manual", { method: "POST", body: payload }),
  createScan: (payload) => request("/api/admin/scans/manual", { method: "POST", body: payload }),
  getScans: () => request("/api/scans"),
  getScan: (scanId) => request(`/api/scans/${scanId}`),
  getScanEvents: (scanId) => request(`/api/scans/${scanId}/events`),
  getScanRaw: (scanId) => request(`/api/scans/${scanId}/raw`),
  getHealthChecks: () => request("/api/admin/health-checks"),
  createHealthCheck: (payload) => request("/api/admin/health-checks", { method: "POST", body: payload }),
  getHealthCheck: (checkId) => request(`/api/admin/health-checks/${checkId}`),
  updateHealthCheck: (checkId, payload) => request(`/api/admin/health-checks/${checkId}`, { method: "PATCH", body: payload }),
  deleteHealthCheck: (checkId) => request(`/api/admin/health-checks/${checkId}`, { method: "DELETE" }),
  runHealthCheck: (checkId) => request(`/api/admin/health-checks/${checkId}/run`, { method: "POST", body: {} }),
  getHealthCheckResults: (checkId) => request(`/api/admin/health-checks/${checkId}/results`),
  runManualHealthCheck: (payload) => request("/api/admin/health-checks/manual", { method: "POST", body: payload }),
  getTopology: (qs = "") => request("/api/topology" + (qs ? "?" + qs : "")),
  runAdminQuery: (query) => request("/api/admin/query", { method: "POST", body: { query } }),
  getAgents: () => request("/api/agents"),
  getAgent: (agentId) => request(`/api/agents/${encodeURIComponent(agentId)}`),
  getMe: async () => {
    const data = await request("/api/auth/me");
    persistUser(data);
    return data;
  },
  login: async (username, password) => {
    const data = await request("/api/auth/login", { method: "POST", auth: false, body: { username, password } });
    persistTokens(data.access_token, data.refresh_token);
    persistUser(data.user);
    if (data.admin_login_alert) {
      storeAdminLoginNotice(data);
    }
    return data;
  },
  logout: async () => {
    const refreshToken = getRefreshToken();
    try {
      await request("/api/auth/logout", { method: "POST", body: { refresh_token: refreshToken || null } });
    } finally {
      clearSession();
    }
    return { logged_out: true };
  },
  refresh: () => refreshAccessToken(),
  changePassword: (payload) => request("/api/auth/change-password", { method: "POST", body: payload }),
  getUsers: () => request("/api/users"),
  createUser: (payload) => request("/api/users", { method: "POST", body: payload }),
  getUser: (userId) => request(`/api/users/${userId}`),
  updateUser: (userId, payload) => request(`/api/users/${userId}`, { method: "PATCH", body: payload }),
  deleteUser: (userId) => request(`/api/users/${userId}`, { method: "DELETE" }),
  resetUserPassword: (userId, payload) => request(`/api/users/${userId}/reset-password`, { method: "POST", body: payload }),
  disableUser: (userId) => request(`/api/users/${userId}/disable`, { method: "POST", body: {} }),
  enableUser: (userId) => request(`/api/users/${userId}/enable`, { method: "POST", body: {} }),
  getAuthAudit: (limit = 100) => request(`/api/auth/audit?limit=${encodeURIComponent(limit)}`),
  getAuditLog: (limit = 100) => request(`/api/admin/audit-log?limit=${encodeURIComponent(limit)}`),
};
