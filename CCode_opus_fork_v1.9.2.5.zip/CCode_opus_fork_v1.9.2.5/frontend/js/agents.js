import { api, escapeHtml, notifyError, renderSeverityBadge, renderStatus } from "./api.js";

let selectedAgentId = null;

function renderKpis(agents, summary = {}) {
  const total = agents.length;
  const online = agents.filter((item) => item.status === "online").length;
  const offline = agents.filter((item) => item.status === "offline").length;
  const servicesDown = summary.services_down ?? 0;
  const latest = agents
    .map((item) => item.last_seen)
    .filter(Boolean)
    .sort()
    .pop();

  document.getElementById("totalAgents").textContent = total;
  document.getElementById("onlineAgentsCount").textContent = online;
  document.getElementById("offlineAgentsCount").textContent = offline;
  document.getElementById("servicesDownCount").textContent = servicesDown;
  document.getElementById("lastHeartbeatLabel").textContent = `Last heartbeat ${latest || "-"}`;
}

function renderPressureBars(agents) {
  const rows = agents.slice(0, 6).map((item) => ({
    label: item.hostname || item.agent_id,
    count: Math.max(Number(item.cpu_percent || 0), Number(item.ram_percent || 0), Number(item.disk_percent || 0)),
  }));
  const max = Math.max(1, ...rows.map((item) => item.count));
  document.getElementById("agentPressureBars").innerHTML = rows
    .map(
      (item, index) => `
        <div class="progress-row">
          <span>${escapeHtml(item.label)}</span>
          <div class="progress-track">
            <div class="progress-fill protocol-color-${index % 6}" style="width:${Math.max(8, (item.count / max) * 100)}%"></div>
          </div>
          <strong>${item.count.toFixed(0)}%</strong>
        </div>
      `
    )
    .join("");
}

function renderAgentsTable(agents) {
  document.getElementById("agentsTable").innerHTML = agents
    .map(
      (agent) => `
        <tr class="clickable-row" data-agent-id="${escapeHtml(agent.agent_id)}">
          <td>${escapeHtml(agent.hostname || agent.agent_id)}</td>
          <td>${escapeHtml(agent.ip_address)}</td>
          <td>${escapeHtml(agent.os_name)}</td>
          <td>${renderStatus(agent.status)}</td>
          <td>${escapeHtml(agent.last_seen)}</td>
          <td>${agent.cpu_percent == null ? "-" : `${Number(agent.cpu_percent).toFixed(0)}%`}</td>
          <td>${agent.ram_percent == null ? "-" : `${Number(agent.ram_percent).toFixed(0)}%`}</td>
          <td>${agent.disk_percent == null ? "-" : `${Number(agent.disk_percent).toFixed(0)}%`}</td>
        </tr>
      `
    )
    .join("");

  document.querySelectorAll("[data-agent-id]").forEach((row) => {
    row.addEventListener("click", () => loadAgentDetail(row.dataset.agentId));
  });
}

function renderMetrics(metrics) {
  document.getElementById("agentMetricsFeed").innerHTML = metrics
    .slice(0, 10)
    .map(
      (item) => `
        <article class="feed-item feed-item-compact">
          <div class="feed-item-top">
            <strong>${escapeHtml(item.collected_at)}</strong>
            <span class="badge micro-badge">uptime ${Number(item.uptime_seconds) || 0}s</span>
          </div>
          <p>CPU ${Number(item.cpu_percent).toFixed(1)}% - RAM ${Number(item.ram_percent).toFixed(1)}% - Disk ${Number(item.disk_percent).toFixed(1)}%</p>
        </article>
      `
    )
    .join("");
}

function renderServices(services) {
  document.getElementById("agentServicesTable").innerHTML = services
    .map(
      (item) => `
        <tr>
          <td>${escapeHtml(item.service_name)}</td>
          <td>${escapeHtml(item.display_name || "-")}</td>
          <td>${renderStatus(item.status)}</td>
          <td>${escapeHtml(item.checked_at)}</td>
        </tr>
      `
    )
    .join("");
}

function renderEvents(events) {
  document.getElementById("agentEventsFeed").innerHTML = events
    .slice(0, 12)
    .map(
      (event) => `
        <article class="feed-item">
          <div class="feed-item-top">
            <strong>${escapeHtml(event.source)}</strong>
            <span class="badge micro-badge">${escapeHtml(event.level)}</span>
          </div>
          <p>${escapeHtml(event.message)}</p>
          <small>${escapeHtml(event.event_time)}</small>
        </article>
      `
    )
    .join("");
}

function renderAlerts(alerts) {
  document.getElementById("agentAlertsFeed").innerHTML = alerts
    .slice(0, 12)
    .map(
      (alert) => `
        <article class="feed-item">
          <div class="feed-item-top">
            <strong>${escapeHtml(alert.type)}</strong>
            ${renderSeverityBadge(alert.severity)}
          </div>
          <p>${escapeHtml(alert.description)}</p>
          <small>${escapeHtml(alert.timestamp)} - ${escapeHtml(alert.status)}</small>
        </article>
      `
    )
    .join("");
}

async function loadAgentDetail(agentId) {
  try {
    selectedAgentId = agentId;
    const detail = await api.getAgent(agentId);
    const agent = detail.agent || {};
    document.getElementById("agentDetailTitle").textContent = `${agent.hostname || agent.agent_id} - ${agent.ip_address || ""}`;
    renderMetrics(detail.metrics || []);
    renderServices(detail.services || []);
    renderEvents(detail.events || []);
    renderAlerts(detail.alerts || []);
  } catch (error) {
    notifyError(error);
  }
}

async function loadAgents() {
  try {
    const [agents, operations] = await Promise.all([api.getAgents(), api.getDashboardOperations()]);
    const summary = (operations.agents_overview && operations.agents_overview.summary) || {};
    renderKpis(agents, summary);
    renderPressureBars(agents);
    renderAgentsTable(agents);

    if (!selectedAgentId && agents[0]) {
      await loadAgentDetail(agents[0].agent_id);
      return;
    }
    if (selectedAgentId) {
      const exists = agents.some((item) => item.agent_id === selectedAgentId);
      if (exists) {
        await loadAgentDetail(selectedAgentId);
      }
    }
  } catch (error) {
    notifyError(error);
  }
}

window.addEventListener("netvisor:manual-refresh", loadAgents);
loadAgents();
window.setInterval(loadAgents, 8000);
