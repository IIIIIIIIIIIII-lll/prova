import { api, notifyError, renderStatus } from "./api.js";

const FLOW_COLORS = {
  ipv4: "#4cc9f0",
  ssh: "#00d084",
  http: "#3a86ff",
  https: "#7b2cbf",
  smb: "#ef476f",
  rdp: "#ff9f1c",
  mssql: "#ff6b35",
  tcp: "#9fb3c8",
};

const KIND_COLORS = {
  console: "#43b5ff",
  container: "#4cc9f0",
  database: "#ffb84d",
  service: "#20c997",
  dataset: "#9d4edd",
  group: "#9fb3c8",
  endpoint: "#ef476f",
  "network-device": "#ffd166",
};

const canvas = document.getElementById("topologyCanvas");
const context = canvas.getContext("2d");
const tooltip = document.getElementById("topologyTooltip");
const detailPanel = document.getElementById("nodeDetailPanel");
const cardsContainer = document.getElementById("topologyCards");
const legendContainer = document.getElementById("topologyLegend");
const viewBadge = document.getElementById("topologyViewBadge");
const backButton = document.getElementById("backTopologyButton");
const sqlQueryInput = document.getElementById("sqlQueryInput");
const sqlQueryMessage = document.getElementById("sqlQueryMessage");
const sqlResultsTable = document.getElementById("sqlResultsTable");

const scene = {
  rotationX: -0.2,
  rotationY: 0.58,
  zoom: 1,
  isDragging: false,
  dragStartX: 0,
  dragStartY: 0,
  hoveredId: null,
  selectedId: null,
  focusId: null,
  topology: { resources: [], flows: [] },
  visibleResources: [],
  resources3d: [],
  projected: [],
  pulsePhase: 0,
};

function getResourceById(id) {
  return scene.topology.resources.find((item) => String(item.id) === String(id)) || null;
}

function getChildren(parentId) {
  return scene.topology.resources.filter((item) => String(item.parent) === String(parentId));
}

function hasChildren(resource) {
  return getChildren(resource.id).length > 0;
}

const NetworkFlows = {
  fromTopologyPayload(data) {
    if (Array.isArray(data.flows) && data.flows.length) {
      return [...data.flows, ...this.fromResourceHierarchy(data.resources || [])];
    }

    // demo fallback only, no real network activity
    return [
      { from: "soc-console", to: "backend-core", protocol: "https", label: "UI read" },
      { from: "backend-core", to: "sql-core", protocol: "mssql", label: "Read DB" },
      { from: "scanner-core", to: "assets-core", protocol: "ipv4", label: "Known lab paths" },
    ];
  },

  fromResourceHierarchy(resources) {
    return resources
      .filter((resource) => resource.parent)
      .map((resource) => ({
        from: resource.parent,
        to: resource.id,
        protocol: resource.kind === "dataset" ? "mssql" : "tcp",
        label: "Internal component",
        visualOnly: true,
      }));
  },
};

function getOverviewResources() {
  return scene.topology.resources.filter((item) => !item.parent);
}

function getVisibleResources() {
  if (!scene.focusId) {
    return getOverviewResources();
  }
  const focus = getResourceById(scene.focusId);
  if (!focus) {
    return getOverviewResources();
  }
  return [focus, ...getChildren(scene.focusId)];
}

function createLayout(resources) {
  const count = Math.max(resources.length, 1);
  const focused = Boolean(scene.focusId);
  const radiusX = focused ? 310 : 360;
  const radiusY = focused ? 165 : 185;

  return resources.map((resource, index) => {
    if (focused && String(resource.id) === String(scene.focusId)) {
      return { id: resource.id, x: 0, y: 0, z: -70, anchor: "center" };
    }

    const adjustedIndex = focused ? index - 1 : index;
    const adjustedCount = focused ? Math.max(count - 1, 1) : count;
    const angle = (Math.PI * 2 * adjustedIndex) / adjustedCount - Math.PI / 2;
    return {
      id: resource.id,
      x: Math.cos(angle) * radiusX,
      y: Math.sin(angle) * radiusY,
      z: Math.sin(angle * 1.7) * 95 + (resource.parent ? 90 : 0),
      anchor: "ring",
    };
  });
}

function rotatePoint(point) {
  const cosY = Math.cos(scene.rotationY);
  const sinY = Math.sin(scene.rotationY);
  const cosX = Math.cos(scene.rotationX);
  const sinX = Math.sin(scene.rotationX);
  const x1 = point.x * cosY - point.z * sinY;
  const z1 = point.x * sinY + point.z * cosY;
  const y2 = point.y * cosX - z1 * sinX;
  const z2 = point.y * sinX + z1 * cosX;
  return { x: x1, y: y2, z: z2 };
}

function projectPoint(point) {
  const depth = 860;
  const scale = (depth / (depth + point.z + 260)) * scene.zoom;
  return {
    x: canvas.width / 2 + point.x * scale,
    y: canvas.height / 2 + point.y * scale,
    scale,
    depth: point.z,
  };
}

function drawBackground() {
  const gradient = context.createLinearGradient(0, 0, canvas.width, canvas.height);
  gradient.addColorStop(0, "#f4f7fb");
  gradient.addColorStop(0.5, "#dfe8f3");
  gradient.addColorStop(1, "#eef3f8");
  context.fillStyle = gradient;
  context.fillRect(0, 0, canvas.width, canvas.height);

  context.strokeStyle = "rgba(16, 33, 51, 0.08)";
  context.lineWidth = 1;
  for (let x = 56; x < canvas.width; x += 84) {
    context.beginPath();
    context.moveTo(x, 0);
    context.lineTo(x, canvas.height);
    context.stroke();
  }
  for (let y = 56; y < canvas.height; y += 84) {
    context.beginPath();
    context.moveTo(0, y);
    context.lineTo(canvas.width, y);
    context.stroke();
  }
}

function drawCloud(x, y, width, height, color, selected) {
  context.save();
  context.fillStyle = selected ? `${color}33` : "rgba(255, 255, 255, 0.72)";
  context.strokeStyle = selected ? color : `${color}aa`;
  context.lineWidth = selected ? 3 : 2;
  context.shadowBlur = selected ? 18 : 8;
  context.shadowColor = `${color}66`;

  context.beginPath();
  context.ellipse(x - width * 0.23, y + height * 0.03, width * 0.28, height * 0.3, 0, 0, Math.PI * 2);
  context.ellipse(x, y - height * 0.13, width * 0.32, height * 0.38, 0, 0, Math.PI * 2);
  context.ellipse(x + width * 0.25, y + height * 0.02, width * 0.3, height * 0.32, 0, 0, Math.PI * 2);
  context.rect(x - width * 0.43, y, width * 0.86, height * 0.3);
  context.fill();
  context.stroke();
  context.restore();
}

function drawDevice(x, y, size, color, selected) {
  context.save();
  context.fillStyle = selected ? `${color}44` : "#ffffffcc";
  context.strokeStyle = selected ? color : `${color}cc`;
  context.lineWidth = selected ? 3 : 2;
  context.shadowBlur = selected ? 18 : 6;
  context.shadowColor = `${color}55`;
  context.beginPath();
  context.roundRect(x - size, y - size * 0.62, size * 2, size * 1.24, 8);
  context.fill();
  context.stroke();
  context.restore();
}

function visibleIdSet() {
  return new Set(scene.visibleResources.map((item) => String(item.id)));
}

function getVisibleAncestorId(resourceId, ids) {
  let current = getResourceById(resourceId);
  while (current) {
    if (ids.has(String(current.id))) {
      return String(current.id);
    }
    current = current.parent ? getResourceById(current.parent) : null;
  }
  return ids.has(String(resourceId)) ? String(resourceId) : null;
}

function drawFlows(projectedById) {
  const ids = visibleIdSet();
  scene.topology.flows
    .forEach((flow, index) => {
      const sourceId = getVisibleAncestorId(flow.from, ids);
      const targetId = getVisibleAncestorId(flow.to, ids);
      if (!sourceId || !targetId || sourceId === targetId) {
        return;
      }
      const source = projectedById[sourceId];
      const target = projectedById[targetId];
      if (!source || !target) {
        return;
      }

      const color = FLOW_COLORS[flow.protocol] || FLOW_COLORS.tcp;
      const pulse = (scene.pulsePhase + index * 0.09) % 1;
      const controlX = (source.x + target.x) / 2 + Math.sin(index + scene.rotationY) * 46;
      const controlY = (source.y + target.y) / 2 - 58;

      context.strokeStyle = `${color}aa`;
      context.lineWidth = 2.4;
      context.beginPath();
      context.moveTo(source.x, source.y);
      context.quadraticCurveTo(controlX, controlY, target.x, target.y);
      context.stroke();

      const dotX =
        (1 - pulse) * (1 - pulse) * source.x +
        2 * (1 - pulse) * pulse * controlX +
        pulse * pulse * target.x;
      const dotY =
        (1 - pulse) * (1 - pulse) * source.y +
        2 * (1 - pulse) * pulse * controlY +
        pulse * pulse * target.y;
      context.fillStyle = color;
      context.beginPath();
      context.arc(dotX, dotY, 4, 0, Math.PI * 2);
      context.fill();
    });
}

function drawScene() {
  drawBackground();
  if (!scene.visibleResources.length) {
    return;
  }

  scene.projected = scene.resources3d
    .map((point) => {
      const rotated = rotatePoint(point);
      const projection = projectPoint(rotated);
      return { ...projection, point, rotated };
    })
    .sort((left, right) => left.depth - right.depth);

  const projectedById = Object.fromEntries(scene.projected.map((item) => [String(item.point.id), item]));
  drawFlows(projectedById);

  scene.projected.forEach((item) => {
    const resource = getResourceById(item.point.id);
    if (!resource) {
      return;
    }

    const color = KIND_COLORS[resource.kind] || "#4cc9f0";
    const selected = String(scene.selectedId) === String(resource.id);
    const hovered = String(scene.hoveredId) === String(resource.id);
    const isContainer = hasChildren(resource) || ["container", "database", "group"].includes(resource.kind);
    const width = Math.max(118, 150 * item.scale);
    const height = Math.max(72, 90 * item.scale);

    if (isContainer) {
      drawCloud(item.x, item.y, width, height, color, selected || hovered);
    } else {
      drawDevice(item.x, item.y, Math.max(32, 38 * item.scale), color, selected || hovered);
    }

    context.textAlign = "center";
    context.fillStyle = "#142033";
    context.font = `700 ${Math.max(13, 15 * item.scale)}px Segoe UI`;
    context.fillText(resource.label, item.x, item.y + (isContainer ? 6 : 3));
    context.fillStyle = "#52657d";
    context.font = `600 ${Math.max(11, 12 * item.scale)}px Segoe UI`;
    context.fillText(hasChildren(resource) ? "open" : resource.kind, item.x, item.y + (isContainer ? 25 : 23));
  });
}

function getNearestResource(mouseX, mouseY) {
  let nearest = null;
  let nearestDistance = Infinity;
  scene.projected.forEach((item) => {
    const distance = Math.hypot(item.x - mouseX, item.y - mouseY);
    if (distance < 86 && distance < nearestDistance) {
      nearestDistance = distance;
      nearest = item.point.id;
    }
  });
  return nearest;
}

function renderLegend() {
  const protocols = Object.entries(FLOW_COLORS).map(
    ([protocol, color]) => `<span class="legend-chip"><span class="legend-dot" style="background:${color}"></span>${protocol.toUpperCase()}</span>`
  );
  const kinds = Object.entries(KIND_COLORS).map(
    ([kind, color]) => `<span class="legend-chip"><span class="legend-dot" style="background:${color}"></span>${kind}</span>`
  );
  legendContainer.innerHTML = [...protocols, ...kinds].join("");
}

function renderCards() {
  cardsContainer.innerHTML = scene.visibleResources
    .map((resource) => {
      const statusMarkup = resource.status ? renderStatus(resource.status) : "<span class='muted'>n/a</span>";
      const children = getChildren(resource.id).length;
      return `
        <article class="topology-card ${String(scene.selectedId) === String(resource.id) ? "topology-card-active" : ""}" data-resource-id="${resource.id}">
          <h4>${resource.label}</h4>
          <p>${resource.kind} ${children ? `- ${children} elementi` : ""}</p>
          <p>${statusMarkup}</p>
          <p class="muted">${resource.details || "-"}</p>
        </article>
      `;
    })
    .join("");

  cardsContainer.querySelectorAll("[data-resource-id]").forEach((card) => {
    card.addEventListener("click", () => selectResource(card.dataset.resourceId, true));
  });
}

function renderDetail() {
  const resource = getResourceById(scene.selectedId);
  if (!resource) {
    detailPanel.className = "detail-stack muted";
    detailPanel.textContent = "Seleziona una risorsa per vedere gruppo, dipendenze, servizi, rischio e relazioni.";
    return;
  }

  const services = resource.services || [];
  const dependencies = resource.dependencies || [];
  const children = getChildren(resource.id);
  detailPanel.className = "detail-stack";
  detailPanel.innerHTML = `
    <div class="detail-kpi-row">
      <span class="detail-kpi"><strong>${resource.kind}</strong><small>Tipo</small></span>
      <span class="detail-kpi"><strong>${resource.status || "n/a"}</strong><small>Stato</small></span>
      <span class="detail-kpi"><strong>${children.length}</strong><small>Elementi</small></span>
    </div>
    <div class="detail-grid">
      <div>
        <h4>${resource.label}</h4>
        <p>${resource.details || "-"}</p>
        <p class="muted">Vista: ${scene.focusId ? "interna" : "overview"}</p>
      </div>
      <div>
        <h4>Flow visibili</h4>
        <p class="muted">${scene.topology.flows.filter((flow) => String(flow.from) === String(resource.id) || String(flow.to) === String(resource.id)).length} collegamenti associati</p>
      </div>
      <div class="detail-grid-span">
        <h4>Contenuto</h4>
        <ul class="plain-list">
          ${
            children.length || dependencies.length || services.length
              ? [
                  ...children.map((item) => `<li>${item.label} (${item.kind})</li>`),
                  ...dependencies.map((item) => `<li>${item}</li>`),
                  ...services.map((service) => `<li>${service.service_name || service.protocol}:${service.port}/${service.protocol}</li>`),
                ].join("")
              : "<li>Nessun elemento interno registrato.</li>"
          }
        </ul>
      </div>
    </div>
  `;
}

function updateSceneData() {
  scene.visibleResources = getVisibleResources();
  scene.resources3d = createLayout(scene.visibleResources);
  backButton.hidden = !scene.focusId;
  const focus = getResourceById(scene.focusId);
  viewBadge.textContent = focus ? focus.label : "Overview";
  if (!scene.selectedId || !scene.visibleResources.some((item) => String(item.id) === String(scene.selectedId))) {
    scene.selectedId = scene.visibleResources[0]?.id ?? null;
  }
}

function selectResource(resourceId, enterIfContainer = false) {
  const resource = getResourceById(resourceId);
  if (!resource) {
    return;
  }
  scene.selectedId = resource.id;
  if (enterIfContainer && hasChildren(resource)) {
    scene.focusId = resource.id;
    scene.selectedId = resource.id;
    updateSceneData();
  }
  renderCards();
  renderDetail();
}

function handlePointerMove(event) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;
  const mouseX = (event.clientX - rect.left) * scaleX;
  const mouseY = (event.clientY - rect.top) * scaleY;

  if (scene.isDragging) {
    const deltaX = event.clientX - scene.dragStartX;
    const deltaY = event.clientY - scene.dragStartY;
    scene.rotationY += deltaX * 0.008;
    scene.rotationX = Math.max(-1.05, Math.min(1.05, scene.rotationX + deltaY * 0.008));
    scene.dragStartX = event.clientX;
    scene.dragStartY = event.clientY;
    tooltip.hidden = true;
    return;
  }

  scene.hoveredId = getNearestResource(mouseX, mouseY);
  const resource = getResourceById(scene.hoveredId);
  if (!resource) {
    tooltip.hidden = true;
    return;
  }
  tooltip.hidden = false;
  tooltip.style.left = `${event.clientX + 14}px`;
  tooltip.style.top = `${event.clientY + 14}px`;
  tooltip.innerHTML = `<strong>${resource.label}</strong><br>${resource.kind}<br>${resource.details || ""}`;
}

function handleCanvasClick(event) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;
  const mouseX = (event.clientX - rect.left) * scaleX;
  const mouseY = (event.clientY - rect.top) * scaleY;
  selectResource(getNearestResource(mouseX, mouseY), true);
}

function animate() {
  scene.pulsePhase = (scene.pulsePhase + 0.008) % 1;
  drawScene();
  window.requestAnimationFrame(animate);
}

function renderSqlResults(result) {
  const thead = sqlResultsTable.querySelector("thead");
  const tbody = sqlResultsTable.querySelector("tbody");
  thead.innerHTML = `<tr>${result.columns.map((column) => `<th>${column}</th>`).join("")}</tr>`;
  tbody.innerHTML = result.rows
    .map((row) => `<tr>${row.map((cell) => `<td>${cell == null ? "" : String(cell)}</td>`).join("")}</tr>`)
    .join("");
  sqlQueryMessage.textContent = result.truncated
    ? `Mostrate ${result.row_count} righe. Output troncato dal limite di sicurezza.`
    : `Query completata: ${result.row_count} righe.`;
}

async function runSqlQuery() {
  try {
    const result = await api.runAdminQuery(sqlQueryInput.value.trim());
    renderSqlResults(result);
  } catch (error) {
    sqlQueryMessage.textContent = error.message || String(error);
    notifyError(error);
  }
}

function registerSqlTemplates() {
  document.querySelectorAll(".query-template").forEach((button) => {
    button.addEventListener("click", () => {
      sqlQueryInput.value = button.dataset.query || "";
    });
  });
}

async function loadTopology() {
  try {
    const data = await api.getTopology();
    scene.topology = {
      resources: data.resources || [],
      flows: NetworkFlows.fromTopologyPayload(data),
    };
    scene.focusId = null;
    scene.selectedId = null;
    updateSceneData();
    renderLegend();
    renderCards();
    renderDetail();
  } catch (error) {
    notifyError(error);
  }
}

document.getElementById("reloadTopologyButton").addEventListener("click", loadTopology);
backButton.addEventListener("click", () => {
  scene.focusId = null;
  scene.selectedId = null;
  updateSceneData();
  renderCards();
  renderDetail();
});
document.getElementById("runSqlButton").addEventListener("click", runSqlQuery);

canvas.addEventListener("mousedown", (event) => {
  scene.isDragging = true;
  scene.dragStartX = event.clientX;
  scene.dragStartY = event.clientY;
});
canvas.addEventListener("mousemove", handlePointerMove);
canvas.addEventListener("mouseleave", () => {
  scene.isDragging = false;
  scene.hoveredId = null;
  tooltip.hidden = true;
});
canvas.addEventListener("mouseup", () => {
  scene.isDragging = false;
});
window.addEventListener("mouseup", () => {
  scene.isDragging = false;
});
canvas.addEventListener("click", handleCanvasClick);
canvas.addEventListener("wheel", (event) => {
  event.preventDefault();
  scene.zoom = Math.max(0.65, Math.min(1.7, scene.zoom + (event.deltaY < 0 ? 0.08 : -0.08)));
});

registerSqlTemplates();
loadTopology();
animate();
