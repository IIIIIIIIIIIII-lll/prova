import { api, exportTableToCSV, isAdminUser, notifyError, renderStatus } from "./api.js";

const FLOW_COLORS = {
  ipv4: "#00b8d9",
  ssh: "#f59e0b",
  http: "#38bdf8",
  https: "#2563eb",
  smb: "#10b981",
  rdp: "#ef4444",
  mssql: "#8b5cf6",
  icmp: "#ec4899",
  udp: "#14b8a6",
  tcp: "#9fb3c8",
  volume: "#94a3b8",
};

const KIND_COLORS = {
  console: "#43b5ff",
  container: "#4cc9f0",
  database: "#ffb84d",
  service: "#20c997",
  dataset: "#9d4edd",
  group: "#9fb3c8",
  endpoint: "#ef476f",
  "network-device": "#ffd166",
  storage_volume: "#94a3b8",
};

const FLOW_TYPE_LABELS = {
  static: "Architettura",
  service: "Servizi",
  health_check: "Health check",
  scan_run: "Scan run",
  volume_mount: "Volume mount",
};

const NODE_DESCRIPTIONS = {
  "soc-console": "CTR_frontend-1 · Nginx UI e reverse proxy",
  "backend-core": "CTR_backend-1 · Flask API, auth, orchestrazione",
  "sql-core": "CTR_sqlserver-1 · SQL Server e persistenza SIEM",
  "scanner-core": "CTR_scan-worker-1 · Worker scan e parser",
  "assets-core": "CTR_assets-1 · Nodi del laboratorio",
  "agents-core": "CTR_agents-1 · Telemetry agent",
  "jobs-core": "CTR_jobs-1 · Job scansioni e checks",
  "pipeline-core": "CTR_event-pipeline-1 · Ingest e alerting",
  "vol-scan-output": "Volume scanner output",
  "vol-sqlserver-data": "Volume persistenza SQL Server",
};

const MAX_FLOW_WIDTH = 8;

const filterState = {
  protocols: new Set(Object.keys(FLOW_COLORS)),
  types: new Set(["static", "service", "health_check", "scan_run", "volume_mount"]),
  timeWindowHours: 1,
  direction: "both",
  isolatedFlow: null,
};

const canvas = document.getElementById("topologyCanvas");
const context = canvas.getContext("2d");
const tooltip = document.getElementById("topologyTooltip");
const detailPanel = document.getElementById("nodeDetailPanel");
const cardsContainer = document.getElementById("topologyCards");
const legendContainer = document.getElementById("topologyLegend");
const viewBadge = document.getElementById("topologyViewBadge");
const backButton = document.getElementById("backTopologyButton");
const sqlQueryInput = document.getElementById("sqlQueryInput");
const sqlQueryMessage = document.getElementById("sqlQueryMessage");
const sqlResultsTable = document.getElementById("sqlResultsTable");
const isolatedFlowLabel = document.getElementById("isolatedFlowLabel");

if (backButton) {
  backButton.textContent = "← Back";
}

const scene = {
  rotationX: -0.22,
  rotationY: 0.62,
  zoom: 1,
  isDragging: false,
  dragStartX: 0,
  dragStartY: 0,
  hoveredId: null,
  selectedId: null,
  focusId: null,
  topology: { resources: [], flows: [] },
  visibleResources: [],
  resources3d: [],
  projected: [],
  pulsePhase: 0,
};

window._topologyScene = scene;

const drillStack = [];
let drawnFlowPaths = [];
let topologyPollTimer = null;



function getResourceById(id) {
  return scene.topology.resources.find((item) => String(item.id) === String(id)) || null;
}

function getChildren(parentId) {
  return scene.topology.resources.filter((item) => String(item.parent) === String(parentId));
}

function hasChildren(resource) {
  return getChildren(resource.id).length > 0;
}

function buildDrillPath(resourceId) {
  const path = [];
  let current = getResourceById(resourceId);
  while (current) {
    path.unshift({ id: current.id, label: current.label, kind: current.kind });
    current = current.parent ? getResourceById(current.parent) : null;
  }
  return path;
}

function renderBreadcrumb() {
  if (!viewBadge) return;
  if (!drillStack.length) {
    viewBadge.textContent = "Overview";
    viewBadge.classList.remove("topology-breadcrumb");
    return;
  }
  viewBadge.classList.add("topology-breadcrumb");
  viewBadge.textContent = drillStack.map((item) => item.label).join("  >  ");
}

function getOverviewResources() {
  return scene.topology.resources.filter((item) => !item.parent);
}

function getVisibleResources() {
  if (!scene.focusId) {
    return getOverviewResources();
  }
  const focus = getResourceById(scene.focusId);
  if (!focus) {
    return getOverviewResources();
  }
  return [focus, ...getChildren(scene.focusId)];
}

const NetworkFlows = {
  fromTopologyPayload(data) {
    const base = Array.isArray(data.flows) ? data.flows : [];
    const hierarchy = this.fromResourceHierarchy(data.resources || []);
    const existing = new Set(base.map((flow) => `${flow.from}|${flow.to}|${flow.protocol}|${flow.port || ""}|${flow.label || ""}`));
    const extras = hierarchy.filter((flow) => !existing.has(`${flow.from}|${flow.to}|${flow.protocol}|${flow.port || ""}|${flow.label || ""}`));
    return [...base, ...extras];
  },

  fromResourceHierarchy(resources) {
    return resources
      .filter((resource) => resource.parent)
      .map((resource) => ({
        from: resource.parent,
        to: resource.id,
        protocol: resource.kind === "storage_volume" ? "volume" : (resource.flow_protocol || (resource.kind === "dataset" ? "mssql" : "tcp")),
        label: resource.kind === "storage_volume" ? "Volume mount" : "Internal component",
        visualOnly: true,
        type: resource.kind === "storage_volume" ? "volume_mount" : "static",
        active: true,
        direction: "out",
        volume: resource.volume || 10,
        avg_mbps: resource.avg_mbps || Math.max(0.8, Math.round((resource.volume || 10) * 0.28 * 100) / 100),
      }));
  },
};

function getDirectionAnchor() {
  return scene.selectedId || scene.focusId || null;
}

function flowVisible(flow) {
  if (filterState.isolatedFlow) {
    return flow === filterState.isolatedFlow;
  }
  const protocol = flow.protocol || "tcp";
  const type = flow.type || "static";
  if (!filterState.protocols.has(protocol) || !filterState.types.has(type)) {
    return false;
  }
  if (filterState.direction === "in") {
    return (flow.direction || "out") === "in";
  }
  if (filterState.direction === "out") {
    return (flow.direction || "out") === "out";
  }
  return true;
}

function createLayout(resources) {
  const count = Math.max(resources.length, 1);
  const focused = Boolean(scene.focusId);
  const radiusX = focused ? 320 : 380;
  const radiusY = focused ? 175 : 195;

  return resources.map((resource, index) => {
    if (focused && String(resource.id) === String(scene.focusId)) {
      return { id: resource.id, x: 0, y: 0, z: -80, anchor: "center" };
    }
    const adjustedIndex = focused ? index - 1 : index;
    const adjustedCount = focused ? Math.max(count - 1, 1) : count;
    const angle = (Math.PI * 2 * adjustedIndex) / adjustedCount - Math.PI / 2;
    const level = resource.level || (resource.parent ? 2 : 1);
    return {
      id: resource.id,
      x: Math.cos(angle) * radiusX,
      y: Math.sin(angle) * radiusY,
      z: Math.sin(angle * 1.65) * 105 + (level === 3 ? 110 : resource.parent ? 75 : 0),
      anchor: "ring",
    };
  });
}

function rotatePoint(point) {
  const cosY = Math.cos(scene.rotationY);
  const sinY = Math.sin(scene.rotationY);
  const cosX = Math.cos(scene.rotationX);
  const sinX = Math.sin(scene.rotationX);
  const x1 = point.x * cosY - point.z * sinY;
  const z1 = point.x * sinY + point.z * cosY;
  const y2 = point.y * cosX - z1 * sinX;
  const z2 = point.y * sinX + z1 * cosX;
  return { x: x1, y: y2, z: z2 };
}

function projectPoint(point) {
  const depth = 860;
  const scale = (depth / (depth + point.z + 260)) * scene.zoom;
  return {
    x: canvas.width / 2 + point.x * scale,
    y: canvas.height / 2 + point.y * scale,
    scale,
    depth: point.z,
  };
}

function drawBackground() {
  const gradient = context.createLinearGradient(0, 0, canvas.width, canvas.height);
  gradient.addColorStop(0, "#f4f7fb");
  gradient.addColorStop(0.46, "#dfe8f3");
  gradient.addColorStop(1, "#eef3f8");
  context.fillStyle = gradient;
  context.fillRect(0, 0, canvas.width, canvas.height);

  context.strokeStyle = "rgba(16, 33, 51, 0.08)";
  context.lineWidth = 1;
  for (let x = 56; x < canvas.width; x += 84) {
    context.beginPath();
    context.moveTo(x, 0);
    context.lineTo(x, canvas.height);
    context.stroke();
  }
  for (let y = 56; y < canvas.height; y += 84) {
    context.beginPath();
    context.moveTo(0, y);
    context.lineTo(canvas.width, y);
    context.stroke();
  }
}

function drawCloud(x, y, width, height, color, selected) {
  context.save();
  context.fillStyle = selected ? `${color}33` : "rgba(255, 255, 255, 0.76)";
  context.strokeStyle = selected ? color : `${color}bb`;
  context.lineWidth = selected ? 3 : 2;
  context.shadowBlur = selected ? 18 : 8;
  context.shadowColor = `${color}66`;
  context.beginPath();
  context.ellipse(x - width * 0.23, y + height * 0.03, width * 0.28, height * 0.3, 0, 0, Math.PI * 2);
  context.ellipse(x, y - height * 0.13, width * 0.32, height * 0.38, 0, 0, Math.PI * 2);
  context.ellipse(x + width * 0.25, y + height * 0.02, width * 0.3, height * 0.32, 0, 0, Math.PI * 2);
  context.rect(x - width * 0.43, y, width * 0.86, height * 0.3);
  context.fill();
  context.stroke();
  context.restore();
}

function drawDevice(x, y, size, color, selected) {
  context.save();
  context.fillStyle = selected ? `${color}44` : "#ffffffd8";
  context.strokeStyle = selected ? color : `${color}cc`;
  context.lineWidth = selected ? 3 : 2;
  context.shadowBlur = selected ? 18 : 6;
  context.shadowColor = `${color}55`;
  context.beginPath();
  context.roundRect(x - size, y - size * 0.62, size * 2, size * 1.24, 8);
  context.fill();
  context.stroke();
  context.restore();
}

function drawCylinder(x, y, width, height, color, selected) {
  context.save();
  const ellipseH = height * 0.22;
  context.fillStyle = selected ? `${color}33` : "rgba(255,255,255,0.85)";
  context.strokeStyle = selected ? color : `${color}cc`;
  context.lineWidth = selected ? 3 : 2;
  context.shadowBlur = selected ? 14 : 6;
  context.shadowColor = `${color}55`;

  context.beginPath();
  context.moveTo(x - width / 2, y - height / 2 + ellipseH / 2);
  context.lineTo(x - width / 2, y + height / 2 - ellipseH / 2);
  context.bezierCurveTo(x - width / 2, y + height / 2, x + width / 2, y + height / 2, x + width / 2, y + height / 2 - ellipseH / 2);
  context.lineTo(x + width / 2, y - height / 2 + ellipseH / 2);
  context.bezierCurveTo(x + width / 2, y - height / 2, x - width / 2, y - height / 2, x - width / 2, y - height / 2 + ellipseH / 2);
  context.fill();
  context.stroke();

  context.beginPath();
  context.ellipse(x, y - height / 2 + ellipseH / 2, width / 2, ellipseH / 2, 0, 0, Math.PI * 2);
  context.stroke();
  context.restore();
}

function visibleIdSet() {
  return new Set(scene.visibleResources.map((item) => String(item.id)));
}

function getVisibleAncestorId(resourceId, ids) {
  let current = getResourceById(resourceId);
  while (current) {
    if (ids.has(String(current.id))) {
      return String(current.id);
    }
    current = current.parent ? getResourceById(current.parent) : null;
  }
  return ids.has(String(resourceId)) ? String(resourceId) : null;
}

function resolveVisibleFlows() {
  const ids = visibleIdSet();
  return scene.topology.flows
    .filter(flowVisible)
    .map((flow) => {
      const sourceId = getVisibleAncestorId(flow.from, ids);
      const targetId = getVisibleAncestorId(flow.to, ids);
      if (!sourceId || !targetId || sourceId === targetId) {
        return null;
      }
      return {
        ...flow,
        sourceId,
        targetId,
        volume: Number(flow.volume || 10),
        avg_mbps: Number(flow.avg_mbps || 0.8),
      };
    })
    .filter(Boolean);
}

function drawFlows(projectedById) {
  drawnFlowPaths = [];
  const resolvedFlows = resolveVisibleFlows();
  const pairDirections = new Map();

  resolvedFlows.forEach((flow) => {
    const pairKey = `${[flow.sourceId, flow.targetId].sort().join("|")}|${flow.protocol}|${flow.port || ""}`;
    if (!pairDirections.has(pairKey)) {
      pairDirections.set(pairKey, new Set());
    }
    pairDirections.get(pairKey).add(`${flow.sourceId}->${flow.targetId}`);
  });

  resolvedFlows.forEach((flow, index) => {
    const source = projectedById[flow.sourceId];
    const target = projectedById[flow.targetId];
    if (!source || !target) {
      return;
    }

    const pairKey = `${[flow.sourceId, flow.targetId].sort().join("|")}|${flow.protocol}|${flow.port || ""}`;
    const directionSet = pairDirections.get(pairKey) || new Set();
    const isBidirectional = directionSet.size > 1;
    const isVolumeMount = flow.type === "volume_mount" || flow.protocol === "volume";
    const baseColor = isVolumeMount ? FLOW_COLORS.volume : (FLOW_COLORS[flow.protocol] || FLOW_COLORS.tcp);
    const dimmed = filterState.isolatedFlow && filterState.isolatedFlow !== flow;
    const alpha = dimmed ? "1a" : (flow.active !== false ? "d1" : "58");

    const dx = target.x - source.x;
    const dy = target.y - source.y;
    const length = Math.hypot(dx, dy) || 1;
    const normalX = -dy / length;
    const normalY = dx / length;
    let offset = 0;
    if (isBidirectional && filterState.direction === "both") {
      const canonical = `${flow.sourceId}->${flow.targetId}` === [...directionSet][0];
      offset = canonical ? 16 : -16;
    }

    const startX = source.x + normalX * offset * 0.28;
    const startY = source.y + normalY * offset * 0.28;
    const endX = target.x + normalX * offset * 0.28;
    const endY = target.y + normalY * offset * 0.28;
    const controlX = (startX + endX) / 2 + normalX * offset * 0.9 + Math.sin(index + scene.rotationY) * 22;
    const controlY = (startY + endY) / 2 + normalY * offset * 0.9 - 58;
    const lineWidth = Math.min(MAX_FLOW_WIDTH, 1.8 + Math.log2(1 + Math.max(1, flow.volume)) * 1.28);

    drawnFlowPaths.push({
      flow,
      sx: startX,
      sy: startY,
      cx: controlX,
      cy: controlY,
      tx: endX,
      ty: endY,
    });

    context.save();
    context.strokeStyle = `${baseColor}${alpha}`;
    context.lineWidth = lineWidth;
    context.setLineDash(isVolumeMount ? [8, 5] : []);
    context.beginPath();
    context.moveTo(startX, startY);
    context.quadraticCurveTo(controlX, controlY, endX, endY);
    context.stroke();
    context.restore();

    if (flow.active !== false && !dimmed && !isVolumeMount) {
      const pulse = (scene.pulsePhase + index * 0.085) % 1;
      const dotX = (1 - pulse) * (1 - pulse) * startX + 2 * (1 - pulse) * pulse * controlX + pulse * pulse * endX;
      const dotY = (1 - pulse) * (1 - pulse) * startY + 2 * (1 - pulse) * pulse * controlY + pulse * pulse * endY;
      context.fillStyle = baseColor;
      context.beginPath();
      context.arc(dotX, dotY, Math.min(6, 3 + lineWidth * 0.25), 0, Math.PI * 2);
      context.fill();
    }
  });
}

function drawScene() {
  drawBackground();
  if (!scene.visibleResources.length) {
    return;
  }

  scene.projected = scene.resources3d
    .map((point) => {
      const rotated = rotatePoint(point);
      const projection = projectPoint(rotated);
      return { ...projection, point, rotated };
    })
    .sort((left, right) => left.depth - right.depth);

  const projectedById = Object.fromEntries(scene.projected.map((item) => [String(item.point.id), item]));
  drawFlows(projectedById);

  scene.projected.forEach((item) => {
    const resource = getResourceById(item.point.id);
    if (!resource) return;

    const color = KIND_COLORS[resource.kind] || "#4cc9f0";
    const selected = String(scene.selectedId) === String(resource.id);
    const hovered = String(scene.hoveredId) === String(resource.id);
    const isContainer = hasChildren(resource) || ["container", "database", "group"].includes(resource.kind);
    const isStorage = resource.kind === "storage_volume";
    const width = Math.max(120, 152 * item.scale);
    const height = Math.max(72, 92 * item.scale);

    if (isStorage) {
      drawCylinder(item.x, item.y, width * 0.72, height * 0.95, color, selected || hovered);
    } else if (isContainer) {
      drawCloud(item.x, item.y, width, height, color, selected || hovered);
    } else {
      drawDevice(item.x, item.y, Math.max(32, 38 * item.scale), color, selected || hovered);
    }

    context.textAlign = "center";
    context.fillStyle = "#142033";
    context.font = `700 ${Math.max(12, 15 * item.scale)}px Segoe UI`;
    context.fillText(resource.label, item.x, item.y + (isContainer ? 6 : 2));
    context.fillStyle = "#52657d";
    context.font = `600 ${Math.max(10, 12 * item.scale)}px Segoe UI`;
    const subLabel = hasChildren(resource) ? `L${resource.level || 1} open` : (resource.kind === "service" && resource.port ? `${resource.flow_protocol || resource.transport_protocol}:${resource.port}` : resource.kind);
    context.fillText(subLabel, item.x, item.y + (isContainer ? 25 : 23));
  });
}

function getNearestResource(mouseX, mouseY) {
  let nearest = null;
  let nearestDistance = Infinity;
  scene.projected.forEach((item) => {
    const distance = Math.hypot(item.x - mouseX, item.y - mouseY);
    if (distance < 86 && distance < nearestDistance) {
      nearestDistance = distance;
      nearest = item.point.id;
    }
  });
  return nearest;
}

function distToQuadBezier(mx, my, sx, sy, cx, cy, tx, ty) {
  let minDistance = Infinity;
  for (let t = 0; t <= 1; t += 0.04) {
    const it = 1 - t;
    const bx = it * it * sx + 2 * it * t * cx + t * t * tx;
    const by = it * it * sy + 2 * it * t * cy + t * t * ty;
    minDistance = Math.min(minDistance, Math.hypot(mx - bx, my - by));
  }
  return minDistance;
}

function getFlowAtPoint(mx, my) {
  for (const path of drawnFlowPaths) {
    if (distToQuadBezier(mx, my, path.sx, path.sy, path.cx, path.cy, path.tx, path.ty) < 10) {
      return path.flow;
    }
  }
  return null;
}

function renderLegend() {
  const protocolChips = Object.entries(FLOW_COLORS).map(([proto, color]) => {
    const active = filterState.protocols.has(proto);
    return `<button class="legend-chip legend-filter ${active ? "legend-filter-on" : "legend-filter-off"}" data-filter-proto="${proto}" style="--chip-color:${color}">
      <span class="legend-dot" style="${proto === "volume" ? `background:transparent;border:1.4px dashed ${color}` : `background:${color}`}"></span>${proto.toUpperCase()}
    </button>`;
  }).join("");

  const typeChips = Object.entries(FLOW_TYPE_LABELS).map(([type, label]) => {
    const active = filterState.types.has(type);
    return `<button class="legend-chip legend-filter ${active ? "legend-filter-on" : "legend-filter-off"}" data-filter-type="${type}">
      <span class="legend-dot" style="background:#9fb3c8"></span>${label}
    </button>`;
  }).join("");

    const nodeRows = Object.entries(NODE_DESCRIPTIONS).map(([id, description]) => `
      <div class="legend-node-row">
        <code class="legend-node-id">${id}</code>
        <span class="muted">${description}</span>
      </div>
  `).join("");

  legendContainer.innerHTML = `
    <div class="legend-section">
      <span class="legend-section-label">Protocolli</span>
      <div class="legend-chips-row">${protocolChips}</div>
    </div>
      <div class="legend-section">
        <span class="legend-section-label">Tipo flusso</span>
        <div class="legend-chips-row">${typeChips}</div>
      </div>
      <details class="legend-node-dir">
        <summary class="legend-section-label">Directory container</summary>
        <div class="legend-node-list">${nodeRows}</div>
      </details>
  `;

  legendContainer.querySelectorAll("[data-filter-proto]").forEach((button) => {
    button.addEventListener("click", () => {
      const protocol = button.dataset.filterProto;
      filterState.protocols.has(protocol) ? filterState.protocols.delete(protocol) : filterState.protocols.add(protocol);
      renderLegend();
    });
  });
  legendContainer.querySelectorAll("[data-filter-type]").forEach((button) => {
    button.addEventListener("click", () => {
      const type = button.dataset.filterType;
      filterState.types.has(type) ? filterState.types.delete(type) : filterState.types.add(type);
      renderLegend();
    });
  });
}

function renderCards() {
  cardsContainer.innerHTML = scene.visibleResources.map((resource) => {
    const statusMarkup = resource.status ? renderStatus(resource.status) : "<span class='muted'>n/a</span>";
    const children = getChildren(resource.id).length;
    const childBadge = children ? `<span class="topology-child-badge${resource.highlight ? " is-active" : ""}">${children}</span>` : "";
    return `
      <article class="topology-card${String(scene.selectedId) === String(resource.id) ? " topology-card-active" : ""}${resource.highlight ? " topology-card-highlight" : ""}" data-resource-id="${resource.id}">
        ${childBadge}
        <h4>${resource.label}</h4>
        <p>${resource.kind}${children ? ` · ${children} elementi` : ""}</p>
        <p>${statusMarkup}</p>
        <p class="muted">${resource.details || "-"}</p>
        ${children ? '<p class="topology-card-hint">▸ Drill-down</p>' : ""}
      </article>
    `;
  }).join("");

  cardsContainer.querySelectorAll("[data-resource-id]").forEach((card) => {
    card.addEventListener("click", () => selectResource(card.dataset.resourceId, true));
  });

  cardsContainer.classList.toggle("has-selection", Boolean(scene.selectedId));
}

function renderDetail() {
  const resource = getResourceById(scene.selectedId);
  if (!resource) {
    detailPanel.className = "detail-stack muted";
    detailPanel.textContent = "Seleziona una risorsa per vedere genealogia, throughput, dipendenze e servizi.";
    return;
  }

  const path = buildDrillPath(resource.id).map((item) => item.label).join(" > ");
  const children = getChildren(resource.id);
  const services = resource.services || [];
  const dependencies = resource.dependencies || [];
  const relatedFlows = scene.topology.flows.filter((flow) => String(flow.from) === String(resource.id) || String(flow.to) === String(resource.id));
  const topFlow = [...relatedFlows].sort((left, right) => Number(right.volume || 0) - Number(left.volume || 0))[0];

  detailPanel.className = "detail-stack";
  detailPanel.innerHTML = `
    <div class="detail-kpi-row">
      <span class="detail-kpi"><strong>${resource.kind}</strong><small>Tipo</small></span>
      <span class="detail-kpi"><strong>${resource.status || "n/a"}</strong><small>Stato</small></span>
      <span class="detail-kpi"><strong>${resource.avg_mbps ? `${Number(resource.avg_mbps).toFixed(1)} Mb/s` : (topFlow ? `${Number(topFlow.avg_mbps || 0).toFixed(1)} Mb/s` : "n/a")}</strong><small>Throughput</small></span>
    </div>
    <div class="detail-grid">
      <div class="detail-grid-span">
        <h4>Breadcrumb</h4>
        <p class="muted">${path || "Overview"}</p>
      </div>
      <div>
        <h4>${resource.label}</h4>
        <p>${resource.details || "-"}</p>
      </div>
      <div>
        <h4>Flow associati</h4>
        <p class="muted">${relatedFlows.length} collegamenti · ${topFlow ? `${Number(topFlow.avg_mbps || 0).toFixed(1)} Mb/s medi` : "nessun dato"}</p>
      </div>
      <div class="detail-grid-span">
        <h4>Contenuto</h4>
        <ul class="plain-list">
          ${
            children.length || dependencies.length || services.length
              ? [
                  ...children.map((item) => `<li>${item.label} (${item.kind})</li>`),
                  ...dependencies.map((item) => `<li>${item}</li>`),
                  ...services.map((service) => `<li>${service.service_name || service.protocol}:${service.port}/${service.protocol} · ${Number(service.avg_mbps || 0).toFixed(1)} Mb/s</li>`),
                ].join("")
              : "<li>Nessun elemento interno registrato.</li>"
          }
        </ul>
      </div>
    </div>
  `;
}

function updateSceneData() {
  scene.visibleResources = getVisibleResources();
  scene.resources3d = createLayout(scene.visibleResources);
  backButton.hidden = !drillStack.length;
  renderBreadcrumb();
  if (!scene.selectedId || !scene.visibleResources.some((item) => String(item.id) === String(scene.selectedId))) {
    scene.selectedId = scene.visibleResources[0]?.id ?? null;
  }
}

function selectResource(resourceId, enterIfExpandable = false) {
  const resource = getResourceById(resourceId);
  if (!resource) return;

  scene.selectedId = resource.id;
  const path = buildDrillPath(resource.id);
  if (enterIfExpandable) {
    drillStack.length = 0;
    drillStack.push(...path);
    if (hasChildren(resource)) {
      scene.focusId = resource.id;
    } else {
      const parent = resource.parent ? getResourceById(resource.parent) : null;
      scene.focusId = parent && hasChildren(parent) ? parent.id : null;
    }
  }

  updateSceneData();
  renderCards();
  renderDetail();
}

function stepBackDrill() {
  if (!drillStack.length) return;
  drillStack.pop();
  if (!drillStack.length) {
    scene.focusId = null;
    scene.selectedId = null;
  } else {
    const current = drillStack[drillStack.length - 1];
    scene.selectedId = current.id;
    const currentResource = getResourceById(current.id);
    if (currentResource && hasChildren(currentResource)) {
      scene.focusId = current.id;
    } else if (currentResource?.parent) {
      scene.focusId = currentResource.parent;
    } else {
      scene.focusId = null;
    }
  }
  updateSceneData();
  renderCards();
  renderDetail();
}

function updateIsolatedFlowLabel() {
  if (!isolatedFlowLabel) return;
  if (!filterState.isolatedFlow) {
    isolatedFlowLabel.hidden = true;
    return;
  }
  const flow = filterState.isolatedFlow;
  isolatedFlowLabel.hidden = false;
  isolatedFlowLabel.textContent = `Isolato: ${(flow.protocol || "tcp").toUpperCase()} · ${Number(flow.avg_mbps || 0).toFixed(1)} Mb/s`;
}

function handlePointerMove(event) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;
  const mouseX = (event.clientX - rect.left) * scaleX;
  const mouseY = (event.clientY - rect.top) * scaleY;

  if (scene.isDragging) {
    scene.rotationY += (event.clientX - scene.dragStartX) * 0.008;
    scene.rotationX = Math.max(-1.05, Math.min(1.05, scene.rotationX + (event.clientY - scene.dragStartY) * 0.008));
    scene.dragStartX = event.clientX;
    scene.dragStartY = event.clientY;
    tooltip.hidden = true;
    return;
  }

  const hoveredFlow = getFlowAtPoint(mouseX, mouseY);
  if (hoveredFlow) {
    const fromLabel = getResourceById(hoveredFlow.from)?.label || hoveredFlow.from;
    const toLabel = getResourceById(hoveredFlow.to)?.label || hoveredFlow.to;
    tooltip.hidden = false;
    tooltip.style.left = `${event.clientX + 14}px`;
    tooltip.style.top = `${event.clientY + 14}px`;
    tooltip.innerHTML = `
      <strong>${hoveredFlow.label || hoveredFlow.protocol.toUpperCase()}</strong><br>
      <span style="color:${FLOW_COLORS[hoveredFlow.protocol] || "#9fb3c8"}">${(hoveredFlow.protocol || "tcp").toUpperCase()}${hoveredFlow.port ? `:${hoveredFlow.port}` : ""}</span><br>
      <span class="muted">${fromLabel} → ${toLabel}</span><br>
      <span class="muted">Throughput medio: ${Number(hoveredFlow.avg_mbps || 0).toFixed(1)} Mb/s · volume ${Number(hoveredFlow.volume || 0)}</span>
    `;
    canvas.style.cursor = "pointer";
    return;
  }

  scene.hoveredId = getNearestResource(mouseX, mouseY);
  const resource = getResourceById(scene.hoveredId);
  if (!resource) {
    tooltip.hidden = true;
    canvas.style.cursor = "";
    return;
  }

  canvas.style.cursor = hasChildren(resource) ? "pointer" : "default";
  tooltip.hidden = false;
  tooltip.style.left = `${event.clientX + 14}px`;
  tooltip.style.top = `${event.clientY + 14}px`;
  tooltip.innerHTML = `
    <strong>${resource.label}</strong><br>
    ${resource.kind}<br>
    ${resource.details || ""}<br>
    <span class="muted">${resource.avg_mbps ? `${Number(resource.avg_mbps).toFixed(1)} Mb/s medi` : resource.port ? `porta ${resource.port}` : ""}</span>
  `;
}

function handleCanvasClick(event) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;
  const mouseX = (event.clientX - rect.left) * scaleX;
  const mouseY = (event.clientY - rect.top) * scaleY;

  const clickedFlow = getFlowAtPoint(mouseX, mouseY);
  if (clickedFlow) {
    filterState.isolatedFlow = filterState.isolatedFlow === clickedFlow ? null : clickedFlow;
    updateIsolatedFlowLabel();
    return;
  }

  if (filterState.isolatedFlow) {
    filterState.isolatedFlow = null;
    updateIsolatedFlowLabel();
    return;
  }

  const resourceId = getNearestResource(mouseX, mouseY);
  if (resourceId) {
    selectResource(resourceId, true);
  }
}

function animate() {
  scene.pulsePhase = (scene.pulsePhase + 0.008) % 1;
  drawScene();
  window.requestAnimationFrame(animate);
}

// ── Tracking ultima query SQL eseguita (per nome file CSV significativo) ──
// Estrae il primo nome di tabella dalla FROM clause per intitolare l'export.
function _lastQueryTableHint(query) {
  if (!query) return "query";
  const match = /\b(?:from|join)\s+([A-Za-z0-9_\[\]\.]+)/i.exec(query);
  if (!match) return "query";
  return match[1].replace(/[\[\]]/g, "").split(".").pop().toLowerCase();
}
let _lastSqlQueryHint = "query";

function renderSqlResults(result) {
  const thead = sqlResultsTable.querySelector("thead");
  const tbody = sqlResultsTable.querySelector("tbody");
  thead.innerHTML = `<tr>${result.columns.map((column) => `<th>${column}</th>`).join("")}</tr>`;
  tbody.innerHTML = result.rows.map((row) => `<tr>${row.map((cell) => `<td>${cell == null ? "" : String(cell)}</td>`).join("")}</tr>`).join("");
  sqlQueryMessage.textContent = result.truncated
    ? `Mostrate ${result.row_count} righe. Output troncato dal limite di sicurezza.`
    : `Query completata: ${result.row_count} righe.`;
  // Abilita export CSV solo se ci sono righe da esportare.
  const exportBtn = document.getElementById("exportSqlCsvButton");
  if (exportBtn) exportBtn.disabled = (result.row_count || 0) === 0;
}

async function runSqlQuery() {
  if (!isAdminUser()) {
    sqlQueryMessage.textContent = "Query SQL disponibile solo per admin.";
    return;
  }
  try {
    const query = sqlQueryInput.value.trim();
    _lastSqlQueryHint = _lastQueryTableHint(query);
    const result = await api.runAdminQuery(query);
    renderSqlResults(result);
  } catch (error) {
    sqlQueryMessage.textContent = error.message || String(error);
    notifyError(error);
  }
}

// ── Export CSV dei risultati ultima query SQL ─────────────────────────────
// Il file include header (colonne dal thead) e tutte le righe del tbody.
// Nome file: netvisor-sql-{table_hint}-{YYYYMMDDhhmm}.csv
document.getElementById("exportSqlCsvButton")?.addEventListener("click", () => {
  if (!sqlResultsTable) return;
  const tbody = sqlResultsTable.querySelector("tbody");
  if (!tbody || !tbody.children.length) {
    sqlQueryMessage.textContent = "Nessun risultato da esportare — esegui prima una query.";
    return;
  }
  try {
    const stamp = new Date().toISOString().slice(0, 16).replace(/[-T:]/g, "");
    exportTableToCSV(sqlResultsTable, `netvisor-sql-${_lastSqlQueryHint}-${stamp}.csv`);
  } catch (error) {
    notifyError(error);
  }
});

function registerSqlTemplates() {
  document.querySelectorAll(".query-template").forEach((button) => {
    button.addEventListener("click", () => {
      sqlQueryInput.value = button.dataset.query || "";
    });
  });
}

async function loadTopology() {
  try {
    if (!isAdminUser()) {
      document.getElementById("runSqlButton")?.closest(".panel")?.setAttribute("hidden", "hidden");
    }
    const params = new URLSearchParams({ hours: String(filterState.timeWindowHours) });
    const data = await api.getTopology(params.toString());
    scene.topology = {
      resources: data.resources || [],
      flows: NetworkFlows.fromTopologyPayload(data),
    };
    updateSceneData();
    renderLegend();
    renderStaticLegend();
    renderCards();
    renderDetail();
    updateIsolatedFlowLabel();
  } catch (error) {
    notifyError(error);
  }
}

function startTopologyPolling(intervalMs = 30000) {
  stopTopologyPolling();
  topologyPollTimer = setInterval(loadTopology, intervalMs);
}

function stopTopologyPolling() {
  if (topologyPollTimer) {
    clearInterval(topologyPollTimer);
    topologyPollTimer = null;
  }
}

document.getElementById("reloadTopologyButton")?.addEventListener("click", async () => {
  const button = document.getElementById("reloadTopologyButton");
  const icon = button?.querySelector(".reload-icon");
  if (button) {
    button.disabled = true;
    button.classList.add("loading");
  }
  if (icon) {
    icon.style.animation = "spin 0.7s linear infinite";
  }
  await loadTopology();
  if (button) {
    button.disabled = false;
    button.classList.remove("loading");
  }
  if (icon) {
    icon.style.animation = "";
  }
});

backButton?.addEventListener("click", stepBackDrill);
document.getElementById("runSqlButton")?.addEventListener("click", runSqlQuery);

canvas.addEventListener("mousedown", (event) => {
  scene.isDragging = true;
  scene.dragStartX = event.clientX;
  scene.dragStartY = event.clientY;
});

canvas.addEventListener("mousemove", handlePointerMove);
canvas.addEventListener("mouseleave", () => {
  scene.isDragging = false;
  scene.hoveredId = null;
  tooltip.hidden = true;
});
canvas.addEventListener("mouseup", () => {
  scene.isDragging = false;
});
window.addEventListener("mouseup", () => {
  scene.isDragging = false;
});
canvas.addEventListener("click", handleCanvasClick);
canvas.addEventListener("wheel", (event) => {
  event.preventDefault();
  scene.zoom = Math.max(0.65, Math.min(1.7, scene.zoom + (event.deltaY < 0 ? 0.08 : -0.08)));
});

document.getElementById("timeWindowSelect")?.addEventListener("change", (event) => {
  filterState.timeWindowHours = parseInt(event.target.value, 10) || 1;
  loadTopology();
});

document.getElementById("directionFilterSelect")?.addEventListener("change", (event) => {
  const value = (event.target.value || "both").toLowerCase();
  filterState.direction = value === "in" || value === "out" ? value : "both";
  updateIsolatedFlowLabel();
});

registerSqlTemplates();
window.addEventListener("netvisor:manual-refresh", loadTopology);
loadTopology();
startTopologyPolling(30000);
animate();
