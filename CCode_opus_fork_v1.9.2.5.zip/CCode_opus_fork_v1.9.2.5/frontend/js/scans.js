import { api, escapeHtml, exportRecordsToCSV, exportTableToCSV, formatDateTime, formatDateTimeShort, isAdminUser, notifyError, renderStatus } from "./api.js";

// ── Tracking dello scan attualmente mostrato nel Dettaglio Scan ───────────
// Usato dal bottone Export CSV per nominare il file in modo significativo
// (es. netvisor-scan-7359-202605091428.csv) e per attivare/disattivare il
// bottone in base alla presenza di dati esportabili.
let _currentScanDetail = null;

// ── KPI / Tabelle overview ────────────────────────────────────────────────────
function renderSummary(summary) {
  // Helper sicuro: alcuni KPI sono stati rimossi dalla UI (es. Evaded Est.)
  // perché non avevano dato reale dietro. setText evita TypeError quando
  // l'elemento non esiste più nel DOM.
  const setText = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  };
  setText("activeNodes", summary.active_nodes ?? 0);
  setText("inactiveNodes", summary.inactive_nodes ?? 0);
  setText("openServices", summary.open_services ?? 0);
  setText("blockedConnections", summary.blocked_estimated ?? 0);
  setText("suspiciousConnections", summary.suspicious_estimated ?? 0);
  setText("evadedConnections", summary.evaded_estimated ?? 0);  // legacy, no-op se rimosso
}

function renderProtocols(protocols) {
  const total = protocols.reduce((sum, item) => sum + item.count, 0) || 1;
  document.getElementById("connectionProtocolBars").innerHTML = protocols
    .map(
      (item, index) => `
        <div class="protocol-bar-row">
          <span>${escapeHtml(item.protocol)}</span>
          <div class="protocol-bar-track">
            <div class="protocol-bar-fill protocol-color-${index % 6}" style="width:${Math.max(8, (item.count / total) * 100)}%"></div>
          </div>
          <strong>${Number(item.count) || 0}</strong>
        </div>
      `
    )
    .join("");
}

function renderServices(services) {
  document.getElementById("servicesMatrixTable").innerHTML = services.length
    ? services.map((service) => `
        <tr>
          <td>${escapeHtml(service.hostname || "-")}</td>
          <td>${escapeHtml(service.ip)}</td>
          <td>${renderStatus(service.node_status)}</td>
          <td>${Number(service.port) || 0}</td>
          <td>${escapeHtml(service.protocol)}</td>
          <td>${escapeHtml(service.service_name || "-")}</td>
          <td>${escapeHtml([service.product, service.version].filter(Boolean).join(" ") || "-")}</td>
        </tr>
      `).join("")
    : `<tr><td colspan="7" class="muted" style="text-align:center;padding:.6rem">Nessun servizio rilevato. Esegui una scan nmap per popolare.</td></tr>`;
}

function renderTests(tests) {
  document.getElementById("recentTestsTable").innerHTML = tests.length
    ? tests.map((test) => `
        <tr>
          <td>${escapeHtml(test.target)}</td>
          <td>${escapeHtml(test.type)}</td>
          <td>${test.latency_ms == null ? "-" : `${Number(test.latency_ms)} ms`}</td>
          <td>${renderStatus(test.result)}</td>
          <td>${escapeHtml(formatDateTimeShort(test.checked_at))}</td>
        </tr>
      `).join("")
    : `<tr><td colspan="5" class="muted" style="text-align:center;padding:.6rem">Nessun test eseguito.</td></tr>`;
}

// ── Overview generale ─────────────────────────────────────────────────────────
async function loadConnectionsOverview() {
  try {
    const scanPanel = document.getElementById("scanForm")?.closest(".panel");
    if (scanPanel && !isAdminUser()) {
      scanPanel.hidden = true;
    }
    const overview = await api.getConnectionsOverview();
    renderSummary(overview.summary || {});
    renderProtocols(overview.protocols || []);
    renderServices(overview.services || []);
    renderTests(overview.tests || []);

    document.getElementById("scansTable").innerHTML = (overview.scans || []).length
      ? (overview.scans || []).map((scan) => `
          <tr class="clickable-row" data-scan-id="${Number(scan.id) || 0}">
            <td>#${Number(scan.id) || 0}</td>
            <td>${escapeHtml(scan.scanner)}</td>
            <td>${escapeHtml(scan.target)}</td>
            <td>${escapeHtml(scan.ports || "-")}</td>
            <td>${renderStatus(scan.status)}</td>
          </tr>
        `).join("")
      : `<tr><td colspan="5" class="muted" style="text-align:center;padding:.6rem">Nessuna scan eseguita.</td></tr>`;
  } catch (error) {
    notifyError(error);
  }
}

// Event delegation sul tbody (resiste ai re-render)
document.getElementById("scansTable")?.addEventListener("click", (event) => {
  const row = event.target.closest("tr[data-scan-id]");
  if (row) loadScanDetail(row.dataset.scanId);
});

// ── PARSER nmap XML / masscan JSON → struttura uniforme host/porte ────────────
function parseScanRaw(rawContent, format) {
  if (!rawContent) return { hosts: [], stats: null };

  if (format === "xml" || (rawContent.trim().startsWith("<") && rawContent.includes("nmaprun"))) {
    return parseNmapXml(rawContent);
  }
  if (format === "json" || rawContent.trim().startsWith("[") || rawContent.trim().startsWith("{")) {
    return parseMasscanJson(rawContent);
  }
  return { hosts: [], stats: null };
}

function parseNmapXml(xml) {
  try {
    const dom = new DOMParser().parseFromString(xml, "application/xml");
    if (dom.querySelector("parsererror")) return { hosts: [], stats: null };

    const hosts = [...dom.querySelectorAll("host")].map((host) => {
      const status = host.querySelector("status")?.getAttribute("state") || "unknown";
      const ipv4 = [...host.querySelectorAll('address[addrtype="ipv4"]')][0]?.getAttribute("addr") || "";
      const mac  = [...host.querySelectorAll('address[addrtype="mac"]')][0]?.getAttribute("addr") || "";
      const vendor = [...host.querySelectorAll('address[addrtype="mac"]')][0]?.getAttribute("vendor") || "";
      const hostname = host.querySelector("hostname")?.getAttribute("name") || "";
      const osmatch  = host.querySelector("osmatch")?.getAttribute("name") || "";

      const ports = [...host.querySelectorAll("ports > port")].map((port) => {
        const svc = port.querySelector("service");
        // NSE script results (mode=aggressive): <script id="..." output="...">
        // Estrarre CVE references via regex sul testo aggregato.
        const scriptNodes = [...port.querySelectorAll("script")];
        const scripts = scriptNodes.map((sn) => {
          const out = sn.getAttribute("output") || "";
          const idAttr = sn.getAttribute("id") || "";
          // CVE-YYYY-NNNNN+ — case insensitive, uniche, ordinate
          const cveSet = new Set();
          const cveRe = /CVE-\d{4}-\d{4,7}/gi;
          let m;
          while ((m = cveRe.exec(out + " " + idAttr)) !== null) cveSet.add(m[0].toUpperCase());
          return {
            id: idAttr,
            cves: [...cveSet].sort(),
            output: out.length > 240 ? out.slice(0, 240) + "…" : out,
          };
        });
        const portCves = [...new Set(scripts.flatMap((s) => s.cves))].sort();
        return {
          port: Number(port.getAttribute("portid")) || 0,
          protocol: port.getAttribute("protocol") || "tcp",
          state: port.querySelector("state")?.getAttribute("state") || "unknown",
          reason: port.querySelector("state")?.getAttribute("reason") || "",
          service: svc?.getAttribute("name") || "",
          product: svc?.getAttribute("product") || "",
          version: svc?.getAttribute("version") || "",
          extrainfo: svc?.getAttribute("extrainfo") || "",
          scripts,
          cves: portCves,
        };
      });
      return { hostname, ip: ipv4, mac, vendor, status, os: osmatch, ports };
    });

    const runstats = dom.querySelector("runstats > finished");
    const hostsStats = dom.querySelector("runstats > hosts");
    const root = dom.querySelector("nmaprun");
    const stats = {
      scanner: root?.getAttribute("scanner") || "nmap",
      version: root?.getAttribute("version") || "",
      args: root?.getAttribute("args") || "",
      startedAt: root?.getAttribute("startstr") || root?.getAttribute("start") || "",
      summary: runstats?.getAttribute("summary") || "",
      elapsed: runstats?.getAttribute("elapsed") || "",
      hostsUp: Number(hostsStats?.getAttribute("up") || 0),
      hostsDown: Number(hostsStats?.getAttribute("down") || 0),
      hostsTotal: Number(hostsStats?.getAttribute("total") || 0),
    };
    return { hosts, stats };
  } catch (_e) {
    return { hosts: [], stats: null };
  }
}

function parseMasscanJson(json) {
  try {
    let parsed = JSON.parse(json);
    if (!Array.isArray(parsed)) parsed = [parsed];

    // Aggrega per IP — masscan emette una entry per ogni porta
    const byIp = new Map();
    for (const entry of parsed) {
      const ip = entry.ip;
      if (!ip) continue;
      if (!byIp.has(ip)) byIp.set(ip, { ip, hostname: "", mac: "", vendor: "", status: "up", os: "", ports: [] });
      const slot = byIp.get(ip);
      for (const portInfo of entry.ports || []) {
        slot.ports.push({
          port: Number(portInfo.port) || 0,
          protocol: portInfo.proto || "tcp",
          state: portInfo.status || "open",
          reason: portInfo.reason || "",
          service: "",
          product: "",
          version: "",
          extrainfo: "",
        });
      }
    }

    const hosts = [...byIp.values()];
    const totalPorts = hosts.reduce((s, h) => s + h.ports.length, 0);
    const stats = {
      scanner: "masscan",
      summary: `Masscan: ${hosts.length} host, ${totalPorts} porte trovate aperte.`,
      hostsUp: hosts.length,
      hostsDown: 0,
      hostsTotal: hosts.length,
    };
    return { hosts, stats };
  } catch (_e) {
    return { hosts: [], stats: null };
  }
}

// ── Render del dettaglio scan (user-friendly) ────────────────────────────────
function renderScanSummaryBox(scan, parsed) {
  const box = document.getElementById("scanSummaryBox");
  if (!box) return;
  box.hidden = false;

  const hostsCount = parsed.hosts.length;
  const totalPorts = parsed.hosts.reduce((s, h) => s + h.ports.length, 0);
  const openPorts = parsed.hosts.reduce(
    (s, h) => s + h.ports.filter((p) => p.state === "open").length, 0,
  );

  const summaryText = parsed.stats?.summary
    || `${parsed.stats?.scanner || scan.scanner || "scan"} su ${scan.target}`;

  const statusClass = (scan.status || "").toLowerCase() === "completed" ? "feedback-ok"
    : (scan.status || "").toLowerCase() === "failed" ? "feedback-error" : "feedback-info";

  box.innerHTML = `
    <div class="scan-summary-grid">
      <div>
        <p class="eyebrow">Comando</p>
        <p class="scan-summary-cmd"><code>${escapeHtml(parsed.stats?.args || "(comando non disponibile)")}</code></p>
      </div>
      <div>
        <p class="eyebrow">Esito</p>
        <p><span class="${statusClass}">${escapeHtml((scan.status || "").toUpperCase())}</span></p>
      </div>
      <div>
        <p class="eyebrow">Inizio / Fine</p>
        <p class="muted">${escapeHtml(formatDateTime(scan.started_at))} → ${escapeHtml(formatDateTime(scan.finished_at))}</p>
      </div>
      <div>
        <p class="eyebrow">Durata scanner</p>
        <p>${parsed.stats?.elapsed ? `${parsed.stats.elapsed}s` : "-"}</p>
      </div>
    </div>

    <div class="scan-summary-stats">
      <span class="kpi-pill"><strong>${hostsCount}</strong> Host trovati</span>
      <span class="kpi-pill"><strong>${parsed.stats?.hostsUp ?? hostsCount}</strong> UP</span>
      <span class="kpi-pill"><strong>${parsed.stats?.hostsDown ?? 0}</strong> DOWN</span>
      <span class="kpi-pill kpi-pill-strong"><strong>${openPorts}</strong> Porte aperte</span>
      <span class="kpi-pill"><strong>${totalPorts}</strong> Porte scansionate</span>
    </div>

    <p class="scan-summary-text">${escapeHtml(summaryText)}</p>
    ${scan.error_message ? `<p class="feedback-error" style="display:block;margin-top:.5rem">Errore: ${escapeHtml(scan.error_message)}</p>` : ""}
  `;
}

function renderScanHostsTable(parsed) {
  const block = document.getElementById("scanHostsBlock");
  const tbody = document.getElementById("scanHostsTable");
  if (!block || !tbody) return;

  // Espandi ogni host in una riga per ogni porta — chiarezza > compattezza
  const rows = [];
  for (const host of parsed.hosts) {
    if (!host.ports.length) {
      rows.push(`
        <tr>
          <td>${escapeHtml(host.hostname || "-")}</td>
          <td>${escapeHtml(host.ip)}</td>
          <td>${renderStatus(host.status)}</td>
          <td colspan="6" class="muted">Nessuna porta scansionata aperta</td>
        </tr>
      `);
      continue;
    }
    for (const port of host.ports) {
      const productVer = [port.product, port.version, port.extrainfo].filter(Boolean).join(" ");
      // CVE/script summary: badge col conteggio + tooltip dettaglio
      let cveCell = `<span class="muted">-</span>`;
      const cveList = port.cves || [];
      const scriptCount = (port.scripts || []).length;
      if (cveList.length) {
        const cveTitle = cveList.join(", ");
        cveCell = `<span class="kpi-pill kpi-pill-strong" style="background:#7f1d1d;color:#fee2e2" title="${escapeHtml(cveTitle)}">${cveList.length} CVE</span>`;
      } else if (scriptCount) {
        const scriptIds = (port.scripts || []).map((s) => s.id).filter(Boolean).join(", ");
        cveCell = `<span class="kpi-pill" title="${escapeHtml(scriptIds)}">${scriptCount} script</span>`;
      }
      rows.push(`
        <tr>
          <td>${escapeHtml(host.hostname || "-")}</td>
          <td>${escapeHtml(host.ip)}</td>
          <td>${renderStatus(host.status)}</td>
          <td><strong>${port.port}</strong></td>
          <td>${escapeHtml(port.protocol)}</td>
          <td>${renderStatus(port.state)}</td>
          <td>${escapeHtml(port.service || "-")}</td>
          <td>${escapeHtml(productVer || "-")}</td>
          <td>${cveCell}</td>
        </tr>
      `);
    }
  }

  if (!rows.length) {
    block.hidden = true;
    return;
  }
  block.hidden = false;
  tbody.innerHTML = rows.join("");
}

function renderScanEventsTable(events) {
  const block = document.getElementById("scanEventsBlock");
  const tbody = document.getElementById("scanEventsTable");
  if (!block || !tbody) return;

  const list = Array.isArray(events) ? events : [];
  if (!list.length) {
    block.hidden = true;
    return;
  }
  block.hidden = false;
  tbody.innerHTML = list.map((ev) => `
    <tr>
      <td>${escapeHtml(ev.event_type || ev.type || "-")}</td>
      <td>${renderStatus(ev.severity || "info")}</td>
      <td>${escapeHtml(ev.message || ev.description || "-")}</td>
      <td>${escapeHtml(formatDateTimeShort(ev.event_time || ev.created_at || ev.timestamp))}</td>
    </tr>
  `).join("");
}

async function loadScanDetail(scanId) {
  try {
    const [scan, raw, events] = await Promise.all([
      api.getScan(scanId), api.getScanRaw(scanId), api.getScanEvents(scanId),
    ]);

    document.getElementById("scanDetailTitle").textContent =
      `Scan #${scan.id} — ${scan.scanner} → ${scan.target}`;
    document.getElementById("scanDetailSubtitle").textContent =
      `Porte richieste: ${scan.ports || "(default)"} · Avviata ${formatDateTime(scan.started_at)}`;

    const statusEl = document.getElementById("scanDetailStatus");
    const status = (scan.status || "").toLowerCase();
    statusEl.textContent = (scan.status || "?").toUpperCase();
    statusEl.className = `badge ${status === "completed" ? "badge-success" : status === "failed" ? "badge-critical" : ""}`;

    // Parse del raw output in struttura uniforme
    const rawEntry = (raw || [])[0];
    const parsed = parseScanRaw(rawEntry?.content || "", rawEntry?.format || "");

    // ── Salva contesto per Export CSV ───────────────────────────────────
    // Il bottone usa _currentScanDetail per nominare il file e disabilitarsi
    // quando non ci sono host/porte da esportare.
    _currentScanDetail = { scan, parsed };
    const exportBtn = document.getElementById("exportScanCsvButton");
    if (exportBtn) {
      const hasData = (parsed.hosts || []).some((h) => (h.ports || []).length > 0);
      exportBtn.disabled = !hasData;
    }

    renderScanSummaryBox(scan, parsed);
    renderScanHostsTable(parsed);
    renderScanEventsTable(events);

    // Raw output collassato — accessibile ma non invasivo
    const rawDetails = document.getElementById("scanRawDetails");
    const rawPre = document.getElementById("scanRawOutput");
    if (rawEntry?.content) {
      rawDetails.hidden = false;
      rawPre.textContent = rawEntry.content;
    } else {
      rawDetails.hidden = true;
      rawPre.textContent = "";
    }

    // Scroll al pannello detail
    document.getElementById("scanDetailPanel")?.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    notifyError(error);
  }
}

// ── Form Manual Scan ──────────────────────────────────────────────────────────
document.getElementById("scanForm")?.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!isAdminUser()) {
    notifyError(new Error("Operazione disponibile solo per admin."));
    return;
  }
  const feedback = document.getElementById("scanFeedback");
  feedback.textContent = "Scansione in esecuzione…";
  feedback.className = "feedback-info";
  try {
    const payload = Object.fromEntries(new FormData(event.currentTarget).entries());
    const result = await api.createScan(payload);
    feedback.textContent = `Scansione #${result.scan_id} completata.`;
    feedback.className = "feedback-ok";
    await loadConnectionsOverview();
    await loadScanDetail(result.scan_id);
  } catch (error) {
    feedback.textContent = `Errore scan: ${error?.message || error}`;
    feedback.className = "feedback-error";
    notifyError(error);
  }
});

document.getElementById("reloadScansButton")?.addEventListener("click", loadConnectionsOverview);
window.addEventListener("netvisor:manual-refresh", loadConnectionsOverview);

// ── Preset porte: scrivono nell'input scanPortsInput ──────────────────────
document.querySelectorAll(".port-preset").forEach((btn) => {
  btn.addEventListener("click", (e) => {
    e.preventDefault();
    const ports = btn.getAttribute("data-ports") || "";
    const input = document.getElementById("scanPortsInput");
    if (input && ports) {
      input.value = ports;
      input.focus();
    }
  });
});

// ── Export CSV Dettaglio Scan ─────────────────────────────────────────────
// Esporta i dati STRUTTURATI parsed dall'XML/JSON dello scanner — NON il
// raw text dell'XML (sarebbe inutile in un CSV). Genera una riga per
// coppia host:porta con tutte le colonne della tabella visibile +
// colonne extra utili per analisi spreadsheet (CVE count, banner, scan_id).
document.getElementById("exportScanCsvButton")?.addEventListener("click", () => {
  if (!_currentScanDetail || !_currentScanDetail.parsed) {
    return;
  }
  const { scan, parsed } = _currentScanDetail;
  const records = [];
  for (const host of parsed.hosts || []) {
    if (!host.ports || !host.ports.length) {
      records.push({
        scan_id: scan.id,
        scanner: scan.scanner,
        target: scan.target,
        host_hostname: host.hostname || "",
        host_ip: host.ip || "",
        host_status: host.status || "",
        host_os: host.os || "",
        port: "",
        protocol: "",
        port_state: "",
        port_reason: "",
        service_name: "",
        product: "",
        version: "",
        extrainfo: "",
        scripts_count: 0,
        cves_count: 0,
        cves: "",
      });
      continue;
    }
    for (const port of host.ports) {
      records.push({
        scan_id: scan.id,
        scanner: scan.scanner,
        target: scan.target,
        host_hostname: host.hostname || "",
        host_ip: host.ip || "",
        host_status: host.status || "",
        host_os: host.os || "",
        port: port.port,
        protocol: port.protocol || "",
        port_state: port.state || "",
        port_reason: port.reason || "",
        service_name: port.service || "",
        product: port.product || "",
        version: port.version || "",
        extrainfo: port.extrainfo || "",
        scripts_count: (port.scripts || []).length,
        cves_count: (port.cves || []).length,
        cves: (port.cves || []).join(";"),
      });
    }
  }
  if (!records.length) {
    notifyError(new Error("Nessun dato da esportare per questa scan."));
    return;
  }
  try {
    const stamp = new Date().toISOString().slice(0, 16).replace(/[-T:]/g, "");
    exportRecordsToCSV(records, `netvisor-scan-${scan.id}-${stamp}.csv`);
  } catch (error) {
    notifyError(error);
  }
});

loadConnectionsOverview();
