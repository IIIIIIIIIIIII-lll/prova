// Banner di stato applicativo — versione semplificata LIVE-only.
// NetVisor non ha più una modalità DEMO/sintetica: tutti i dati sono reali.
// Questo modulo monta solo un piccolo CHIP "LIVE vX.Y.Z" nella topbar che
// permette agli operatori di:
//   1. Confermare a colpo d'occhio la modalità live (non c'è più ambiguità)
//   2. Verificare la versione del backend in produzione
// Esposto:
//   - mountVersionChip(): monta il chip nella topbar (idempotente)
//   - applyModeMeta(meta): no-op di compatibilità (il _meta API non ha più
//     informazioni utili al banner — manteniamo lo stub per non rompere
//     gli import di shell.js durante la transizione).

import { api } from "./api.js";

const STATE = { version: null, mounted: null };

function ensureStyles() {
  if (document.getElementById("nv-mode-chip-styles")) return;
  const css = `
    .nv-mode-chip{display:inline-flex;align-items:center;gap:.55rem;
      padding:.25rem .75rem;border-radius:999px;font-size:.7rem;
      font-weight:700;letter-spacing:.05em;text-transform:uppercase;
      border:1px solid #10b98155;background:#10b98122;color:#10b981;
      line-height:1;white-space:nowrap}
    .nv-mode-chip .nv-dot{width:.45rem;height:.45rem;border-radius:50%;
      background:#10b981;box-shadow:0 0 0 0 rgba(16,185,129,.5);
      animation:nv-chip-pulse 2s ease-out infinite}
    .nv-mode-chip .nv-live-label{font-weight:700;letter-spacing:.06em}
    .nv-mode-chip .nv-version-pill{font-weight:500;letter-spacing:.04em;
      color:#86efac;opacity:.9;padding:.05rem .35rem;border-radius:6px;
      background:rgba(16,185,129,.12);text-transform:lowercase;
      font-size:.65rem}
    @keyframes nv-chip-pulse{
      0%{box-shadow:0 0 0 0 rgba(16,185,129,.5)}
      70%{box-shadow:0 0 0 4px rgba(16,185,129,0)}
      100%{box-shadow:0 0 0 0 rgba(16,185,129,0)}
    }
  `;
  const style = document.createElement("style");
  style.id = "nv-mode-chip-styles";
  style.textContent = css;
  document.head.appendChild(style);
}



function mountChipInTopbar() {
  const slot = document.querySelector(".topbar-actions");
  if (!slot) return;
  const existing = document.getElementById("nvModeChip");
  const chip = buildChip(STATE.version);
  if (existing) {
    existing.replaceWith(chip);
  } else {
    slot.insertBefore(chip, slot.firstChild);
  }
  STATE.mounted = chip;
}

export async function mountModeBanner() {
  ensureStyles();
  try {
    const info = await api.getSystemInfo();
    STATE.version = info?.version || null;
  } catch (_e) {
    STATE.version = null;
  }
  mountChipInTopbar();
}

// Stub di compatibilità — alcune chiamate legacy in shell.js dispatch-ano
// l'evento "netvisor:mode-meta" con il _meta delle API. NetVisor LIVE-only
// non usa più quell'informazione, ma teniamo lo stub no-op per evitare
// errori di import.
export function applyModeMeta(_meta) {
  // no-op: il chip LIVE è statico una volta montato.
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    mountModeBanner().catch(() => {});
  }, { once: true });
} else {
  mountModeBanner().catch(() => {});
}

// Re-mount automatico quando shell.js ricostruisce la topbar dopo nav.
const observer = new MutationObserver(() => {
  if (!document.getElementById("nvModeChip") && document.querySelector(".topbar-actions")) {
    mountChipInTopbar();
  }
});
observer.observe(document.body, { childList: true, subtree: true });
