import { api, escapeHtml, exportTableToCSV, notifyError, renderSeverityBadge } from "./api.js";

function renderFailureBars(rows) {
  const total = rows.reduce((sum, item) => sum + item.failed_count, 0) || 1;
  document.getElementById("topFailureBars").innerHTML = rows
    .map(
      (item, index) => `
        <div class="protocol-bar-row">
          <span>${escapeHtml(item.username)}</span>
          <div class="protocol-bar-track">
            <div class="protocol-bar-fill protocol-color-${index % 6}" style="width:${Math.max(8, (item.failed_count / total) * 100)}%"></div>
          </div>
          <strong>${Number(item.failed_count) || 0}</strong>
        </div>
      `
    )
    .join("");
}

function renderPeakHours(rows) {
  const maxValue = Math.max(1, ...rows.map((item) => item.count));
  const peak = rows.reduce((best, item) => (item.count > (best.count || 0) ? item : best), {});
  document.getElementById("peakHourKpi").textContent = peak.hour || "-";
  document.getElementById("peakHoursChart").innerHTML = rows
    .map(
      (item) => `
        <div class="trend-day">
          <div class="trend-bars-stack">
            <span class="trend-bar trend-bar-events" style="height:${Math.max(8, (item.count / maxValue) * 120)}px"></span>
          </div>
          <small>${escapeHtml(item.hour)}</small>
        </div>
      `
    )
    .join("");
}

function renderAnomalies(rows) {
  document.getElementById("loginAnomaliesFeed").innerHTML = rows
    .map(
      (item) => `
        <article class="feed-item">
          <div class="feed-item-top">
            <strong>${escapeHtml(item.username)}</strong>
            ${renderSeverityBadge(item.severity)}
          </div>
          <p>Tipi: ${escapeHtml((item.types || []).join(", ") || "-")}</p>
          <small>failed: ${Number(item.failed_count) || 0} - source IP: ${Number(item.source_ips) || 0} - source MAC: ${Number(item.source_macs) || 0} - risk: ${Number(item.risk_score) || 0}</small>
        </article>
      `
    )
    .join("");
}

function renderAudit(rows) {
  document.getElementById("auditActivityFeed").innerHTML = rows
    .map(
      (item) => `
        <article class="feed-item feed-item-compact">
          <div class="feed-item-top">
            <strong>${escapeHtml(item.action)}</strong>
            <span class="badge micro-badge">${escapeHtml(item.actor || "system")}</span>
          </div>
          <p>${escapeHtml(item.details || "-")}</p>
          <small>${escapeHtml(item.created_at)}</small>
        </article>
      `
    )
    .join("");
}

function renderLoginActivity(rows) {
  document.getElementById("loginActivityTable").innerHTML = rows
    .map(
      (item) => `
        <tr>
          <td>${escapeHtml(item.username)}</td>
          <td>${escapeHtml(item.account_type || "-")}</td>
          <td>${escapeHtml(item.hostname || item.ip)}</td>
          <td>${escapeHtml(item.source || "-")}</td>
          <td>${escapeHtml(item.source_ip || "-")}</td>
          <td>${escapeHtml(item.source_mac || "-")}</td>
          <td>${escapeHtml(item.auth_channel || "-")}</td>
          <td>${escapeHtml(item.result)}</td>
          <td>${Number(item.risk_score) || 0}</td>
          <td>${escapeHtml(item.timestamp)}</td>
        </tr>
      `
    )
    .join("");
}

async function loadSecuritySummary() {
  try {
    const data = await api.getSecurityLoginSummary();
    const summary = data.summary || {};
    document.getElementById("totalLogins").textContent = summary.total_logins ?? 0;
    document.getElementById("successLogins").textContent = summary.success_logins ?? 0;
    document.getElementById("failedLogins").textContent = summary.failed_logins ?? 0;
    document.getElementById("adminEvents").textContent = summary.admin_events ?? 0;
    document.getElementById("suspiciousAccounts").textContent = summary.suspicious_accounts ?? 0;
    document.getElementById("multiOriginAccounts").textContent = summary.multi_origin_accounts ?? 0;
    document.getElementById("uniqueUsersKpi").textContent = summary.unique_users ?? 0;

    renderFailureBars(data.top_failures || []);
    renderPeakHours(data.peak_hours || []);
    renderAnomalies(data.anomalies || []);
    renderAudit(data.audit_activity || []);
    renderLoginActivity(data.recent_activity || []);
  } catch (error) {
    notifyError(error);
  }
}

window.addEventListener("netvisor:manual-refresh", loadSecuritySummary);
loadSecuritySummary();
window.setInterval(loadSecuritySummary, 8000);

// ── Export CSV Recent Login Activity ──────────────────────────────────────
// Esporta tutte le righe attualmente visibili (la Global Search del topbar
// nasconde righe non matching via style.display=none → escluse dall'export
// che diventa quindi "esporta quello che vedi").
document.getElementById("exportLoginActivityCsvButton")?.addEventListener("click", () => {
  const table = document.getElementById("loginActivityTableEl");
  if (!table) return;
  try {
    const stamp = new Date().toISOString().slice(0, 16).replace(/[-T:]/g, "");
    exportTableToCSV(table, `netvisor-login-activity-${stamp}.csv`);
  } catch (error) {
    notifyError(error);
  }
});
