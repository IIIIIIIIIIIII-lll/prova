import { api, ensureAuthenticated, notifyError, renderStatus } from "./api.js";

let selectedCheckId = null;

function parseBoolean(value) {
  return String(value).toLowerCase() === "true";
}

function renderResults(results) {
  document.getElementById("healthCheckResultsTable").innerHTML = results
    .map(
      (item) => `
        <tr>
          <td>#${item.id}</td>
          <td>${renderStatus(item.result)}</td>
          <td>${item.latency_ms == null ? "-" : `${item.latency_ms} ms`}</td>
          <td>${item.checked_at}</td>
          <td>${item.error_message || "-"}</td>
        </tr>
      `
    )
    .join("");
}

async function loadResults(checkId) {
  selectedCheckId = checkId;
  document.getElementById("healthCheckResultsTitle").textContent = `Check #${checkId}`;
  try {
    renderResults(await api.getHealthCheckResults(checkId));
  } catch (error) {
    notifyError(error);
  }
}

async function loadHealthChecks() {
  try {
    const checks = await api.getHealthChecks();
    const totalChecks = checks.length;
    const upChecks = checks.filter((check) => check.last_status === "success").length;
    const downChecks = checks.filter((check) => check.last_status === "failed").length;
    const latencies = checks.map((check) => Number(check.last_latency_ms)).filter((value) => Number.isFinite(value));
    const avgLatency = latencies.length
      ? `${Math.round(latencies.reduce((sum, value) => sum + value, 0) / latencies.length)} ms`
      : "-";
    document.getElementById("checksTotalKpi").textContent = totalChecks;
    document.getElementById("checksUpKpi").textContent = upChecks;
    document.getElementById("checksDownKpi").textContent = downChecks;
    document.getElementById("checksLatencyKpi").textContent = avgLatency;

    const byType = Object.entries(
      checks.reduce((acc, check) => {
        acc[check.check_type] = (acc[check.check_type] || 0) + 1;
        return acc;
      }, {})
    ).map(([label, count]) => ({ label: label.toUpperCase(), count }));
    const maxCount = Math.max(1, ...byType.map((item) => item.count));
    document.getElementById("checksProtocolBars").innerHTML = byType
      .map(
        (item, index) => `
          <div class="protocol-bar-row">
            <span>${item.label}</span>
            <div class="protocol-bar-track">
              <div class="protocol-bar-fill protocol-color-${index % 6}" style="width:${Math.max(8, (item.count / maxCount) * 100)}%"></div>
            </div>
            <strong>${item.count}</strong>
          </div>
        `
      )
      .join("");

    document.getElementById("healthChecksTable").innerHTML = checks
      .map(
        (check) => `
          <tr data-check-id="${check.id}">
            <td>#${check.id}</td>
            <td>${check.name}</td>
            <td>${check.target}</td>
            <td>${check.check_type}</td>
            <td>${check.port || "-"}</td>
            <td>${renderStatus(check.last_status || "unknown")}</td>
            <td>${check.last_latency_ms == null ? "-" : `${check.last_latency_ms} ms`}</td>
            <td>
              <div class="table-actions">
                <button class="ghost-button" type="button" data-action="run" data-check-id="${check.id}">Run now</button>
                <button class="ghost-button" type="button" data-action="toggle" data-check-id="${check.id}" data-enabled="${check.enabled}">
                  ${check.enabled ? "Disable" : "Enable"}
                </button>
                <button class="ghost-button" type="button" data-action="delete" data-check-id="${check.id}">Delete</button>
              </div>
            </td>
          </tr>
        `
      )
      .join("");

    document.querySelectorAll("[data-action]").forEach((button) => {
      button.addEventListener("click", async (event) => {
        event.stopPropagation();
        const { action, checkId, enabled } = button.dataset;
        try {
          if (action === "run") {
            await api.runHealthCheck(checkId);
          } else if (action === "toggle") {
            await api.updateHealthCheck(checkId, { enabled: !parseBoolean(enabled) });
          } else if (action === "delete") {
            await api.deleteHealthCheck(checkId);
          }
          await loadHealthChecks();
          if (selectedCheckId === checkId) {
            await loadResults(checkId);
          }
        } catch (error) {
          notifyError(error);
        }
      });
    });

    document.querySelectorAll("[data-check-id]").forEach((row) => {
      row.addEventListener("click", () => loadResults(row.dataset.checkId));
    });

    if (selectedCheckId) {
      const exists = checks.some((check) => String(check.id) === String(selectedCheckId));
      if (exists) {
        await loadResults(selectedCheckId);
      }
    }
  } catch (error) {
    notifyError(error);
  }
}

async function init() {
  const guard = await ensureAuthenticated({ adminOnly: true });
  if (!guard.authenticated || !guard.authorized || document.body.dataset.forbidden === "true") {
    return;
  }

  document.getElementById("healthCheckForm")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const feedback = document.getElementById("healthCheckFeedback");
    feedback.textContent = "Creazione controllo...";
    try {
      const payload = Object.fromEntries(new FormData(event.currentTarget).entries());
      payload.enabled = parseBoolean(payload.enabled);
      payload.permanent = parseBoolean(payload.permanent ?? true);
      if (!payload.port) {
        payload.port = null;
      }
      const created = await api.createHealthCheck(payload);
      feedback.textContent = `Check #${created.id} creato.`;
      event.currentTarget.reset();
      await loadHealthChecks();
    } catch (error) {
      feedback.textContent = "Errore creazione controllo.";
      notifyError(error);
    }
  });

  document.getElementById("reloadHealthChecksButton")?.addEventListener("click", loadHealthChecks);
  window.addEventListener("netvisor:manual-refresh", loadHealthChecks);
  loadHealthChecks();
  window.setInterval(loadHealthChecks, 10000);
}

init().catch(notifyError);
