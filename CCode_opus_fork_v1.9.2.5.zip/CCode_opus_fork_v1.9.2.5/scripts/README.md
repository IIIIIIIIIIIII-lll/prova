# NetVisor — Scripts utility

A partire dalla v1.0.0 NetVisor è **LIVE-only**: nessuna funzionalità DEMO,
nessun toggle DEMO/LIVE, nessun seed sintetico.

Gli script `switch-mode.sh` / `switch-mode.ps1` sono stati rimossi insieme a
tutta l'infrastruttura demo. Vedi `CHANGELOG.md` (root del repo) per la
release `1.0.0` e le breaking-change associate.

## Versioning

La versione applicativa risiede nel file `VERSION` (root, backend/, frontend/).
I tre file sono tenuti in sync (1.0.0 ovunque). Per rilasciare una nuova
versione:

```bash
# Esempio per bump 1.0.0 → 1.0.1 (PATCH)
echo "1.0.1" > VERSION
echo "1.0.1" > backend/VERSION
echo "1.0.1" > frontend/VERSION
# Aggiornare CHANGELOG.md con la sezione [1.0.1]
git add VERSION backend/VERSION frontend/VERSION CHANGELOG.md
git commit -m "chore(release): v1.0.1 - <breve descrizione>"
git tag v1.0.1
```

Il backend espone la versione via `GET /api/system/info`:
```json
{ "service": "NetVisor API", "version": "1.0.1", "mode": "live", "data_policy": "real-only" }
```

Il frontend la mostra come chip "LIVE v1.0.1" nella topbar.

## Operazioni di manutenzione DB

Per resettare totalmente il DB (es. test, ambiente sporco):

```powershell
docker compose down
docker volume rm ccode_opus_fork_v1_sqlserver_data_lab
docker compose up -d
```

Per eliminare solo le scansioni vecchie senza toccare utenti/sessioni:

```sql
-- Da SQL Query Console (Topology page) o sqlcmd
DELETE FROM dbo.HealthCheckResults;
DELETE FROM dbo.HealthChecks;
DELETE FROM dbo.ScanJobRuns;
DELETE FROM dbo.ScanJobs;
DELETE FROM dbo.RawLogs;
DELETE FROM dbo.Scans;
DELETE FROM dbo.Tests;
DELETE FROM dbo.Services;
DELETE FROM dbo.Alerts;
DELETE FROM dbo.SecurityEvents;
DELETE FROM dbo.Logins;
DELETE FROM dbo.Nodes;
-- NON tocca: Users, AuthSessions, AuthAuditLog, AuditLog, Agents
```
