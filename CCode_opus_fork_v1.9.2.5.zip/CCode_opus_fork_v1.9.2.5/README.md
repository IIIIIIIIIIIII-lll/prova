# NetVisor Mini-SIEM / NOSD

[![version](https://img.shields.io/badge/version-1.0.0-blue.svg)](./CHANGELOG.md)
[![mode](https://img.shields.io/badge/mode-LIVE--only-green.svg)](#live-only)

NetVisor e un project work didattico per laboratorio autorizzato che combina dashboard web Vanilla JS, backend Flask, SQL Server, worker schedulati, agent telemetry e scheletro mobile .NET MAUI.

A partire dalla **v1.0.0** NetVisor è **LIVE-only**: nessuna funzionalità demo, nessun dato sintetico — il DB nasce vuoto e si popola solo con dati reali da scansioni autorizzate e telemetria agent. Vedi [CHANGELOG.md](./CHANGELOG.md) per le breaking change.

## Stack

- Frontend: HTML, CSS, JavaScript Vanilla
- Backend: Python, Flask, pyodbc
- Database: Microsoft SQL Server
- Mobile: C# + .NET MAUI
- DevOps: Docker Compose
- Monitoring difensivo: Nmap, Masscan, ping, HTTP/HTTPS check, agent heartbeat e metriche

## Auth seconda iterazione

- utenti reali `admin` e `user`
- login web e mobile via `POST /api/auth/login`
- access token breve + refresh token opaco ruotato
- password hash Argon2id come default, bcrypt solo fallback
- audit login in `AuthAuditLog`
- alert applicativo immediato su login admin riuscito
- RBAC lato backend: lettura `admin`/`user`, operazioni mutative solo `admin`

## Prerequisiti

- Docker Desktop con Docker Compose
- almeno 4 GB RAM liberi consigliati
- workload MAUI installato solo se vuoi aprire il progetto mobile
- ambiente di laboratorio autorizzato se abiliti scansioni reali

## Variabili importanti

Nel file [.env.example](/C:/Users/Dr3w.DESKTOP-SLP4ALB/Documents/New%20project/NetVisor/.env.example) trovi i valori demo di sviluppo. Le principali:

- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`
- `AUTH_PEPPER`
- `JWT_SECRET_KEY`
- `ACCESS_TOKEN_MINUTES`
- `REFRESH_TOKEN_DAYS`
- `REQUIRE_AUTH`
- `LOGIN_RATE_LIMIT_PER_MINUTE`
- `ACCOUNT_LOCK_MINUTES`
- `SCAN_ALLOWED_CIDRS`
- `ALLOW_PUBLIC_SCAN`
- `MASSCAN_MAX_RATE`
- `MIN_JOB_INTERVAL_SECONDS`

In produzione vanno sostituite con segreti lunghi e casuali.

## Avvio rapido

1. Copia `.env.example` in `.env`.
2. Imposta una password forte per `MSSQL_SA_PASSWORD`.
3. Imposta `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `AUTH_PEPPER` e `JWT_SECRET_KEY`.
4. Avvia:

```bash
docker compose up -d --build
```

5. Verifica:
   - frontend: [http://localhost:8080/login.html](http://localhost:8080/login.html)
   - backend health: [http://localhost:5000/api/health](http://localhost:5000/api/health)
   - versione + service info: [http://localhost:5000/api/system/info](http://localhost:5000/api/system/info)
   - SQL Server: `localhost:1433` solo come porta TCP

## LIVE-only

NetVisor è **esclusivamente LIVE**: nessuna modalità demo, nessun seed sintetico.
Il DB nasce vuoto al primo avvio e si popola solo con dati reali via:
- scansioni nmap/masscan eseguite **realmente** sui CIDR autorizzati
- telemetria agent (heartbeat, metrics, services, events)
- audit/auth log generati dall'uso reale dell'applicazione

Il banner UI mostra in topbar una chip verde **LIVE v1.0.0** con la versione applicativa.

### Versioning

La versione è in `VERSION` (root + backend/ + frontend/). Vedi [CHANGELOG.md](./CHANGELOG.md) per il log delle release.

## Bootstrap admin

Se la tabella `Users` e vuota, al primo avvio backend:

- crea l'utente iniziale da `ADMIN_USERNAME` e `ADMIN_PASSWORD`
- salva solo `password_hash`
- imposta `must_change_password=true`
- scrive audit in `AuthAuditLog`

Se esiste gia almeno un utente, il bootstrap non ricrea o sovrascrive l'admin.

## Flusso login web

1. Apri [http://localhost:8080/login.html](http://localhost:8080/login.html)
2. Inserisci username e password
3. Il frontend salva access token e refresh token in `sessionStorage`
4. Se il login e admin:
   - viene scritto `admin_login` in `AuthAuditLog`
   - viene creato un alert applicativo
   - compare un popup immediato in UI

Nota: su web il refresh token non usa cookie HttpOnly in questa demo, ma `sessionStorage`. In produzione e preferibile reverse proxy HTTPS + cookie HttpOnly o pattern BFF.

## Ruoli

- `admin`: utenti, console operativa, scan jobs, health checks, ACK/Close alert, query admin
- `user`: sola lettura su dashboard, topology, agents, alerts, logs, reports

## Pagine principali

- [index.html](http://localhost:8080/index.html): dashboard SIEM/NOC
- [topology.html](http://localhost:8080/topology.html): topologia cloud/container
- [admin-console.html](http://localhost:8080/admin-console.html): console operativa admin
- [agents.html](http://localhost:8080/agents.html): agent monitoring
- [alerts.html](http://localhost:8080/alerts.html): coda alert
- [users.html](http://localhost:8080/users.html): gestione utenti admin-only
- [settings.html](http://localhost:8080/settings.html): profilo e cambio password

## Mobile MAUI

Il progetto mobile include:

- `LoginPage`
- `AuthService`
- token in `SecureStorage`
- Bearer token su API
- supporto refresh sessione
- logout

Dettagli in [docs/MANUAL.md](/C:/Users/Dr3w.DESKTOP-SLP4ALB/Documents/New%20project/NetVisor/docs/MANUAL.md).

## Documentazione

- [docs/API.md](/C:/Users/Dr3w.DESKTOP-SLP4ALB/Documents/New%20project/NetVisor/docs/API.md)
- [docs/SECURITY.md](/C:/Users/Dr3w.DESKTOP-SLP4ALB/Documents/New%20project/NetVisor/docs/SECURITY.md)
- [docs/MANUAL.md](/C:/Users/Dr3w.DESKTOP-SLP4ALB/Documents/New%20project/NetVisor/docs/MANUAL.md)
- [docs/ARCHITECTURE.md](/C:/Users/Dr3w.DESKTOP-SLP4ALB/Documents/New%20project/NetVisor/docs/ARCHITECTURE.md)

## Troubleshooting rapido

- se `login.html` ritorna errore 401, verifica credenziali e bootstrap admin
- se il backend non parte, verifica `JWT_SECRET_KEY` e connessione SQL Server
- se il worker non esegue job, controlla `enabled`, `permanent`, `next_run_at` e `MIN_JOB_INTERVAL_SECONDS`
- se il mobile non raggiunge il backend, usa `10.0.2.2` su emulatore Android
- `http://localhost:1433/index.html` non puo funzionare: `1433` e la porta TCP di SQL Server, non un server web
